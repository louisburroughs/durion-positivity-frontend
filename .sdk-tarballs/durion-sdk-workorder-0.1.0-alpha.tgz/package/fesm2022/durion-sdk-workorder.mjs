import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://localhost:8086';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ApprovalConfigurationAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createConfiguration(approvalConfigurationRequest, observe = 'body', reportProgress = false, options) {
        if (approvalConfigurationRequest === null || approvalConfigurationRequest === undefined) {
            throw new Error('Required parameter approvalConfigurationRequest was null or undefined when calling createConfiguration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/approvalConfigurations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approvalConfigurationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteConfiguration(approvalId, observe = 'body', reportProgress = false, options) {
        if (approvalId === null || approvalId === undefined) {
            throw new Error('Required parameter approvalId was null or undefined when calling deleteConfiguration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/approvalConfigurations/${this.configuration.encodeParam({ name: "approvalId", value: approvalId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAllConfigurations(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getApplicableConfiguration(locationId, customerId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/approvalConfigurations/applicable`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getConfigurationById(approvalId, observe = 'body', reportProgress = false, options) {
        if (approvalId === null || approvalId === undefined) {
            throw new Error('Required parameter approvalId was null or undefined when calling getConfigurationById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/approvalConfigurations/${this.configuration.encodeParam({ name: "approvalId", value: approvalId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateConfiguration(approvalId, approvalConfigurationRequest, observe = 'body', reportProgress = false, options) {
        if (approvalId === null || approvalId === undefined) {
            throw new Error('Required parameter approvalId was null or undefined when calling updateConfiguration.');
        }
        if (approvalConfigurationRequest === null || approvalConfigurationRequest === undefined) {
            throw new Error('Required parameter approvalConfigurationRequest was null or undefined when calling updateConfiguration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/approvalConfigurations/${this.configuration.encodeParam({ name: "approvalId", value: approvalId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approvalConfigurationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApprovalConfigurationAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApprovalConfigurationAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApprovalConfigurationAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ChangeRequestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    applyEmergencyOverride(changeId, emergencyOverrideDTO, observe = 'body', reportProgress = false, options) {
        if (changeId === null || changeId === undefined) {
            throw new Error('Required parameter changeId was null or undefined when calling applyEmergencyOverride.');
        }
        if (emergencyOverrideDTO === null || emergencyOverrideDTO === undefined) {
            throw new Error('Required parameter emergencyOverrideDTO was null or undefined when calling applyEmergencyOverride.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/changeRequests/${this.configuration.encodeParam({ name: "changeId", value: changeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/emergency-override`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: emergencyOverrideDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    approveChangeRequest(changeId, approveChangeRequestDTO, observe = 'body', reportProgress = false, options) {
        if (changeId === null || changeId === undefined) {
            throw new Error('Required parameter changeId was null or undefined when calling approveChangeRequest.');
        }
        if (approveChangeRequestDTO === null || approveChangeRequestDTO === undefined) {
            throw new Error('Required parameter approveChangeRequestDTO was null or undefined when calling approveChangeRequest.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/changeRequests/${this.configuration.encodeParam({ name: "changeId", value: changeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approveChangeRequestDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    canCloseWorkorder(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling canCloseWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/canClose`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createChangeRequest(workorderId, createChangeRequestDTO, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling createChangeRequest.');
        }
        if (createChangeRequestDTO === null || createChangeRequestDTO === undefined) {
            throw new Error('Required parameter createChangeRequestDTO was null or undefined when calling createChangeRequest.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/changeRequests`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createChangeRequestDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    declineChangeRequest(changeId, declineChangeRequestDTO, observe = 'body', reportProgress = false, options) {
        if (changeId === null || changeId === undefined) {
            throw new Error('Required parameter changeId was null or undefined when calling declineChangeRequest.');
        }
        if (declineChangeRequestDTO === null || declineChangeRequestDTO === undefined) {
            throw new Error('Required parameter declineChangeRequestDTO was null or undefined when calling declineChangeRequest.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/changeRequests/${this.configuration.encodeParam({ name: "changeId", value: changeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/decline`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: declineChangeRequestDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getChangeRequestById(changeId, observe = 'body', reportProgress = false, options) {
        if (changeId === null || changeId === undefined) {
            throw new Error('Required parameter changeId was null or undefined when calling getChangeRequestById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/changeRequests/${this.configuration.encodeParam({ name: "changeId", value: changeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getChangeRequestsByWorkorder(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getChangeRequestsByWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/changeRequests`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordCustomerDenialAcknowledgment(changeId, observe = 'body', reportProgress = false, options) {
        if (changeId === null || changeId === undefined) {
            throw new Error('Required parameter changeId was null or undefined when calling recordCustomerDenialAcknowledgment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/changeRequests/${this.configuration.encodeParam({ name: "changeId", value: changeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/acknowledgeDenial`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ChangeRequestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ChangeRequestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ChangeRequestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class DailyDispatchBoardDashboardService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getDashboard(locationId, date, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getDashboard.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'date', date, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/dashboard/today`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: DailyDispatchBoardDashboardService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: DailyDispatchBoardDashboardService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: DailyDispatchBoardDashboardService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class EstimateAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addEstimateItem(estimateId, addEstimateItemRequest, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling addEstimateItem.');
        }
        if (addEstimateItemRequest === null || addEstimateItemRequest === undefined) {
            throw new Error('Required parameter addEstimateItemRequest was null or undefined when calling addEstimateItem.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/items`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: addEstimateItemRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    approveEstimate(estimateId, approveEstimateRequest, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling approveEstimate.');
        }
        if (approveEstimateRequest === null || approveEstimateRequest === undefined) {
            throw new Error('Required parameter approveEstimateRequest was null or undefined when calling approveEstimate.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/approval`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approveEstimateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    calculateEstimateTotals(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling calculateEstimateTotals.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/calculate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createEstimate(createEstimateRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (createEstimateRequest === null || createEstimateRequest === undefined) {
            throw new Error('Required parameter createEstimateRequest was null or undefined when calling createEstimate.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createEstimateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createEstimateSnapshot(estimateId, notes, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling createEstimateSnapshot.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'notes', notes, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    declineEstimate(estimateId, reason, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling declineEstimate.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'reason', reason, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/decline`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteEstimate(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling deleteEstimate.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteEstimateItem(estimateId, itemId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling deleteEstimateItem.');
        }
        if (itemId === null || itemId === undefined) {
            throw new Error('Required parameter itemId was null or undefined when calling deleteEstimateItem.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/items/${this.configuration.encodeParam({ name: "itemId", value: itemId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateEstimatePdf(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling generateEstimatePdf.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/pdf'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/pdf`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAllEstimates(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEstimateById(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling getEstimateById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEstimateSummary(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling getEstimateSummary.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/summary`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEstimatesByCustomer(customerId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling getEstimatesByCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/customer/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEstimatesByLocation(locationId, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getEstimatesByLocation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/location/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEstimatesByShop(locationId, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getEstimatesByShop.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/shop/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    patchEstimateStatus(estimateId, requestBody, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling patchEstimateStatus.');
        }
        if (requestBody === null || requestBody === undefined) {
            throw new Error('Required parameter requestBody was null or undefined when calling patchEstimateStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('patch', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: requestBody,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    promoteEstimateToWorkorder(estimateId, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling promoteEstimateToWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/promote`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reopenEstimate(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling reopenEstimate.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/reopen`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitForApproval(estimateId, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling submitForApproval.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/submit-for-approval`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateEstimateItem(estimateId, itemId, updateEstimateItemRequest, observe = 'body', reportProgress = false, options) {
        if (estimateId === null || estimateId === undefined) {
            throw new Error('Required parameter estimateId was null or undefined when calling updateEstimateItem.');
        }
        if (itemId === null || itemId === undefined) {
            throw new Error('Required parameter itemId was null or undefined when calling updateEstimateItem.');
        }
        if (updateEstimateItemRequest === null || updateEstimateItemRequest === undefined) {
            throw new Error('Required parameter updateEstimateItemRequest was null or undefined when calling updateEstimateItem.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/${this.configuration.encodeParam({ name: "estimateId", value: estimateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/items/${this.configuration.encodeParam({ name: "itemId", value: itemId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('patch', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateEstimateItemRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimateAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimateAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimateAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class EstimateSearchService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    searchEstimates(pageable, customerId, vehicleId, observe = 'body', reportProgress = false, options) {
        if (pageable === null || pageable === undefined) {
            throw new Error('Required parameter pageable was null or undefined when calling searchEstimates.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vehicleId', vehicleId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageable', pageable, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/estimates/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimateSearchService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimateSearchService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimateSearchService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class EstimatesFromAppointmentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createEstimateFromAppointment(createEstimateFromAppointmentRequest, observe = 'body', reportProgress = false, options) {
        if (createEstimateFromAppointmentRequest === null || createEstimateFromAppointmentRequest === undefined) {
            throw new Error('Required parameter createEstimateFromAppointmentRequest was null or undefined when calling createEstimateFromAppointment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/estimates/from-appointment`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createEstimateFromAppointmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimatesFromAppointmentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimatesFromAppointmentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EstimatesFromAppointmentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class OperationalContextService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getOperationalContext(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getOperationalContext.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/operationalContext`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    overrideOperationalContext(workorderId, operationalContextOverrideRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling overrideOperationalContext.');
        }
        if (operationalContextOverrideRequest === null || operationalContextOverrideRequest === undefined) {
            throw new Error('Required parameter operationalContextOverrideRequest was null or undefined when calling overrideOperationalContext.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/operationalContext/override`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: operationalContextOverrideRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    startWork(workorderId, startWorkorderRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling startWork.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: startWorkorderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: OperationalContextService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: OperationalContextService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: OperationalContextService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SubstituteLinkControllerService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    suggestSubstitutes(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling suggestSubstitutes.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/suggestSubstitutes`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SubstituteLinkControllerService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SubstituteLinkControllerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SubstituteLinkControllerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TechnicianAssignmentAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignTechnician(workorderId, assignTechnicianRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling assignTechnician.');
        }
        if (assignTechnicianRequest === null || assignTechnicianRequest === undefined) {
            throw new Error('Required parameter assignTechnicianRequest was null or undefined when calling assignTechnician.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/technician`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: assignTechnicianRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTechnicianAssignment(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getTechnicianAssignment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/technician`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reassignTechnician(workorderId, reassignTechnicianRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling reassignTechnician.');
        }
        if (reassignTechnicianRequest === null || reassignTechnicianRequest === undefined) {
            throw new Error('Required parameter reassignTechnicianRequest was null or undefined when calling reassignTechnician.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/technician`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reassignTechnicianRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TechnicianAssignmentAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TechnicianAssignmentAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TechnicianAssignmentAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TimeEntryAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveTimeEntry(timeEntryId, observe = 'body', reportProgress = false, options) {
        if (timeEntryId === null || timeEntryId === undefined) {
            throw new Error('Required parameter timeEntryId was null or undefined when calling approveTimeEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/timeEntries/${this.configuration.encodeParam({ name: "timeEntryId", value: timeEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectTimeEntry(timeEntryId, rejectTimeEntryRequest, observe = 'body', reportProgress = false, options) {
        if (timeEntryId === null || timeEntryId === undefined) {
            throw new Error('Required parameter timeEntryId was null or undefined when calling rejectTimeEntry.');
        }
        if (rejectTimeEntryRequest === null || rejectTimeEntryRequest === undefined) {
            throw new Error('Required parameter rejectTimeEntryRequest was null or undefined when calling rejectTimeEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/timeEntries/${this.configuration.encodeParam({ name: "timeEntryId", value: timeEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rejectTimeEntryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimeEntryAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimeEntryAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimeEntryAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TravelSegmentAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createAdjustment(travelSegmentId, createTravelSegmentAdjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (travelSegmentId === null || travelSegmentId === undefined) {
            throw new Error('Required parameter travelSegmentId was null or undefined when calling createAdjustment.');
        }
        if (createTravelSegmentAdjustmentRequest === null || createTravelSegmentAdjustmentRequest === undefined) {
            throw new Error('Required parameter createTravelSegmentAdjustmentRequest was null or undefined when calling createAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/travelSegments/${this.configuration.encodeParam({ name: "travelSegmentId", value: travelSegmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createTravelSegmentAdjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    startTravelSegment(startTravelSegmentRequest, observe = 'body', reportProgress = false, options) {
        if (startTravelSegmentRequest === null || startTravelSegmentRequest === undefined) {
            throw new Error('Required parameter startTravelSegmentRequest was null or undefined when calling startTravelSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/travelSegments/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: startTravelSegmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopTravelSegment(travelSegmentId, stopTravelSegmentRequest, observe = 'body', reportProgress = false, options) {
        if (travelSegmentId === null || travelSegmentId === undefined) {
            throw new Error('Required parameter travelSegmentId was null or undefined when calling stopTravelSegment.');
        }
        if (stopTravelSegmentRequest === null || stopTravelSegmentRequest === undefined) {
            throw new Error('Required parameter stopTravelSegmentRequest was null or undefined when calling stopTravelSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/travelSegments/${this.configuration.encodeParam({ name: "travelSegmentId", value: travelSegmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: stopTravelSegmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitTravelSegments(mobileWorkAssignmentId, submitTravelSegmentsRequest, observe = 'body', reportProgress = false, options) {
        if (mobileWorkAssignmentId === null || mobileWorkAssignmentId === undefined) {
            throw new Error('Required parameter mobileWorkAssignmentId was null or undefined when calling submitTravelSegments.');
        }
        if (submitTravelSegmentsRequest === null || submitTravelSegmentsRequest === undefined) {
            throw new Error('Required parameter submitTravelSegmentsRequest was null or undefined when calling submitTravelSegments.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/travelSegments/submit/${this.configuration.encodeParam({ name: "mobileWorkAssignmentId", value: mobileWorkAssignmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitTravelSegmentsRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TravelSegmentAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TravelSegmentAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TravelSegmentAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WIPDashboardService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getWipDetail(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getWipDetail.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/wip/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listWip(locationId, pageable, multiLocation, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling listWip.');
        }
        if (pageable === null || pageable === undefined) {
            throw new Error('Required parameter pageable was null or undefined when calling listWip.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'multiLocation', multiLocation, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageable', pageable, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/wip`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WIPDashboardService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WIPDashboardService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WIPDashboardService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkOrderAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveWorkorder(workorderId, approveWorkorderRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling approveWorkorder.');
        }
        if (approveWorkorderRequest === null || approveWorkorderRequest === undefined) {
            throw new Error('Required parameter approveWorkorderRequest was null or undefined when calling approveWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/approval`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approveWorkorderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    completeWorkorder(workorderId, completeWorkorderRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling completeWorkorder.');
        }
        if (completeWorkorderRequest === null || completeWorkorderRequest === undefined) {
            throw new Error('Required parameter completeWorkorderRequest was null or undefined when calling completeWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/complete`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: completeWorkorderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createWorkorder(createWorkorderRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (createWorkorderRequest === null || createWorkorderRequest === undefined) {
            throw new Error('Required parameter createWorkorderRequest was null or undefined when calling createWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createWorkorderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteWorkorder(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling deleteWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateInvoice(workorderId, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling generateInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/generate-invoice`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAllWorkorders(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCompletionPreconditions(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getCompletionPreconditions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/completion-preconditions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getSnapshotHistory(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getSnapshotHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTransitionHistory(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getTransitionHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/transitions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getWorkorderById(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getWorkorderById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reopenWorkorder(workorderId, reopenWorkorderRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling reopenWorkorder.');
        }
        if (reopenWorkorderRequest === null || reopenWorkorderRequest === undefined) {
            throw new Error('Required parameter reopenWorkorderRequest was null or undefined when calling reopenWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/reopen`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reopenWorkorderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkOrderAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkOrderAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkOrderAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkSessionAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addBreakSegment(workSessionId, addBreakSegmentRequest, observe = 'body', reportProgress = false, options) {
        if (workSessionId === null || workSessionId === undefined) {
            throw new Error('Required parameter workSessionId was null or undefined when calling addBreakSegment.');
        }
        if (addBreakSegmentRequest === null || addBreakSegmentRequest === undefined) {
            throw new Error('Required parameter addBreakSegmentRequest was null or undefined when calling addBreakSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/workSessions/${this.configuration.encodeParam({ name: "workSessionId", value: workSessionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/breaks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: addBreakSegmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    startWorkSession(startWorkSessionRequest, observe = 'body', reportProgress = false, options) {
        if (startWorkSessionRequest === null || startWorkSessionRequest === undefined) {
            throw new Error('Required parameter startWorkSessionRequest was null or undefined when calling startWorkSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/workSessions/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: startWorkSessionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopBreakSegment(workSessionId, breakSegmentId, observe = 'body', reportProgress = false, options) {
        if (workSessionId === null || workSessionId === undefined) {
            throw new Error('Required parameter workSessionId was null or undefined when calling stopBreakSegment.');
        }
        if (breakSegmentId === null || breakSegmentId === undefined) {
            throw new Error('Required parameter breakSegmentId was null or undefined when calling stopBreakSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/workSessions/${this.configuration.encodeParam({ name: "workSessionId", value: workSessionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/breaks/${this.configuration.encodeParam({ name: "breakSegmentId", value: breakSegmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopWorkSession(workSessionId, stopWorkSessionRequest, observe = 'body', reportProgress = false, options) {
        if (workSessionId === null || workSessionId === undefined) {
            throw new Error('Required parameter workSessionId was null or undefined when calling stopWorkSession.');
        }
        if (stopWorkSessionRequest === null || stopWorkSessionRequest === undefined) {
            throw new Error('Required parameter stopWorkSessionRequest was null or undefined when calling stopWorkSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/workSessions/${this.configuration.encodeParam({ name: "workSessionId", value: workSessionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: stopWorkSessionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkSessionAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkSessionAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkSessionAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkexecTimeTrackingAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createLaborPerformed(idempotencyKey, workexecLaborPerformedRequest, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (idempotencyKey === null || idempotencyKey === undefined) {
            throw new Error('Required parameter idempotencyKey was null or undefined when calling createLaborPerformed.');
        }
        if (workexecLaborPerformedRequest === null || workexecLaborPerformedRequest === undefined) {
            throw new Error('Required parameter workexecLaborPerformedRequest was null or undefined when calling createLaborPerformed.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/labor-performed`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: workexecLaborPerformedRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getActiveTimerEntries(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/time-entries/timer/active`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getJobTimeTotals(startDate, endDate, timezone, locationId, technicianIds, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getJobTimeTotals.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getJobTimeTotals.');
        }
        if (timezone === null || timezone === undefined) {
            throw new Error('Required parameter timezone was null or undefined when calling getJobTimeTotals.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'timezone', timezone, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'technicianIds', technicianIds, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/job-time-totals`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    startTimer(workexecTimerStartRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workexecTimerStartRequest === null || workexecTimerStartRequest === undefined) {
            throw new Error('Required parameter workexecTimerStartRequest was null or undefined when calling startTimer.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/time-entries/timer/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: workexecTimerStartRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopTimers(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workexec/time-entries/timer/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkexecTimeTrackingAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkexecTimeTrackingAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkexecTimeTrackingAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkorderDetailService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getWorkorderDetail(workorderId, xAuthorities, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getWorkorderDetail.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xAuthorities !== undefined && xAuthorities !== null) {
            localVarHeaders = localVarHeaders.set('X-Authorities', String(xAuthorities));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/detail`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderDetailService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderDetailService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderDetailService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkorderLaborAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    adjustLaborHours(workorderId, entryId, adjustLaborRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling adjustLaborHours.');
        }
        if (entryId === null || entryId === undefined) {
            throw new Error('Required parameter entryId was null or undefined when calling adjustLaborHours.');
        }
        if (adjustLaborRequest === null || adjustLaborRequest === undefined) {
            throw new Error('Required parameter adjustLaborRequest was null or undefined when calling adjustLaborHours.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/labor/${this.configuration.encodeParam({ name: "entryId", value: entryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/adjust`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: adjustLaborRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getLaborHistory(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getLaborHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/labor`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    startLaborSession(workorderId, serviceId, startLaborRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling startLaborSession.');
        }
        if (serviceId === null || serviceId === undefined) {
            throw new Error('Required parameter serviceId was null or undefined when calling startLaborSession.');
        }
        if (startLaborRequest === null || startLaborRequest === undefined) {
            throw new Error('Required parameter startLaborRequest was null or undefined when calling startLaborSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/services/${this.configuration.encodeParam({ name: "serviceId", value: serviceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/labor/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: startLaborRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopLaborSession(workorderId, entryId, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling stopLaborSession.');
        }
        if (entryId === null || entryId === undefined) {
            throw new Error('Required parameter entryId was null or undefined when calling stopLaborSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/labor/${this.configuration.encodeParam({ name: "entryId", value: entryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderLaborAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderLaborAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderLaborAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkorderPartAdjustmentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    correctPartQuantity(workorderId, correctPartQuantityRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling correctPartQuantity.');
        }
        if (correctPartQuantityRequest === null || correctPartQuantityRequest === undefined) {
            throw new Error('Required parameter correctPartQuantityRequest was null or undefined when calling correctPartQuantity.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/correct`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: correctPartQuantityRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAdjustmentHistory(workorderId, partId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getAdjustmentHistory.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'partId', partId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    returnUnusedQuantity(workorderId, returnPartQuantityRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling returnUnusedQuantity.');
        }
        if (returnPartQuantityRequest === null || returnPartQuantityRequest === undefined) {
            throw new Error('Required parameter returnPartQuantityRequest was null or undefined when calling returnUnusedQuantity.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/returnUnused`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: returnPartQuantityRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    substitutePart(workorderId, substitutePartRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling substitutePart.');
        }
        if (substitutePartRequest === null || substitutePartRequest === undefined) {
            throw new Error('Required parameter substitutePartRequest was null or undefined when calling substitutePart.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/substitute`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: substitutePartRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPartAdjustmentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPartAdjustmentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPartAdjustmentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkorderPartsUsageService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    consumeParts(workorderId, consumePartRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling consumeParts.');
        }
        if (consumePartRequest === null || consumePartRequest === undefined) {
            throw new Error('Required parameter consumePartRequest was null or undefined when calling consumeParts.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/consume`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: consumePartRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUsageHistory(workorderId, partLineId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getUsageHistory.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'partLineId', partLineId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/usageHistory`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    issueParts(workorderId, issuePartRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling issueParts.');
        }
        if (issuePartRequest === null || issuePartRequest === undefined) {
            throw new Error('Required parameter issuePartRequest was null or undefined when calling issueParts.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/issue`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: issuePartRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    returnParts(workorderId, returnPartRequest, idempotencyKey, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling returnParts.');
        }
        if (returnPartRequest === null || returnPartRequest === undefined) {
            throw new Error('Required parameter returnPartRequest was null or undefined when calling returnParts.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/parts/return`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: returnPartRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPartsUsageService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPartsUsageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPartsUsageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkorderPickFacadeService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    completePickTask(workorderId, pickTaskId, completePickTaskRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling completePickTask.');
        }
        if (pickTaskId === null || pickTaskId === undefined) {
            throw new Error('Required parameter pickTaskId was null or undefined when calling completePickTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/pick-tasks/${this.configuration.encodeParam({ name: "pickTaskId", value: pickTaskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}:complete`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: completePickTaskRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    confirmPickLine(workorderId, pickTaskId, pickLineId, confirmPickLineRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling confirmPickLine.');
        }
        if (pickTaskId === null || pickTaskId === undefined) {
            throw new Error('Required parameter pickTaskId was null or undefined when calling confirmPickLine.');
        }
        if (pickLineId === null || pickLineId === undefined) {
            throw new Error('Required parameter pickLineId was null or undefined when calling confirmPickLine.');
        }
        if (confirmPickLineRequest === null || confirmPickLineRequest === undefined) {
            throw new Error('Required parameter confirmPickLineRequest was null or undefined when calling confirmPickLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/pick-tasks/${this.configuration.encodeParam({ name: "pickTaskId", value: pickTaskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/lines/${this.configuration.encodeParam({ name: "pickLineId", value: pickLineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}:confirm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: confirmPickLineRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPickList(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getPickList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/pick-list`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPickTasks(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getPickTasks.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/pick-list/tasks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveScan(workorderId, pickTaskId, resolveScanRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling resolveScan.');
        }
        if (pickTaskId === null || pickTaskId === undefined) {
            throw new Error('Required parameter pickTaskId was null or undefined when calling resolveScan.');
        }
        if (resolveScanRequest === null || resolveScanRequest === undefined) {
            throw new Error('Required parameter resolveScanRequest was null or undefined when calling resolveScan.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/pick-tasks/${this.configuration.encodeParam({ name: "pickTaskId", value: pickTaskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}:resolve-scan`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: resolveScanRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPickFacadeService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPickFacadeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPickFacadeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkorderPickedItemsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    consumePickedItems(workorderId, consumePickedItemsRequest, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling consumePickedItems.');
        }
        if (consumePickedItemsRequest === null || consumePickedItemsRequest === undefined) {
            throw new Error('Required parameter consumePickedItemsRequest was null or undefined when calling consumePickedItems.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/picked-items:consume`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: consumePickedItemsRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPickedItems(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getPickedItems.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/workorders/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/picked-items`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPickedItemsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPickedItemsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkorderPickedItemsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

const APIS = [ApprovalConfigurationAPIService, ChangeRequestAPIService, DailyDispatchBoardDashboardService, EstimateAPIService, EstimateSearchService, EstimatesFromAppointmentsService, OperationalContextService, SubstituteLinkControllerService, TechnicianAssignmentAPIService, TimeEntryAPIService, TravelSegmentAPIService, WIPDashboardService, WorkOrderAPIService, WorkSessionAPIService, WorkexecTimeTrackingAPIService, WorkorderDetailService, WorkorderLaborAPIService, WorkorderPartAdjustmentsService, WorkorderPartsUsageService, WorkorderPickFacadeService, WorkorderPickedItemsService];

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AddBreakSegmentRequestBreakTypeEnum;
(function (AddBreakSegmentRequestBreakTypeEnum) {
    AddBreakSegmentRequestBreakTypeEnum["Meal"] = "MEAL";
    AddBreakSegmentRequestBreakTypeEnum["Rest"] = "REST";
    AddBreakSegmentRequestBreakTypeEnum["Other"] = "OTHER";
})(AddBreakSegmentRequestBreakTypeEnum || (AddBreakSegmentRequestBreakTypeEnum = {}));
;
function AddBreakSegmentRequestFromJSON(json) { return json; }
function AddBreakSegmentRequestFromJSONTyped(json, _) { return json; }
function AddBreakSegmentRequestToJSON(value) { return value; }
function AddBreakSegmentRequestBreakTypeEnumFromJSON(json) { return json; }
function AddBreakSegmentRequestBreakTypeEnumFromJSONTyped(json, _) { return json; }
function AddBreakSegmentRequestBreakTypeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AddEstimateItemRequestItemTypeEnum;
(function (AddEstimateItemRequestItemTypeEnum) {
    AddEstimateItemRequestItemTypeEnum["Part"] = "PART";
    AddEstimateItemRequestItemTypeEnum["Labor"] = "LABOR";
})(AddEstimateItemRequestItemTypeEnum || (AddEstimateItemRequestItemTypeEnum = {}));
;
function AddEstimateItemRequestFromJSON(json) { return json; }
function AddEstimateItemRequestFromJSONTyped(json, _) { return json; }
function AddEstimateItemRequestToJSON(value) { return value; }
function AddEstimateItemRequestItemTypeEnumFromJSON(json) { return json; }
function AddEstimateItemRequestItemTypeEnumFromJSONTyped(json, _) { return json; }
function AddEstimateItemRequestItemTypeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function AdjustLaborRequestFromJSON(json) { return json; }
function AdjustLaborRequestFromJSONTyped(json, _) { return json; }
function AdjustLaborRequestToJSON(value) { return value; }

function ApiErrorFromJSON(json) { return json; }
function ApiErrorFromJSONTyped(json, _) { return json; }
function ApiErrorToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ApprovalConfigurationRequestFromJSON(json) { return json; }
function ApprovalConfigurationRequestFromJSONTyped(json, _) { return json; }
function ApprovalConfigurationRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ApprovalConfigurationResponseFromJSON(json) { return json; }
function ApprovalConfigurationResponseFromJSONTyped(json, _) { return json; }
function ApprovalConfigurationResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ApproveChangeRequestDTOFromJSON(json) { return json; }
function ApproveChangeRequestDTOFromJSONTyped(json, _) { return json; }
function ApproveChangeRequestDTOToJSON(value) { return value; }

function ApproveEstimateRequestFromJSON(json) { return json; }
function ApproveEstimateRequestFromJSONTyped(json, _) { return json; }
function ApproveEstimateRequestToJSON(value) { return value; }

function ApproveWorkorderRequestFromJSON(json) { return json; }
function ApproveWorkorderRequestFromJSONTyped(json, _) { return json; }
function ApproveWorkorderRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function AssignTechnicianRequestFromJSON(json) { return json; }
function AssignTechnicianRequestFromJSONTyped(json, _) { return json; }
function AssignTechnicianRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function AssignmentHistoryEntryFromJSON(json) { return json; }
function AssignmentHistoryEntryFromJSONTyped(json, _) { return json; }
function AssignmentHistoryEntryToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function BayStatusFromJSON(json) { return json; }
function BayStatusFromJSONTyped(json, _) { return json; }
function BayStatusToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BreakSegmentResponseBreakTypeEnum;
(function (BreakSegmentResponseBreakTypeEnum) {
    BreakSegmentResponseBreakTypeEnum["Meal"] = "MEAL";
    BreakSegmentResponseBreakTypeEnum["Rest"] = "REST";
    BreakSegmentResponseBreakTypeEnum["Other"] = "OTHER";
})(BreakSegmentResponseBreakTypeEnum || (BreakSegmentResponseBreakTypeEnum = {}));
;
function BreakSegmentResponseFromJSON(json) { return json; }
function BreakSegmentResponseFromJSONTyped(json, _) { return json; }
function BreakSegmentResponseToJSON(value) { return value; }
function BreakSegmentResponseBreakTypeEnumFromJSON(json) { return json; }
function BreakSegmentResponseBreakTypeEnumFromJSONTyped(json, _) { return json; }
function BreakSegmentResponseBreakTypeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ChangeRequestResponseFromJSON(json) { return json; }
function ChangeRequestResponseFromJSONTyped(json, _) { return json; }
function ChangeRequestResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CompletePickTaskRequestFromJSON(json) { return json; }
function CompletePickTaskRequestFromJSONTyped(json, _) { return json; }
function CompletePickTaskRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CompleteWorkorderRequestFromJSON(json) { return json; }
function CompleteWorkorderRequestFromJSONTyped(json, _) { return json; }
function CompleteWorkorderRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CompleteWorkorderResponseFromJSON(json) { return json; }
function CompleteWorkorderResponseFromJSONTyped(json, _) { return json; }
function CompleteWorkorderResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CompletionPreconditionsResponseFromJSON(json) { return json; }
function CompletionPreconditionsResponseFromJSONTyped(json, _) { return json; }
function CompletionPreconditionsResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ConfirmPickLineRequestFromJSON(json) { return json; }
function ConfirmPickLineRequestFromJSONTyped(json, _) { return json; }
function ConfirmPickLineRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ConflictEntryFromJSON(json) { return json; }
function ConflictEntryFromJSONTyped(json, _) { return json; }
function ConflictEntryToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ConsumeItemFromJSON(json) { return json; }
function ConsumeItemFromJSONTyped(json, _) { return json; }
function ConsumeItemToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ConsumePartRequestFromJSON(json) { return json; }
function ConsumePartRequestFromJSONTyped(json, _) { return json; }
function ConsumePartRequestToJSON(value) { return value; }

function ConsumePickedItemsRequestFromJSON(json) { return json; }
function ConsumePickedItemsRequestFromJSONTyped(json, _) { return json; }
function ConsumePickedItemsRequestToJSON(value) { return value; }

function ConsumePickedItemsResponseFromJSON(json) { return json; }
function ConsumePickedItemsResponseFromJSONTyped(json, _) { return json; }
function ConsumePickedItemsResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ConsumedItemResultStatusEnum;
(function (ConsumedItemResultStatusEnum) {
    ConsumedItemResultStatusEnum["Success"] = "SUCCESS";
    ConsumedItemResultStatusEnum["Partial"] = "PARTIAL";
    ConsumedItemResultStatusEnum["Failed"] = "FAILED";
})(ConsumedItemResultStatusEnum || (ConsumedItemResultStatusEnum = {}));
;
function ConsumedItemResultFromJSON(json) { return json; }
function ConsumedItemResultFromJSONTyped(json, _) { return json; }
function ConsumedItemResultToJSON(value) { return value; }
function ConsumedItemResultStatusEnumFromJSON(json) { return json; }
function ConsumedItemResultStatusEnumFromJSONTyped(json, _) { return json; }
function ConsumedItemResultStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CorrectPartQuantityRequestFromJSON(json) { return json; }
function CorrectPartQuantityRequestFromJSONTyped(json, _) { return json; }
function CorrectPartQuantityRequestToJSON(value) { return value; }

function CreateChangeRequestDTOFromJSON(json) { return json; }
function CreateChangeRequestDTOFromJSONTyped(json, _) { return json; }
function CreateChangeRequestDTOToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CreateEstimateFromAppointmentRequestFromJSON(json) { return json; }
function CreateEstimateFromAppointmentRequestFromJSONTyped(json, _) { return json; }
function CreateEstimateFromAppointmentRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CreateEstimateFromAppointmentResponseFromJSON(json) { return json; }
function CreateEstimateFromAppointmentResponseFromJSONTyped(json, _) { return json; }
function CreateEstimateFromAppointmentResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CreateEstimateRequestFromJSON(json) { return json; }
function CreateEstimateRequestFromJSONTyped(json, _) { return json; }
function CreateEstimateRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CreateTravelSegmentAdjustmentRequestFromJSON(json) { return json; }
function CreateTravelSegmentAdjustmentRequestFromJSONTyped(json, _) { return json; }
function CreateTravelSegmentAdjustmentRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CreateWorkorderRequestFromJSON(json) { return json; }
function CreateWorkorderRequestFromJSONTyped(json, _) { return json; }
function CreateWorkorderRequestToJSON(value) { return value; }

function DashboardResponseFromJSON(json) { return json; }
function DashboardResponseFromJSONTyped(json, _) { return json; }
function DashboardResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function DeclineChangeRequestDTOFromJSON(json) { return json; }
function DeclineChangeRequestDTOFromJSONTyped(json, _) { return json; }
function DeclineChangeRequestDTOToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function EmergencyOverrideDTOFromJSON(json) { return json; }
function EmergencyOverrideDTOFromJSONTyped(json, _) { return json; }
function EmergencyOverrideDTOToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EstimateItemResponseItemTypeEnum;
(function (EstimateItemResponseItemTypeEnum) {
    EstimateItemResponseItemTypeEnum["Part"] = "PART";
    EstimateItemResponseItemTypeEnum["Labor"] = "LABOR";
})(EstimateItemResponseItemTypeEnum || (EstimateItemResponseItemTypeEnum = {}));
;
function EstimateItemResponseFromJSON(json) { return json; }
function EstimateItemResponseFromJSONTyped(json, _) { return json; }
function EstimateItemResponseToJSON(value) { return value; }
function EstimateItemResponseItemTypeEnumFromJSON(json) { return json; }
function EstimateItemResponseItemTypeEnumFromJSONTyped(json, _) { return json; }
function EstimateItemResponseItemTypeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function EstimateResponseFromJSON(json) { return json; }
function EstimateResponseFromJSONTyped(json, _) { return json; }
function EstimateResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EstimateSnapshotResponseStatusEnum;
(function (EstimateSnapshotResponseStatusEnum) {
    EstimateSnapshotResponseStatusEnum["Draft"] = "DRAFT";
    EstimateSnapshotResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    EstimateSnapshotResponseStatusEnum["Open"] = "OPEN";
    EstimateSnapshotResponseStatusEnum["PendingCustomer"] = "PENDING_CUSTOMER";
    EstimateSnapshotResponseStatusEnum["Approved"] = "APPROVED";
    EstimateSnapshotResponseStatusEnum["Declined"] = "DECLINED";
    EstimateSnapshotResponseStatusEnum["Expired"] = "EXPIRED";
    EstimateSnapshotResponseStatusEnum["Scheduled"] = "SCHEDULED";
    EstimateSnapshotResponseStatusEnum["Invoiced"] = "INVOICED";
    EstimateSnapshotResponseStatusEnum["Cancelled"] = "CANCELLED";
    EstimateSnapshotResponseStatusEnum["Archived"] = "ARCHIVED";
})(EstimateSnapshotResponseStatusEnum || (EstimateSnapshotResponseStatusEnum = {}));
;
function EstimateSnapshotResponseFromJSON(json) { return json; }
function EstimateSnapshotResponseFromJSONTyped(json, _) { return json; }
function EstimateSnapshotResponseToJSON(value) { return value; }
function EstimateSnapshotResponseStatusEnumFromJSON(json) { return json; }
function EstimateSnapshotResponseStatusEnumFromJSONTyped(json, _) { return json; }
function EstimateSnapshotResponseStatusEnumToJSON(value) { return value; }

var EstimateSummaryResponseStatusEnum;
(function (EstimateSummaryResponseStatusEnum) {
    EstimateSummaryResponseStatusEnum["Draft"] = "DRAFT";
    EstimateSummaryResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    EstimateSummaryResponseStatusEnum["Open"] = "OPEN";
    EstimateSummaryResponseStatusEnum["PendingCustomer"] = "PENDING_CUSTOMER";
    EstimateSummaryResponseStatusEnum["Approved"] = "APPROVED";
    EstimateSummaryResponseStatusEnum["Declined"] = "DECLINED";
    EstimateSummaryResponseStatusEnum["Expired"] = "EXPIRED";
    EstimateSummaryResponseStatusEnum["Scheduled"] = "SCHEDULED";
    EstimateSummaryResponseStatusEnum["Invoiced"] = "INVOICED";
    EstimateSummaryResponseStatusEnum["Cancelled"] = "CANCELLED";
    EstimateSummaryResponseStatusEnum["Archived"] = "ARCHIVED";
})(EstimateSummaryResponseStatusEnum || (EstimateSummaryResponseStatusEnum = {}));
;
function EstimateSummaryResponseFromJSON(json) { return json; }
function EstimateSummaryResponseFromJSONTyped(json, _) { return json; }
function EstimateSummaryResponseToJSON(value) { return value; }
function EstimateSummaryResponseStatusEnumFromJSON(json) { return json; }
function EstimateSummaryResponseStatusEnumFromJSONTyped(json, _) { return json; }
function EstimateSummaryResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function FieldErrorFromJSON(json) { return json; }
function FieldErrorFromJSONTyped(json, _) { return json; }
function FieldErrorToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function InvoiceGenerationResponseFromJSON(json) { return json; }
function InvoiceGenerationResponseFromJSONTyped(json, _) { return json; }
function InvoiceGenerationResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function IssuePartRequestFromJSON(json) { return json; }
function IssuePartRequestFromJSONTyped(json, _) { return json; }
function IssuePartRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function LaborQuantityFromJSON(json) { return json; }
function LaborQuantityFromJSONTyped(json, _) { return json; }
function LaborQuantityToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function LineItemApprovalDtoFromJSON(json) { return json; }
function LineItemApprovalDtoFromJSONTyped(json, _) { return json; }
function LineItemApprovalDtoToJSON(value) { return value; }

function MechanicStatusFromJSON(json) { return json; }
function MechanicStatusFromJSONTyped(json, _) { return json; }
function MechanicStatusToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function OperationalContextOverrideRequestFromJSON(json) { return json; }
function OperationalContextOverrideRequestFromJSONTyped(json, _) { return json; }
function OperationalContextOverrideRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function OperationalContextResponseFromJSON(json) { return json; }
function OperationalContextResponseFromJSONTyped(json, _) { return json; }
function OperationalContextResponseToJSON(value) { return value; }

function PageEstimateSummaryResponseFromJSON(json) { return json; }
function PageEstimateSummaryResponseFromJSONTyped(json, _) { return json; }
function PageEstimateSummaryResponseToJSON(value) { return value; }

function PageWorkorderStatusViewFromJSON(json) { return json; }
function PageWorkorderStatusViewFromJSONTyped(json, _) { return json; }
function PageWorkorderStatusViewToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function PageableFromJSON(json) { return json; }
function PageableFromJSONTyped(json, _) { return json; }
function PageableToJSON(value) { return value; }

function PageableObjectFromJSON(json) { return json; }
function PageableObjectFromJSONTyped(json, _) { return json; }
function PageableObjectToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function PtoEntryFromJSON(json) { return json; }
function PtoEntryFromJSONTyped(json, _) { return json; }
function PtoEntryToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ReassignTechnicianRequestFromJSON(json) { return json; }
function ReassignTechnicianRequestFromJSONTyped(json, _) { return json; }
function ReassignTechnicianRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function RejectTimeEntryRequestFromJSON(json) { return json; }
function RejectTimeEntryRequestFromJSONTyped(json, _) { return json; }
function RejectTimeEntryRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ReopenWorkorderRequestFromJSON(json) { return json; }
function ReopenWorkorderRequestFromJSONTyped(json, _) { return json; }
function ReopenWorkorderRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ReopenWorkorderResponseFromJSON(json) { return json; }
function ReopenWorkorderResponseFromJSONTyped(json, _) { return json; }
function ReopenWorkorderResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ResolveScanRequestFromJSON(json) { return json; }
function ResolveScanRequestFromJSONTyped(json, _) { return json; }
function ResolveScanRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ResolveScanResponseFromJSON(json) { return json; }
function ResolveScanResponseFromJSONTyped(json, _) { return json; }
function ResolveScanResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ReturnPartQuantityRequestFromJSON(json) { return json; }
function ReturnPartQuantityRequestFromJSONTyped(json, _) { return json; }
function ReturnPartQuantityRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ReturnPartRequestFromJSON(json) { return json; }
function ReturnPartRequestFromJSONTyped(json, _) { return json; }
function ReturnPartRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function SortObjectFromJSON(json) { return json; }
function SortObjectFromJSONTyped(json, _) { return json; }
function SortObjectToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function SourceReferenceFromJSON(json) { return json; }
function SourceReferenceFromJSONTyped(json, _) { return json; }
function SourceReferenceToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function StartLaborRequestFromJSON(json) { return json; }
function StartLaborRequestFromJSONTyped(json, _) { return json; }
function StartLaborRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var StartTravelSegmentRequestSegmentTypeEnum;
(function (StartTravelSegmentRequestSegmentTypeEnum) {
    StartTravelSegmentRequestSegmentTypeEnum["DepartShop"] = "DEPART_SHOP";
    StartTravelSegmentRequestSegmentTypeEnum["ArriveCustomerSite"] = "ARRIVE_CUSTOMER_SITE";
    StartTravelSegmentRequestSegmentTypeEnum["DepartCustomerSite"] = "DEPART_CUSTOMER_SITE";
    StartTravelSegmentRequestSegmentTypeEnum["ArriveShop"] = "ARRIVE_SHOP";
    StartTravelSegmentRequestSegmentTypeEnum["TravelBetweenSites"] = "TRAVEL_BETWEEN_SITES";
    StartTravelSegmentRequestSegmentTypeEnum["Deadhead"] = "DEADHEAD";
})(StartTravelSegmentRequestSegmentTypeEnum || (StartTravelSegmentRequestSegmentTypeEnum = {}));
;
var StartTravelSegmentRequestOnBehalfReasonCodeEnum;
(function (StartTravelSegmentRequestOnBehalfReasonCodeEnum) {
    StartTravelSegmentRequestOnBehalfReasonCodeEnum["TechnicianUnavailable"] = "TECHNICIAN_UNAVAILABLE";
    StartTravelSegmentRequestOnBehalfReasonCodeEnum["ForgotToClock"] = "FORGOT_TO_CLOCK";
    StartTravelSegmentRequestOnBehalfReasonCodeEnum["DataEntryError"] = "DATA_ENTRY_ERROR";
})(StartTravelSegmentRequestOnBehalfReasonCodeEnum || (StartTravelSegmentRequestOnBehalfReasonCodeEnum = {}));
;
function StartTravelSegmentRequestFromJSON(json) { return json; }
function StartTravelSegmentRequestFromJSONTyped(json, _) { return json; }
function StartTravelSegmentRequestToJSON(value) { return value; }
function StartTravelSegmentRequestSegmentTypeEnumFromJSON(json) { return json; }
function StartTravelSegmentRequestSegmentTypeEnumFromJSONTyped(json, _) { return json; }
function StartTravelSegmentRequestSegmentTypeEnumToJSON(value) { return value; }
function StartTravelSegmentRequestOnBehalfReasonCodeEnumFromJSON(json) { return json; }
function StartTravelSegmentRequestOnBehalfReasonCodeEnumFromJSONTyped(json, _) { return json; }
function StartTravelSegmentRequestOnBehalfReasonCodeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function StartWorkSessionRequestFromJSON(json) { return json; }
function StartWorkSessionRequestFromJSONTyped(json, _) { return json; }
function StartWorkSessionRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function StartWorkorderRequestFromJSON(json) { return json; }
function StartWorkorderRequestFromJSONTyped(json, _) { return json; }
function StartWorkorderRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function StopTravelSegmentRequestFromJSON(json) { return json; }
function StopTravelSegmentRequestFromJSONTyped(json, _) { return json; }
function StopTravelSegmentRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function StopWorkSessionRequestFromJSON(json) { return json; }
function StopWorkSessionRequestFromJSONTyped(json, _) { return json; }
function StopWorkSessionRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function SubmitTravelSegmentsRequestFromJSON(json) { return json; }
function SubmitTravelSegmentsRequestFromJSONTyped(json, _) { return json; }
function SubmitTravelSegmentsRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SubstituteLinkResponseSubstituteTypeEnum;
(function (SubstituteLinkResponseSubstituteTypeEnum) {
    SubstituteLinkResponseSubstituteTypeEnum["Equivalent"] = "EQUIVALENT";
    SubstituteLinkResponseSubstituteTypeEnum["ApprovedAlternative"] = "APPROVED_ALTERNATIVE";
    SubstituteLinkResponseSubstituteTypeEnum["Upgrade"] = "UPGRADE";
    SubstituteLinkResponseSubstituteTypeEnum["Downgrade"] = "DOWNGRADE";
})(SubstituteLinkResponseSubstituteTypeEnum || (SubstituteLinkResponseSubstituteTypeEnum = {}));
;
function SubstituteLinkResponseFromJSON(json) { return json; }
function SubstituteLinkResponseFromJSONTyped(json, _) { return json; }
function SubstituteLinkResponseToJSON(value) { return value; }
function SubstituteLinkResponseSubstituteTypeEnumFromJSON(json) { return json; }
function SubstituteLinkResponseSubstituteTypeEnumFromJSONTyped(json, _) { return json; }
function SubstituteLinkResponseSubstituteTypeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function SubstitutePartRequestFromJSON(json) { return json; }
function SubstitutePartRequestFromJSONTyped(json, _) { return json; }
function SubstitutePartRequestToJSON(value) { return value; }

function TechnicianAssignmentResponseFromJSON(json) { return json; }
function TechnicianAssignmentResponseFromJSONTyped(json, _) { return json; }
function TechnicianAssignmentResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimeEntryResponseStatusEnum;
(function (TimeEntryResponseStatusEnum) {
    TimeEntryResponseStatusEnum["Draft"] = "DRAFT";
    TimeEntryResponseStatusEnum["Submitted"] = "SUBMITTED";
    TimeEntryResponseStatusEnum["Approved"] = "APPROVED";
    TimeEntryResponseStatusEnum["Rejected"] = "REJECTED";
})(TimeEntryResponseStatusEnum || (TimeEntryResponseStatusEnum = {}));
;
function TimeEntryResponseFromJSON(json) { return json; }
function TimeEntryResponseFromJSONTyped(json, _) { return json; }
function TimeEntryResponseToJSON(value) { return value; }
function TimeEntryResponseStatusEnumFromJSON(json) { return json; }
function TimeEntryResponseStatusEnumFromJSONTyped(json, _) { return json; }
function TimeEntryResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function TravelSegmentAdjustmentResponseFromJSON(json) { return json; }
function TravelSegmentAdjustmentResponseFromJSONTyped(json, _) { return json; }
function TravelSegmentAdjustmentResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TravelSegmentResponseSegmentTypeEnum;
(function (TravelSegmentResponseSegmentTypeEnum) {
    TravelSegmentResponseSegmentTypeEnum["DepartShop"] = "DEPART_SHOP";
    TravelSegmentResponseSegmentTypeEnum["ArriveCustomerSite"] = "ARRIVE_CUSTOMER_SITE";
    TravelSegmentResponseSegmentTypeEnum["DepartCustomerSite"] = "DEPART_CUSTOMER_SITE";
    TravelSegmentResponseSegmentTypeEnum["ArriveShop"] = "ARRIVE_SHOP";
    TravelSegmentResponseSegmentTypeEnum["TravelBetweenSites"] = "TRAVEL_BETWEEN_SITES";
    TravelSegmentResponseSegmentTypeEnum["Deadhead"] = "DEADHEAD";
})(TravelSegmentResponseSegmentTypeEnum || (TravelSegmentResponseSegmentTypeEnum = {}));
;
var TravelSegmentResponseStatusEnum;
(function (TravelSegmentResponseStatusEnum) {
    TravelSegmentResponseStatusEnum["Draft"] = "DRAFT";
    TravelSegmentResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    TravelSegmentResponseStatusEnum["Completed"] = "COMPLETED";
    TravelSegmentResponseStatusEnum["Submitted"] = "SUBMITTED";
    TravelSegmentResponseStatusEnum["Approved"] = "APPROVED";
    TravelSegmentResponseStatusEnum["Cancelled"] = "CANCELLED";
})(TravelSegmentResponseStatusEnum || (TravelSegmentResponseStatusEnum = {}));
;
var TravelSegmentResponseOnBehalfReasonCodeEnum;
(function (TravelSegmentResponseOnBehalfReasonCodeEnum) {
    TravelSegmentResponseOnBehalfReasonCodeEnum["TechnicianUnavailable"] = "TECHNICIAN_UNAVAILABLE";
    TravelSegmentResponseOnBehalfReasonCodeEnum["ForgotToClock"] = "FORGOT_TO_CLOCK";
    TravelSegmentResponseOnBehalfReasonCodeEnum["DataEntryError"] = "DATA_ENTRY_ERROR";
})(TravelSegmentResponseOnBehalfReasonCodeEnum || (TravelSegmentResponseOnBehalfReasonCodeEnum = {}));
;
function TravelSegmentResponseFromJSON(json) { return json; }
function TravelSegmentResponseFromJSONTyped(json, _) { return json; }
function TravelSegmentResponseToJSON(value) { return value; }
function TravelSegmentResponseSegmentTypeEnumFromJSON(json) { return json; }
function TravelSegmentResponseSegmentTypeEnumFromJSONTyped(json, _) { return json; }
function TravelSegmentResponseSegmentTypeEnumToJSON(value) { return value; }
function TravelSegmentResponseStatusEnumFromJSON(json) { return json; }
function TravelSegmentResponseStatusEnumFromJSONTyped(json, _) { return json; }
function TravelSegmentResponseStatusEnumToJSON(value) { return value; }
function TravelSegmentResponseOnBehalfReasonCodeEnumFromJSON(json) { return json; }
function TravelSegmentResponseOnBehalfReasonCodeEnumFromJSONTyped(json, _) { return json; }
function TravelSegmentResponseOnBehalfReasonCodeEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function UpdateEstimateItemRequestFromJSON(json) { return json; }
function UpdateEstimateItemRequestFromJSONTyped(json, _) { return json; }
function UpdateEstimateItemRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var WorkSessionResponseStatusEnum;
(function (WorkSessionResponseStatusEnum) {
    WorkSessionResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    WorkSessionResponseStatusEnum["Completed"] = "COMPLETED";
    WorkSessionResponseStatusEnum["Approved"] = "APPROVED";
    WorkSessionResponseStatusEnum["Rejected"] = "REJECTED";
})(WorkSessionResponseStatusEnum || (WorkSessionResponseStatusEnum = {}));
;
function WorkSessionResponseFromJSON(json) { return json; }
function WorkSessionResponseFromJSONTyped(json, _) { return json; }
function WorkSessionResponseToJSON(value) { return value; }
function WorkSessionResponseStatusEnumFromJSON(json) { return json; }
function WorkSessionResponseStatusEnumFromJSONTyped(json, _) { return json; }
function WorkSessionResponseStatusEnumToJSON(value) { return value; }

function WorkexecLaborPerformedRequestFromJSON(json) { return json; }
function WorkexecLaborPerformedRequestFromJSONTyped(json, _) { return json; }
function WorkexecLaborPerformedRequestToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkexecLaborPerformedResponseFromJSON(json) { return json; }
function WorkexecLaborPerformedResponseFromJSONTyped(json, _) { return json; }
function WorkexecLaborPerformedResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkexecTimerEntryResponseFromJSON(json) { return json; }
function WorkexecTimerEntryResponseFromJSONTyped(json, _) { return json; }
function WorkexecTimerEntryResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkexecTimerStartRequestFromJSON(json) { return json; }
function WorkexecTimerStartRequestFromJSONTyped(json, _) { return json; }
function WorkexecTimerStartRequestToJSON(value) { return value; }

function WorkexecTimerStopResponseFromJSON(json) { return json; }
function WorkexecTimerStopResponseFromJSONTyped(json, _) { return json; }
function WorkexecTimerStopResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderCapabilitiesFromJSON(json) { return json; }
function WorkorderCapabilitiesFromJSONTyped(json, _) { return json; }
function WorkorderCapabilitiesToJSON(value) { return value; }

var WorkorderDetailResponseStatusEnum;
(function (WorkorderDetailResponseStatusEnum) {
    WorkorderDetailResponseStatusEnum["Draft"] = "DRAFT";
    WorkorderDetailResponseStatusEnum["Approved"] = "APPROVED";
    WorkorderDetailResponseStatusEnum["Assigned"] = "ASSIGNED";
    WorkorderDetailResponseStatusEnum["WorkInProgress"] = "WORK_IN_PROGRESS";
    WorkorderDetailResponseStatusEnum["AwaitingParts"] = "AWAITING_PARTS";
    WorkorderDetailResponseStatusEnum["AwaitingApproval"] = "AWAITING_APPROVAL";
    WorkorderDetailResponseStatusEnum["ReadyForPickup"] = "READY_FOR_PICKUP";
    WorkorderDetailResponseStatusEnum["Completed"] = "COMPLETED";
    WorkorderDetailResponseStatusEnum["Cancelled"] = "CANCELLED";
})(WorkorderDetailResponseStatusEnum || (WorkorderDetailResponseStatusEnum = {}));
;
function WorkorderDetailResponseFromJSON(json) { return json; }
function WorkorderDetailResponseFromJSONTyped(json, _) { return json; }
function WorkorderDetailResponseToJSON(value) { return value; }
function WorkorderDetailResponseStatusEnumFromJSON(json) { return json; }
function WorkorderDetailResponseStatusEnumFromJSONTyped(json, _) { return json; }
function WorkorderDetailResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderItemDTOFromJSON(json) { return json; }
function WorkorderItemDTOFromJSONTyped(json, _) { return json; }
function WorkorderItemDTOToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderLaborEntryResponseFromJSON(json) { return json; }
function WorkorderLaborEntryResponseFromJSONTyped(json, _) { return json; }
function WorkorderLaborEntryResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderPartAdjustmentEventResponseFromJSON(json) { return json; }
function WorkorderPartAdjustmentEventResponseFromJSONTyped(json, _) { return json; }
function WorkorderPartAdjustmentEventResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var WorkorderPartResponseStatusEnum;
(function (WorkorderPartResponseStatusEnum) {
    WorkorderPartResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    WorkorderPartResponseStatusEnum["Open"] = "OPEN";
    WorkorderPartResponseStatusEnum["ReadyToExecute"] = "READY_TO_EXECUTE";
    WorkorderPartResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    WorkorderPartResponseStatusEnum["Completed"] = "COMPLETED";
    WorkorderPartResponseStatusEnum["Cancelled"] = "CANCELLED";
})(WorkorderPartResponseStatusEnum || (WorkorderPartResponseStatusEnum = {}));
;
function WorkorderPartResponseFromJSON(json) { return json; }
function WorkorderPartResponseFromJSONTyped(json, _) { return json; }
function WorkorderPartResponseToJSON(value) { return value; }
function WorkorderPartResponseStatusEnumFromJSON(json) { return json; }
function WorkorderPartResponseStatusEnumFromJSONTyped(json, _) { return json; }
function WorkorderPartResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderPartUsageEventResponseFromJSON(json) { return json; }
function WorkorderPartUsageEventResponseFromJSONTyped(json, _) { return json; }
function WorkorderPartUsageEventResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderPickListResponseFromJSON(json) { return json; }
function WorkorderPickListResponseFromJSONTyped(json, _) { return json; }
function WorkorderPickListResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderPickTaskResponseFromJSON(json) { return json; }
function WorkorderPickTaskResponseFromJSONTyped(json, _) { return json; }
function WorkorderPickTaskResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderPickedItemResponseFromJSON(json) { return json; }
function WorkorderPickedItemResponseFromJSONTyped(json, _) { return json; }
function WorkorderPickedItemResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderResponseFromJSON(json) { return json; }
function WorkorderResponseFromJSONTyped(json, _) { return json; }
function WorkorderResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var WorkorderServiceResponseStatusEnum;
(function (WorkorderServiceResponseStatusEnum) {
    WorkorderServiceResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    WorkorderServiceResponseStatusEnum["Open"] = "OPEN";
    WorkorderServiceResponseStatusEnum["ReadyToExecute"] = "READY_TO_EXECUTE";
    WorkorderServiceResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    WorkorderServiceResponseStatusEnum["Completed"] = "COMPLETED";
    WorkorderServiceResponseStatusEnum["Cancelled"] = "CANCELLED";
})(WorkorderServiceResponseStatusEnum || (WorkorderServiceResponseStatusEnum = {}));
;
function WorkorderServiceResponseFromJSON(json) { return json; }
function WorkorderServiceResponseFromJSONTyped(json, _) { return json; }
function WorkorderServiceResponseToJSON(value) { return value; }
function WorkorderServiceResponseStatusEnumFromJSON(json) { return json; }
function WorkorderServiceResponseStatusEnumFromJSONTyped(json, _) { return json; }
function WorkorderServiceResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderSnapshotResponseFromJSON(json) { return json; }
function WorkorderSnapshotResponseFromJSONTyped(json, _) { return json; }
function WorkorderSnapshotResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderStartResponseFromJSON(json) { return json; }
function WorkorderStartResponseFromJSONTyped(json, _) { return json; }
function WorkorderStartResponseToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderStateTransitionResponseFromJSON(json) { return json; }
function WorkorderStateTransitionResponseFromJSONTyped(json, _) { return json; }
function WorkorderStateTransitionResponseToJSON(value) { return value; }

var WorkorderStatusDetailStatusEnum;
(function (WorkorderStatusDetailStatusEnum) {
    WorkorderStatusDetailStatusEnum["Draft"] = "DRAFT";
    WorkorderStatusDetailStatusEnum["Approved"] = "APPROVED";
    WorkorderStatusDetailStatusEnum["Assigned"] = "ASSIGNED";
    WorkorderStatusDetailStatusEnum["WorkInProgress"] = "WORK_IN_PROGRESS";
    WorkorderStatusDetailStatusEnum["AwaitingParts"] = "AWAITING_PARTS";
    WorkorderStatusDetailStatusEnum["AwaitingApproval"] = "AWAITING_APPROVAL";
    WorkorderStatusDetailStatusEnum["ReadyForPickup"] = "READY_FOR_PICKUP";
    WorkorderStatusDetailStatusEnum["Completed"] = "COMPLETED";
    WorkorderStatusDetailStatusEnum["Cancelled"] = "CANCELLED";
})(WorkorderStatusDetailStatusEnum || (WorkorderStatusDetailStatusEnum = {}));
;
function WorkorderStatusDetailFromJSON(json) { return json; }
function WorkorderStatusDetailFromJSONTyped(json, _) { return json; }
function WorkorderStatusDetailToJSON(value) { return value; }
function WorkorderStatusDetailStatusEnumFromJSON(json) { return json; }
function WorkorderStatusDetailStatusEnumFromJSONTyped(json, _) { return json; }
function WorkorderStatusDetailStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var WorkorderStatusHistoryEntryStatusEnum;
(function (WorkorderStatusHistoryEntryStatusEnum) {
    WorkorderStatusHistoryEntryStatusEnum["Draft"] = "DRAFT";
    WorkorderStatusHistoryEntryStatusEnum["Approved"] = "APPROVED";
    WorkorderStatusHistoryEntryStatusEnum["Assigned"] = "ASSIGNED";
    WorkorderStatusHistoryEntryStatusEnum["WorkInProgress"] = "WORK_IN_PROGRESS";
    WorkorderStatusHistoryEntryStatusEnum["AwaitingParts"] = "AWAITING_PARTS";
    WorkorderStatusHistoryEntryStatusEnum["AwaitingApproval"] = "AWAITING_APPROVAL";
    WorkorderStatusHistoryEntryStatusEnum["ReadyForPickup"] = "READY_FOR_PICKUP";
    WorkorderStatusHistoryEntryStatusEnum["Completed"] = "COMPLETED";
    WorkorderStatusHistoryEntryStatusEnum["Cancelled"] = "CANCELLED";
})(WorkorderStatusHistoryEntryStatusEnum || (WorkorderStatusHistoryEntryStatusEnum = {}));
;
function WorkorderStatusHistoryEntryFromJSON(json) { return json; }
function WorkorderStatusHistoryEntryFromJSONTyped(json, _) { return json; }
function WorkorderStatusHistoryEntryToJSON(value) { return value; }
function WorkorderStatusHistoryEntryStatusEnumFromJSON(json) { return json; }
function WorkorderStatusHistoryEntryStatusEnumFromJSONTyped(json, _) { return json; }
function WorkorderStatusHistoryEntryStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var WorkorderStatusViewStatusEnum;
(function (WorkorderStatusViewStatusEnum) {
    WorkorderStatusViewStatusEnum["Draft"] = "DRAFT";
    WorkorderStatusViewStatusEnum["Approved"] = "APPROVED";
    WorkorderStatusViewStatusEnum["Assigned"] = "ASSIGNED";
    WorkorderStatusViewStatusEnum["WorkInProgress"] = "WORK_IN_PROGRESS";
    WorkorderStatusViewStatusEnum["AwaitingParts"] = "AWAITING_PARTS";
    WorkorderStatusViewStatusEnum["AwaitingApproval"] = "AWAITING_APPROVAL";
    WorkorderStatusViewStatusEnum["ReadyForPickup"] = "READY_FOR_PICKUP";
    WorkorderStatusViewStatusEnum["Completed"] = "COMPLETED";
    WorkorderStatusViewStatusEnum["Cancelled"] = "CANCELLED";
})(WorkorderStatusViewStatusEnum || (WorkorderStatusViewStatusEnum = {}));
;
function WorkorderStatusViewFromJSON(json) { return json; }
function WorkorderStatusViewFromJSONTyped(json, _) { return json; }
function WorkorderStatusViewToJSON(value) { return value; }
function WorkorderStatusViewStatusEnumFromJSON(json) { return json; }
function WorkorderStatusViewStatusEnumFromJSONTyped(json, _) { return json; }
function WorkorderStatusViewStatusEnumToJSON(value) { return value; }

/**
 * POS Workorder Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function WorkorderSummaryFromJSON(json) { return json; }
function WorkorderSummaryFromJSONTyped(json, _) { return json; }
function WorkorderSummaryToJSON(value) { return value; }

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { APIS, AddBreakSegmentRequestBreakTypeEnum, AddBreakSegmentRequestBreakTypeEnumFromJSON, AddBreakSegmentRequestBreakTypeEnumFromJSONTyped, AddBreakSegmentRequestBreakTypeEnumToJSON, AddBreakSegmentRequestFromJSON, AddBreakSegmentRequestFromJSONTyped, AddBreakSegmentRequestToJSON, AddEstimateItemRequestFromJSON, AddEstimateItemRequestFromJSONTyped, AddEstimateItemRequestItemTypeEnum, AddEstimateItemRequestItemTypeEnumFromJSON, AddEstimateItemRequestItemTypeEnumFromJSONTyped, AddEstimateItemRequestItemTypeEnumToJSON, AddEstimateItemRequestToJSON, AdjustLaborRequestFromJSON, AdjustLaborRequestFromJSONTyped, AdjustLaborRequestToJSON, ApiErrorFromJSON, ApiErrorFromJSONTyped, ApiErrorToJSON, ApiModule, ApprovalConfigurationAPIService, ApprovalConfigurationRequestFromJSON, ApprovalConfigurationRequestFromJSONTyped, ApprovalConfigurationRequestToJSON, ApprovalConfigurationResponseFromJSON, ApprovalConfigurationResponseFromJSONTyped, ApprovalConfigurationResponseToJSON, ApproveChangeRequestDTOFromJSON, ApproveChangeRequestDTOFromJSONTyped, ApproveChangeRequestDTOToJSON, ApproveEstimateRequestFromJSON, ApproveEstimateRequestFromJSONTyped, ApproveEstimateRequestToJSON, ApproveWorkorderRequestFromJSON, ApproveWorkorderRequestFromJSONTyped, ApproveWorkorderRequestToJSON, AssignTechnicianRequestFromJSON, AssignTechnicianRequestFromJSONTyped, AssignTechnicianRequestToJSON, AssignmentHistoryEntryFromJSON, AssignmentHistoryEntryFromJSONTyped, AssignmentHistoryEntryToJSON, BASE_PATH, BayStatusFromJSON, BayStatusFromJSONTyped, BayStatusToJSON, BreakSegmentResponseBreakTypeEnum, BreakSegmentResponseBreakTypeEnumFromJSON, BreakSegmentResponseBreakTypeEnumFromJSONTyped, BreakSegmentResponseBreakTypeEnumToJSON, BreakSegmentResponseFromJSON, BreakSegmentResponseFromJSONTyped, BreakSegmentResponseToJSON, COLLECTION_FORMATS, ChangeRequestAPIService, ChangeRequestResponseFromJSON, ChangeRequestResponseFromJSONTyped, ChangeRequestResponseToJSON, CompletePickTaskRequestFromJSON, CompletePickTaskRequestFromJSONTyped, CompletePickTaskRequestToJSON, CompleteWorkorderRequestFromJSON, CompleteWorkorderRequestFromJSONTyped, CompleteWorkorderRequestToJSON, CompleteWorkorderResponseFromJSON, CompleteWorkorderResponseFromJSONTyped, CompleteWorkorderResponseToJSON, CompletionPreconditionsResponseFromJSON, CompletionPreconditionsResponseFromJSONTyped, CompletionPreconditionsResponseToJSON, Configuration, ConfirmPickLineRequestFromJSON, ConfirmPickLineRequestFromJSONTyped, ConfirmPickLineRequestToJSON, ConflictEntryFromJSON, ConflictEntryFromJSONTyped, ConflictEntryToJSON, ConsumeItemFromJSON, ConsumeItemFromJSONTyped, ConsumeItemToJSON, ConsumePartRequestFromJSON, ConsumePartRequestFromJSONTyped, ConsumePartRequestToJSON, ConsumePickedItemsRequestFromJSON, ConsumePickedItemsRequestFromJSONTyped, ConsumePickedItemsRequestToJSON, ConsumePickedItemsResponseFromJSON, ConsumePickedItemsResponseFromJSONTyped, ConsumePickedItemsResponseToJSON, ConsumedItemResultFromJSON, ConsumedItemResultFromJSONTyped, ConsumedItemResultStatusEnum, ConsumedItemResultStatusEnumFromJSON, ConsumedItemResultStatusEnumFromJSONTyped, ConsumedItemResultStatusEnumToJSON, ConsumedItemResultToJSON, CorrectPartQuantityRequestFromJSON, CorrectPartQuantityRequestFromJSONTyped, CorrectPartQuantityRequestToJSON, CreateChangeRequestDTOFromJSON, CreateChangeRequestDTOFromJSONTyped, CreateChangeRequestDTOToJSON, CreateEstimateFromAppointmentRequestFromJSON, CreateEstimateFromAppointmentRequestFromJSONTyped, CreateEstimateFromAppointmentRequestToJSON, CreateEstimateFromAppointmentResponseFromJSON, CreateEstimateFromAppointmentResponseFromJSONTyped, CreateEstimateFromAppointmentResponseToJSON, CreateEstimateRequestFromJSON, CreateEstimateRequestFromJSONTyped, CreateEstimateRequestToJSON, CreateTravelSegmentAdjustmentRequestFromJSON, CreateTravelSegmentAdjustmentRequestFromJSONTyped, CreateTravelSegmentAdjustmentRequestToJSON, CreateWorkorderRequestFromJSON, CreateWorkorderRequestFromJSONTyped, CreateWorkorderRequestToJSON, DailyDispatchBoardDashboardService, DashboardResponseFromJSON, DashboardResponseFromJSONTyped, DashboardResponseToJSON, DeclineChangeRequestDTOFromJSON, DeclineChangeRequestDTOFromJSONTyped, DeclineChangeRequestDTOToJSON, EmergencyOverrideDTOFromJSON, EmergencyOverrideDTOFromJSONTyped, EmergencyOverrideDTOToJSON, EstimateAPIService, EstimateItemResponseFromJSON, EstimateItemResponseFromJSONTyped, EstimateItemResponseItemTypeEnum, EstimateItemResponseItemTypeEnumFromJSON, EstimateItemResponseItemTypeEnumFromJSONTyped, EstimateItemResponseItemTypeEnumToJSON, EstimateItemResponseToJSON, EstimateResponseFromJSON, EstimateResponseFromJSONTyped, EstimateResponseToJSON, EstimateSearchService, EstimateSnapshotResponseFromJSON, EstimateSnapshotResponseFromJSONTyped, EstimateSnapshotResponseStatusEnum, EstimateSnapshotResponseStatusEnumFromJSON, EstimateSnapshotResponseStatusEnumFromJSONTyped, EstimateSnapshotResponseStatusEnumToJSON, EstimateSnapshotResponseToJSON, EstimateSummaryResponseFromJSON, EstimateSummaryResponseFromJSONTyped, EstimateSummaryResponseStatusEnum, EstimateSummaryResponseStatusEnumFromJSON, EstimateSummaryResponseStatusEnumFromJSONTyped, EstimateSummaryResponseStatusEnumToJSON, EstimateSummaryResponseToJSON, EstimatesFromAppointmentsService, FieldErrorFromJSON, FieldErrorFromJSONTyped, FieldErrorToJSON, InvoiceGenerationResponseFromJSON, InvoiceGenerationResponseFromJSONTyped, InvoiceGenerationResponseToJSON, IssuePartRequestFromJSON, IssuePartRequestFromJSONTyped, IssuePartRequestToJSON, LaborQuantityFromJSON, LaborQuantityFromJSONTyped, LaborQuantityToJSON, LineItemApprovalDtoFromJSON, LineItemApprovalDtoFromJSONTyped, LineItemApprovalDtoToJSON, MechanicStatusFromJSON, MechanicStatusFromJSONTyped, MechanicStatusToJSON, OperationalContextOverrideRequestFromJSON, OperationalContextOverrideRequestFromJSONTyped, OperationalContextOverrideRequestToJSON, OperationalContextResponseFromJSON, OperationalContextResponseFromJSONTyped, OperationalContextResponseToJSON, OperationalContextService, PageEstimateSummaryResponseFromJSON, PageEstimateSummaryResponseFromJSONTyped, PageEstimateSummaryResponseToJSON, PageWorkorderStatusViewFromJSON, PageWorkorderStatusViewFromJSONTyped, PageWorkorderStatusViewToJSON, PageableFromJSON, PageableFromJSONTyped, PageableObjectFromJSON, PageableObjectFromJSONTyped, PageableObjectToJSON, PageableToJSON, PtoEntryFromJSON, PtoEntryFromJSONTyped, PtoEntryToJSON, ReassignTechnicianRequestFromJSON, ReassignTechnicianRequestFromJSONTyped, ReassignTechnicianRequestToJSON, RejectTimeEntryRequestFromJSON, RejectTimeEntryRequestFromJSONTyped, RejectTimeEntryRequestToJSON, ReopenWorkorderRequestFromJSON, ReopenWorkorderRequestFromJSONTyped, ReopenWorkorderRequestToJSON, ReopenWorkorderResponseFromJSON, ReopenWorkorderResponseFromJSONTyped, ReopenWorkorderResponseToJSON, ResolveScanRequestFromJSON, ResolveScanRequestFromJSONTyped, ResolveScanRequestToJSON, ResolveScanResponseFromJSON, ResolveScanResponseFromJSONTyped, ResolveScanResponseToJSON, ReturnPartQuantityRequestFromJSON, ReturnPartQuantityRequestFromJSONTyped, ReturnPartQuantityRequestToJSON, ReturnPartRequestFromJSON, ReturnPartRequestFromJSONTyped, ReturnPartRequestToJSON, SortObjectFromJSON, SortObjectFromJSONTyped, SortObjectToJSON, SourceReferenceFromJSON, SourceReferenceFromJSONTyped, SourceReferenceToJSON, StartLaborRequestFromJSON, StartLaborRequestFromJSONTyped, StartLaborRequestToJSON, StartTravelSegmentRequestFromJSON, StartTravelSegmentRequestFromJSONTyped, StartTravelSegmentRequestOnBehalfReasonCodeEnum, StartTravelSegmentRequestOnBehalfReasonCodeEnumFromJSON, StartTravelSegmentRequestOnBehalfReasonCodeEnumFromJSONTyped, StartTravelSegmentRequestOnBehalfReasonCodeEnumToJSON, StartTravelSegmentRequestSegmentTypeEnum, StartTravelSegmentRequestSegmentTypeEnumFromJSON, StartTravelSegmentRequestSegmentTypeEnumFromJSONTyped, StartTravelSegmentRequestSegmentTypeEnumToJSON, StartTravelSegmentRequestToJSON, StartWorkSessionRequestFromJSON, StartWorkSessionRequestFromJSONTyped, StartWorkSessionRequestToJSON, StartWorkorderRequestFromJSON, StartWorkorderRequestFromJSONTyped, StartWorkorderRequestToJSON, StopTravelSegmentRequestFromJSON, StopTravelSegmentRequestFromJSONTyped, StopTravelSegmentRequestToJSON, StopWorkSessionRequestFromJSON, StopWorkSessionRequestFromJSONTyped, StopWorkSessionRequestToJSON, SubmitTravelSegmentsRequestFromJSON, SubmitTravelSegmentsRequestFromJSONTyped, SubmitTravelSegmentsRequestToJSON, SubstituteLinkControllerService, SubstituteLinkResponseFromJSON, SubstituteLinkResponseFromJSONTyped, SubstituteLinkResponseSubstituteTypeEnum, SubstituteLinkResponseSubstituteTypeEnumFromJSON, SubstituteLinkResponseSubstituteTypeEnumFromJSONTyped, SubstituteLinkResponseSubstituteTypeEnumToJSON, SubstituteLinkResponseToJSON, SubstitutePartRequestFromJSON, SubstitutePartRequestFromJSONTyped, SubstitutePartRequestToJSON, TechnicianAssignmentAPIService, TechnicianAssignmentResponseFromJSON, TechnicianAssignmentResponseFromJSONTyped, TechnicianAssignmentResponseToJSON, TimeEntryAPIService, TimeEntryResponseFromJSON, TimeEntryResponseFromJSONTyped, TimeEntryResponseStatusEnum, TimeEntryResponseStatusEnumFromJSON, TimeEntryResponseStatusEnumFromJSONTyped, TimeEntryResponseStatusEnumToJSON, TimeEntryResponseToJSON, TravelSegmentAPIService, TravelSegmentAdjustmentResponseFromJSON, TravelSegmentAdjustmentResponseFromJSONTyped, TravelSegmentAdjustmentResponseToJSON, TravelSegmentResponseFromJSON, TravelSegmentResponseFromJSONTyped, TravelSegmentResponseOnBehalfReasonCodeEnum, TravelSegmentResponseOnBehalfReasonCodeEnumFromJSON, TravelSegmentResponseOnBehalfReasonCodeEnumFromJSONTyped, TravelSegmentResponseOnBehalfReasonCodeEnumToJSON, TravelSegmentResponseSegmentTypeEnum, TravelSegmentResponseSegmentTypeEnumFromJSON, TravelSegmentResponseSegmentTypeEnumFromJSONTyped, TravelSegmentResponseSegmentTypeEnumToJSON, TravelSegmentResponseStatusEnum, TravelSegmentResponseStatusEnumFromJSON, TravelSegmentResponseStatusEnumFromJSONTyped, TravelSegmentResponseStatusEnumToJSON, TravelSegmentResponseToJSON, UpdateEstimateItemRequestFromJSON, UpdateEstimateItemRequestFromJSONTyped, UpdateEstimateItemRequestToJSON, WIPDashboardService, WorkOrderAPIService, WorkSessionAPIService, WorkSessionResponseFromJSON, WorkSessionResponseFromJSONTyped, WorkSessionResponseStatusEnum, WorkSessionResponseStatusEnumFromJSON, WorkSessionResponseStatusEnumFromJSONTyped, WorkSessionResponseStatusEnumToJSON, WorkSessionResponseToJSON, WorkexecLaborPerformedRequestFromJSON, WorkexecLaborPerformedRequestFromJSONTyped, WorkexecLaborPerformedRequestToJSON, WorkexecLaborPerformedResponseFromJSON, WorkexecLaborPerformedResponseFromJSONTyped, WorkexecLaborPerformedResponseToJSON, WorkexecTimeTrackingAPIService, WorkexecTimerEntryResponseFromJSON, WorkexecTimerEntryResponseFromJSONTyped, WorkexecTimerEntryResponseToJSON, WorkexecTimerStartRequestFromJSON, WorkexecTimerStartRequestFromJSONTyped, WorkexecTimerStartRequestToJSON, WorkexecTimerStopResponseFromJSON, WorkexecTimerStopResponseFromJSONTyped, WorkexecTimerStopResponseToJSON, WorkorderCapabilitiesFromJSON, WorkorderCapabilitiesFromJSONTyped, WorkorderCapabilitiesToJSON, WorkorderDetailResponseFromJSON, WorkorderDetailResponseFromJSONTyped, WorkorderDetailResponseStatusEnum, WorkorderDetailResponseStatusEnumFromJSON, WorkorderDetailResponseStatusEnumFromJSONTyped, WorkorderDetailResponseStatusEnumToJSON, WorkorderDetailResponseToJSON, WorkorderDetailService, WorkorderItemDTOFromJSON, WorkorderItemDTOFromJSONTyped, WorkorderItemDTOToJSON, WorkorderLaborAPIService, WorkorderLaborEntryResponseFromJSON, WorkorderLaborEntryResponseFromJSONTyped, WorkorderLaborEntryResponseToJSON, WorkorderPartAdjustmentEventResponseFromJSON, WorkorderPartAdjustmentEventResponseFromJSONTyped, WorkorderPartAdjustmentEventResponseToJSON, WorkorderPartAdjustmentsService, WorkorderPartResponseFromJSON, WorkorderPartResponseFromJSONTyped, WorkorderPartResponseStatusEnum, WorkorderPartResponseStatusEnumFromJSON, WorkorderPartResponseStatusEnumFromJSONTyped, WorkorderPartResponseStatusEnumToJSON, WorkorderPartResponseToJSON, WorkorderPartUsageEventResponseFromJSON, WorkorderPartUsageEventResponseFromJSONTyped, WorkorderPartUsageEventResponseToJSON, WorkorderPartsUsageService, WorkorderPickFacadeService, WorkorderPickListResponseFromJSON, WorkorderPickListResponseFromJSONTyped, WorkorderPickListResponseToJSON, WorkorderPickTaskResponseFromJSON, WorkorderPickTaskResponseFromJSONTyped, WorkorderPickTaskResponseToJSON, WorkorderPickedItemResponseFromJSON, WorkorderPickedItemResponseFromJSONTyped, WorkorderPickedItemResponseToJSON, WorkorderPickedItemsService, WorkorderResponseFromJSON, WorkorderResponseFromJSONTyped, WorkorderResponseToJSON, WorkorderServiceResponseFromJSON, WorkorderServiceResponseFromJSONTyped, WorkorderServiceResponseStatusEnum, WorkorderServiceResponseStatusEnumFromJSON, WorkorderServiceResponseStatusEnumFromJSONTyped, WorkorderServiceResponseStatusEnumToJSON, WorkorderServiceResponseToJSON, WorkorderSnapshotResponseFromJSON, WorkorderSnapshotResponseFromJSONTyped, WorkorderSnapshotResponseToJSON, WorkorderStartResponseFromJSON, WorkorderStartResponseFromJSONTyped, WorkorderStartResponseToJSON, WorkorderStateTransitionResponseFromJSON, WorkorderStateTransitionResponseFromJSONTyped, WorkorderStateTransitionResponseToJSON, WorkorderStatusDetailFromJSON, WorkorderStatusDetailFromJSONTyped, WorkorderStatusDetailStatusEnum, WorkorderStatusDetailStatusEnumFromJSON, WorkorderStatusDetailStatusEnumFromJSONTyped, WorkorderStatusDetailStatusEnumToJSON, WorkorderStatusDetailToJSON, WorkorderStatusHistoryEntryFromJSON, WorkorderStatusHistoryEntryFromJSONTyped, WorkorderStatusHistoryEntryStatusEnum, WorkorderStatusHistoryEntryStatusEnumFromJSON, WorkorderStatusHistoryEntryStatusEnumFromJSONTyped, WorkorderStatusHistoryEntryStatusEnumToJSON, WorkorderStatusHistoryEntryToJSON, WorkorderStatusViewFromJSON, WorkorderStatusViewFromJSONTyped, WorkorderStatusViewStatusEnum, WorkorderStatusViewStatusEnumFromJSON, WorkorderStatusViewStatusEnumFromJSONTyped, WorkorderStatusViewStatusEnumToJSON, WorkorderStatusViewToJSON, WorkorderSummaryFromJSON, WorkorderSummaryFromJSONTyped, WorkorderSummaryToJSON, provideApi };
//# sourceMappingURL=durion-sdk-workorder.mjs.map
