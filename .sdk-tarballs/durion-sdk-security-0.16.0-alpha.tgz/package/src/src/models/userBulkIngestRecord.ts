export * from '../../models/userBulkIngestRecord';
