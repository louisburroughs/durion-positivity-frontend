export * from '../../models/userPersonLinkBulkIngestRecord';
