import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/invoice';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class BillingAuthorizationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    elevateManagerApproval(elevateRequest, observe = 'body', reportProgress = false, options) {
        if (elevateRequest === null || elevateRequest === undefined) {
            throw new Error('Required parameter elevateRequest was null or undefined when calling elevateManagerApproval.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/billing/auth/elevate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: elevateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BillingAuthorizationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BillingAuthorizationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BillingAuthorizationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class BillingRulesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getBillingRules(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/billing/rules/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertBillingRules(partyId, billingRulesDTO, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertBillingRules.');
        }
        if (billingRulesDTO === null || billingRulesDTO === undefined) {
            throw new Error('Required parameter billingRulesDTO was null or undefined when calling upsertBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/billing/rules/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: billingRulesDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BillingRulesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BillingRulesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BillingRulesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class DepositCreditsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createDepositCredit(createDepositRequest, observe = 'body', reportProgress = false, options) {
        if (createDepositRequest === null || createDepositRequest === undefined) {
            throw new Error('Required parameter createDepositRequest was null or undefined when calling createDepositCredit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/deposits`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createDepositRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getDepositCredit(depositCreditId, observe = 'body', reportProgress = false, options) {
        if (depositCreditId === null || depositCreditId === undefined) {
            throw new Error('Required parameter depositCreditId was null or undefined when calling getDepositCredit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/deposits/${this.configuration.encodeParam({ name: "depositCreditId", value: depositCreditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listDepositCreditsBySource(sourceType, sourceId, observe = 'body', reportProgress = false, options) {
        if (sourceType === null || sourceType === undefined) {
            throw new Error('Required parameter sourceType was null or undefined when calling listDepositCreditsBySource.');
        }
        if (sourceId === null || sourceId === undefined) {
            throw new Error('Required parameter sourceId was null or undefined when calling listDepositCreditsBySource.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceType', sourceType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceId', sourceId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/deposits`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    refundDepositCredit(depositCreditId, reason, observe = 'body', reportProgress = false, options) {
        if (depositCreditId === null || depositCreditId === undefined) {
            throw new Error('Required parameter depositCreditId was null or undefined when calling refundDepositCredit.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'reason', reason, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/deposits/${this.configuration.encodeParam({ name: "depositCreditId", value: depositCreditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/refund`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DepositCreditsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DepositCreditsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DepositCreditsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InvoiceService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    applyInvoiceAdjustment(invoiceId, adjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling applyInvoiceAdjustment.');
        }
        if (adjustmentRequest === null || adjustmentRequest === undefined) {
            throw new Error('Required parameter adjustmentRequest was null or undefined when calling applyInvoiceAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: adjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    cancelInvoice(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling cancelInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/cancel`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createInvoice(invoiceCreationRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceCreationRequest === null || invoiceCreationRequest === undefined) {
            throw new Error('Required parameter invoiceCreationRequest was null or undefined when calling createInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: invoiceCreationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createInvoiceFromOrder(orderInvoiceCreationRequest, observe = 'body', reportProgress = false, options) {
        if (orderInvoiceCreationRequest === null || orderInvoiceCreationRequest === undefined) {
            throw new Error('Required parameter orderInvoiceCreationRequest was null or undefined when calling createInvoiceFromOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/from-order`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: orderInvoiceCreationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    finalizeInvoice(invoiceId, finalizationRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling finalizeInvoice.');
        }
        if (finalizationRequest === null || finalizationRequest === undefined) {
            throw new Error('Required parameter finalizationRequest was null or undefined when calling finalizeInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/finalize`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: finalizationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getInvoice(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling getInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revertInvoice(invoiceId, revertRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling revertInvoice.');
        }
        if (revertRequest === null || revertRequest === undefined) {
            throw new Error('Required parameter revertRequest was null or undefined when calling revertInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/revert`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: revertRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InvoiceArtifactControllerService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createArtifactDownloadToken(invoiceId, artifactRefId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling createArtifactDownloadToken.');
        }
        if (artifactRefId === null || artifactRefId === undefined) {
            throw new Error('Required parameter artifactRefId was null or undefined when calling createArtifactDownloadToken.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/artifacts/${this.configuration.encodeParam({ name: "artifactRefId", value: artifactRefId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/download-token`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listInvoiceArtifacts(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling listInvoiceArtifacts.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/artifacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceArtifactControllerService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceArtifactControllerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceArtifactControllerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InvoiceArtifactDownloadControllerService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    downloadInvoiceArtifact(invoiceId, artifactRefId, token, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling downloadInvoiceArtifact.');
        }
        if (artifactRefId === null || artifactRefId === undefined) {
            throw new Error('Required parameter artifactRefId was null or undefined when calling downloadInvoiceArtifact.');
        }
        if (token === null || token === undefined) {
            throw new Error('Required parameter token was null or undefined when calling downloadInvoiceArtifact.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'token', token, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/artifacts/${this.configuration.encodeParam({ name: "artifactRefId", value: artifactRefId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/download`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceArtifactDownloadControllerService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceArtifactDownloadControllerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceArtifactDownloadControllerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InvoiceSearchService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    searchInvoiceLines(partyId, q, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling searchInvoiceLines.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'partyId', partyId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'q', q, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/items/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchInvoices(pageable, q, observe = 'body', reportProgress = false, options) {
        if (pageable === null || pageable === undefined) {
            throw new Error('Required parameter pageable was null or undefined when calling searchInvoices.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'q', q, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageable', pageable, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceSearchService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceSearchService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoiceSearchService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PaymentService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    capturePayment(invoiceId, paymentId, captureAmountRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling capturePayment.');
        }
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling capturePayment.');
        }
        if (captureAmountRequest === null || captureAmountRequest === undefined) {
            throw new Error('Required parameter captureAmountRequest was null or undefined when calling capturePayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/capture`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: captureAmountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    initiatePayment(invoiceId, initiatePaymentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling initiatePayment.');
        }
        if (initiatePaymentRequest === null || initiatePaymentRequest === undefined) {
            throw new Error('Required parameter initiatePaymentRequest was null or undefined when calling initiatePayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: initiatePaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PaymentReversalService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listInvoiceRefunds(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling listInvoiceRefunds.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/refunds`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    refundPayment(invoiceId, paymentId, refundPaymentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling refundPayment.');
        }
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling refundPayment.');
        }
        if (refundPaymentRequest === null || refundPaymentRequest === undefined) {
            throw new Error('Required parameter refundPaymentRequest was null or undefined when calling refundPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/refunds`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: refundPaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    voidPayment(invoiceId, paymentId, voidPaymentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling voidPayment.');
        }
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling voidPayment.');
        }
        if (voidPaymentRequest === null || voidPaymentRequest === undefined) {
            throw new Error('Required parameter voidPaymentRequest was null or undefined when calling voidPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/void`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: voidPaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentReversalService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentReversalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentReversalService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ReceiptService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    generateReceipt(invoiceId, generateReceiptRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling generateReceipt.');
        }
        if (generateReceiptRequest === null || generateReceiptRequest === undefined) {
            throw new Error('Required parameter generateReceiptRequest was null or undefined when calling generateReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: generateReceiptRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordReceiptEmailDelivery(invoiceId, receiptId, emailDeliveryRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling recordReceiptEmailDelivery.');
        }
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling recordReceiptEmailDelivery.');
        }
        if (emailDeliveryRequest === null || emailDeliveryRequest === undefined) {
            throw new Error('Required parameter emailDeliveryRequest was null or undefined when calling recordReceiptEmailDelivery.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/email`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: emailDeliveryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordReceiptPrintDelivery(invoiceId, receiptId, printDeliveryRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling recordReceiptPrintDelivery.');
        }
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling recordReceiptPrintDelivery.');
        }
        if (printDeliveryRequest === null || printDeliveryRequest === undefined) {
            throw new Error('Required parameter printDeliveryRequest was null or undefined when calling recordReceiptPrintDelivery.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/print`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: printDeliveryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reprintReceipt(invoiceId, receiptId, reprintReceiptRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling reprintReceipt.');
        }
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling reprintReceipt.');
        }
        if (reprintReceiptRequest === null || reprintReceiptRequest === undefined) {
            throw new Error('Required parameter reprintReceiptRequest was null or undefined when calling reprintReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reprint`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reprintReceiptRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReceiptService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReceiptService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReceiptService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class StandaloneRefundService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createStandaloneInvoiceRefund(invoiceId, standaloneRefundRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling createStandaloneInvoiceRefund.');
        }
        if (standaloneRefundRequest === null || standaloneRefundRequest === undefined) {
            throw new Error('Required parameter standaloneRefundRequest was null or undefined when calling createStandaloneInvoiceRefund.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/refunds`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: standaloneRefundRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createStandalonePartyRefund(partyStandaloneRefundRequest, observe = 'body', reportProgress = false, options) {
        if (partyStandaloneRefundRequest === null || partyStandaloneRefundRequest === undefined) {
            throw new Error('Required parameter partyStandaloneRefundRequest was null or undefined when calling createStandalonePartyRefund.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/refunds`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: partyStandaloneRefundRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StandaloneRefundService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StandaloneRefundService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StandaloneRefundService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AdjustmentRequestTypeEnum;
(function (AdjustmentRequestTypeEnum) {
    AdjustmentRequestTypeEnum["Discount"] = "DISCOUNT";
    AdjustmentRequestTypeEnum["Fee"] = "FEE";
    AdjustmentRequestTypeEnum["Correction"] = "CORRECTION";
    AdjustmentRequestTypeEnum["Warranty"] = "WARRANTY";
})(AdjustmentRequestTypeEnum || (AdjustmentRequestTypeEnum = {}));
;
function isOptionalAdjustmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAdjustmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAdjustmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAdjustmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAdjustmentRequestPropertyNames('amount', 'authorizedBy', 'reason', 'type');
    const optionalStringProperties = createAdjustmentRequestOptionalProperties({ name: 'authorizedBy', nullable: false }, { name: 'externalReference', nullable: false }, { name: 'reason', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createAdjustmentRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createAdjustmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAdjustmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAdjustmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAdjustmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalApplicationPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApplicationPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApplicationOptionalProperties(...properties) {
    return properties;
}
function instanceOfApplication(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApplicationPropertyNames();
    const optionalStringProperties = createApplicationOptionalProperties({ name: 'appliedAt', nullable: false }, { name: 'invoiceId', nullable: false });
    const optionalNumberProperties = createApplicationOptionalProperties({ name: 'amountApplied', nullable: false });
    const optionalBooleanProperties = createApplicationOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApplicationPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApplicationPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApplicationPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalArtifactDownloadTokenPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createArtifactDownloadTokenPropertyNames(...propertyNames) {
    return propertyNames;
}
function createArtifactDownloadTokenOptionalProperties(...properties) {
    return properties;
}
function instanceOfArtifactDownloadToken(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createArtifactDownloadTokenPropertyNames();
    const optionalStringProperties = createArtifactDownloadTokenOptionalProperties({ name: 'downloadToken', nullable: false }, { name: 'expiresAt', nullable: false });
    const optionalNumberProperties = createArtifactDownloadTokenOptionalProperties();
    const optionalBooleanProperties = createArtifactDownloadTokenOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalArtifactDownloadTokenPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalArtifactDownloadTokenPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalArtifactDownloadTokenPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BillingRulesDTOInvoiceDeliveryMethodEnum;
(function (BillingRulesDTOInvoiceDeliveryMethodEnum) {
    BillingRulesDTOInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    BillingRulesDTOInvoiceDeliveryMethodEnum["Portal"] = "PORTAL";
    BillingRulesDTOInvoiceDeliveryMethodEnum["Mail"] = "MAIL";
})(BillingRulesDTOInvoiceDeliveryMethodEnum || (BillingRulesDTOInvoiceDeliveryMethodEnum = {}));
;
var BillingRulesDTOInvoiceGroupingStrategyEnum;
(function (BillingRulesDTOInvoiceGroupingStrategyEnum) {
    BillingRulesDTOInvoiceGroupingStrategyEnum["PerWorkorder"] = "PER_WORKORDER";
    BillingRulesDTOInvoiceGroupingStrategyEnum["PerVehicle"] = "PER_VEHICLE";
    BillingRulesDTOInvoiceGroupingStrategyEnum["SingleInvoice"] = "SINGLE_INVOICE";
})(BillingRulesDTOInvoiceGroupingStrategyEnum || (BillingRulesDTOInvoiceGroupingStrategyEnum = {}));
;
function isOptionalBillingRulesDTOPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingRulesDTOPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingRulesDTOOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingRulesDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingRulesDTOPropertyNames('createdAt', 'invoiceDeliveryMethod', 'invoiceGroupingStrategy', 'partyId', 'paymentTermsCode', 'purchaseOrderRequired', 'updatedAt', 'updatedBy', 'version');
    const optionalStringProperties = createBillingRulesDTOOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'id', nullable: false }, { name: 'invoiceDeliveryMethod', nullable: false }, { name: 'invoiceGroupingStrategy', nullable: false }, { name: 'partyId', nullable: false }, { name: 'paymentTermsCode', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'updatedBy', nullable: false });
    const optionalNumberProperties = createBillingRulesDTOOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createBillingRulesDTOOptionalProperties({ name: 'purchaseOrderRequired', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingRulesDTOPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingRulesDTOPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingRulesDTOPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCaptureAmountRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCaptureAmountRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCaptureAmountRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCaptureAmountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCaptureAmountRequestPropertyNames('amount', 'captureIdempotencyKey');
    const optionalStringProperties = createCaptureAmountRequestOptionalProperties({ name: 'captureIdempotencyKey', nullable: false });
    const optionalNumberProperties = createCaptureAmountRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createCaptureAmountRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCaptureAmountRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCaptureAmountRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCaptureAmountRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreateDepositRequestSourceTypeEnum;
(function (CreateDepositRequestSourceTypeEnum) {
    CreateDepositRequestSourceTypeEnum["Estimate"] = "ESTIMATE";
    CreateDepositRequestSourceTypeEnum["Workorder"] = "WORKORDER";
    CreateDepositRequestSourceTypeEnum["Order"] = "ORDER";
})(CreateDepositRequestSourceTypeEnum || (CreateDepositRequestSourceTypeEnum = {}));
;
function isOptionalCreateDepositRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateDepositRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateDepositRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateDepositRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateDepositRequestPropertyNames('amount', 'orderId', 'sourceId', 'sourceType');
    const optionalStringProperties = createCreateDepositRequestOptionalProperties({ name: 'currencyCode', nullable: false }, { name: 'orderId', nullable: false }, { name: 'partyId', nullable: false }, { name: 'sourceId', nullable: false }, { name: 'sourceType', nullable: false });
    const optionalNumberProperties = createCreateDepositRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createCreateDepositRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateDepositRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateDepositRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateDepositRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalDepositCreditResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDepositCreditResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createDepositCreditResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfDepositCreditResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDepositCreditResponsePropertyNames();
    const optionalStringProperties = createDepositCreditResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'currencyCode', nullable: false }, { name: 'depositCreditId', nullable: false }, { name: 'orderId', nullable: false }, { name: 'partyId', nullable: false }, { name: 'sourceId', nullable: false }, { name: 'sourceType', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createDepositCreditResponseOptionalProperties({ name: 'originalAmount', nullable: false }, { name: 'remainingBalance', nullable: false });
    const optionalBooleanProperties = createDepositCreditResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDepositCreditResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDepositCreditResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDepositCreditResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalElevateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createElevateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createElevateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfElevateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createElevateRequestPropertyNames('invoiceId', 'managerEmployeeNumber');
    const optionalStringProperties = createElevateRequestOptionalProperties({ name: 'invoiceId', nullable: false }, { name: 'managerEmployeeNumber', nullable: false });
    const optionalNumberProperties = createElevateRequestOptionalProperties();
    const optionalBooleanProperties = createElevateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalElevateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalElevateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalElevateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalElevateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createElevateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createElevateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfElevateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createElevateResponsePropertyNames('elevationToken', 'expiresAt');
    const optionalStringProperties = createElevateResponseOptionalProperties({ name: 'elevationToken', nullable: false }, { name: 'expiresAt', nullable: false });
    const optionalNumberProperties = createElevateResponseOptionalProperties();
    const optionalBooleanProperties = createElevateResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalElevateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalElevateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalElevateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EmailDeliveryRequestStatusEnum;
(function (EmailDeliveryRequestStatusEnum) {
    EmailDeliveryRequestStatusEnum["Success"] = "SUCCESS";
    EmailDeliveryRequestStatusEnum["Failed"] = "FAILED";
})(EmailDeliveryRequestStatusEnum || (EmailDeliveryRequestStatusEnum = {}));
;
function isOptionalEmailDeliveryRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmailDeliveryRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmailDeliveryRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmailDeliveryRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmailDeliveryRequestPropertyNames('emailAddress', 'status');
    const optionalStringProperties = createEmailDeliveryRequestOptionalProperties({ name: 'emailAddress', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createEmailDeliveryRequestOptionalProperties();
    const optionalBooleanProperties = createEmailDeliveryRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmailDeliveryRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmailDeliveryRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmailDeliveryRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFinalizationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFinalizationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFinalizationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfFinalizationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFinalizationRequestPropertyNames();
    const optionalStringProperties = createFinalizationRequestOptionalProperties({ name: 'managerApprovalCode', nullable: false }, { name: 'overrideReason', nullable: false });
    const optionalNumberProperties = createFinalizationRequestOptionalProperties();
    const optionalBooleanProperties = createFinalizationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFinalizationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFinalizationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFinalizationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGenerateReceiptRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGenerateReceiptRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGenerateReceiptRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGenerateReceiptRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGenerateReceiptRequestPropertyNames('paymentIntentId', 'templateId', 'templateVersion', 'terminalId');
    const optionalStringProperties = createGenerateReceiptRequestOptionalProperties({ name: 'paymentIntentId', nullable: false }, { name: 'templateId', nullable: false }, { name: 'templateVersion', nullable: false }, { name: 'terminalId', nullable: false });
    const optionalNumberProperties = createGenerateReceiptRequestOptionalProperties();
    const optionalBooleanProperties = createGenerateReceiptRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGenerateReceiptRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGenerateReceiptRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGenerateReceiptRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InitiatePaymentRequestPaymentFlowEnum;
(function (InitiatePaymentRequestPaymentFlowEnum) {
    InitiatePaymentRequestPaymentFlowEnum["SaleCapture"] = "SALE_CAPTURE";
    InitiatePaymentRequestPaymentFlowEnum["AuthOnly"] = "AUTH_ONLY";
})(InitiatePaymentRequestPaymentFlowEnum || (InitiatePaymentRequestPaymentFlowEnum = {}));
;
function isOptionalInitiatePaymentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInitiatePaymentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInitiatePaymentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfInitiatePaymentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInitiatePaymentRequestPropertyNames('amount', 'idempotencyKey', 'paymentFlow', 'paymentToken');
    const optionalStringProperties = createInitiatePaymentRequestOptionalProperties({ name: 'idempotencyKey', nullable: false }, { name: 'paymentFlow', nullable: false }, { name: 'paymentToken', nullable: false });
    const optionalNumberProperties = createInitiatePaymentRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createInitiatePaymentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInitiatePaymentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInitiatePaymentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInitiatePaymentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InitiatePaymentResponseStatusEnum;
(function (InitiatePaymentResponseStatusEnum) {
    InitiatePaymentResponseStatusEnum["Pending"] = "PENDING";
    InitiatePaymentResponseStatusEnum["Authorized"] = "AUTHORIZED";
    InitiatePaymentResponseStatusEnum["Captured"] = "CAPTURED";
    InitiatePaymentResponseStatusEnum["CaptureFailed"] = "CAPTURE_FAILED";
    InitiatePaymentResponseStatusEnum["Voided"] = "VOIDED";
    InitiatePaymentResponseStatusEnum["Expired"] = "EXPIRED";
})(InitiatePaymentResponseStatusEnum || (InitiatePaymentResponseStatusEnum = {}));
;
function isOptionalInitiatePaymentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInitiatePaymentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInitiatePaymentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInitiatePaymentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInitiatePaymentResponsePropertyNames('paymentIntentId', 'status');
    const optionalStringProperties = createInitiatePaymentResponseOptionalProperties({ name: 'gatewayProvider', nullable: false }, { name: 'gatewayResponse', nullable: false }, { name: 'paymentIntentId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createInitiatePaymentResponseOptionalProperties({ name: 'authorizedAmount', nullable: false }, { name: 'capturedAmount', nullable: false }, { name: 'voidedRemainderAmount', nullable: false });
    const optionalBooleanProperties = createInitiatePaymentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInitiatePaymentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInitiatePaymentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInitiatePaymentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InvoiceAdjustmentResponseTypeEnum;
(function (InvoiceAdjustmentResponseTypeEnum) {
    InvoiceAdjustmentResponseTypeEnum["Discount"] = "DISCOUNT";
    InvoiceAdjustmentResponseTypeEnum["Fee"] = "FEE";
    InvoiceAdjustmentResponseTypeEnum["Correction"] = "CORRECTION";
    InvoiceAdjustmentResponseTypeEnum["Warranty"] = "WARRANTY";
})(InvoiceAdjustmentResponseTypeEnum || (InvoiceAdjustmentResponseTypeEnum = {}));
;
function isOptionalInvoiceAdjustmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceAdjustmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceAdjustmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceAdjustmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceAdjustmentResponsePropertyNames();
    const optionalStringProperties = createInvoiceAdjustmentResponseOptionalProperties({ name: 'authorizedBy', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'externalReference', nullable: false }, { name: 'id', nullable: false }, { name: 'reason', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createInvoiceAdjustmentResponseOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createInvoiceAdjustmentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceAdjustmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceAdjustmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceAdjustmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceArtifactPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceArtifactPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceArtifactOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceArtifact(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceArtifactPropertyNames();
    const optionalStringProperties = createInvoiceArtifactOptionalProperties({ name: 'artifactRefId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'fileName', nullable: false }, { name: 'mimeType', nullable: false });
    const optionalNumberProperties = createInvoiceArtifactOptionalProperties();
    const optionalBooleanProperties = createInvoiceArtifactOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceArtifactPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceArtifactPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceArtifactPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalInvoiceCreationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceCreationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceCreationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceCreationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceCreationRequestPropertyNames();
    const optionalStringProperties = createInvoiceCreationRequestOptionalProperties({ name: 'approvalId', nullable: false }, { name: 'customerId', nullable: false }, { name: 'estimateId', nullable: false }, { name: 'idempotencyKey', nullable: false }, { name: 'locationId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createInvoiceCreationRequestOptionalProperties();
    const optionalBooleanProperties = createInvoiceCreationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceCreationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceCreationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceCreationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var InvoiceDetailsResponseStatusEnum;
(function (InvoiceDetailsResponseStatusEnum) {
    InvoiceDetailsResponseStatusEnum["Draft"] = "DRAFT";
    InvoiceDetailsResponseStatusEnum["Finalized"] = "FINALIZED";
    InvoiceDetailsResponseStatusEnum["Posted"] = "POSTED";
    InvoiceDetailsResponseStatusEnum["Error"] = "ERROR";
    InvoiceDetailsResponseStatusEnum["Cancelled"] = "CANCELLED";
})(InvoiceDetailsResponseStatusEnum || (InvoiceDetailsResponseStatusEnum = {}));
;
function isOptionalInvoiceDetailsResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceDetailsResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceDetailsResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceDetailsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceDetailsResponsePropertyNames('adjustmentEntries', 'items');
    const optionalStringProperties = createInvoiceDetailsResponseOptionalProperties({ name: 'approvalId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'estimateId', nullable: false }, { name: 'finalizedAt', nullable: false }, { name: 'finalizedBy', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'invoiceNumber', nullable: false }, { name: 'partyId', nullable: false }, { name: 'reversionReason', nullable: false }, { name: 'revertedAt', nullable: false }, { name: 'revertedBy', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'workorderId', nullable: false }, { name: 'workorderNumber', nullable: false });
    const optionalNumberProperties = createInvoiceDetailsResponseOptionalProperties({ name: 'adjustments', nullable: false }, { name: 'subtotal', nullable: false }, { name: 'tax', nullable: false }, { name: 'total', nullable: false });
    const optionalBooleanProperties = createInvoiceDetailsResponseOptionalProperties({ name: 'requiresManagerApproval', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceDetailsResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceDetailsResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceDetailsResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceGenerationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceGenerationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceGenerationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceGenerationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceGenerationResponsePropertyNames('createdAt', 'invoiceId', 'status', 'subtotal', 'taxAmount', 'totalAmount', 'workorderId');
    const optionalStringProperties = createInvoiceGenerationResponseOptionalProperties({ name: 'approvalId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'estimateId', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'status', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createInvoiceGenerationResponseOptionalProperties({ name: 'subtotal', nullable: false }, { name: 'taxAmount', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createInvoiceGenerationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceGenerationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceGenerationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceGenerationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceItemResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceItemResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceItemResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceItemResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceItemResponsePropertyNames();
    const optionalStringProperties = createInvoiceItemResponseOptionalProperties({ name: 'description', nullable: false }, { name: 'id', nullable: false }, { name: 'type', nullable: false }, { name: 'workorderItemId', nullable: false });
    const optionalNumberProperties = createInvoiceItemResponseOptionalProperties({ name: 'amount', nullable: false }, { name: 'quantity', nullable: false }, { name: 'unitPrice', nullable: false });
    const optionalBooleanProperties = createInvoiceItemResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceItemResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceItemResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceItemResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceLineItemPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceLineItemPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceLineItemOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceLineItem(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceLineItemPropertyNames('amount', 'description', 'quantity', 'unitPrice');
    const optionalStringProperties = createInvoiceLineItemOptionalProperties({ name: 'description', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createInvoiceLineItemOptionalProperties({ name: 'amount', nullable: false }, { name: 'quantity', nullable: false }, { name: 'unitPrice', nullable: false });
    const optionalBooleanProperties = createInvoiceLineItemOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceLineItemPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceLineItemPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceLineItemPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceLineSearchResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceLineSearchResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceLineSearchResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceLineSearchResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceLineSearchResultPropertyNames('invoiceId', 'invoiceItemId');
    const optionalStringProperties = createInvoiceLineSearchResultOptionalProperties({ name: 'description', nullable: false }, { name: 'invoiceCreatedAt', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'invoiceItemId', nullable: false }, { name: 'invoiceNumber', nullable: false }, { name: 'invoiceStatus', nullable: false }, { name: 'itemType', nullable: false }, { name: 'workorderItemId', nullable: false });
    const optionalNumberProperties = createInvoiceLineSearchResultOptionalProperties({ name: 'amount', nullable: false }, { name: 'quantity', nullable: false }, { name: 'unitPrice', nullable: false });
    const optionalBooleanProperties = createInvoiceLineSearchResultOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceLineSearchResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceLineSearchResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceLineSearchResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InvoiceRefundResponseReasonEnum;
(function (InvoiceRefundResponseReasonEnum) {
    InvoiceRefundResponseReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    InvoiceRefundResponseReasonEnum["ServiceError"] = "SERVICE_ERROR";
    InvoiceRefundResponseReasonEnum["Overcharge"] = "OVERCHARGE";
    InvoiceRefundResponseReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    InvoiceRefundResponseReasonEnum["Goodwill"] = "GOODWILL";
    InvoiceRefundResponseReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    InvoiceRefundResponseReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    InvoiceRefundResponseReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    InvoiceRefundResponseReasonEnum["Other"] = "OTHER";
})(InvoiceRefundResponseReasonEnum || (InvoiceRefundResponseReasonEnum = {}));
;
var InvoiceRefundResponseStatusEnum;
(function (InvoiceRefundResponseStatusEnum) {
    InvoiceRefundResponseStatusEnum["Pending"] = "PENDING";
    InvoiceRefundResponseStatusEnum["Completed"] = "COMPLETED";
    InvoiceRefundResponseStatusEnum["Failed"] = "FAILED";
})(InvoiceRefundResponseStatusEnum || (InvoiceRefundResponseStatusEnum = {}));
;
function isOptionalInvoiceRefundResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceRefundResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceRefundResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceRefundResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceRefundResponsePropertyNames();
    const optionalStringProperties = createInvoiceRefundResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'externalReference', nullable: false }, { name: 'gatewayReference', nullable: false }, { name: 'id', nullable: false }, { name: 'paymentIntentId', nullable: false }, { name: 'reason', nullable: false }, { name: 'requestedAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createInvoiceRefundResponseOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createInvoiceRefundResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceRefundResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceRefundResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceRefundResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InvoiceSearchResultStatusEnum;
(function (InvoiceSearchResultStatusEnum) {
    InvoiceSearchResultStatusEnum["Draft"] = "DRAFT";
    InvoiceSearchResultStatusEnum["Finalized"] = "FINALIZED";
    InvoiceSearchResultStatusEnum["Posted"] = "POSTED";
    InvoiceSearchResultStatusEnum["Error"] = "ERROR";
    InvoiceSearchResultStatusEnum["Cancelled"] = "CANCELLED";
})(InvoiceSearchResultStatusEnum || (InvoiceSearchResultStatusEnum = {}));
;
function isOptionalInvoiceSearchResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceSearchResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceSearchResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceSearchResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceSearchResultPropertyNames('invoiceId', 'status');
    const optionalStringProperties = createInvoiceSearchResultOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'customerName', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'invoiceNumber', nullable: false }, { name: 'status', nullable: false }, { name: 'workorderId', nullable: false }, { name: 'workorderNumber', nullable: false });
    const optionalNumberProperties = createInvoiceSearchResultOptionalProperties({ name: 'total', nullable: false });
    const optionalBooleanProperties = createInvoiceSearchResultOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceSearchResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceSearchResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceSearchResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var OrderInvoiceCreationRequestDepositSourceTypeEnum;
(function (OrderInvoiceCreationRequestDepositSourceTypeEnum) {
    OrderInvoiceCreationRequestDepositSourceTypeEnum["Estimate"] = "ESTIMATE";
    OrderInvoiceCreationRequestDepositSourceTypeEnum["Workorder"] = "WORKORDER";
    OrderInvoiceCreationRequestDepositSourceTypeEnum["Order"] = "ORDER";
})(OrderInvoiceCreationRequestDepositSourceTypeEnum || (OrderInvoiceCreationRequestDepositSourceTypeEnum = {}));
;
function isOptionalOrderInvoiceCreationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createOrderInvoiceCreationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createOrderInvoiceCreationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfOrderInvoiceCreationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createOrderInvoiceCreationRequestPropertyNames('lines', 'orderId', 'subtotal', 'taxAmount', 'totalAmount');
    const optionalStringProperties = createOrderInvoiceCreationRequestOptionalProperties({ name: 'customerId', nullable: false }, { name: 'depositSourceId', nullable: false }, { name: 'depositSourceType', nullable: false }, { name: 'locationId', nullable: false }, { name: 'orderId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createOrderInvoiceCreationRequestOptionalProperties({ name: 'depositAmount', nullable: false }, { name: 'subtotal', nullable: false }, { name: 'taxAmount', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createOrderInvoiceCreationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalOrderInvoiceCreationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalOrderInvoiceCreationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalOrderInvoiceCreationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalOrderInvoiceLineItemPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createOrderInvoiceLineItemPropertyNames(...propertyNames) {
    return propertyNames;
}
function createOrderInvoiceLineItemOptionalProperties(...properties) {
    return properties;
}
function instanceOfOrderInvoiceLineItem(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createOrderInvoiceLineItemPropertyNames('amount', 'description', 'quantity', 'unitPrice');
    const optionalStringProperties = createOrderInvoiceLineItemOptionalProperties({ name: 'description', nullable: false }, { name: 'orderLineId', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createOrderInvoiceLineItemOptionalProperties({ name: 'amount', nullable: false }, { name: 'quantity', nullable: false }, { name: 'taxAmount', nullable: false }, { name: 'unitPrice', nullable: false });
    const optionalBooleanProperties = createOrderInvoiceLineItemOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalOrderInvoiceLineItemPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalOrderInvoiceLineItemPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalOrderInvoiceLineItemPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalOrderInvoiceResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createOrderInvoiceResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createOrderInvoiceResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfOrderInvoiceResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createOrderInvoiceResponsePropertyNames('existing', 'invoiceId', 'status');
    const optionalStringProperties = createOrderInvoiceResponseOptionalProperties({ name: 'invoiceId', nullable: false }, { name: 'invoiceNumber', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createOrderInvoiceResponseOptionalProperties({ name: 'depositApplied', nullable: false }, { name: 'subtotal', nullable: false }, { name: 'taxAmount', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createOrderInvoiceResponseOptionalProperties({ name: 'existing', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalOrderInvoiceResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalOrderInvoiceResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalOrderInvoiceResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageInvoiceSearchResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageInvoiceSearchResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageInvoiceSearchResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageInvoiceSearchResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageInvoiceSearchResultPropertyNames();
    const optionalStringProperties = createPageInvoiceSearchResultOptionalProperties();
    const optionalNumberProperties = createPageInvoiceSearchResultOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageInvoiceSearchResultOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageInvoiceSearchResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageInvoiceSearchResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageInvoiceSearchResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPageablePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageablePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageable(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageablePropertyNames();
    const optionalStringProperties = createPageableOptionalProperties();
    const optionalNumberProperties = createPageableOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false });
    const optionalBooleanProperties = createPageableOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageablePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageablePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageablePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageableObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageableObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageableObjectPropertyNames();
    const optionalStringProperties = createPageableObjectOptionalProperties();
    const optionalNumberProperties = createPageableObjectOptionalProperties({ name: 'offset', nullable: false }, { name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createPageableObjectOptionalProperties({ name: 'paged', nullable: false }, { name: 'unpaged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartyStandaloneRefundRequestReasonEnum;
(function (PartyStandaloneRefundRequestReasonEnum) {
    PartyStandaloneRefundRequestReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    PartyStandaloneRefundRequestReasonEnum["ServiceError"] = "SERVICE_ERROR";
    PartyStandaloneRefundRequestReasonEnum["Overcharge"] = "OVERCHARGE";
    PartyStandaloneRefundRequestReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    PartyStandaloneRefundRequestReasonEnum["Goodwill"] = "GOODWILL";
    PartyStandaloneRefundRequestReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    PartyStandaloneRefundRequestReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    PartyStandaloneRefundRequestReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    PartyStandaloneRefundRequestReasonEnum["Other"] = "OTHER";
})(PartyStandaloneRefundRequestReasonEnum || (PartyStandaloneRefundRequestReasonEnum = {}));
;
function isOptionalPartyStandaloneRefundRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyStandaloneRefundRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyStandaloneRefundRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyStandaloneRefundRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyStandaloneRefundRequestPropertyNames('amount', 'partyId', 'reason');
    const optionalStringProperties = createPartyStandaloneRefundRequestOptionalProperties({ name: 'externalReference', nullable: false }, { name: 'notes', nullable: false }, { name: 'partyId', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createPartyStandaloneRefundRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createPartyStandaloneRefundRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyStandaloneRefundRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyStandaloneRefundRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyStandaloneRefundRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PrintDeliveryRequestStatusEnum;
(function (PrintDeliveryRequestStatusEnum) {
    PrintDeliveryRequestStatusEnum["Success"] = "SUCCESS";
    PrintDeliveryRequestStatusEnum["Failed"] = "FAILED";
})(PrintDeliveryRequestStatusEnum || (PrintDeliveryRequestStatusEnum = {}));
;
function isOptionalPrintDeliveryRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPrintDeliveryRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPrintDeliveryRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPrintDeliveryRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPrintDeliveryRequestPropertyNames('status');
    const optionalStringProperties = createPrintDeliveryRequestOptionalProperties({ name: 'status', nullable: false });
    const optionalNumberProperties = createPrintDeliveryRequestOptionalProperties();
    const optionalBooleanProperties = createPrintDeliveryRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPrintDeliveryRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPrintDeliveryRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPrintDeliveryRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReceiptResponseStatusEnum;
(function (ReceiptResponseStatusEnum) {
    ReceiptResponseStatusEnum["Generated"] = "GENERATED";
})(ReceiptResponseStatusEnum || (ReceiptResponseStatusEnum = {}));
;
function isOptionalReceiptResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceiptResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceiptResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceiptResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceiptResponsePropertyNames('receiptId', 'status');
    const optionalStringProperties = createReceiptResponseOptionalProperties({ name: 'receiptId', nullable: false }, { name: 'reference', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createReceiptResponseOptionalProperties();
    const optionalBooleanProperties = createReceiptResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceiptResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceiptResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceiptResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RefundPaymentRequestReasonEnum;
(function (RefundPaymentRequestReasonEnum) {
    RefundPaymentRequestReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    RefundPaymentRequestReasonEnum["ServiceError"] = "SERVICE_ERROR";
    RefundPaymentRequestReasonEnum["Overcharge"] = "OVERCHARGE";
    RefundPaymentRequestReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    RefundPaymentRequestReasonEnum["Goodwill"] = "GOODWILL";
    RefundPaymentRequestReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    RefundPaymentRequestReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    RefundPaymentRequestReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    RefundPaymentRequestReasonEnum["Other"] = "OTHER";
})(RefundPaymentRequestReasonEnum || (RefundPaymentRequestReasonEnum = {}));
;
function isOptionalRefundPaymentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRefundPaymentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRefundPaymentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRefundPaymentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRefundPaymentRequestPropertyNames('amount', 'reason');
    const optionalStringProperties = createRefundPaymentRequestOptionalProperties({ name: 'externalReference', nullable: false }, { name: 'notes', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createRefundPaymentRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createRefundPaymentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRefundPaymentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRefundPaymentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRefundPaymentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RefundPaymentResponseReasonEnum;
(function (RefundPaymentResponseReasonEnum) {
    RefundPaymentResponseReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    RefundPaymentResponseReasonEnum["ServiceError"] = "SERVICE_ERROR";
    RefundPaymentResponseReasonEnum["Overcharge"] = "OVERCHARGE";
    RefundPaymentResponseReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    RefundPaymentResponseReasonEnum["Goodwill"] = "GOODWILL";
    RefundPaymentResponseReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    RefundPaymentResponseReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    RefundPaymentResponseReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    RefundPaymentResponseReasonEnum["Other"] = "OTHER";
})(RefundPaymentResponseReasonEnum || (RefundPaymentResponseReasonEnum = {}));
;
var RefundPaymentResponseStatusEnum;
(function (RefundPaymentResponseStatusEnum) {
    RefundPaymentResponseStatusEnum["Pending"] = "PENDING";
    RefundPaymentResponseStatusEnum["Completed"] = "COMPLETED";
    RefundPaymentResponseStatusEnum["Failed"] = "FAILED";
})(RefundPaymentResponseStatusEnum || (RefundPaymentResponseStatusEnum = {}));
;
function isOptionalRefundPaymentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRefundPaymentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createRefundPaymentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfRefundPaymentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRefundPaymentResponsePropertyNames('refundId', 'status');
    const optionalStringProperties = createRefundPaymentResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'externalReference', nullable: false }, { name: 'gatewayReference', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'notes', nullable: false }, { name: 'partyId', nullable: false }, { name: 'paymentIntentId', nullable: false }, { name: 'reason', nullable: false }, { name: 'refundId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createRefundPaymentResponseOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createRefundPaymentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRefundPaymentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRefundPaymentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRefundPaymentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReprintReceiptRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReprintReceiptRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReprintReceiptRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReprintReceiptRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReprintReceiptRequestPropertyNames('reason');
    const optionalStringProperties = createReprintReceiptRequestOptionalProperties({ name: 'reason', nullable: false });
    const optionalNumberProperties = createReprintReceiptRequestOptionalProperties();
    const optionalBooleanProperties = createReprintReceiptRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReprintReceiptRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReprintReceiptRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReprintReceiptRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRevertRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRevertRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRevertRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRevertRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRevertRequestPropertyNames('managerApprovalCode', 'reason');
    const optionalStringProperties = createRevertRequestOptionalProperties({ name: 'managerApprovalCode', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createRevertRequestOptionalProperties();
    const optionalBooleanProperties = createRevertRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRevertRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRevertRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRevertRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSortObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSortObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSortObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSortObjectPropertyNames();
    const optionalStringProperties = createSortObjectOptionalProperties();
    const optionalNumberProperties = createSortObjectOptionalProperties();
    const optionalBooleanProperties = createSortObjectOptionalProperties({ name: 'empty', nullable: false }, { name: 'sorted', nullable: false }, { name: 'unsorted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var StandaloneRefundRequestReasonEnum;
(function (StandaloneRefundRequestReasonEnum) {
    StandaloneRefundRequestReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    StandaloneRefundRequestReasonEnum["ServiceError"] = "SERVICE_ERROR";
    StandaloneRefundRequestReasonEnum["Overcharge"] = "OVERCHARGE";
    StandaloneRefundRequestReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    StandaloneRefundRequestReasonEnum["Goodwill"] = "GOODWILL";
    StandaloneRefundRequestReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    StandaloneRefundRequestReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    StandaloneRefundRequestReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    StandaloneRefundRequestReasonEnum["Other"] = "OTHER";
})(StandaloneRefundRequestReasonEnum || (StandaloneRefundRequestReasonEnum = {}));
;
function isOptionalStandaloneRefundRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStandaloneRefundRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createStandaloneRefundRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfStandaloneRefundRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStandaloneRefundRequestPropertyNames('amount', 'reason');
    const optionalStringProperties = createStandaloneRefundRequestOptionalProperties({ name: 'externalReference', nullable: false }, { name: 'notes', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createStandaloneRefundRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createStandaloneRefundRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStandaloneRefundRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStandaloneRefundRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStandaloneRefundRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VoidPaymentRequestReasonEnum;
(function (VoidPaymentRequestReasonEnum) {
    VoidPaymentRequestReasonEnum["CustomerRequest"] = "CUSTOMER_REQUEST";
    VoidPaymentRequestReasonEnum["DuplicateAuthorization"] = "DUPLICATE_AUTHORIZATION";
    VoidPaymentRequestReasonEnum["EntryError"] = "ENTRY_ERROR";
    VoidPaymentRequestReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    VoidPaymentRequestReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    VoidPaymentRequestReasonEnum["Other"] = "OTHER";
})(VoidPaymentRequestReasonEnum || (VoidPaymentRequestReasonEnum = {}));
;
function isOptionalVoidPaymentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVoidPaymentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVoidPaymentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfVoidPaymentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVoidPaymentRequestPropertyNames('reason');
    const optionalStringProperties = createVoidPaymentRequestOptionalProperties({ name: 'notes', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createVoidPaymentRequestOptionalProperties();
    const optionalBooleanProperties = createVoidPaymentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVoidPaymentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVoidPaymentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVoidPaymentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AdjustmentRequestTypeEnum, ApiModule, BASE_PATH, BillingAuthorizationService, BillingRulesDTOInvoiceDeliveryMethodEnum, BillingRulesDTOInvoiceGroupingStrategyEnum, BillingRulesService, COLLECTION_FORMATS, Configuration, CreateDepositRequestSourceTypeEnum, DepositCreditsService, EmailDeliveryRequestStatusEnum, InitiatePaymentRequestPaymentFlowEnum, InitiatePaymentResponseStatusEnum, InvoiceAdjustmentResponseTypeEnum, InvoiceArtifactControllerService, InvoiceArtifactDownloadControllerService, InvoiceDetailsResponseStatusEnum, InvoiceRefundResponseReasonEnum, InvoiceRefundResponseStatusEnum, InvoiceSearchResultStatusEnum, InvoiceSearchService, InvoiceService, OrderInvoiceCreationRequestDepositSourceTypeEnum, PartyStandaloneRefundRequestReasonEnum, PaymentReversalService, PaymentService, PrintDeliveryRequestStatusEnum, ReceiptResponseStatusEnum, ReceiptService, RefundPaymentRequestReasonEnum, RefundPaymentResponseReasonEnum, RefundPaymentResponseStatusEnum, StandaloneRefundRequestReasonEnum, StandaloneRefundService, VoidPaymentRequestReasonEnum, instanceOfAdjustmentRequest, instanceOfApiError, instanceOfApplication, instanceOfArtifactDownloadToken, instanceOfBillingRulesDTO, instanceOfCaptureAmountRequest, instanceOfCreateDepositRequest, instanceOfDepositCreditResponse, instanceOfElevateRequest, instanceOfElevateResponse, instanceOfEmailDeliveryRequest, instanceOfFieldError, instanceOfFinalizationRequest, instanceOfGenerateReceiptRequest, instanceOfInitiatePaymentRequest, instanceOfInitiatePaymentResponse, instanceOfInvoiceAdjustmentResponse, instanceOfInvoiceArtifact, instanceOfInvoiceCreationRequest, instanceOfInvoiceDetailsResponse, instanceOfInvoiceGenerationResponse, instanceOfInvoiceItemResponse, instanceOfInvoiceLineItem, instanceOfInvoiceLineSearchResult, instanceOfInvoiceRefundResponse, instanceOfInvoiceSearchResult, instanceOfOrderInvoiceCreationRequest, instanceOfOrderInvoiceLineItem, instanceOfOrderInvoiceResponse, instanceOfPageInvoiceSearchResult, instanceOfPageable, instanceOfPageableObject, instanceOfPartyStandaloneRefundRequest, instanceOfPrintDeliveryRequest, instanceOfReceiptResponse, instanceOfRefundPaymentRequest, instanceOfRefundPaymentResponse, instanceOfReprintReceiptRequest, instanceOfRevertRequest, instanceOfSortObject, instanceOfStandaloneRefundRequest, instanceOfVoidPaymentRequest, provideApi };
//# sourceMappingURL=durion-sdk-invoice.mjs.map
