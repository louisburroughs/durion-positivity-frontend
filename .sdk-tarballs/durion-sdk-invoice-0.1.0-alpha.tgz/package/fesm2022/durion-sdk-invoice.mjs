import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://localhost:8086';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class BillingRulesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getBillingRules(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/billing/rules/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertBillingRules(partyId, billingRulesDTO, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertBillingRules.');
        }
        if (billingRulesDTO === null || billingRulesDTO === undefined) {
            throw new Error('Required parameter billingRulesDTO was null or undefined when calling upsertBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/billing/rules/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: billingRulesDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: BillingRulesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: BillingRulesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: BillingRulesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InvoiceService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    applyAdjustment(invoiceId, adjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling applyAdjustment.');
        }
        if (adjustmentRequest === null || adjustmentRequest === undefined) {
            throw new Error('Required parameter adjustmentRequest was null or undefined when calling applyAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: adjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createInvoice(invoiceCreationRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceCreationRequest === null || invoiceCreationRequest === undefined) {
            throw new Error('Required parameter invoiceCreationRequest was null or undefined when calling createInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: invoiceCreationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    finalizeInvoice(invoiceId, finalizationRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling finalizeInvoice.');
        }
        if (finalizationRequest === null || finalizationRequest === undefined) {
            throw new Error('Required parameter finalizationRequest was null or undefined when calling finalizeInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/finalize`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: finalizationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getInvoice(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling getInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revertInvoice(invoiceId, revertRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling revertInvoice.');
        }
        if (revertRequest === null || revertRequest === undefined) {
            throw new Error('Required parameter revertRequest was null or undefined when calling revertInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/revert`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: revertRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: InvoiceService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: InvoiceService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: InvoiceService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PaymentService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    capturePayment(invoiceId, paymentId, captureAmountRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling capturePayment.');
        }
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling capturePayment.');
        }
        if (captureAmountRequest === null || captureAmountRequest === undefined) {
            throw new Error('Required parameter captureAmountRequest was null or undefined when calling capturePayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/capture`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: captureAmountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    initiatePayment(invoiceId, initiatePaymentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling initiatePayment.');
        }
        if (initiatePaymentRequest === null || initiatePaymentRequest === undefined) {
            throw new Error('Required parameter initiatePaymentRequest was null or undefined when calling initiatePayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: initiatePaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PaymentService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PaymentService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PaymentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PaymentReversalService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    refundPayment(invoiceId, paymentId, refundPaymentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling refundPayment.');
        }
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling refundPayment.');
        }
        if (refundPaymentRequest === null || refundPaymentRequest === undefined) {
            throw new Error('Required parameter refundPaymentRequest was null or undefined when calling refundPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/refunds`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: refundPaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    voidPayment(invoiceId, paymentId, voidPaymentRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling voidPayment.');
        }
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling voidPayment.');
        }
        if (voidPaymentRequest === null || voidPaymentRequest === undefined) {
            throw new Error('Required parameter voidPaymentRequest was null or undefined when calling voidPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/void`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: voidPaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PaymentReversalService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PaymentReversalService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PaymentReversalService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ReceiptService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    generateReceipt(invoiceId, generateReceiptRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling generateReceipt.');
        }
        if (generateReceiptRequest === null || generateReceiptRequest === undefined) {
            throw new Error('Required parameter generateReceiptRequest was null or undefined when calling generateReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: generateReceiptRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordPrintDelivery(invoiceId, receiptId, printDeliveryRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling recordPrintDelivery.');
        }
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling recordPrintDelivery.');
        }
        if (printDeliveryRequest === null || printDeliveryRequest === undefined) {
            throw new Error('Required parameter printDeliveryRequest was null or undefined when calling recordPrintDelivery.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/print`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: printDeliveryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reprintReceipt(invoiceId, receiptId, reprintReceiptRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling reprintReceipt.');
        }
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling reprintReceipt.');
        }
        if (reprintReceiptRequest === null || reprintReceiptRequest === undefined) {
            throw new Error('Required parameter reprintReceiptRequest was null or undefined when calling reprintReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reprint`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reprintReceiptRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    sendEmailReceipt(invoiceId, receiptId, emailDeliveryRequest, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling sendEmailReceipt.');
        }
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling sendEmailReceipt.');
        }
        if (emailDeliveryRequest === null || emailDeliveryRequest === undefined) {
            throw new Error('Required parameter emailDeliveryRequest was null or undefined when calling sendEmailReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/invoices/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/email`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: emailDeliveryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ReceiptService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ReceiptService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ReceiptService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

const APIS = [BillingRulesService, InvoiceService, PaymentService, PaymentReversalService, ReceiptService];

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AdjustmentRequestTypeEnum;
(function (AdjustmentRequestTypeEnum) {
    AdjustmentRequestTypeEnum["Discount"] = "DISCOUNT";
    AdjustmentRequestTypeEnum["Fee"] = "FEE";
    AdjustmentRequestTypeEnum["Correction"] = "CORRECTION";
})(AdjustmentRequestTypeEnum || (AdjustmentRequestTypeEnum = {}));
;
function AdjustmentRequestFromJSON(json) { return json; }
function AdjustmentRequestFromJSONTyped(json, _) { return json; }
function AdjustmentRequestToJSON(value) { return value; }
function AdjustmentRequestTypeEnumFromJSON(json) { return json; }
function AdjustmentRequestTypeEnumFromJSONTyped(json, _) { return json; }
function AdjustmentRequestTypeEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BillingRulesDTOInvoiceDeliveryMethodEnum;
(function (BillingRulesDTOInvoiceDeliveryMethodEnum) {
    BillingRulesDTOInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    BillingRulesDTOInvoiceDeliveryMethodEnum["Portal"] = "PORTAL";
    BillingRulesDTOInvoiceDeliveryMethodEnum["Mail"] = "MAIL";
})(BillingRulesDTOInvoiceDeliveryMethodEnum || (BillingRulesDTOInvoiceDeliveryMethodEnum = {}));
;
var BillingRulesDTOInvoiceGroupingStrategyEnum;
(function (BillingRulesDTOInvoiceGroupingStrategyEnum) {
    BillingRulesDTOInvoiceGroupingStrategyEnum["PerWorkorder"] = "PER_WORKORDER";
    BillingRulesDTOInvoiceGroupingStrategyEnum["PerVehicle"] = "PER_VEHICLE";
    BillingRulesDTOInvoiceGroupingStrategyEnum["SingleInvoice"] = "SINGLE_INVOICE";
})(BillingRulesDTOInvoiceGroupingStrategyEnum || (BillingRulesDTOInvoiceGroupingStrategyEnum = {}));
;
function BillingRulesDTOFromJSON(json) { return json; }
function BillingRulesDTOFromJSONTyped(json, _) { return json; }
function BillingRulesDTOToJSON(value) { return value; }
function BillingRulesDTOInvoiceDeliveryMethodEnumFromJSON(json) { return json; }
function BillingRulesDTOInvoiceDeliveryMethodEnumFromJSONTyped(json, _) { return json; }
function BillingRulesDTOInvoiceDeliveryMethodEnumToJSON(value) { return value; }
function BillingRulesDTOInvoiceGroupingStrategyEnumFromJSON(json) { return json; }
function BillingRulesDTOInvoiceGroupingStrategyEnumFromJSONTyped(json, _) { return json; }
function BillingRulesDTOInvoiceGroupingStrategyEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function CaptureAmountRequestFromJSON(json) { return json; }
function CaptureAmountRequestFromJSONTyped(json, _) { return json; }
function CaptureAmountRequestToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EmailDeliveryRequestStatusEnum;
(function (EmailDeliveryRequestStatusEnum) {
    EmailDeliveryRequestStatusEnum["Success"] = "SUCCESS";
    EmailDeliveryRequestStatusEnum["Failed"] = "FAILED";
})(EmailDeliveryRequestStatusEnum || (EmailDeliveryRequestStatusEnum = {}));
;
function EmailDeliveryRequestFromJSON(json) { return json; }
function EmailDeliveryRequestFromJSONTyped(json, _) { return json; }
function EmailDeliveryRequestToJSON(value) { return value; }
function EmailDeliveryRequestStatusEnumFromJSON(json) { return json; }
function EmailDeliveryRequestStatusEnumFromJSONTyped(json, _) { return json; }
function EmailDeliveryRequestStatusEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function FinalizationRequestFromJSON(json) { return json; }
function FinalizationRequestFromJSONTyped(json, _) { return json; }
function FinalizationRequestToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function GenerateReceiptRequestFromJSON(json) { return json; }
function GenerateReceiptRequestFromJSONTyped(json, _) { return json; }
function GenerateReceiptRequestToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InitiatePaymentRequestPaymentFlowEnum;
(function (InitiatePaymentRequestPaymentFlowEnum) {
    InitiatePaymentRequestPaymentFlowEnum["SaleCapture"] = "SALE_CAPTURE";
    InitiatePaymentRequestPaymentFlowEnum["AuthOnly"] = "AUTH_ONLY";
})(InitiatePaymentRequestPaymentFlowEnum || (InitiatePaymentRequestPaymentFlowEnum = {}));
;
function InitiatePaymentRequestFromJSON(json) { return json; }
function InitiatePaymentRequestFromJSONTyped(json, _) { return json; }
function InitiatePaymentRequestToJSON(value) { return value; }
function InitiatePaymentRequestPaymentFlowEnumFromJSON(json) { return json; }
function InitiatePaymentRequestPaymentFlowEnumFromJSONTyped(json, _) { return json; }
function InitiatePaymentRequestPaymentFlowEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InitiatePaymentResponseStatusEnum;
(function (InitiatePaymentResponseStatusEnum) {
    InitiatePaymentResponseStatusEnum["Pending"] = "PENDING";
    InitiatePaymentResponseStatusEnum["Authorized"] = "AUTHORIZED";
    InitiatePaymentResponseStatusEnum["Captured"] = "CAPTURED";
    InitiatePaymentResponseStatusEnum["CaptureFailed"] = "CAPTURE_FAILED";
    InitiatePaymentResponseStatusEnum["Voided"] = "VOIDED";
    InitiatePaymentResponseStatusEnum["Expired"] = "EXPIRED";
})(InitiatePaymentResponseStatusEnum || (InitiatePaymentResponseStatusEnum = {}));
;
function InitiatePaymentResponseFromJSON(json) { return json; }
function InitiatePaymentResponseFromJSONTyped(json, _) { return json; }
function InitiatePaymentResponseToJSON(value) { return value; }
function InitiatePaymentResponseStatusEnumFromJSON(json) { return json; }
function InitiatePaymentResponseStatusEnumFromJSONTyped(json, _) { return json; }
function InitiatePaymentResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InvoiceAdjustmentResponseTypeEnum;
(function (InvoiceAdjustmentResponseTypeEnum) {
    InvoiceAdjustmentResponseTypeEnum["Discount"] = "DISCOUNT";
    InvoiceAdjustmentResponseTypeEnum["Fee"] = "FEE";
    InvoiceAdjustmentResponseTypeEnum["Correction"] = "CORRECTION";
})(InvoiceAdjustmentResponseTypeEnum || (InvoiceAdjustmentResponseTypeEnum = {}));
;
function InvoiceAdjustmentResponseFromJSON(json) { return json; }
function InvoiceAdjustmentResponseFromJSONTyped(json, _) { return json; }
function InvoiceAdjustmentResponseToJSON(value) { return value; }
function InvoiceAdjustmentResponseTypeEnumFromJSON(json) { return json; }
function InvoiceAdjustmentResponseTypeEnumFromJSONTyped(json, _) { return json; }
function InvoiceAdjustmentResponseTypeEnumToJSON(value) { return value; }

function InvoiceCreationRequestFromJSON(json) { return json; }
function InvoiceCreationRequestFromJSONTyped(json, _) { return json; }
function InvoiceCreationRequestToJSON(value) { return value; }

var InvoiceDetailsResponseStatusEnum;
(function (InvoiceDetailsResponseStatusEnum) {
    InvoiceDetailsResponseStatusEnum["Draft"] = "DRAFT";
    InvoiceDetailsResponseStatusEnum["Finalized"] = "FINALIZED";
    InvoiceDetailsResponseStatusEnum["Posted"] = "POSTED";
    InvoiceDetailsResponseStatusEnum["Error"] = "ERROR";
})(InvoiceDetailsResponseStatusEnum || (InvoiceDetailsResponseStatusEnum = {}));
;
function InvoiceDetailsResponseFromJSON(json) { return json; }
function InvoiceDetailsResponseFromJSONTyped(json, _) { return json; }
function InvoiceDetailsResponseToJSON(value) { return value; }
function InvoiceDetailsResponseStatusEnumFromJSON(json) { return json; }
function InvoiceDetailsResponseStatusEnumFromJSONTyped(json, _) { return json; }
function InvoiceDetailsResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function InvoiceGenerationResponseFromJSON(json) { return json; }
function InvoiceGenerationResponseFromJSONTyped(json, _) { return json; }
function InvoiceGenerationResponseToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function InvoiceItemResponseFromJSON(json) { return json; }
function InvoiceItemResponseFromJSONTyped(json, _) { return json; }
function InvoiceItemResponseToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function InvoiceLineItemFromJSON(json) { return json; }
function InvoiceLineItemFromJSONTyped(json, _) { return json; }
function InvoiceLineItemToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PrintDeliveryRequestStatusEnum;
(function (PrintDeliveryRequestStatusEnum) {
    PrintDeliveryRequestStatusEnum["Success"] = "SUCCESS";
    PrintDeliveryRequestStatusEnum["Failed"] = "FAILED";
})(PrintDeliveryRequestStatusEnum || (PrintDeliveryRequestStatusEnum = {}));
;
function PrintDeliveryRequestFromJSON(json) { return json; }
function PrintDeliveryRequestFromJSONTyped(json, _) { return json; }
function PrintDeliveryRequestToJSON(value) { return value; }
function PrintDeliveryRequestStatusEnumFromJSON(json) { return json; }
function PrintDeliveryRequestStatusEnumFromJSONTyped(json, _) { return json; }
function PrintDeliveryRequestStatusEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReceiptResponseStatusEnum;
(function (ReceiptResponseStatusEnum) {
    ReceiptResponseStatusEnum["Generated"] = "GENERATED";
})(ReceiptResponseStatusEnum || (ReceiptResponseStatusEnum = {}));
;
function ReceiptResponseFromJSON(json) { return json; }
function ReceiptResponseFromJSONTyped(json, _) { return json; }
function ReceiptResponseToJSON(value) { return value; }
function ReceiptResponseStatusEnumFromJSON(json) { return json; }
function ReceiptResponseStatusEnumFromJSONTyped(json, _) { return json; }
function ReceiptResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RefundPaymentRequestReasonEnum;
(function (RefundPaymentRequestReasonEnum) {
    RefundPaymentRequestReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    RefundPaymentRequestReasonEnum["ServiceError"] = "SERVICE_ERROR";
    RefundPaymentRequestReasonEnum["Overcharge"] = "OVERCHARGE";
    RefundPaymentRequestReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    RefundPaymentRequestReasonEnum["Goodwill"] = "GOODWILL";
    RefundPaymentRequestReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    RefundPaymentRequestReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    RefundPaymentRequestReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    RefundPaymentRequestReasonEnum["Other"] = "OTHER";
})(RefundPaymentRequestReasonEnum || (RefundPaymentRequestReasonEnum = {}));
;
function RefundPaymentRequestFromJSON(json) { return json; }
function RefundPaymentRequestFromJSONTyped(json, _) { return json; }
function RefundPaymentRequestToJSON(value) { return value; }
function RefundPaymentRequestReasonEnumFromJSON(json) { return json; }
function RefundPaymentRequestReasonEnumFromJSONTyped(json, _) { return json; }
function RefundPaymentRequestReasonEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RefundPaymentResponseReasonEnum;
(function (RefundPaymentResponseReasonEnum) {
    RefundPaymentResponseReasonEnum["CustomerReturn"] = "CUSTOMER_RETURN";
    RefundPaymentResponseReasonEnum["ServiceError"] = "SERVICE_ERROR";
    RefundPaymentResponseReasonEnum["Overcharge"] = "OVERCHARGE";
    RefundPaymentResponseReasonEnum["DamagedGoods"] = "DAMAGED_GOODS";
    RefundPaymentResponseReasonEnum["Goodwill"] = "GOODWILL";
    RefundPaymentResponseReasonEnum["ChargebackAvoidance"] = "CHARGEBACK_AVOIDANCE";
    RefundPaymentResponseReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    RefundPaymentResponseReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    RefundPaymentResponseReasonEnum["Other"] = "OTHER";
})(RefundPaymentResponseReasonEnum || (RefundPaymentResponseReasonEnum = {}));
;
var RefundPaymentResponseStatusEnum;
(function (RefundPaymentResponseStatusEnum) {
    RefundPaymentResponseStatusEnum["Pending"] = "PENDING";
    RefundPaymentResponseStatusEnum["Completed"] = "COMPLETED";
    RefundPaymentResponseStatusEnum["Failed"] = "FAILED";
})(RefundPaymentResponseStatusEnum || (RefundPaymentResponseStatusEnum = {}));
;
function RefundPaymentResponseFromJSON(json) { return json; }
function RefundPaymentResponseFromJSONTyped(json, _) { return json; }
function RefundPaymentResponseToJSON(value) { return value; }
function RefundPaymentResponseReasonEnumFromJSON(json) { return json; }
function RefundPaymentResponseReasonEnumFromJSONTyped(json, _) { return json; }
function RefundPaymentResponseReasonEnumToJSON(value) { return value; }
function RefundPaymentResponseStatusEnumFromJSON(json) { return json; }
function RefundPaymentResponseStatusEnumFromJSONTyped(json, _) { return json; }
function RefundPaymentResponseStatusEnumToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function ReprintReceiptRequestFromJSON(json) { return json; }
function ReprintReceiptRequestFromJSONTyped(json, _) { return json; }
function ReprintReceiptRequestToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function RevertRequestFromJSON(json) { return json; }
function RevertRequestFromJSONTyped(json, _) { return json; }
function RevertRequestToJSON(value) { return value; }

/**
 * POS Invoice API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VoidPaymentRequestReasonEnum;
(function (VoidPaymentRequestReasonEnum) {
    VoidPaymentRequestReasonEnum["CustomerRequest"] = "CUSTOMER_REQUEST";
    VoidPaymentRequestReasonEnum["DuplicateAuthorization"] = "DUPLICATE_AUTHORIZATION";
    VoidPaymentRequestReasonEnum["EntryError"] = "ENTRY_ERROR";
    VoidPaymentRequestReasonEnum["FraudPrevention"] = "FRAUD_PREVENTION";
    VoidPaymentRequestReasonEnum["ManagerDiscretion"] = "MANAGER_DISCRETION";
    VoidPaymentRequestReasonEnum["Other"] = "OTHER";
})(VoidPaymentRequestReasonEnum || (VoidPaymentRequestReasonEnum = {}));
;
function VoidPaymentRequestFromJSON(json) { return json; }
function VoidPaymentRequestFromJSONTyped(json, _) { return json; }
function VoidPaymentRequestToJSON(value) { return value; }
function VoidPaymentRequestReasonEnumFromJSON(json) { return json; }
function VoidPaymentRequestReasonEnumFromJSONTyped(json, _) { return json; }
function VoidPaymentRequestReasonEnumToJSON(value) { return value; }

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { APIS, AdjustmentRequestFromJSON, AdjustmentRequestFromJSONTyped, AdjustmentRequestToJSON, AdjustmentRequestTypeEnum, AdjustmentRequestTypeEnumFromJSON, AdjustmentRequestTypeEnumFromJSONTyped, AdjustmentRequestTypeEnumToJSON, ApiModule, BASE_PATH, BillingRulesDTOFromJSON, BillingRulesDTOFromJSONTyped, BillingRulesDTOInvoiceDeliveryMethodEnum, BillingRulesDTOInvoiceDeliveryMethodEnumFromJSON, BillingRulesDTOInvoiceDeliveryMethodEnumFromJSONTyped, BillingRulesDTOInvoiceDeliveryMethodEnumToJSON, BillingRulesDTOInvoiceGroupingStrategyEnum, BillingRulesDTOInvoiceGroupingStrategyEnumFromJSON, BillingRulesDTOInvoiceGroupingStrategyEnumFromJSONTyped, BillingRulesDTOInvoiceGroupingStrategyEnumToJSON, BillingRulesDTOToJSON, BillingRulesService, COLLECTION_FORMATS, CaptureAmountRequestFromJSON, CaptureAmountRequestFromJSONTyped, CaptureAmountRequestToJSON, Configuration, EmailDeliveryRequestFromJSON, EmailDeliveryRequestFromJSONTyped, EmailDeliveryRequestStatusEnum, EmailDeliveryRequestStatusEnumFromJSON, EmailDeliveryRequestStatusEnumFromJSONTyped, EmailDeliveryRequestStatusEnumToJSON, EmailDeliveryRequestToJSON, FinalizationRequestFromJSON, FinalizationRequestFromJSONTyped, FinalizationRequestToJSON, GenerateReceiptRequestFromJSON, GenerateReceiptRequestFromJSONTyped, GenerateReceiptRequestToJSON, InitiatePaymentRequestFromJSON, InitiatePaymentRequestFromJSONTyped, InitiatePaymentRequestPaymentFlowEnum, InitiatePaymentRequestPaymentFlowEnumFromJSON, InitiatePaymentRequestPaymentFlowEnumFromJSONTyped, InitiatePaymentRequestPaymentFlowEnumToJSON, InitiatePaymentRequestToJSON, InitiatePaymentResponseFromJSON, InitiatePaymentResponseFromJSONTyped, InitiatePaymentResponseStatusEnum, InitiatePaymentResponseStatusEnumFromJSON, InitiatePaymentResponseStatusEnumFromJSONTyped, InitiatePaymentResponseStatusEnumToJSON, InitiatePaymentResponseToJSON, InvoiceAdjustmentResponseFromJSON, InvoiceAdjustmentResponseFromJSONTyped, InvoiceAdjustmentResponseToJSON, InvoiceAdjustmentResponseTypeEnum, InvoiceAdjustmentResponseTypeEnumFromJSON, InvoiceAdjustmentResponseTypeEnumFromJSONTyped, InvoiceAdjustmentResponseTypeEnumToJSON, InvoiceCreationRequestFromJSON, InvoiceCreationRequestFromJSONTyped, InvoiceCreationRequestToJSON, InvoiceDetailsResponseFromJSON, InvoiceDetailsResponseFromJSONTyped, InvoiceDetailsResponseStatusEnum, InvoiceDetailsResponseStatusEnumFromJSON, InvoiceDetailsResponseStatusEnumFromJSONTyped, InvoiceDetailsResponseStatusEnumToJSON, InvoiceDetailsResponseToJSON, InvoiceGenerationResponseFromJSON, InvoiceGenerationResponseFromJSONTyped, InvoiceGenerationResponseToJSON, InvoiceItemResponseFromJSON, InvoiceItemResponseFromJSONTyped, InvoiceItemResponseToJSON, InvoiceLineItemFromJSON, InvoiceLineItemFromJSONTyped, InvoiceLineItemToJSON, InvoiceService, PaymentReversalService, PaymentService, PrintDeliveryRequestFromJSON, PrintDeliveryRequestFromJSONTyped, PrintDeliveryRequestStatusEnum, PrintDeliveryRequestStatusEnumFromJSON, PrintDeliveryRequestStatusEnumFromJSONTyped, PrintDeliveryRequestStatusEnumToJSON, PrintDeliveryRequestToJSON, ReceiptResponseFromJSON, ReceiptResponseFromJSONTyped, ReceiptResponseStatusEnum, ReceiptResponseStatusEnumFromJSON, ReceiptResponseStatusEnumFromJSONTyped, ReceiptResponseStatusEnumToJSON, ReceiptResponseToJSON, ReceiptService, RefundPaymentRequestFromJSON, RefundPaymentRequestFromJSONTyped, RefundPaymentRequestReasonEnum, RefundPaymentRequestReasonEnumFromJSON, RefundPaymentRequestReasonEnumFromJSONTyped, RefundPaymentRequestReasonEnumToJSON, RefundPaymentRequestToJSON, RefundPaymentResponseFromJSON, RefundPaymentResponseFromJSONTyped, RefundPaymentResponseReasonEnum, RefundPaymentResponseReasonEnumFromJSON, RefundPaymentResponseReasonEnumFromJSONTyped, RefundPaymentResponseReasonEnumToJSON, RefundPaymentResponseStatusEnum, RefundPaymentResponseStatusEnumFromJSON, RefundPaymentResponseStatusEnumFromJSONTyped, RefundPaymentResponseStatusEnumToJSON, RefundPaymentResponseToJSON, ReprintReceiptRequestFromJSON, ReprintReceiptRequestFromJSONTyped, ReprintReceiptRequestToJSON, RevertRequestFromJSON, RevertRequestFromJSONTyped, RevertRequestToJSON, VoidPaymentRequestFromJSON, VoidPaymentRequestFromJSONTyped, VoidPaymentRequestReasonEnum, VoidPaymentRequestReasonEnumFromJSON, VoidPaymentRequestReasonEnumFromJSONTyped, VoidPaymentRequestReasonEnumToJSON, VoidPaymentRequestToJSON, provideApi };
//# sourceMappingURL=durion-sdk-invoice.mjs.map
