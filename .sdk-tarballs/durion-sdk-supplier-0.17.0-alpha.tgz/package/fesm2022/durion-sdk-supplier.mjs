import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/supplier';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierAuthConfigsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createAuthConfig(vendorProfileId, authConfigRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling createAuthConfig.');
        }
        if (authConfigRequest === null || authConfigRequest === undefined) {
            throw new Error('Required parameter authConfigRequest was null or undefined when calling createAuthConfig.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/auth-configs`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: authConfigRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteAuthConfig(vendorProfileId, authConfigId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling deleteAuthConfig.');
        }
        if (authConfigId === null || authConfigId === undefined) {
            throw new Error('Required parameter authConfigId was null or undefined when calling deleteAuthConfig.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/auth-configs/${this.configuration.encodeParam({ name: "authConfigId", value: authConfigId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listAuthConfigs(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listAuthConfigs.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/auth-configs`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateAuthConfig(vendorProfileId, authConfigId, authConfigRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling updateAuthConfig.');
        }
        if (authConfigId === null || authConfigId === undefined) {
            throw new Error('Required parameter authConfigId was null or undefined when calling updateAuthConfig.');
        }
        if (authConfigRequest === null || authConfigRequest === undefined) {
            throw new Error('Required parameter authConfigRequest was null or undefined when calling updateAuthConfig.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/auth-configs/${this.configuration.encodeParam({ name: "authConfigId", value: authConfigId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: authConfigRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierAuthConfigsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierAuthConfigsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierAuthConfigsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierCommercialAccountsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCommercialAccount(vendorProfileId, commercialAccountRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling createCommercialAccount.');
        }
        if (commercialAccountRequest === null || commercialAccountRequest === undefined) {
            throw new Error('Required parameter commercialAccountRequest was null or undefined when calling createCommercialAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/accounts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: commercialAccountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteCommercialAccount(vendorProfileId, accountId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling deleteCommercialAccount.');
        }
        if (accountId === null || accountId === undefined) {
            throw new Error('Required parameter accountId was null or undefined when calling deleteCommercialAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/accounts/${this.configuration.encodeParam({ name: "accountId", value: accountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCommercialAccounts(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listCommercialAccounts.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/accounts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCommercialAccount(vendorProfileId, accountId, commercialAccountRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling updateCommercialAccount.');
        }
        if (accountId === null || accountId === undefined) {
            throw new Error('Required parameter accountId was null or undefined when calling updateCommercialAccount.');
        }
        if (commercialAccountRequest === null || commercialAccountRequest === undefined) {
            throw new Error('Required parameter commercialAccountRequest was null or undefined when calling updateCommercialAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/accounts/${this.configuration.encodeParam({ name: "accountId", value: accountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: commercialAccountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierCommercialAccountsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierCommercialAccountsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierCommercialAccountsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierEndpointBindingsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createEndpointBinding(vendorProfileId, endpointBindingRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling createEndpointBinding.');
        }
        if (endpointBindingRequest === null || endpointBindingRequest === undefined) {
            throw new Error('Required parameter endpointBindingRequest was null or undefined when calling createEndpointBinding.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/bindings`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: endpointBindingRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteEndpointBinding(vendorProfileId, bindingId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling deleteEndpointBinding.');
        }
        if (bindingId === null || bindingId === undefined) {
            throw new Error('Required parameter bindingId was null or undefined when calling deleteEndpointBinding.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/bindings/${this.configuration.encodeParam({ name: "bindingId", value: bindingId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listEndpointBindings(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listEndpointBindings.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/bindings`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateEndpointBinding(vendorProfileId, bindingId, endpointBindingRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling updateEndpointBinding.');
        }
        if (bindingId === null || bindingId === undefined) {
            throw new Error('Required parameter bindingId was null or undefined when calling updateEndpointBinding.');
        }
        if (endpointBindingRequest === null || endpointBindingRequest === undefined) {
            throw new Error('Required parameter endpointBindingRequest was null or undefined when calling updateEndpointBinding.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/bindings/${this.configuration.encodeParam({ name: "bindingId", value: bindingId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: endpointBindingRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierEndpointBindingsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierEndpointBindingsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierEndpointBindingsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierExchangeAuditService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSupplierExchange(exchangeAuditId, observe = 'body', reportProgress = false, options) {
        if (exchangeAuditId === null || exchangeAuditId === undefined) {
            throw new Error('Required parameter exchangeAuditId was null or undefined when calling getSupplierExchange.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/audit/exchanges/${this.configuration.encodeParam({ name: "exchangeAuditId", value: exchangeAuditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierExchangeAccesses(exchangeAuditId, page, size, observe = 'body', reportProgress = false, options) {
        if (exchangeAuditId === null || exchangeAuditId === undefined) {
            throw new Error('Required parameter exchangeAuditId was null or undefined when calling listSupplierExchangeAccesses.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/audit/exchanges/${this.configuration.encodeParam({ name: "exchangeAuditId", value: exchangeAuditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/accesses`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierExchanges(vendorProfileId, from, to, capability, page, size, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listSupplierExchanges.');
        }
        if (from === null || from === undefined) {
            throw new Error('Required parameter from was null or undefined when calling listSupplierExchanges.');
        }
        if (to === null || to === undefined) {
            throw new Error('Required parameter to was null or undefined when calling listSupplierExchanges.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vendorProfileId', vendorProfileId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'from', from, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'to', to, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'capability', capability, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/audit/exchanges`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    readSupplierExchangePayload(exchangeAuditId, observe = 'body', reportProgress = false, options) {
        if (exchangeAuditId === null || exchangeAuditId === undefined) {
            throw new Error('Required parameter exchangeAuditId was null or undefined when calling readSupplierExchangePayload.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/audit/exchanges/${this.configuration.encodeParam({ name: "exchangeAuditId", value: exchangeAuditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/payload`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    traceSupplierCorrelation(correlationId, page, size, observe = 'body', reportProgress = false, options) {
        if (correlationId === null || correlationId === undefined) {
            throw new Error('Required parameter correlationId was null or undefined when calling traceSupplierCorrelation.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/audit/exchanges/by-correlation/${this.configuration.encodeParam({ name: "correlationId", value: correlationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierExchangeAuditService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierExchangeAuditService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierExchangeAuditService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierFleetAuthorizationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getFleetWorkorderAuthorization(supplierRef, workorderId, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling getFleetWorkorderAuthorization.');
        }
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling getFleetWorkorderAuthorization.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/fleet/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/authorizations/${this.configuration.encodeParam({ name: "workorderId", value: workorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listFleetAuthorizationsNeedingReview(limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/fleet/authorizations/reviews`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listFleetContracts(supplierRef, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling listFleetContracts.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/fleet/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/contracts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listFleetPolicies(supplierRef, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling listFleetPolicies.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/fleet/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/policies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    lookupFleetVehicle(supplierRef, vehicleIdent, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling lookupFleetVehicle.');
        }
        if (vehicleIdent === null || vehicleIdent === undefined) {
            throw new Error('Required parameter vehicleIdent was null or undefined when calling lookupFleetVehicle.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/fleet/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/vehicles/${this.configuration.encodeParam({ name: "vehicleIdent", value: vehicleIdent, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    requestFleetWorkorderAuthorization(supplierRef, fleetAuthorizationRequestBody, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling requestFleetWorkorderAuthorization.');
        }
        if (fleetAuthorizationRequestBody === null || fleetAuthorizationRequestBody === undefined) {
            throw new Error('Required parameter fleetAuthorizationRequestBody was null or undefined when calling requestFleetWorkorderAuthorization.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/fleet/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/authorizations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: fleetAuthorizationRequestBody,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierFleetAuthorizationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierFleetAuthorizationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierFleetAuthorizationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierInvoicesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    fetchSupplierInvoices(supplierRef, fromDate, toDate, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling fetchSupplierInvoices.');
        }
        if (fromDate === null || fromDate === undefined) {
            throw new Error('Required parameter fromDate was null or undefined when calling fetchSupplierInvoices.');
        }
        if (toDate === null || toDate === undefined) {
            throw new Error('Required parameter toDate was null or undefined when calling fetchSupplierInvoices.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'fromDate', fromDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'toDate', toDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/invoices/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/fetches`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierInvoicesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierInvoicesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierInvoicesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierMarketingCatalogService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    importMarketingCatalog(supplierRef, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling importMarketingCatalog.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/mktcat/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/imports`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listMarketingCatalogVariants(supplierRef, limit, hasUnresolvedImages, observe = 'body', reportProgress = false, options) {
        if (supplierRef === null || supplierRef === undefined) {
            throw new Error('Required parameter supplierRef was null or undefined when calling listMarketingCatalogVariants.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'hasUnresolvedImages', hasUnresolvedImages, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/mktcat/${this.configuration.encodeParam({ name: "supplierRef", value: supplierRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/variants`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierMarketingCatalogService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierMarketingCatalogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierMarketingCatalogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierOrderTransmissionService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSupplierTransmission(transmissionIntentId, observe = 'body', reportProgress = false, options) {
        if (transmissionIntentId === null || transmissionIntentId === undefined) {
            throw new Error('Required parameter transmissionIntentId was null or undefined when calling getSupplierTransmission.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/transmissions/${this.configuration.encodeParam({ name: "transmissionIntentId", value: transmissionIntentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierTransmissionsForPurchaseOrder(purchaseOrderId, observe = 'body', reportProgress = false, options) {
        if (purchaseOrderId === null || purchaseOrderId === undefined) {
            throw new Error('Required parameter purchaseOrderId was null or undefined when calling listSupplierTransmissionsForPurchaseOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/transmissions/purchase-order/${this.configuration.encodeParam({ name: "purchaseOrderId", value: purchaseOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveSupplierTransmission(transmissionIntentId, transmissionResolutionRequest, observe = 'body', reportProgress = false, options) {
        if (transmissionIntentId === null || transmissionIntentId === undefined) {
            throw new Error('Required parameter transmissionIntentId was null or undefined when calling resolveSupplierTransmission.');
        }
        if (transmissionResolutionRequest === null || transmissionResolutionRequest === undefined) {
            throw new Error('Required parameter transmissionResolutionRequest was null or undefined when calling resolveSupplierTransmission.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/transmissions/${this.configuration.encodeParam({ name: "transmissionIntentId", value: transmissionIntentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: transmissionResolutionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchSupplierTransmissions(attemptState, vendorProfileId, search, dateFrom, dateTo, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'attemptState', attemptState, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vendorProfileId', vendorProfileId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'search', search, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateFrom', dateFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateTo', dateTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/transmissions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierOrderTransmissionService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierOrderTransmissionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierOrderTransmissionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierPriceCatalogService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSupplierPriceCatalogFreshness(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling getSupplierPriceCatalogFreshness.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/price-catalog/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/freshness`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierPriceCatalogImports(vendorProfileId, bindingId, status, dateFrom, dateTo, page, size, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listSupplierPriceCatalogImports.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'bindingId', bindingId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateFrom', dateFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateTo', dateTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/price-catalog/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/imports`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierPriceCatalogUnmatchedLines(vendorProfileId, reason, search, dateFrom, dateTo, resolved, page, size, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listSupplierPriceCatalogUnmatchedLines.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'reason', reason, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'search', search, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateFrom', dateFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateTo', dateTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'resolved', resolved, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/price-catalog/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/unmatched-lines`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reapplySupplierPriceCatalogQuarantine(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling reapplySupplierPriceCatalogQuarantine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/price-catalog/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/quarantine/reapply`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    triggerSupplierPriceCatalogImport(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling triggerSupplierPriceCatalogImport.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/price-catalog/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/imports`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierPriceCatalogService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierPriceCatalogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierPriceCatalogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierStockAvailabilityService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSupplierStockAvailability(deliveryLocationId, productId, sku, quantity, observe = 'body', reportProgress = false, options) {
        if (deliveryLocationId === null || deliveryLocationId === undefined) {
            throw new Error('Required parameter deliveryLocationId was null or undefined when calling getSupplierStockAvailability.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productId', productId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'deliveryLocationId', deliveryLocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'quantity', quantity, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/stock/availability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockAvailabilityService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockAvailabilityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockAvailabilityService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierStockInquiryService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    inquireSupplierStock(stockInquiryRequest, observe = 'body', reportProgress = false, options) {
        if (stockInquiryRequest === null || stockInquiryRequest === undefined) {
            throw new Error('Required parameter stockInquiryRequest was null or undefined when calling inquireSupplierStock.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/stock/inquiries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: stockInquiryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockInquiryService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockInquiryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockInquiryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierStockSnapshotsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getLatestSupplierStockSnapshot(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling getLatestSupplierStockSnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/vendor-profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/stock-snapshots/latest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierStockSnapshotLines(vendorProfileId, snapshotId, search, page, size, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling listSupplierStockSnapshotLines.');
        }
        if (snapshotId === null || snapshotId === undefined) {
            throw new Error('Required parameter snapshotId was null or undefined when calling listSupplierStockSnapshotLines.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'search', search, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/vendor-profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/stock-snapshots/${this.configuration.encodeParam({ name: "snapshotId", value: snapshotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/lines`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockSnapshotsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockSnapshotsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockSnapshotsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierVendorProfilesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createVendorProfile(vendorProfileRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileRequest === null || vendorProfileRequest === undefined) {
            throw new Error('Required parameter vendorProfileRequest was null or undefined when calling createVendorProfile.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: vendorProfileRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteVendorProfile(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling deleteVendorProfile.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getVendorProfile(vendorProfileId, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling getVendorProfile.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listVendorProfiles(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateVendorProfile(vendorProfileId, vendorProfileRequest, observe = 'body', reportProgress = false, options) {
        if (vendorProfileId === null || vendorProfileId === undefined) {
            throw new Error('Required parameter vendorProfileId was null or undefined when calling updateVendorProfile.');
        }
        if (vendorProfileRequest === null || vendorProfileRequest === undefined) {
            throw new Error('Required parameter vendorProfileRequest was null or undefined when calling updateVendorProfile.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/supplier/admin/profiles/${this.configuration.encodeParam({ name: "vendorProfileId", value: vendorProfileId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: vendorProfileRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierVendorProfilesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierVendorProfilesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierVendorProfilesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AuthConfigRequestTypeEnum;
(function (AuthConfigRequestTypeEnum) {
    AuthConfigRequestTypeEnum["BasicPlusApikey"] = "BASIC_PLUS_APIKEY";
    AuthConfigRequestTypeEnum["Oauth2ClientCredentials"] = "OAUTH2_CLIENT_CREDENTIALS";
    AuthConfigRequestTypeEnum["Bearer"] = "BEARER";
})(AuthConfigRequestTypeEnum || (AuthConfigRequestTypeEnum = {}));
;
function isOptionalAuthConfigRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuthConfigRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuthConfigRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuthConfigRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuthConfigRequestPropertyNames();
    const optionalStringProperties = createAuthConfigRequestOptionalProperties({ name: 'apiKeyHeader', nullable: false }, { name: 'apiKeyRef', nullable: false }, { name: 'bearerTokenRef', nullable: false }, { name: 'clientIdRef', nullable: false }, { name: 'clientSecretRef', nullable: false }, { name: 'name', nullable: false }, { name: 'passwordRef', nullable: false }, { name: 'tokenUrlRef', nullable: false }, { name: 'type', nullable: false }, { name: 'usernameRef', nullable: false });
    const optionalNumberProperties = createAuthConfigRequestOptionalProperties();
    const optionalBooleanProperties = createAuthConfigRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuthConfigRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuthConfigRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuthConfigRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AuthConfigViewTypeEnum;
(function (AuthConfigViewTypeEnum) {
    AuthConfigViewTypeEnum["BasicPlusApikey"] = "BASIC_PLUS_APIKEY";
    AuthConfigViewTypeEnum["Oauth2ClientCredentials"] = "OAUTH2_CLIENT_CREDENTIALS";
    AuthConfigViewTypeEnum["Bearer"] = "BEARER";
})(AuthConfigViewTypeEnum || (AuthConfigViewTypeEnum = {}));
;
function isOptionalAuthConfigViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuthConfigViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuthConfigViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuthConfigView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuthConfigViewPropertyNames();
    const optionalStringProperties = createAuthConfigViewOptionalProperties({ name: 'apiKeyHeader', nullable: false }, { name: 'authConfigId', nullable: false }, { name: 'name', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createAuthConfigViewOptionalProperties();
    const optionalBooleanProperties = createAuthConfigViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuthConfigViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuthConfigViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuthConfigViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CommercialAccountRequestRoleEnum;
(function (CommercialAccountRequestRoleEnum) {
    CommercialAccountRequestRoleEnum["Billing"] = "BILLING";
    CommercialAccountRequestRoleEnum["Delivery"] = "DELIVERY";
})(CommercialAccountRequestRoleEnum || (CommercialAccountRequestRoleEnum = {}));
;
function isOptionalCommercialAccountRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCommercialAccountRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCommercialAccountRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCommercialAccountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCommercialAccountRequestPropertyNames();
    const optionalStringProperties = createCommercialAccountRequestOptionalProperties({ name: 'accountNumber', nullable: false }, { name: 'agencyCode', nullable: false }, { name: 'deliveryLocationId', nullable: false }, { name: 'role', nullable: false });
    const optionalNumberProperties = createCommercialAccountRequestOptionalProperties();
    const optionalBooleanProperties = createCommercialAccountRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCommercialAccountRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCommercialAccountRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCommercialAccountRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CommercialAccountViewRoleEnum;
(function (CommercialAccountViewRoleEnum) {
    CommercialAccountViewRoleEnum["Billing"] = "BILLING";
    CommercialAccountViewRoleEnum["Delivery"] = "DELIVERY";
})(CommercialAccountViewRoleEnum || (CommercialAccountViewRoleEnum = {}));
;
function isOptionalCommercialAccountViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCommercialAccountViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCommercialAccountViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfCommercialAccountView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCommercialAccountViewPropertyNames();
    const optionalStringProperties = createCommercialAccountViewOptionalProperties({ name: 'accountId', nullable: false }, { name: 'accountNumber', nullable: false }, { name: 'agencyCode', nullable: false }, { name: 'deliveryLocationId', nullable: false }, { name: 'role', nullable: false });
    const optionalNumberProperties = createCommercialAccountViewOptionalProperties();
    const optionalBooleanProperties = createCommercialAccountViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCommercialAccountViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCommercialAccountViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCommercialAccountViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EndpointBindingRequestCaptureLevelEnum;
(function (EndpointBindingRequestCaptureLevelEnum) {
    EndpointBindingRequestCaptureLevelEnum["Full"] = "FULL";
    EndpointBindingRequestCaptureLevelEnum["Redacted"] = "REDACTED";
    EndpointBindingRequestCaptureLevelEnum["MetadataOnly"] = "METADATA_ONLY";
})(EndpointBindingRequestCaptureLevelEnum || (EndpointBindingRequestCaptureLevelEnum = {}));
;
var EndpointBindingRequestRedactionClassificationsEnum;
(function (EndpointBindingRequestRedactionClassificationsEnum) {
    EndpointBindingRequestRedactionClassificationsEnum["CustomerIdentifier"] = "CUSTOMER_IDENTIFIER";
    EndpointBindingRequestRedactionClassificationsEnum["CommercialPricing"] = "COMMERCIAL_PRICING";
})(EndpointBindingRequestRedactionClassificationsEnum || (EndpointBindingRequestRedactionClassificationsEnum = {}));
;
function isOptionalEndpointBindingRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEndpointBindingRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEndpointBindingRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfEndpointBindingRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEndpointBindingRequestPropertyNames();
    const optionalStringProperties = createEndpointBindingRequestOptionalProperties({ name: 'authConfigName', nullable: false }, { name: 'baseUrl', nullable: false }, { name: 'capability', nullable: false }, { name: 'captureLevel', nullable: false }, { name: 'path', nullable: false }, { name: 'protocolFamily', nullable: false }, { name: 'schedule', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createEndpointBindingRequestOptionalProperties();
    const optionalBooleanProperties = createEndpointBindingRequestOptionalProperties({ name: 'enabled', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEndpointBindingRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEndpointBindingRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEndpointBindingRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EndpointBindingViewCaptureLevelEnum;
(function (EndpointBindingViewCaptureLevelEnum) {
    EndpointBindingViewCaptureLevelEnum["Full"] = "FULL";
    EndpointBindingViewCaptureLevelEnum["Redacted"] = "REDACTED";
    EndpointBindingViewCaptureLevelEnum["MetadataOnly"] = "METADATA_ONLY";
})(EndpointBindingViewCaptureLevelEnum || (EndpointBindingViewCaptureLevelEnum = {}));
;
var EndpointBindingViewRedactionClassificationsEnum;
(function (EndpointBindingViewRedactionClassificationsEnum) {
    EndpointBindingViewRedactionClassificationsEnum["CustomerIdentifier"] = "CUSTOMER_IDENTIFIER";
    EndpointBindingViewRedactionClassificationsEnum["CommercialPricing"] = "COMMERCIAL_PRICING";
})(EndpointBindingViewRedactionClassificationsEnum || (EndpointBindingViewRedactionClassificationsEnum = {}));
;
function isOptionalEndpointBindingViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEndpointBindingViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEndpointBindingViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfEndpointBindingView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEndpointBindingViewPropertyNames();
    const optionalStringProperties = createEndpointBindingViewOptionalProperties({ name: 'authConfigName', nullable: false }, { name: 'baseUrl', nullable: false }, { name: 'bindingId', nullable: false }, { name: 'capability', nullable: false }, { name: 'captureLevel', nullable: false }, { name: 'path', nullable: false }, { name: 'protocolFamily', nullable: false }, { name: 'schedule', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createEndpointBindingViewOptionalProperties();
    const optionalBooleanProperties = createEndpointBindingViewOptionalProperties({ name: 'enabled', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEndpointBindingViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEndpointBindingViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEndpointBindingViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ExchangeAuditAccessViewAccessKindEnum;
(function (ExchangeAuditAccessViewAccessKindEnum) {
    ExchangeAuditAccessViewAccessKindEnum["PayloadRead"] = "PAYLOAD_READ";
})(ExchangeAuditAccessViewAccessKindEnum || (ExchangeAuditAccessViewAccessKindEnum = {}));
;
var ExchangeAuditAccessViewPayloadOutcomeEnum;
(function (ExchangeAuditAccessViewPayloadOutcomeEnum) {
    ExchangeAuditAccessViewPayloadOutcomeEnum["Decrypted"] = "DECRYPTED";
    ExchangeAuditAccessViewPayloadOutcomeEnum["Unreadable"] = "UNREADABLE";
    ExchangeAuditAccessViewPayloadOutcomeEnum["NotCaptured"] = "NOT_CAPTURED";
})(ExchangeAuditAccessViewPayloadOutcomeEnum || (ExchangeAuditAccessViewPayloadOutcomeEnum = {}));
;
function isOptionalExchangeAuditAccessViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExchangeAuditAccessViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createExchangeAuditAccessViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfExchangeAuditAccessView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExchangeAuditAccessViewPropertyNames();
    const optionalStringProperties = createExchangeAuditAccessViewOptionalProperties({ name: 'accessKind', nullable: false }, { name: 'accessedAt', nullable: false }, { name: 'accessedBy', nullable: false }, { name: 'auditAccessId', nullable: false }, { name: 'capability', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'exchangeAuditId', nullable: false }, { name: 'payloadOutcome', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createExchangeAuditAccessViewOptionalProperties();
    const optionalBooleanProperties = createExchangeAuditAccessViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExchangeAuditAccessViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExchangeAuditAccessViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExchangeAuditAccessViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ExchangeAuditPayloadViewCaptureLevelEnum;
(function (ExchangeAuditPayloadViewCaptureLevelEnum) {
    ExchangeAuditPayloadViewCaptureLevelEnum["Full"] = "FULL";
    ExchangeAuditPayloadViewCaptureLevelEnum["Redacted"] = "REDACTED";
    ExchangeAuditPayloadViewCaptureLevelEnum["MetadataOnly"] = "METADATA_ONLY";
})(ExchangeAuditPayloadViewCaptureLevelEnum || (ExchangeAuditPayloadViewCaptureLevelEnum = {}));
;
function isOptionalExchangeAuditPayloadViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExchangeAuditPayloadViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createExchangeAuditPayloadViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfExchangeAuditPayloadView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExchangeAuditPayloadViewPropertyNames();
    const optionalStringProperties = createExchangeAuditPayloadViewOptionalProperties({ name: 'captureLevel', nullable: false }, { name: 'exchangeAuditId', nullable: false }, { name: 'requestPayload', nullable: false }, { name: 'responsePayload', nullable: false });
    const optionalNumberProperties = createExchangeAuditPayloadViewOptionalProperties();
    const optionalBooleanProperties = createExchangeAuditPayloadViewOptionalProperties({ name: 'redacted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExchangeAuditPayloadViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExchangeAuditPayloadViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExchangeAuditPayloadViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ExchangeAuditSummaryCaptureLevelEnum;
(function (ExchangeAuditSummaryCaptureLevelEnum) {
    ExchangeAuditSummaryCaptureLevelEnum["Full"] = "FULL";
    ExchangeAuditSummaryCaptureLevelEnum["Redacted"] = "REDACTED";
    ExchangeAuditSummaryCaptureLevelEnum["MetadataOnly"] = "METADATA_ONLY";
})(ExchangeAuditSummaryCaptureLevelEnum || (ExchangeAuditSummaryCaptureLevelEnum = {}));
;
function isOptionalExchangeAuditSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExchangeAuditSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createExchangeAuditSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfExchangeAuditSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExchangeAuditSummaryPropertyNames();
    const optionalStringProperties = createExchangeAuditSummaryOptionalProperties({ name: 'bindingId', nullable: false }, { name: 'capability', nullable: false }, { name: 'captureLevel', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'endpointUri', nullable: false }, { name: 'exchangeAuditId', nullable: false }, { name: 'failureDetail', nullable: false }, { name: 'httpMethod', nullable: false }, { name: 'outcome', nullable: false }, { name: 'payloadsPurgedAt', nullable: false }, { name: 'protocolFamily', nullable: false }, { name: 'protocolVersion', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createExchangeAuditSummaryOptionalProperties({ name: 'attempt', nullable: false }, { name: 'durationMs', nullable: false }, { name: 'httpStatus', nullable: false });
    const optionalBooleanProperties = createExchangeAuditSummaryOptionalProperties({ name: 'requestPayloadPresent', nullable: false }, { name: 'responsePayloadPresent', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExchangeAuditSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExchangeAuditSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExchangeAuditSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalFleetAuthorizationRequestBodyPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFleetAuthorizationRequestBodyPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFleetAuthorizationRequestBodyOptionalProperties(...properties) {
    return properties;
}
function instanceOfFleetAuthorizationRequestBody(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFleetAuthorizationRequestBodyPropertyNames('workorderId');
    const optionalStringProperties = createFleetAuthorizationRequestBodyOptionalProperties({ name: 'contractId', nullable: false }, { name: 'fleetNumber', nullable: false }, { name: 'licensePlate', nullable: false }, { name: 'odometerValue', nullable: false }, { name: 'vendorVehicleId', nullable: false }, { name: 'vin', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createFleetAuthorizationRequestBodyOptionalProperties();
    const optionalBooleanProperties = createFleetAuthorizationRequestBodyOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFleetAuthorizationRequestBodyPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFleetAuthorizationRequestBodyPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFleetAuthorizationRequestBodyPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFleetAuthorizationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFleetAuthorizationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createFleetAuthorizationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfFleetAuthorizationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFleetAuthorizationResponsePropertyNames();
    const optionalStringProperties = createFleetAuthorizationResponseOptionalProperties({ name: 'approvalStatus', nullable: false }, { name: 'contractReference', nullable: false }, { name: 'currency', nullable: false }, { name: 'decidedAt', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'reasonText', nullable: false }, { name: 'requestedAt', nullable: false }, { name: 'reviewReason', nullable: false }, { name: 'status', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorAuthorizationId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createFleetAuthorizationResponseOptionalProperties({ name: 'authorizedAmount', nullable: false });
    const optionalBooleanProperties = createFleetAuthorizationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFleetAuthorizationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFleetAuthorizationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFleetAuthorizationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFleetContractPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFleetContractPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFleetContractOptionalProperties(...properties) {
    return properties;
}
function instanceOfFleetContract(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFleetContractPropertyNames();
    const optionalStringProperties = createFleetContractOptionalProperties({ name: 'contractorId', nullable: false }, { name: 'contractorName', nullable: false }, { name: 'endDate', nullable: false }, { name: 'name', nullable: false }, { name: 'startDate', nullable: false }, { name: 'vendorContractId', nullable: false });
    const optionalNumberProperties = createFleetContractOptionalProperties();
    const optionalBooleanProperties = createFleetContractOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFleetContractPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFleetContractPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFleetContractPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFleetPolicyPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFleetPolicyPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFleetPolicyOptionalProperties(...properties) {
    return properties;
}
function instanceOfFleetPolicy(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFleetPolicyPropertyNames();
    const optionalStringProperties = createFleetPolicyOptionalProperties({ name: 'name', nullable: false }, { name: 'policyId', nullable: false });
    const optionalNumberProperties = createFleetPolicyOptionalProperties();
    const optionalBooleanProperties = createFleetPolicyOptionalProperties({ name: 'useBlacklist', nullable: false }, { name: 'useWhitelist', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFleetPolicyPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFleetPolicyPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFleetPolicyPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFleetVehiclePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFleetVehiclePropertyNames(...propertyNames) {
    return propertyNames;
}
function createFleetVehicleOptionalProperties(...properties) {
    return properties;
}
function instanceOfFleetVehicle(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFleetVehiclePropertyNames();
    const optionalStringProperties = createFleetVehicleOptionalProperties({ name: 'brand', nullable: false }, { name: 'fleetNumber', nullable: false }, { name: 'licensePlate', nullable: false }, { name: 'model', nullable: false }, { name: 'odometerValue', nullable: false }, { name: 'vendorVehicleId', nullable: false }, { name: 'vin', nullable: false });
    const optionalNumberProperties = createFleetVehicleOptionalProperties({ name: 'modelYear', nullable: false });
    const optionalBooleanProperties = createFleetVehicleOptionalProperties({ name: 'identifiable', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFleetVehiclePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFleetVehiclePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFleetVehiclePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLinePropertyNames();
    const optionalStringProperties = createLineOptionalProperties({ name: 'description', nullable: false }, { name: 'reference', nullable: false }, { name: 'tirePosition', nullable: false });
    const optionalNumberProperties = createLineOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMarketingEnrichmentViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMarketingEnrichmentViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMarketingEnrichmentViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfMarketingEnrichmentView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMarketingEnrichmentViewPropertyNames();
    const optionalStringProperties = createMarketingEnrichmentViewOptionalProperties({ name: 'brand', nullable: false }, { name: 'firstSeenAt', nullable: false }, { name: 'lastPublishedAt', nullable: false }, { name: 'lastSeenAt', nullable: false }, { name: 'productName', nullable: false }, { name: 'seasonality', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'treadDesign', nullable: false }, { name: 'vendorVariantId', nullable: false });
    const optionalNumberProperties = createMarketingEnrichmentViewOptionalProperties();
    const optionalBooleanProperties = createMarketingEnrichmentViewOptionalProperties({ name: 'unresolvedImages', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMarketingEnrichmentViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMarketingEnrichmentViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMarketingEnrichmentViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var OrderTransmissionStatusStateEnum;
(function (OrderTransmissionStatusStateEnum) {
    OrderTransmissionStatusStateEnum["Pending"] = "PENDING";
    OrderTransmissionStatusStateEnum["Dispatching"] = "DISPATCHING";
    OrderTransmissionStatusStateEnum["SentAwaitingResult"] = "SENT_AWAITING_RESULT";
    OrderTransmissionStatusStateEnum["Confirmed"] = "CONFIRMED";
    OrderTransmissionStatusStateEnum["Rejected"] = "REJECTED";
    OrderTransmissionStatusStateEnum["ManualReview"] = "MANUAL_REVIEW";
    OrderTransmissionStatusStateEnum["Failed"] = "FAILED";
    OrderTransmissionStatusStateEnum["Cancelled"] = "CANCELLED";
})(OrderTransmissionStatusStateEnum || (OrderTransmissionStatusStateEnum = {}));
;
function isOptionalOrderTransmissionStatusPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createOrderTransmissionStatusPropertyNames(...propertyNames) {
    return propertyNames;
}
function createOrderTransmissionStatusOptionalProperties(...properties) {
    return properties;
}
function instanceOfOrderTransmissionStatus(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createOrderTransmissionStatusPropertyNames();
    const optionalStringProperties = createOrderTransmissionStatusOptionalProperties({ name: 'documentId', nullable: false }, { name: 'failureDetail', nullable: false }, { name: 'lastStatusAt', nullable: false }, { name: 'lastTransitionAt', nullable: false }, { name: 'latestScheduledDeliveryDate', nullable: false }, { name: 'purchaseOrderId', nullable: false }, { name: 'purchaseOrderNumber', nullable: false }, { name: 'resolutionAction', nullable: false }, { name: 'resolvedAt', nullable: false }, { name: 'resolvedBy', nullable: false }, { name: 'state', nullable: false }, { name: 'supplierOrderNumber', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'transmissionIntentId', nullable: false }, { name: 'vendorErrorCode', nullable: false }, { name: 'vendorReason', nullable: false });
    const optionalNumberProperties = createOrderTransmissionStatusOptionalProperties({ name: 'dispatchAttempts', nullable: false });
    const optionalBooleanProperties = createOrderTransmissionStatusOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalOrderTransmissionStatusPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalOrderTransmissionStatusPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalOrderTransmissionStatusPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPagedResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagedResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPagedResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPagedResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagedResponsePropertyNames();
    const optionalStringProperties = createPagedResponseOptionalProperties();
    const optionalNumberProperties = createPagedResponseOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPagedResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagedResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagedResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagedResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPagedResponseExchangeAuditAccessViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagedResponseExchangeAuditAccessViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPagedResponseExchangeAuditAccessViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfPagedResponseExchangeAuditAccessView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagedResponseExchangeAuditAccessViewPropertyNames();
    const optionalStringProperties = createPagedResponseExchangeAuditAccessViewOptionalProperties();
    const optionalNumberProperties = createPagedResponseExchangeAuditAccessViewOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPagedResponseExchangeAuditAccessViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagedResponseExchangeAuditAccessViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagedResponseExchangeAuditAccessViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagedResponseExchangeAuditAccessViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPagedResponseExchangeAuditSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagedResponseExchangeAuditSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPagedResponseExchangeAuditSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfPagedResponseExchangeAuditSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagedResponseExchangeAuditSummaryPropertyNames();
    const optionalStringProperties = createPagedResponseExchangeAuditSummaryOptionalProperties();
    const optionalNumberProperties = createPagedResponseExchangeAuditSummaryOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPagedResponseExchangeAuditSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagedResponseExchangeAuditSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagedResponseExchangeAuditSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagedResponseExchangeAuditSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPriceCatalogBindingFreshnessPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceCatalogBindingFreshnessPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceCatalogBindingFreshnessOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceCatalogBindingFreshness(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceCatalogBindingFreshnessPropertyNames();
    const optionalStringProperties = createPriceCatalogBindingFreshnessOptionalProperties({ name: 'bindingId', nullable: false }, { name: 'checkpointAt', nullable: false }, { name: 'lastRunOutcome', nullable: false }, { name: 'lastRunStartedAt', nullable: false }, { name: 'scheduleCron', nullable: false });
    const optionalNumberProperties = createPriceCatalogBindingFreshnessOptionalProperties();
    const optionalBooleanProperties = createPriceCatalogBindingFreshnessOptionalProperties({ name: 'enabled', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceCatalogBindingFreshnessPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceCatalogBindingFreshnessPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceCatalogBindingFreshnessPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPriceCatalogFreshnessViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceCatalogFreshnessViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceCatalogFreshnessViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceCatalogFreshnessView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceCatalogFreshnessViewPropertyNames();
    const optionalStringProperties = createPriceCatalogFreshnessViewOptionalProperties({ name: 'lastCompletedAt', nullable: false }, { name: 'lastFetchedAt', nullable: false }, { name: 'latestEffectiveDate', nullable: false }, { name: 'stalenessThreshold', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createPriceCatalogFreshnessViewOptionalProperties({ name: 'unresolvedUnmatchedCount', nullable: false });
    const optionalBooleanProperties = createPriceCatalogFreshnessViewOptionalProperties({ name: 'stale', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceCatalogFreshnessViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceCatalogFreshnessViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceCatalogFreshnessViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PriceCatalogImportSummaryErrorCodeEnum;
(function (PriceCatalogImportSummaryErrorCodeEnum) {
    PriceCatalogImportSummaryErrorCodeEnum["FetchFailed"] = "FETCH_FAILED";
    PriceCatalogImportSummaryErrorCodeEnum["DecodeFailed"] = "DECODE_FAILED";
})(PriceCatalogImportSummaryErrorCodeEnum || (PriceCatalogImportSummaryErrorCodeEnum = {}));
;
var PriceCatalogImportSummaryStatusEnum;
(function (PriceCatalogImportSummaryStatusEnum) {
    PriceCatalogImportSummaryStatusEnum["InProgress"] = "IN_PROGRESS";
    PriceCatalogImportSummaryStatusEnum["Completed"] = "COMPLETED";
    PriceCatalogImportSummaryStatusEnum["Empty"] = "EMPTY";
    PriceCatalogImportSummaryStatusEnum["Failed"] = "FAILED";
})(PriceCatalogImportSummaryStatusEnum || (PriceCatalogImportSummaryStatusEnum = {}));
;
function isOptionalPriceCatalogImportSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceCatalogImportSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceCatalogImportSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceCatalogImportSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceCatalogImportSummaryPropertyNames();
    const optionalStringProperties = createPriceCatalogImportSummaryOptionalProperties({ name: 'bindingId', nullable: false }, { name: 'checkpointAt', nullable: false }, { name: 'checkpointState', nullable: false }, { name: 'completedAt', nullable: false }, { name: 'countryCode', nullable: false }, { name: 'currency', nullable: false }, { name: 'errorCode', nullable: false }, { name: 'failureDetail', nullable: false }, { name: 'fetchedAt', nullable: false }, { name: 'importManifestId', nullable: false }, { name: 'sourceDocumentDate', nullable: false }, { name: 'sourceDocumentId', nullable: false }, { name: 'status', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorProfileId', nullable: false }, { name: 'windowFrom', nullable: false }, { name: 'windowTo', nullable: false });
    const optionalNumberProperties = createPriceCatalogImportSummaryOptionalProperties({ name: 'chunkCount', nullable: false }, { name: 'linesDuplicate', nullable: false }, { name: 'linesFetched', nullable: false }, { name: 'linesMatched', nullable: false }, { name: 'linesUnmatched', nullable: false });
    const optionalBooleanProperties = createPriceCatalogImportSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceCatalogImportSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceCatalogImportSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceCatalogImportSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var StockInquiryLineStatusEnum;
(function (StockInquiryLineStatusEnum) {
    StockInquiryLineStatusEnum["Available"] = "AVAILABLE";
    StockInquiryLineStatusEnum["Unavailable"] = "UNAVAILABLE";
    StockInquiryLineStatusEnum["NotListed"] = "NOT_LISTED";
    StockInquiryLineStatusEnum["NotAnswered"] = "NOT_ANSWERED";
})(StockInquiryLineStatusEnum || (StockInquiryLineStatusEnum = {}));
;
function isOptionalStockInquiryLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStockInquiryLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createStockInquiryLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfStockInquiryLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStockInquiryLinePropertyNames();
    const optionalStringProperties = createStockInquiryLineOptionalProperties({ name: 'articleEan', nullable: false }, { name: 'currency', nullable: false }, { name: 'earliestDeliveryDate', nullable: false }, { name: 'status', nullable: false }, { name: 'supplierArticleCode', nullable: false });
    const optionalNumberProperties = createStockInquiryLineOptionalProperties({ name: 'availableQuantity', nullable: false }, { name: 'quotedUnitPrice', nullable: false });
    const optionalBooleanProperties = createStockInquiryLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStockInquiryLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStockInquiryLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStockInquiryLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalStockInquiryRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStockInquiryRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createStockInquiryRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfStockInquiryRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStockInquiryRequestPropertyNames();
    const optionalStringProperties = createStockInquiryRequestOptionalProperties({ name: 'deliveryLocationId', nullable: false }, { name: 'inquiryId', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createStockInquiryRequestOptionalProperties();
    const optionalBooleanProperties = createStockInquiryRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStockInquiryRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStockInquiryRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStockInquiryRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalStockInquiryRequestLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStockInquiryRequestLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createStockInquiryRequestLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfStockInquiryRequestLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStockInquiryRequestLinePropertyNames();
    const optionalStringProperties = createStockInquiryRequestLineOptionalProperties({ name: 'articleEan', nullable: false }, { name: 'supplierArticleCode', nullable: false });
    const optionalNumberProperties = createStockInquiryRequestLineOptionalProperties({ name: 'requestedQuantity', nullable: false });
    const optionalBooleanProperties = createStockInquiryRequestLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStockInquiryRequestLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStockInquiryRequestLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStockInquiryRequestLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var StockInquiryResponseStatusEnum;
(function (StockInquiryResponseStatusEnum) {
    StockInquiryResponseStatusEnum["Ok"] = "OK";
    StockInquiryResponseStatusEnum["SupplierUnavailable"] = "SUPPLIER_UNAVAILABLE";
    StockInquiryResponseStatusEnum["NotListed"] = "NOT_LISTED";
    StockInquiryResponseStatusEnum["CapabilityNotConfigured"] = "CAPABILITY_NOT_CONFIGURED";
    StockInquiryResponseStatusEnum["ConfigurationError"] = "CONFIGURATION_ERROR";
})(StockInquiryResponseStatusEnum || (StockInquiryResponseStatusEnum = {}));
;
function isOptionalStockInquiryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStockInquiryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createStockInquiryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfStockInquiryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStockInquiryResponsePropertyNames();
    const optionalStringProperties = createStockInquiryResponseOptionalProperties({ name: 'asOf', nullable: false }, { name: 'inquiryId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createStockInquiryResponseOptionalProperties();
    const optionalBooleanProperties = createStockInquiryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStockInquiryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStockInquiryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStockInquiryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var StockSnapshotSummaryStatusEnum;
(function (StockSnapshotSummaryStatusEnum) {
    StockSnapshotSummaryStatusEnum["Completed"] = "COMPLETED";
    StockSnapshotSummaryStatusEnum["Empty"] = "EMPTY";
    StockSnapshotSummaryStatusEnum["Rejected"] = "REJECTED";
    StockSnapshotSummaryStatusEnum["Failed"] = "FAILED";
})(StockSnapshotSummaryStatusEnum || (StockSnapshotSummaryStatusEnum = {}));
;
function isOptionalStockSnapshotSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStockSnapshotSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createStockSnapshotSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfStockSnapshotSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStockSnapshotSummaryPropertyNames();
    const optionalStringProperties = createStockSnapshotSummaryOptionalProperties({ name: 'buyerAccountNumber', nullable: false }, { name: 'completedAt', nullable: false }, { name: 'countryCode', nullable: false }, { name: 'documentId', nullable: false }, { name: 'fetchedAt', nullable: false }, { name: 'issuedOn', nullable: false }, { name: 'protocolVersion', nullable: false }, { name: 'snapshotAsOf', nullable: false }, { name: 'snapshotId', nullable: false }, { name: 'status', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createStockSnapshotSummaryOptionalProperties({ name: 'linesRejected', nullable: false }, { name: 'linesReported', nullable: false });
    const optionalBooleanProperties = createStockSnapshotSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStockSnapshotSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStockSnapshotSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStockSnapshotSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalSupplierStockAvailabilityPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierStockAvailabilityPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierStockAvailabilityOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierStockAvailability(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierStockAvailabilityPropertyNames();
    const optionalStringProperties = createSupplierStockAvailabilityOptionalProperties({ name: 'deliveryLocationId', nullable: false }, { name: 'productId', nullable: false }, { name: 'stalenessThreshold', nullable: false });
    const optionalNumberProperties = createSupplierStockAvailabilityOptionalProperties({ name: 'requestedQuantity', nullable: false });
    const optionalBooleanProperties = createSupplierStockAvailabilityOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierStockAvailabilityPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierStockAvailabilityPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierStockAvailabilityPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SupplierStockAvailabilityLineStatusEnum;
(function (SupplierStockAvailabilityLineStatusEnum) {
    SupplierStockAvailabilityLineStatusEnum["Available"] = "AVAILABLE";
    SupplierStockAvailabilityLineStatusEnum["Unavailable"] = "UNAVAILABLE";
    SupplierStockAvailabilityLineStatusEnum["NotListed"] = "NOT_LISTED";
    SupplierStockAvailabilityLineStatusEnum["NotAnswered"] = "NOT_ANSWERED";
})(SupplierStockAvailabilityLineStatusEnum || (SupplierStockAvailabilityLineStatusEnum = {}));
;
function isOptionalSupplierStockAvailabilityLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierStockAvailabilityLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierStockAvailabilityLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierStockAvailabilityLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierStockAvailabilityLinePropertyNames();
    const optionalStringProperties = createSupplierStockAvailabilityLineOptionalProperties({ name: 'currency', nullable: false }, { name: 'earliestDeliveryDate', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createSupplierStockAvailabilityLineOptionalProperties({ name: 'availableQuantity', nullable: false }, { name: 'quotedUnitPrice', nullable: false });
    const optionalBooleanProperties = createSupplierStockAvailabilityLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierStockAvailabilityLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierStockAvailabilityLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierStockAvailabilityLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var SupplierStockAvailabilityVendorStatusEnum;
(function (SupplierStockAvailabilityVendorStatusEnum) {
    SupplierStockAvailabilityVendorStatusEnum["Ok"] = "OK";
    SupplierStockAvailabilityVendorStatusEnum["SupplierUnavailable"] = "SUPPLIER_UNAVAILABLE";
    SupplierStockAvailabilityVendorStatusEnum["NotListed"] = "NOT_LISTED";
    SupplierStockAvailabilityVendorStatusEnum["CapabilityNotConfigured"] = "CAPABILITY_NOT_CONFIGURED";
    SupplierStockAvailabilityVendorStatusEnum["ConfigurationError"] = "CONFIGURATION_ERROR";
})(SupplierStockAvailabilityVendorStatusEnum || (SupplierStockAvailabilityVendorStatusEnum = {}));
;
function isOptionalSupplierStockAvailabilityVendorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierStockAvailabilityVendorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierStockAvailabilityVendorOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierStockAvailabilityVendor(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierStockAvailabilityVendorPropertyNames();
    const optionalStringProperties = createSupplierStockAvailabilityVendorOptionalProperties({ name: 'asOf', nullable: false }, { name: 'fetchedAt', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorDisplayName', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createSupplierStockAvailabilityVendorOptionalProperties();
    const optionalBooleanProperties = createSupplierStockAvailabilityVendorOptionalProperties({ name: 'stale', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierStockAvailabilityVendorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierStockAvailabilityVendorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierStockAvailabilityVendorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TransmissionResolutionRequestActionEnum;
(function (TransmissionResolutionRequestActionEnum) {
    TransmissionResolutionRequestActionEnum["ConfirmWithVendorReference"] = "CONFIRM_WITH_VENDOR_REFERENCE";
    TransmissionResolutionRequestActionEnum["MarkNotReceived"] = "MARK_NOT_RECEIVED";
    TransmissionResolutionRequestActionEnum["Cancel"] = "CANCEL";
})(TransmissionResolutionRequestActionEnum || (TransmissionResolutionRequestActionEnum = {}));
;
function isOptionalTransmissionResolutionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTransmissionResolutionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTransmissionResolutionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTransmissionResolutionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTransmissionResolutionRequestPropertyNames('action', 'evidence');
    const optionalStringProperties = createTransmissionResolutionRequestOptionalProperties({ name: 'action', nullable: false }, { name: 'evidence', nullable: false }, { name: 'supplierOrderNumber', nullable: false });
    const optionalNumberProperties = createTransmissionResolutionRequestOptionalProperties();
    const optionalBooleanProperties = createTransmissionResolutionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTransmissionResolutionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTransmissionResolutionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTransmissionResolutionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VendorProfileRequestRetryBackoffEnum;
(function (VendorProfileRequestRetryBackoffEnum) {
    VendorProfileRequestRetryBackoffEnum["Fixed"] = "FIXED";
    VendorProfileRequestRetryBackoffEnum["Exponential"] = "EXPONENTIAL";
})(VendorProfileRequestRetryBackoffEnum || (VendorProfileRequestRetryBackoffEnum = {}));
;
function isOptionalVendorProfileRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorProfileRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorProfileRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorProfileRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorProfileRequestPropertyNames();
    const optionalStringProperties = createVendorProfileRequestOptionalProperties({ name: 'displayName', nullable: false }, { name: 'retryBackoff', nullable: false }, { name: 'sandboxBaseUrlOverride', nullable: false }, { name: 'supplierRef', nullable: false });
    const optionalNumberProperties = createVendorProfileRequestOptionalProperties({ name: 'connectTimeoutMillis', nullable: false }, { name: 'maxRetries', nullable: false }, { name: 'readTimeoutMillis', nullable: false });
    const optionalBooleanProperties = createVendorProfileRequestOptionalProperties({ name: 'enabled', nullable: false }, { name: 'sandbox', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorProfileRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorProfileRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorProfileRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Supplier API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VendorProfileViewRetryBackoffEnum;
(function (VendorProfileViewRetryBackoffEnum) {
    VendorProfileViewRetryBackoffEnum["Fixed"] = "FIXED";
    VendorProfileViewRetryBackoffEnum["Exponential"] = "EXPONENTIAL";
})(VendorProfileViewRetryBackoffEnum || (VendorProfileViewRetryBackoffEnum = {}));
;
var VendorProfileViewSourceOfTruthEnum;
(function (VendorProfileViewSourceOfTruthEnum) {
    VendorProfileViewSourceOfTruthEnum["Yaml"] = "YAML";
    VendorProfileViewSourceOfTruthEnum["Admin"] = "ADMIN";
})(VendorProfileViewSourceOfTruthEnum || (VendorProfileViewSourceOfTruthEnum = {}));
;
function isOptionalVendorProfileViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorProfileViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorProfileViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorProfileView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorProfileViewPropertyNames();
    const optionalStringProperties = createVendorProfileViewOptionalProperties({ name: 'displayName', nullable: false }, { name: 'retryBackoff', nullable: false }, { name: 'sandboxBaseUrlOverride', nullable: false }, { name: 'sourceOfTruth', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createVendorProfileViewOptionalProperties({ name: 'connectTimeoutMillis', nullable: false }, { name: 'maxRetries', nullable: false }, { name: 'readTimeoutMillis', nullable: false });
    const optionalBooleanProperties = createVendorProfileViewOptionalProperties({ name: 'enabled', nullable: false }, { name: 'sandbox', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorProfileViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorProfileViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorProfileViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { ApiModule, AuthConfigRequestTypeEnum, AuthConfigViewTypeEnum, BASE_PATH, COLLECTION_FORMATS, CommercialAccountRequestRoleEnum, CommercialAccountViewRoleEnum, Configuration, EndpointBindingRequestCaptureLevelEnum, EndpointBindingRequestRedactionClassificationsEnum, EndpointBindingViewCaptureLevelEnum, EndpointBindingViewRedactionClassificationsEnum, ExchangeAuditAccessViewAccessKindEnum, ExchangeAuditAccessViewPayloadOutcomeEnum, ExchangeAuditPayloadViewCaptureLevelEnum, ExchangeAuditSummaryCaptureLevelEnum, OrderTransmissionStatusStateEnum, PriceCatalogImportSummaryErrorCodeEnum, PriceCatalogImportSummaryStatusEnum, StockInquiryLineStatusEnum, StockInquiryResponseStatusEnum, StockSnapshotSummaryStatusEnum, SupplierAuthConfigsService, SupplierCommercialAccountsService, SupplierEndpointBindingsService, SupplierExchangeAuditService, SupplierFleetAuthorizationService, SupplierInvoicesService, SupplierMarketingCatalogService, SupplierOrderTransmissionService, SupplierPriceCatalogService, SupplierStockAvailabilityLineStatusEnum, SupplierStockAvailabilityService, SupplierStockAvailabilityVendorStatusEnum, SupplierStockInquiryService, SupplierStockSnapshotsService, SupplierVendorProfilesService, TransmissionResolutionRequestActionEnum, VendorProfileRequestRetryBackoffEnum, VendorProfileViewRetryBackoffEnum, VendorProfileViewSourceOfTruthEnum, instanceOfApiError, instanceOfAuthConfigRequest, instanceOfAuthConfigView, instanceOfCommercialAccountRequest, instanceOfCommercialAccountView, instanceOfEndpointBindingRequest, instanceOfEndpointBindingView, instanceOfExchangeAuditAccessView, instanceOfExchangeAuditPayloadView, instanceOfExchangeAuditSummary, instanceOfFieldError, instanceOfFleetAuthorizationRequestBody, instanceOfFleetAuthorizationResponse, instanceOfFleetContract, instanceOfFleetPolicy, instanceOfFleetVehicle, instanceOfLine, instanceOfMarketingEnrichmentView, instanceOfOrderTransmissionStatus, instanceOfPagedResponse, instanceOfPagedResponseExchangeAuditAccessView, instanceOfPagedResponseExchangeAuditSummary, instanceOfPriceCatalogBindingFreshness, instanceOfPriceCatalogFreshnessView, instanceOfPriceCatalogImportSummary, instanceOfStockInquiryLine, instanceOfStockInquiryRequest, instanceOfStockInquiryRequestLine, instanceOfStockInquiryResponse, instanceOfStockSnapshotSummary, instanceOfSupplierStockAvailability, instanceOfSupplierStockAvailabilityLine, instanceOfSupplierStockAvailabilityVendor, instanceOfTransmissionResolutionRequest, instanceOfVendorProfileRequest, instanceOfVendorProfileView, provideApi };
//# sourceMappingURL=durion-sdk-supplier.mjs.map
