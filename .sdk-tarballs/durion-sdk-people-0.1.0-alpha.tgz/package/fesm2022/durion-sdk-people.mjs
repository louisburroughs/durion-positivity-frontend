import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/people';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class EmployeeAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createEmployee(createEmployeeRequest, observe = 'body', reportProgress = false, options) {
        if (createEmployeeRequest === null || createEmployeeRequest === undefined) {
            throw new Error('Required parameter createEmployeeRequest was null or undefined when calling createEmployee.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/employees`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createEmployeeRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    disableEmployee(employeeId, disableEmployeeRequestDto, observe = 'body', reportProgress = false, options) {
        if (employeeId === null || employeeId === undefined) {
            throw new Error('Required parameter employeeId was null or undefined when calling disableEmployee.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/employees/${this.configuration.encodeParam({ name: "employeeId", value: employeeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/disable`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: disableEmployeeRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEmployee(employeeId, observe = 'body', reportProgress = false, options) {
        if (employeeId === null || employeeId === undefined) {
            throw new Error('Required parameter employeeId was null or undefined when calling getEmployee.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/employees/${this.configuration.encodeParam({ name: "employeeId", value: employeeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateEmployee(employeeId, updateEmployeeRequest, observe = 'body', reportProgress = false, options) {
        if (employeeId === null || employeeId === undefined) {
            throw new Error('Required parameter employeeId was null or undefined when calling updateEmployee.');
        }
        if (updateEmployeeRequest === null || updateEmployeeRequest === undefined) {
            throw new Error('Required parameter updateEmployeeRequest was null or undefined when calling updateEmployee.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/employees/${this.configuration.encodeParam({ name: "employeeId", value: employeeId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateEmployeeRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EmployeeAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EmployeeAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: EmployeeAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPerson(person, observe = 'body', reportProgress = false, options) {
        if (person === null || person === undefined) {
            throw new Error('Required parameter person was null or undefined when calling createPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: person,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deletePerson(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling deletePerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAllPeople(type, q, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'type', type, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'q', q, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPeopleByIds(requestBody, observe = 'body', reportProgress = false, options) {
        if (requestBody === null || requestBody === undefined) {
            throw new Error('Required parameter requestBody was null or undefined when calling getPeopleByIds.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/by-ids`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: requestBody,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPersonById(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getPersonById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    replaceContactPoints(personId, contactPointDto, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling replaceContactPoints.');
        }
        if (contactPointDto === null || contactPointDto === undefined) {
            throw new Error('Required parameter contactPointDto was null or undefined when calling replaceContactPoints.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contact-points`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: contactPointDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolvePerson(resolvePersonRequest, observe = 'body', reportProgress = false, options) {
        if (resolvePersonRequest === null || resolvePersonRequest === undefined) {
            throw new Error('Required parameter resolvePersonRequest was null or undefined when calling resolvePerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: resolvePersonRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePerson(personId, person, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling updatePerson.');
        }
        if (person === null || person === undefined) {
            throw new Error('Required parameter person was null or undefined when calling updatePerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: person,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleAccessControlService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createAssignment(personUuid, personRoleAssignmentRequest, observe = 'body', reportProgress = false, options) {
        if (personUuid === null || personUuid === undefined) {
            throw new Error('Required parameter personUuid was null or undefined when calling createAssignment.');
        }
        if (personRoleAssignmentRequest === null || personRoleAssignmentRequest === undefined) {
            throw new Error('Required parameter personRoleAssignmentRequest was null or undefined when calling createAssignment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json',
            'application/problem+json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personUuid", value: personUuid, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/access/assignments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: personRoleAssignmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAssignments(personUuid, includeHistory, endDate, observe = 'body', reportProgress = false, options) {
        if (personUuid === null || personUuid === undefined) {
            throw new Error('Required parameter personUuid was null or undefined when calling getAssignments.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeHistory', includeHistory, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personUuid", value: personUuid, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/access/assignments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRoles(personUuid, observe = 'body', reportProgress = false, options) {
        if (personUuid === null || personUuid === undefined) {
            throw new Error('Required parameter personUuid was null or undefined when calling getRoles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personUuid", value: personUuid, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/access/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revokeAssignment(personUuid, roleCode, endDate, observe = 'body', reportProgress = false, options) {
        if (personUuid === null || personUuid === undefined) {
            throw new Error('Required parameter personUuid was null or undefined when calling revokeAssignment.');
        }
        if (roleCode === null || roleCode === undefined) {
            throw new Error('Required parameter roleCode was null or undefined when calling revokeAssignment.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/problem+json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personUuid", value: personUuid, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/access/assignments/${this.configuration.encodeParam({ name: "roleCode", value: roleCode, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAccessControlService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAccessControlService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAccessControlService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleAvailabilityAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getCurrentUserPrimaryLocation(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/me/primary-location`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPeopleAvailability(locationId, date, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'date', date, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/availability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAvailabilityAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAvailabilityAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleAvailabilityAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngest(bulkIngestRequestPersonBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestPersonBulkIngestRecord === null || bulkIngestRequestPersonBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestPersonBulkIngestRecord was null or undefined when calling bulkIngest.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestPersonBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleExceptionsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    acknowledgeException(exceptionId, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (exceptionId === null || exceptionId === undefined) {
            throw new Error('Required parameter exceptionId was null or undefined when calling acknowledgeException.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/exceptions/${this.configuration.encodeParam({ name: "exceptionId", value: exceptionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/acknowledge`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createException(timeEntryExceptionRequest, observe = 'body', reportProgress = false, options) {
        if (timeEntryExceptionRequest === null || timeEntryExceptionRequest === undefined) {
            throw new Error('Required parameter timeEntryExceptionRequest was null or undefined when calling createException.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/exceptions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: timeEntryExceptionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listByEmployee(employeeId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'employeeId', employeeId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/exceptions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveException(exceptionId, xCorrelationId, timeEntryExceptionResolveRequest, observe = 'body', reportProgress = false, options) {
        if (exceptionId === null || exceptionId === undefined) {
            throw new Error('Required parameter exceptionId was null or undefined when calling resolveException.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/exceptions/${this.configuration.encodeParam({ name: "exceptionId", value: exceptionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: timeEntryExceptionResolveRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    waiveException(exceptionId, timeEntryExceptionWaiveRequest, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (exceptionId === null || exceptionId === undefined) {
            throw new Error('Required parameter exceptionId was null or undefined when calling waiveException.');
        }
        if (timeEntryExceptionWaiveRequest === null || timeEntryExceptionWaiveRequest === undefined) {
            throw new Error('Required parameter timeEntryExceptionWaiveRequest was null or undefined when calling waiveException.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/exceptions/${this.configuration.encodeParam({ name: "exceptionId", value: exceptionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/waive`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: timeEntryExceptionWaiveRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleExceptionsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleExceptionsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleExceptionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleReportsAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getApprovedTimeForExport(startDate, endDate, locationId, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getApprovedTimeForExport.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getApprovedTimeForExport.');
        }
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getApprovedTimeForExport.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/reports/approvedTime`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAttendanceDiscrepancyReport(startDate, endDate, timezone, locationId, technicianIds, flaggedOnly, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getAttendanceDiscrepancyReport.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getAttendanceDiscrepancyReport.');
        }
        if (timezone === null || timezone === undefined) {
            throw new Error('Required parameter timezone was null or undefined when calling getAttendanceDiscrepancyReport.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'timezone', timezone, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'technicianIds', technicianIds, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'flaggedOnly', flaggedOnly, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/reports/attendanceJobtimeDiscrepancy`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleReportsAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleReportsAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleReportsAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleStaffingAssignmentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createAssignment1(createStaffingAssignmentRequest, observe = 'body', reportProgress = false, options) {
        if (createStaffingAssignmentRequest === null || createStaffingAssignmentRequest === undefined) {
            throw new Error('Required parameter createStaffingAssignmentRequest was null or undefined when calling createAssignment1.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/staffing/assignments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createStaffingAssignmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    endAssignment(assignmentId, observe = 'body', reportProgress = false, options) {
        if (assignmentId === null || assignmentId === undefined) {
            throw new Error('Required parameter assignmentId was null or undefined when calling endAssignment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/staffing/assignments/${this.configuration.encodeParam({ name: "assignmentId", value: assignmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAssignment(assignmentId, observe = 'body', reportProgress = false, options) {
        if (assignmentId === null || assignmentId === undefined) {
            throw new Error('Required parameter assignmentId was null or undefined when calling getAssignment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/staffing/assignments/${this.configuration.encodeParam({ name: "assignmentId", value: assignmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAssignments1(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getAssignments1.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'personId', personId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/staffing/assignments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateAssignment(assignmentId, updateStaffingAssignmentRequest, observe = 'body', reportProgress = false, options) {
        if (assignmentId === null || assignmentId === undefined) {
            throw new Error('Required parameter assignmentId was null or undefined when calling updateAssignment.');
        }
        if (updateStaffingAssignmentRequest === null || updateStaffingAssignmentRequest === undefined) {
            throw new Error('Required parameter updateStaffingAssignmentRequest was null or undefined when calling updateAssignment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/staffing/assignments/${this.configuration.encodeParam({ name: "assignmentId", value: assignmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateStaffingAssignmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleStaffingAssignmentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleStaffingAssignmentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleStaffingAssignmentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PeopleTimeEntriesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveAdjustment(adjustmentId, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (adjustmentId === null || adjustmentId === undefined) {
            throw new Error('Required parameter adjustmentId was null or undefined when calling approveAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timeEntries/adjustments/${this.configuration.encodeParam({ name: "adjustmentId", value: adjustmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createAdjustment(timeEntryAdjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (timeEntryAdjustmentRequest === null || timeEntryAdjustmentRequest === undefined) {
            throw new Error('Required parameter timeEntryAdjustmentRequest was null or undefined when calling createAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timeEntries/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: timeEntryAdjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listForTimeEntry(timeEntryId, observe = 'body', reportProgress = false, options) {
        if (timeEntryId === null || timeEntryId === undefined) {
            throw new Error('Required parameter timeEntryId was null or undefined when calling listForTimeEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timeEntries/${this.configuration.encodeParam({ name: "timeEntryId", value: timeEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleTimeEntriesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleTimeEntriesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PeopleTimeEntriesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TimeEntryApprovalAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveTimeEntries(timeEntryDecisionBatchRequest, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (timeEntryDecisionBatchRequest === null || timeEntryDecisionBatchRequest === undefined) {
            throw new Error('Required parameter timeEntryDecisionBatchRequest was null or undefined when calling approveTimeEntries.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timeEntries/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: timeEntryDecisionBatchRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectTimeEntries(timeEntryDecisionBatchRequest, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (timeEntryDecisionBatchRequest === null || timeEntryDecisionBatchRequest === undefined) {
            throw new Error('Required parameter timeEntryDecisionBatchRequest was null or undefined when calling rejectTimeEntries.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timeEntries/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: timeEntryDecisionBatchRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimeEntryApprovalAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimeEntryApprovalAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimeEntryApprovalAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TimekeepingApprovalAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approvePeriod(timePeriodId, personId, observe = 'body', reportProgress = false, options) {
        if (timePeriodId === null || timePeriodId === undefined) {
            throw new Error('Required parameter timePeriodId was null or undefined when calling approvePeriod.');
        }
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling approvePeriod.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timekeeping/time-periods/${this.configuration.encodeParam({ name: "timePeriodId", value: timePeriodId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTimePeriodApproval(personId, timePeriodId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getTimePeriodApproval.');
        }
        if (timePeriodId === null || timePeriodId === undefined) {
            throw new Error('Required parameter timePeriodId was null or undefined when calling getTimePeriodApproval.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'personId', personId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'timePeriodId', timePeriodId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timekeeping/time-period-approvals`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listApprovalPeople(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timekeeping/approvals/people`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTimePeriods(tenantId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'tenantId', tenantId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timekeeping/time-periods`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTimekeepingEntries(personId, timePeriodId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling listTimekeepingEntries.');
        }
        if (timePeriodId === null || timePeriodId === undefined) {
            throw new Error('Required parameter timePeriodId was null or undefined when calling listTimekeepingEntries.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'personId', personId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'timePeriodId', timePeriodId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timekeeping/timekeeping-entries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectPeriod(timePeriodId, personId, rejectTimePeriodRequest, observe = 'body', reportProgress = false, options) {
        if (timePeriodId === null || timePeriodId === undefined) {
            throw new Error('Required parameter timePeriodId was null or undefined when calling rejectPeriod.');
        }
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling rejectPeriod.');
        }
        if (rejectTimePeriodRequest === null || rejectTimePeriodRequest === undefined) {
            throw new Error('Required parameter rejectTimePeriodRequest was null or undefined when calling rejectPeriod.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/timekeeping/time-periods/${this.configuration.encodeParam({ name: "timePeriodId", value: timePeriodId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rejectTimePeriodRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimekeepingApprovalAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimekeepingApprovalAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: TimekeepingApprovalAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class UserPersonLinkingAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createUserPersonLink(createUserLinkRequest, observe = 'body', reportProgress = false, options) {
        if (createUserLinkRequest === null || createUserLinkRequest === undefined) {
            throw new Error('Required parameter createUserLinkRequest was null or undefined when calling createUserPersonLink.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/user-links`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createUserLinkRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    findActiveUsersForInactivePersons(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/user-links/inactive-person-active-user`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getLinkByPersonId(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getLinkByPersonId.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/user-links/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPersonByUserId(userId, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling getPersonByUserId.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/users/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/person`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUserIdsByPersonId(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getUserIdsByPersonId.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/users`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    linkUserToPerson(linkUserToPersonRequest, observe = 'body', reportProgress = false, options) {
        if (linkUserToPersonRequest === null || linkUserToPersonRequest === undefined) {
            throw new Error('Required parameter linkUserToPersonRequest was null or undefined when calling linkUserToPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/users/link`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: linkUserToPersonRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    unlinkUserFromPerson(userId, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling unlinkUserFromPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/users/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/link`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: UserPersonLinkingAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: UserPersonLinkingAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: UserPersonLinkingAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WorkSessionsAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    startWorkSession(workSessionRequest, observe = 'body', reportProgress = false, options) {
        if (workSessionRequest === null || workSessionRequest === undefined) {
            throw new Error('Required parameter workSessionRequest was null or undefined when calling startWorkSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/workSessions/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: workSessionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    startWorkSessionBreak(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling startWorkSessionBreak.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/workSessions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/breaks/start`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopWorkSession(workSessionRequest, observe = 'body', reportProgress = false, options) {
        if (workSessionRequest === null || workSessionRequest === undefined) {
            throw new Error('Required parameter workSessionRequest was null or undefined when calling stopWorkSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/workSessions/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: workSessionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    stopWorkSessionBreak(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling stopWorkSessionBreak.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/workSessions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/breaks/stop`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitWorkSession(id, workSessionSubmitRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling submitWorkSession.');
        }
        if (workSessionSubmitRequest === null || workSessionSubmitRequest === undefined) {
            throw new Error('Required parameter workSessionSubmitRequest was null or undefined when calling submitWorkSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/people/workSessions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/submit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: workSessionSubmitRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkSessionsAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkSessionsAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: WorkSessionsAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

const APIS = [EmployeeAPIService, PeopleAPIService, PeopleAccessControlService, PeopleAvailabilityAPIService, PeopleBulkIngestAPIService, PeopleExceptionsService, PeopleReportsAPIService, PeopleStaffingAssignmentsService, PeopleTimeEntriesService, TimeEntryApprovalAPIService, TimekeepingApprovalAPIService, UserPersonLinkingAPIService, WorkSessionsAPIService];

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalApprovalPersonDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApprovalPersonDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApprovalPersonDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfApprovalPersonDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApprovalPersonDtoPropertyNames('personId', 'displayName');
    const optionalStringProperties = createApprovalPersonDtoOptionalProperties({ name: 'personId', nullable: false }, { name: 'displayName', nullable: false }, { name: 'employeeNumber', nullable: false });
    const optionalNumberProperties = createApprovalPersonDtoOptionalProperties();
    const optionalBooleanProperties = createApprovalPersonDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApprovalPersonDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApprovalPersonDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApprovalPersonDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalApprovedTimeExportResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApprovedTimeExportResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createApprovedTimeExportResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfApprovedTimeExportResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApprovedTimeExportResponsePropertyNames('timeEntryId', 'employeeId', 'employeeName', 'locationId', 'locationName', 'entryDate', 'hoursWorked', 'approvedAt', 'approvedBy');
    const optionalStringProperties = createApprovedTimeExportResponseOptionalProperties({ name: 'timeEntryId', nullable: false }, { name: 'employeeId', nullable: false }, { name: 'employeeName', nullable: false }, { name: 'locationId', nullable: false }, { name: 'locationName', nullable: false }, { name: 'approvedBy', nullable: false });
    const optionalNumberProperties = createApprovedTimeExportResponseOptionalProperties({ name: 'hoursWorked', nullable: false });
    const optionalBooleanProperties = createApprovedTimeExportResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApprovedTimeExportResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApprovedTimeExportResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApprovedTimeExportResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAttendanceDiscrepancyReportResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAttendanceDiscrepancyReportResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAttendanceDiscrepancyReportResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAttendanceDiscrepancyReportResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAttendanceDiscrepancyReportResponsePropertyNames('technicianId', 'technicianName', 'locationId', 'reportDate', 'totalAttendanceHours', 'totalJobHours', 'discrepancyHours', 'thresholdApplied', 'isFlagged');
    const optionalStringProperties = createAttendanceDiscrepancyReportResponseOptionalProperties({ name: 'technicianId', nullable: false }, { name: 'technicianName', nullable: false }, { name: 'locationId', nullable: false });
    const optionalNumberProperties = createAttendanceDiscrepancyReportResponseOptionalProperties({ name: 'thresholdApplied', nullable: false });
    const optionalBooleanProperties = createAttendanceDiscrepancyReportResponseOptionalProperties({ name: 'isFlagged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAttendanceDiscrepancyReportResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAttendanceDiscrepancyReportResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAttendanceDiscrepancyReportResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBreakDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBreakDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBreakDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfBreakDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBreakDtoPropertyNames('sessionId', 'startedAt');
    const optionalStringProperties = createBreakDtoOptionalProperties({ name: 'sessionId', nullable: false });
    const optionalNumberProperties = createBreakDtoOptionalProperties();
    const optionalBooleanProperties = createBreakDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBreakDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBreakDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBreakDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestPersonBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestPersonBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestPersonBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestPersonBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestPersonBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestPersonBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestPersonBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestPersonBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestPersonBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestPersonBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestPersonBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResponsePropertyNames('totalSubmitted', 'successCount', 'failureCount', 'results');
    const optionalStringProperties = createBulkIngestResponseOptionalProperties();
    const optionalNumberProperties = createBulkIngestResponseOptionalProperties({ name: 'totalSubmitted', nullable: false }, { name: 'successCount', nullable: false }, { name: 'failureCount', nullable: false });
    const optionalBooleanProperties = createBulkIngestResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBulkIngestResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResultPropertyNames('rowIndex', 'success');
    const optionalStringProperties = createBulkIngestResultOptionalProperties({ name: 'entityId', nullable: false }, { name: 'errorCode', nullable: false }, { name: 'errorMessage', nullable: false });
    const optionalNumberProperties = createBulkIngestResultOptionalProperties({ name: 'rowIndex', nullable: false });
    const optionalBooleanProperties = createBulkIngestResultOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ContactPointDtoContactTypeEnum;
(function (ContactPointDtoContactTypeEnum) {
    ContactPointDtoContactTypeEnum["Email"] = "EMAIL";
    ContactPointDtoContactTypeEnum["PhoneMobile"] = "PHONE_MOBILE";
    ContactPointDtoContactTypeEnum["PhoneHome"] = "PHONE_HOME";
    ContactPointDtoContactTypeEnum["PhoneWork"] = "PHONE_WORK";
})(ContactPointDtoContactTypeEnum || (ContactPointDtoContactTypeEnum = {}));
;
function isOptionalContactPointDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContactPointDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createContactPointDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfContactPointDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContactPointDtoPropertyNames('contactType', 'value', 'primary');
    const optionalStringProperties = createContactPointDtoOptionalProperties({ name: 'contactType', nullable: false }, { name: 'value', nullable: false });
    const optionalNumberProperties = createContactPointDtoOptionalProperties();
    const optionalBooleanProperties = createContactPointDtoOptionalProperties({ name: 'primary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContactPointDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContactPointDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContactPointDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var CreateEmployeeRequestStatusEnum;
(function (CreateEmployeeRequestStatusEnum) {
    CreateEmployeeRequestStatusEnum["Active"] = "ACTIVE";
    CreateEmployeeRequestStatusEnum["OnLeave"] = "ON_LEAVE";
    CreateEmployeeRequestStatusEnum["Suspended"] = "SUSPENDED";
    CreateEmployeeRequestStatusEnum["Terminated"] = "TERMINATED";
    CreateEmployeeRequestStatusEnum["Disabled"] = "DISABLED";
})(CreateEmployeeRequestStatusEnum || (CreateEmployeeRequestStatusEnum = {}));
;
var CreateEmployeeRequestDuplicatePolicyEnum;
(function (CreateEmployeeRequestDuplicatePolicyEnum) {
    CreateEmployeeRequestDuplicatePolicyEnum["Strict"] = "STRICT";
    CreateEmployeeRequestDuplicatePolicyEnum["Balanced"] = "BALANCED";
})(CreateEmployeeRequestDuplicatePolicyEnum || (CreateEmployeeRequestDuplicatePolicyEnum = {}));
;
function isOptionalCreateEmployeeRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateEmployeeRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateEmployeeRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateEmployeeRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateEmployeeRequestPropertyNames('legalName', 'employeeNumber', 'status', 'hireDate');
    const optionalStringProperties = createCreateEmployeeRequestOptionalProperties({ name: 'legalName', nullable: false }, { name: 'preferredName', nullable: false }, { name: 'employeeNumber', nullable: false }, { name: 'status', nullable: false }, { name: 'duplicatePolicy', nullable: false });
    const optionalNumberProperties = createCreateEmployeeRequestOptionalProperties();
    const optionalBooleanProperties = createCreateEmployeeRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateEmployeeRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateEmployeeRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateEmployeeRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateStaffingAssignmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateStaffingAssignmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateStaffingAssignmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateStaffingAssignmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateStaffingAssignmentRequestPropertyNames('personId', 'locationId', 'role', 'effectiveFrom', 'isPrimary');
    const optionalStringProperties = createCreateStaffingAssignmentRequestOptionalProperties({ name: 'personId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'role', nullable: false });
    const optionalNumberProperties = createCreateStaffingAssignmentRequestOptionalProperties();
    const optionalBooleanProperties = createCreateStaffingAssignmentRequestOptionalProperties({ name: 'effectiveDateRangeValid', nullable: false }, { name: 'isPrimary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateStaffingAssignmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateStaffingAssignmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateStaffingAssignmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateUserLinkRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateUserLinkRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateUserLinkRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateUserLinkRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateUserLinkRequestPropertyNames('userId', 'personId');
    const optionalStringProperties = createCreateUserLinkRequestOptionalProperties({ name: 'userId', nullable: false }, { name: 'personId', nullable: false });
    const optionalNumberProperties = createCreateUserLinkRequestOptionalProperties();
    const optionalBooleanProperties = createCreateUserLinkRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateUserLinkRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateUserLinkRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateUserLinkRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalDecisionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDecisionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDecisionOptionalProperties(...properties) {
    return properties;
}
function instanceOfDecision(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDecisionPropertyNames('timeEntryId');
    const optionalStringProperties = createDecisionOptionalProperties({ name: 'timeEntryId', nullable: false }, { name: 'rejectionReason', nullable: false });
    const optionalNumberProperties = createDecisionOptionalProperties();
    const optionalBooleanProperties = createDecisionOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDecisionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDecisionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDecisionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var DisableEmployeeRequestDtoAssignmentPolicyEnum;
(function (DisableEmployeeRequestDtoAssignmentPolicyEnum) {
    DisableEmployeeRequestDtoAssignmentPolicyEnum["Immediate"] = "IMMEDIATE";
    DisableEmployeeRequestDtoAssignmentPolicyEnum["GracePeriod"] = "GRACE_PERIOD";
})(DisableEmployeeRequestDtoAssignmentPolicyEnum || (DisableEmployeeRequestDtoAssignmentPolicyEnum = {}));
;
function isOptionalDisableEmployeeRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDisableEmployeeRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDisableEmployeeRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfDisableEmployeeRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDisableEmployeeRequestDtoPropertyNames();
    const optionalStringProperties = createDisableEmployeeRequestDtoOptionalProperties({ name: 'disableReason', nullable: false }, { name: 'assignmentPolicy', nullable: false });
    const optionalNumberProperties = createDisableEmployeeRequestDtoOptionalProperties();
    const optionalBooleanProperties = createDisableEmployeeRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDisableEmployeeRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDisableEmployeeRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDisableEmployeeRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEmployeeAddressDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmployeeAddressDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmployeeAddressDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmployeeAddressDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmployeeAddressDtoPropertyNames();
    const optionalStringProperties = createEmployeeAddressDtoOptionalProperties({ name: 'line1', nullable: false }, { name: 'line2', nullable: false }, { name: 'city', nullable: false }, { name: 'region', nullable: false }, { name: 'postalCode', nullable: false }, { name: 'country', nullable: false });
    const optionalNumberProperties = createEmployeeAddressDtoOptionalProperties();
    const optionalBooleanProperties = createEmployeeAddressDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmployeeAddressDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmployeeAddressDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmployeeAddressDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalEmployeeContactInfoDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmployeeContactInfoDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmployeeContactInfoDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmployeeContactInfoDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmployeeContactInfoDtoPropertyNames();
    const optionalStringProperties = createEmployeeContactInfoDtoOptionalProperties({ name: 'primaryEmail', nullable: false }, { name: 'primaryPhone', nullable: false }, { name: 'secondaryEmail', nullable: false }, { name: 'secondaryPhone', nullable: false });
    const optionalNumberProperties = createEmployeeContactInfoDtoOptionalProperties();
    const optionalBooleanProperties = createEmployeeContactInfoDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmployeeContactInfoDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmployeeContactInfoDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmployeeContactInfoDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEmployeeEmergencyContactDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmployeeEmergencyContactDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmployeeEmergencyContactDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmployeeEmergencyContactDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmployeeEmergencyContactDtoPropertyNames();
    const optionalStringProperties = createEmployeeEmergencyContactDtoOptionalProperties({ name: 'name', nullable: false }, { name: 'relationship', nullable: false }, { name: 'phone', nullable: false }, { name: 'email', nullable: false });
    const optionalNumberProperties = createEmployeeEmergencyContactDtoOptionalProperties();
    const optionalBooleanProperties = createEmployeeEmergencyContactDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmployeeEmergencyContactDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmployeeEmergencyContactDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmployeeEmergencyContactDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var EmployeeProfileDtoStatusEnum;
(function (EmployeeProfileDtoStatusEnum) {
    EmployeeProfileDtoStatusEnum["Active"] = "ACTIVE";
    EmployeeProfileDtoStatusEnum["OnLeave"] = "ON_LEAVE";
    EmployeeProfileDtoStatusEnum["Suspended"] = "SUSPENDED";
    EmployeeProfileDtoStatusEnum["Terminated"] = "TERMINATED";
    EmployeeProfileDtoStatusEnum["Disabled"] = "DISABLED";
})(EmployeeProfileDtoStatusEnum || (EmployeeProfileDtoStatusEnum = {}));
;
function isOptionalEmployeeProfileDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmployeeProfileDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmployeeProfileDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmployeeProfileDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmployeeProfileDtoPropertyNames('id', 'legalName', 'employeeNumber', 'status', 'hireDate');
    const optionalStringProperties = createEmployeeProfileDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'legalName', nullable: false }, { name: 'preferredName', nullable: false }, { name: 'employeeNumber', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createEmployeeProfileDtoOptionalProperties();
    const optionalBooleanProperties = createEmployeeProfileDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmployeeProfileDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmployeeProfileDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmployeeProfileDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InactivePersonActiveUserResponsePersonStatusEnum;
(function (InactivePersonActiveUserResponsePersonStatusEnum) {
    InactivePersonActiveUserResponsePersonStatusEnum["Active"] = "ACTIVE";
    InactivePersonActiveUserResponsePersonStatusEnum["OnLeave"] = "ON_LEAVE";
    InactivePersonActiveUserResponsePersonStatusEnum["Suspended"] = "SUSPENDED";
    InactivePersonActiveUserResponsePersonStatusEnum["Terminated"] = "TERMINATED";
    InactivePersonActiveUserResponsePersonStatusEnum["Disabled"] = "DISABLED";
})(InactivePersonActiveUserResponsePersonStatusEnum || (InactivePersonActiveUserResponsePersonStatusEnum = {}));
;
function isOptionalInactivePersonActiveUserResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInactivePersonActiveUserResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInactivePersonActiveUserResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInactivePersonActiveUserResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInactivePersonActiveUserResponsePropertyNames('linkId', 'userId', 'personId', 'personStatus');
    const optionalStringProperties = createInactivePersonActiveUserResponseOptionalProperties({ name: 'linkId', nullable: false }, { name: 'userId', nullable: false }, { name: 'personId', nullable: false }, { name: 'personStatus', nullable: false });
    const optionalNumberProperties = createInactivePersonActiveUserResponseOptionalProperties();
    const optionalBooleanProperties = createInactivePersonActiveUserResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInactivePersonActiveUserResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInactivePersonActiveUserResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInactivePersonActiveUserResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLinkUserToPersonRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLinkUserToPersonRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLinkUserToPersonRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfLinkUserToPersonRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLinkUserToPersonRequestPropertyNames('userId', 'personId');
    const optionalStringProperties = createLinkUserToPersonRequestOptionalProperties({ name: 'userId', nullable: false }, { name: 'personId', nullable: false }, { name: 'linkType', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createLinkUserToPersonRequestOptionalProperties();
    const optionalBooleanProperties = createLinkUserToPersonRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLinkUserToPersonRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLinkUserToPersonRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLinkUserToPersonRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PeopleAvailabilityResponseAssignmentStatusEnum;
(function (PeopleAvailabilityResponseAssignmentStatusEnum) {
    PeopleAvailabilityResponseAssignmentStatusEnum["Active"] = "ACTIVE";
    PeopleAvailabilityResponseAssignmentStatusEnum["Ended"] = "ENDED";
})(PeopleAvailabilityResponseAssignmentStatusEnum || (PeopleAvailabilityResponseAssignmentStatusEnum = {}));
;
function isOptionalPeopleAvailabilityResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPeopleAvailabilityResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPeopleAvailabilityResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPeopleAvailabilityResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPeopleAvailabilityResponsePropertyNames('personId', 'locationId', 'primary', 'assignmentStatus');
    const optionalStringProperties = createPeopleAvailabilityResponseOptionalProperties({ name: 'personId', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'locationId', nullable: false }, { name: 'role', nullable: false }, { name: 'assignmentStatus', nullable: false });
    const optionalNumberProperties = createPeopleAvailabilityResponseOptionalProperties();
    const optionalBooleanProperties = createPeopleAvailabilityResponseOptionalProperties({ name: 'primary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPeopleAvailabilityResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPeopleAvailabilityResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPeopleAvailabilityResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var PersonEmployeeStatusEnum;
(function (PersonEmployeeStatusEnum) {
    PersonEmployeeStatusEnum["Active"] = "ACTIVE";
    PersonEmployeeStatusEnum["OnLeave"] = "ON_LEAVE";
    PersonEmployeeStatusEnum["Suspended"] = "SUSPENDED";
    PersonEmployeeStatusEnum["Terminated"] = "TERMINATED";
    PersonEmployeeStatusEnum["Disabled"] = "DISABLED";
})(PersonEmployeeStatusEnum || (PersonEmployeeStatusEnum = {}));
;
function isOptionalPersonPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPersonPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPersonOptionalProperties(...properties) {
    return properties;
}
function instanceOfPerson(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPersonPropertyNames('firstName', 'lastName');
    const optionalStringProperties = createPersonOptionalProperties({ name: 'id', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'primaryEmail', nullable: false }, { name: 'secondaryEmail', nullable: false }, { name: 'username', nullable: false }, { name: 'employeeStatus', nullable: false });
    const optionalNumberProperties = createPersonOptionalProperties();
    const optionalBooleanProperties = createPersonOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPersonPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPersonPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPersonPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPersonBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPersonBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPersonBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfPersonBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPersonBulkIngestRecordPropertyNames('legalName', 'employeeNumber', 'hireDate');
    const optionalStringProperties = createPersonBulkIngestRecordOptionalProperties({ name: 'legalName', nullable: false }, { name: 'preferredName', nullable: false }, { name: 'employeeNumber', nullable: false }, { name: 'hireDate', nullable: false }, { name: 'primaryEmail', nullable: false }, { name: 'primaryPhone', nullable: false });
    const optionalNumberProperties = createPersonBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createPersonBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPersonBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPersonBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPersonBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPersonResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPersonResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPersonResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPersonResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPersonResponsePropertyNames('id');
    const optionalStringProperties = createPersonResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'primaryEmail', nullable: false }, { name: 'secondaryEmail', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createPersonResponseOptionalProperties();
    const optionalBooleanProperties = createPersonResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPersonResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPersonResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPersonResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPersonRoleAssignmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPersonRoleAssignmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPersonRoleAssignmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPersonRoleAssignmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPersonRoleAssignmentRequestPropertyNames('roleCode');
    const optionalStringProperties = createPersonRoleAssignmentRequestOptionalProperties({ name: 'roleCode', nullable: false }, { name: 'locationId', nullable: false });
    const optionalNumberProperties = createPersonRoleAssignmentRequestOptionalProperties();
    const optionalBooleanProperties = createPersonRoleAssignmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPersonRoleAssignmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPersonRoleAssignmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPersonRoleAssignmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPrimaryLocationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPrimaryLocationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPrimaryLocationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPrimaryLocationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPrimaryLocationResponsePropertyNames('locationId');
    const optionalStringProperties = createPrimaryLocationResponseOptionalProperties({ name: 'locationId', nullable: false });
    const optionalNumberProperties = createPrimaryLocationResponseOptionalProperties();
    const optionalBooleanProperties = createPrimaryLocationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPrimaryLocationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPrimaryLocationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPrimaryLocationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProblemDetailPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProblemDetailPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProblemDetailOptionalProperties(...properties) {
    return properties;
}
function instanceOfProblemDetail(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProblemDetailPropertyNames();
    const optionalStringProperties = createProblemDetailOptionalProperties({ name: 'type', nullable: false }, { name: 'title', nullable: false }, { name: 'detail', nullable: false }, { name: 'instance', nullable: false });
    const optionalNumberProperties = createProblemDetailOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createProblemDetailOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProblemDetailPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProblemDetailPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProblemDetailPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRejectTimePeriodRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRejectTimePeriodRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRejectTimePeriodRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRejectTimePeriodRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRejectTimePeriodRequestPropertyNames('reason');
    const optionalStringProperties = createRejectTimePeriodRequestOptionalProperties({ name: 'reason', nullable: false });
    const optionalNumberProperties = createRejectTimePeriodRequestOptionalProperties();
    const optionalBooleanProperties = createRejectTimePeriodRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRejectTimePeriodRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRejectTimePeriodRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRejectTimePeriodRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalResolvePersonRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolvePersonRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolvePersonRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolvePersonRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolvePersonRequestPropertyNames();
    const optionalStringProperties = createResolvePersonRequestOptionalProperties({ name: 'email', nullable: false }, { name: 'phone', nullable: false }, { name: 'lastName', nullable: false }, { name: 'firstName', nullable: false });
    const optionalNumberProperties = createResolvePersonRequestOptionalProperties({ name: 'threshold', nullable: false });
    const optionalBooleanProperties = createResolvePersonRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolvePersonRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolvePersonRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolvePersonRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalResolvePersonResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolvePersonResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolvePersonResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolvePersonResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolvePersonResponsePropertyNames('personId', 'matchedExisting', 'score', 'thresholdApplied');
    const optionalStringProperties = createResolvePersonResponseOptionalProperties({ name: 'personId', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'primaryEmail', nullable: false });
    const optionalNumberProperties = createResolvePersonResponseOptionalProperties({ name: 'score', nullable: false }, { name: 'thresholdApplied', nullable: false });
    const optionalBooleanProperties = createResolvePersonResponseOptionalProperties({ name: 'matchedExisting', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolvePersonResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolvePersonResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolvePersonResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleDtoPropertyNames();
    const optionalStringProperties = createRoleDtoOptionalProperties({ name: 'code', nullable: false }, { name: 'name', nullable: false }, { name: 'description', nullable: false }, { name: 'scopeType', nullable: false });
    const optionalNumberProperties = createRoleDtoOptionalProperties();
    const optionalBooleanProperties = createRoleDtoOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var StaffingAssignmentResponseStatusEnum;
(function (StaffingAssignmentResponseStatusEnum) {
    StaffingAssignmentResponseStatusEnum["Active"] = "ACTIVE";
    StaffingAssignmentResponseStatusEnum["Ended"] = "ENDED";
})(StaffingAssignmentResponseStatusEnum || (StaffingAssignmentResponseStatusEnum = {}));
;
function isOptionalStaffingAssignmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStaffingAssignmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createStaffingAssignmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfStaffingAssignmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStaffingAssignmentResponsePropertyNames('assignmentId', 'personId', 'locationId', 'role', 'status', 'effectiveFrom', 'isPrimary');
    const optionalStringProperties = createStaffingAssignmentResponseOptionalProperties({ name: 'assignmentId', nullable: false }, { name: 'personId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'role', nullable: false }, { name: 'status', nullable: false }, { name: 'createdBy', nullable: false });
    const optionalNumberProperties = createStaffingAssignmentResponseOptionalProperties();
    const optionalBooleanProperties = createStaffingAssignmentResponseOptionalProperties({ name: 'isPrimary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStaffingAssignmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStaffingAssignmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStaffingAssignmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimeEntryAdjustmentStatusEnum;
(function (TimeEntryAdjustmentStatusEnum) {
    TimeEntryAdjustmentStatusEnum["Proposed"] = "PROPOSED";
    TimeEntryAdjustmentStatusEnum["Pending"] = "PENDING";
    TimeEntryAdjustmentStatusEnum["Approved"] = "APPROVED";
    TimeEntryAdjustmentStatusEnum["Rejected"] = "REJECTED";
})(TimeEntryAdjustmentStatusEnum || (TimeEntryAdjustmentStatusEnum = {}));
;
function isOptionalTimeEntryAdjustmentPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryAdjustmentPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryAdjustmentOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryAdjustment(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryAdjustmentPropertyNames('timeEntryId', 'reasonCode', 'status');
    const optionalStringProperties = createTimeEntryAdjustmentOptionalProperties({ name: 'adjustmentId', nullable: false }, { name: 'timeEntryId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'notes', nullable: false }, { name: 'status', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'decidedBy', nullable: false });
    const optionalNumberProperties = createTimeEntryAdjustmentOptionalProperties({ name: 'minutesDelta', nullable: false });
    const optionalBooleanProperties = createTimeEntryAdjustmentOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryAdjustmentPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryAdjustmentPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryAdjustmentPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTimeEntryAdjustmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryAdjustmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryAdjustmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryAdjustmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryAdjustmentRequestPropertyNames('timeEntryId', 'reasonCode');
    const optionalStringProperties = createTimeEntryAdjustmentRequestOptionalProperties({ name: 'timeEntryId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'notes', nullable: false }, { name: 'createdBy', nullable: false });
    const optionalNumberProperties = createTimeEntryAdjustmentRequestOptionalProperties({ name: 'minutesDelta', nullable: false });
    const optionalBooleanProperties = createTimeEntryAdjustmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryAdjustmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryAdjustmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryAdjustmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTimeEntryAdjustmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryAdjustmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryAdjustmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryAdjustmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryAdjustmentResponsePropertyNames('success');
    const optionalStringProperties = createTimeEntryAdjustmentResponseOptionalProperties({ name: 'adjustmentId', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createTimeEntryAdjustmentResponseOptionalProperties();
    const optionalBooleanProperties = createTimeEntryAdjustmentResponseOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryAdjustmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryAdjustmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryAdjustmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalTimeEntryDecisionBatchRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryDecisionBatchRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryDecisionBatchRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryDecisionBatchRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryDecisionBatchRequestPropertyNames('decisions');
    const optionalStringProperties = createTimeEntryDecisionBatchRequestOptionalProperties();
    const optionalNumberProperties = createTimeEntryDecisionBatchRequestOptionalProperties();
    const optionalBooleanProperties = createTimeEntryDecisionBatchRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryDecisionBatchRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryDecisionBatchRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryDecisionBatchRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimeEntryExceptionSeverityEnum;
(function (TimeEntryExceptionSeverityEnum) {
    TimeEntryExceptionSeverityEnum["Warning"] = "WARNING";
    TimeEntryExceptionSeverityEnum["Blocking"] = "BLOCKING";
})(TimeEntryExceptionSeverityEnum || (TimeEntryExceptionSeverityEnum = {}));
;
var TimeEntryExceptionStatusEnum;
(function (TimeEntryExceptionStatusEnum) {
    TimeEntryExceptionStatusEnum["Open"] = "OPEN";
    TimeEntryExceptionStatusEnum["Acknowledged"] = "ACKNOWLEDGED";
    TimeEntryExceptionStatusEnum["Resolved"] = "RESOLVED";
    TimeEntryExceptionStatusEnum["Waived"] = "WAIVED";
})(TimeEntryExceptionStatusEnum || (TimeEntryExceptionStatusEnum = {}));
;
function isOptionalTimeEntryExceptionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryExceptionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryExceptionOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryException(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryExceptionPropertyNames('employeeId', 'workDate', 'exceptionCode', 'severity', 'status');
    const optionalStringProperties = createTimeEntryExceptionOptionalProperties({ name: 'exceptionId', nullable: false }, { name: 'employeeId', nullable: false }, { name: 'exceptionCode', nullable: false }, { name: 'severity', nullable: false }, { name: 'status', nullable: false }, { name: 'timeEntryId', nullable: false }, { name: 'resolutionNotes', nullable: false }, { name: 'resolvedBy', nullable: false });
    const optionalNumberProperties = createTimeEntryExceptionOptionalProperties();
    const optionalBooleanProperties = createTimeEntryExceptionOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryExceptionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryExceptionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryExceptionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimeEntryExceptionRequestSeverityEnum;
(function (TimeEntryExceptionRequestSeverityEnum) {
    TimeEntryExceptionRequestSeverityEnum["Warning"] = "WARNING";
    TimeEntryExceptionRequestSeverityEnum["Blocking"] = "BLOCKING";
})(TimeEntryExceptionRequestSeverityEnum || (TimeEntryExceptionRequestSeverityEnum = {}));
;
function isOptionalTimeEntryExceptionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryExceptionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryExceptionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryExceptionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryExceptionRequestPropertyNames('employeeId', 'exceptionCode');
    const optionalStringProperties = createTimeEntryExceptionRequestOptionalProperties({ name: 'employeeId', nullable: false }, { name: 'exceptionCode', nullable: false }, { name: 'severity', nullable: false }, { name: 'timeEntryId', nullable: false }, { name: 'resolutionNotes', nullable: false });
    const optionalNumberProperties = createTimeEntryExceptionRequestOptionalProperties();
    const optionalBooleanProperties = createTimeEntryExceptionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryExceptionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryExceptionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryExceptionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTimeEntryExceptionResolveRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryExceptionResolveRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryExceptionResolveRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryExceptionResolveRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryExceptionResolveRequestPropertyNames();
    const optionalStringProperties = createTimeEntryExceptionResolveRequestOptionalProperties({ name: 'resolutionNotes', nullable: false });
    const optionalNumberProperties = createTimeEntryExceptionResolveRequestOptionalProperties();
    const optionalBooleanProperties = createTimeEntryExceptionResolveRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryExceptionResolveRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryExceptionResolveRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryExceptionResolveRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTimeEntryExceptionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryExceptionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryExceptionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryExceptionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryExceptionResponsePropertyNames('success');
    const optionalStringProperties = createTimeEntryExceptionResponseOptionalProperties({ name: 'exceptionId', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createTimeEntryExceptionResponseOptionalProperties();
    const optionalBooleanProperties = createTimeEntryExceptionResponseOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryExceptionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryExceptionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryExceptionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTimeEntryExceptionWaiveRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimeEntryExceptionWaiveRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimeEntryExceptionWaiveRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimeEntryExceptionWaiveRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimeEntryExceptionWaiveRequestPropertyNames('waiveReason');
    const optionalStringProperties = createTimeEntryExceptionWaiveRequestOptionalProperties({ name: 'waiveReason', nullable: false });
    const optionalNumberProperties = createTimeEntryExceptionWaiveRequestOptionalProperties();
    const optionalBooleanProperties = createTimeEntryExceptionWaiveRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimeEntryExceptionWaiveRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimeEntryExceptionWaiveRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimeEntryExceptionWaiveRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimePeriodApprovalDtoOverallStatusEnum;
(function (TimePeriodApprovalDtoOverallStatusEnum) {
    TimePeriodApprovalDtoOverallStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    TimePeriodApprovalDtoOverallStatusEnum["Approved"] = "APPROVED";
    TimePeriodApprovalDtoOverallStatusEnum["Rejected"] = "REJECTED";
})(TimePeriodApprovalDtoOverallStatusEnum || (TimePeriodApprovalDtoOverallStatusEnum = {}));
;
function isOptionalTimePeriodApprovalDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimePeriodApprovalDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimePeriodApprovalDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimePeriodApprovalDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimePeriodApprovalDtoPropertyNames('personId', 'timePeriodId', 'totalCount', 'pendingCount', 'approvedCount', 'rejectedCount', 'overallStatus');
    const optionalStringProperties = createTimePeriodApprovalDtoOptionalProperties({ name: 'personId', nullable: false }, { name: 'timePeriodId', nullable: false }, { name: 'overallStatus', nullable: false });
    const optionalNumberProperties = createTimePeriodApprovalDtoOptionalProperties({ name: 'totalCount', nullable: false }, { name: 'pendingCount', nullable: false }, { name: 'approvedCount', nullable: false }, { name: 'rejectedCount', nullable: false });
    const optionalBooleanProperties = createTimePeriodApprovalDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimePeriodApprovalDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimePeriodApprovalDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimePeriodApprovalDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTimePeriodDecisionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimePeriodDecisionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimePeriodDecisionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimePeriodDecisionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimePeriodDecisionResponsePropertyNames('personId', 'timePeriodId', 'processedCount', 'status');
    const optionalStringProperties = createTimePeriodDecisionResponseOptionalProperties({ name: 'personId', nullable: false }, { name: 'timePeriodId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createTimePeriodDecisionResponseOptionalProperties({ name: 'processedCount', nullable: false });
    const optionalBooleanProperties = createTimePeriodDecisionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimePeriodDecisionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimePeriodDecisionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimePeriodDecisionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimePeriodDtoStatusEnum;
(function (TimePeriodDtoStatusEnum) {
    TimePeriodDtoStatusEnum["Open"] = "OPEN";
    TimePeriodDtoStatusEnum["SubmissionClosed"] = "SUBMISSION_CLOSED";
    TimePeriodDtoStatusEnum["PayrollClosed"] = "PAYROLL_CLOSED";
})(TimePeriodDtoStatusEnum || (TimePeriodDtoStatusEnum = {}));
;
function isOptionalTimePeriodDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimePeriodDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimePeriodDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimePeriodDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimePeriodDtoPropertyNames('timePeriodId', 'tenantId', 'startDate', 'endDate', 'status');
    const optionalStringProperties = createTimePeriodDtoOptionalProperties({ name: 'timePeriodId', nullable: false }, { name: 'tenantId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createTimePeriodDtoOptionalProperties();
    const optionalBooleanProperties = createTimePeriodDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimePeriodDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimePeriodDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimePeriodDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TimekeepingEntryDtoApprovalStatusEnum;
(function (TimekeepingEntryDtoApprovalStatusEnum) {
    TimekeepingEntryDtoApprovalStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    TimekeepingEntryDtoApprovalStatusEnum["Approved"] = "APPROVED";
    TimekeepingEntryDtoApprovalStatusEnum["Rejected"] = "REJECTED";
})(TimekeepingEntryDtoApprovalStatusEnum || (TimekeepingEntryDtoApprovalStatusEnum = {}));
;
function isOptionalTimekeepingEntryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTimekeepingEntryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTimekeepingEntryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTimekeepingEntryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTimekeepingEntryDtoPropertyNames('timekeepingEntryId', 'employeeId', 'sessionStartTime', 'approvalStatus');
    const optionalStringProperties = createTimekeepingEntryDtoOptionalProperties({ name: 'timekeepingEntryId', nullable: false }, { name: 'employeeId', nullable: false }, { name: 'approvalStatus', nullable: false }, { name: 'associatedWorkOrderId', nullable: false });
    const optionalNumberProperties = createTimekeepingEntryDtoOptionalProperties();
    const optionalBooleanProperties = createTimekeepingEntryDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTimekeepingEntryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTimekeepingEntryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTimekeepingEntryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var UpdateEmployeeRequestStatusEnum;
(function (UpdateEmployeeRequestStatusEnum) {
    UpdateEmployeeRequestStatusEnum["Active"] = "ACTIVE";
    UpdateEmployeeRequestStatusEnum["OnLeave"] = "ON_LEAVE";
    UpdateEmployeeRequestStatusEnum["Suspended"] = "SUSPENDED";
    UpdateEmployeeRequestStatusEnum["Terminated"] = "TERMINATED";
    UpdateEmployeeRequestStatusEnum["Disabled"] = "DISABLED";
})(UpdateEmployeeRequestStatusEnum || (UpdateEmployeeRequestStatusEnum = {}));
;
var UpdateEmployeeRequestDuplicatePolicyEnum;
(function (UpdateEmployeeRequestDuplicatePolicyEnum) {
    UpdateEmployeeRequestDuplicatePolicyEnum["Strict"] = "STRICT";
    UpdateEmployeeRequestDuplicatePolicyEnum["Balanced"] = "BALANCED";
})(UpdateEmployeeRequestDuplicatePolicyEnum || (UpdateEmployeeRequestDuplicatePolicyEnum = {}));
;
function isOptionalUpdateEmployeeRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateEmployeeRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateEmployeeRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateEmployeeRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateEmployeeRequestPropertyNames('legalName', 'employeeNumber', 'status', 'hireDate');
    const optionalStringProperties = createUpdateEmployeeRequestOptionalProperties({ name: 'legalName', nullable: false }, { name: 'preferredName', nullable: false }, { name: 'employeeNumber', nullable: false }, { name: 'status', nullable: false }, { name: 'duplicatePolicy', nullable: false });
    const optionalNumberProperties = createUpdateEmployeeRequestOptionalProperties();
    const optionalBooleanProperties = createUpdateEmployeeRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateEmployeeRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateEmployeeRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateEmployeeRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpdateStaffingAssignmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateStaffingAssignmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateStaffingAssignmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateStaffingAssignmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateStaffingAssignmentRequestPropertyNames('personId', 'locationId', 'role', 'effectiveFrom', 'isPrimary');
    const optionalStringProperties = createUpdateStaffingAssignmentRequestOptionalProperties({ name: 'personId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'role', nullable: false });
    const optionalNumberProperties = createUpdateStaffingAssignmentRequestOptionalProperties();
    const optionalBooleanProperties = createUpdateStaffingAssignmentRequestOptionalProperties({ name: 'effectiveDateRangeValid', nullable: false }, { name: 'isPrimary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateStaffingAssignmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateStaffingAssignmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateStaffingAssignmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUserPersonLinkResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUserPersonLinkResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createUserPersonLinkResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfUserPersonLinkResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUserPersonLinkResponsePropertyNames('linkId', 'userId', 'personId');
    const optionalStringProperties = createUserPersonLinkResponseOptionalProperties({ name: 'linkId', nullable: false }, { name: 'userId', nullable: false }, { name: 'personId', nullable: false }, { name: 'linkType', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createUserPersonLinkResponseOptionalProperties();
    const optionalBooleanProperties = createUserPersonLinkResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUserPersonLinkResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUserPersonLinkResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUserPersonLinkResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUserRoleDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUserRoleDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUserRoleDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUserRoleDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUserRoleDtoPropertyNames();
    const optionalStringProperties = createUserRoleDtoOptionalProperties({ name: 'userId', nullable: false }, { name: 'roleCode', nullable: false }, { name: 'locationId', nullable: false });
    const optionalNumberProperties = createUserRoleDtoOptionalProperties();
    const optionalBooleanProperties = createUserRoleDtoOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUserRoleDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUserRoleDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUserRoleDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalWorkSessionDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createWorkSessionDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createWorkSessionDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfWorkSessionDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createWorkSessionDtoPropertyNames('sessionId', 'personId', 'status');
    const optionalStringProperties = createWorkSessionDtoOptionalProperties({ name: 'sessionId', nullable: false }, { name: 'personId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createWorkSessionDtoOptionalProperties({ name: 'billableMinutes', nullable: false }, { name: 'breakMinutes', nullable: false });
    const optionalBooleanProperties = createWorkSessionDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalWorkSessionDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalWorkSessionDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalWorkSessionDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalWorkSessionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createWorkSessionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createWorkSessionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfWorkSessionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createWorkSessionRequestPropertyNames('personId');
    const optionalStringProperties = createWorkSessionRequestOptionalProperties({ name: 'personId', nullable: false }, { name: 'actor', nullable: false });
    const optionalNumberProperties = createWorkSessionRequestOptionalProperties();
    const optionalBooleanProperties = createWorkSessionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalWorkSessionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalWorkSessionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalWorkSessionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalWorkSessionSubmitRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createWorkSessionSubmitRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createWorkSessionSubmitRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfWorkSessionSubmitRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createWorkSessionSubmitRequestPropertyNames('billableMinutes', 'breakMinutes', 'submittedAt');
    const optionalStringProperties = createWorkSessionSubmitRequestOptionalProperties();
    const optionalNumberProperties = createWorkSessionSubmitRequestOptionalProperties({ name: 'billableMinutes', nullable: false }, { name: 'breakMinutes', nullable: false });
    const optionalBooleanProperties = createWorkSessionSubmitRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalWorkSessionSubmitRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalWorkSessionSubmitRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalWorkSessionSubmitRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { APIS, ApiModule, BASE_PATH, COLLECTION_FORMATS, Configuration, ContactPointDtoContactTypeEnum, CreateEmployeeRequestDuplicatePolicyEnum, CreateEmployeeRequestStatusEnum, DisableEmployeeRequestDtoAssignmentPolicyEnum, EmployeeAPIService, EmployeeProfileDtoStatusEnum, InactivePersonActiveUserResponsePersonStatusEnum, PeopleAPIService, PeopleAccessControlService, PeopleAvailabilityAPIService, PeopleAvailabilityResponseAssignmentStatusEnum, PeopleBulkIngestAPIService, PeopleExceptionsService, PeopleReportsAPIService, PeopleStaffingAssignmentsService, PeopleTimeEntriesService, PersonEmployeeStatusEnum, StaffingAssignmentResponseStatusEnum, TimeEntryAdjustmentStatusEnum, TimeEntryApprovalAPIService, TimeEntryExceptionRequestSeverityEnum, TimeEntryExceptionSeverityEnum, TimeEntryExceptionStatusEnum, TimePeriodApprovalDtoOverallStatusEnum, TimePeriodDtoStatusEnum, TimekeepingApprovalAPIService, TimekeepingEntryDtoApprovalStatusEnum, UpdateEmployeeRequestDuplicatePolicyEnum, UpdateEmployeeRequestStatusEnum, UserPersonLinkingAPIService, WorkSessionsAPIService, instanceOfApprovalPersonDto, instanceOfApprovedTimeExportResponse, instanceOfAttendanceDiscrepancyReportResponse, instanceOfBreakDto, instanceOfBulkIngestRequestPersonBulkIngestRecord, instanceOfBulkIngestResponse, instanceOfBulkIngestResult, instanceOfContactPointDto, instanceOfCreateEmployeeRequest, instanceOfCreateStaffingAssignmentRequest, instanceOfCreateUserLinkRequest, instanceOfDecision, instanceOfDisableEmployeeRequestDto, instanceOfEmployeeAddressDto, instanceOfEmployeeContactInfoDto, instanceOfEmployeeEmergencyContactDto, instanceOfEmployeeProfileDto, instanceOfInactivePersonActiveUserResponse, instanceOfLinkUserToPersonRequest, instanceOfPeopleAvailabilityResponse, instanceOfPerson, instanceOfPersonBulkIngestRecord, instanceOfPersonResponse, instanceOfPersonRoleAssignmentRequest, instanceOfPrimaryLocationResponse, instanceOfProblemDetail, instanceOfRejectTimePeriodRequest, instanceOfResolvePersonRequest, instanceOfResolvePersonResponse, instanceOfRoleDto, instanceOfStaffingAssignmentResponse, instanceOfTimeEntryAdjustment, instanceOfTimeEntryAdjustmentRequest, instanceOfTimeEntryAdjustmentResponse, instanceOfTimeEntryDecisionBatchRequest, instanceOfTimeEntryException, instanceOfTimeEntryExceptionRequest, instanceOfTimeEntryExceptionResolveRequest, instanceOfTimeEntryExceptionResponse, instanceOfTimeEntryExceptionWaiveRequest, instanceOfTimePeriodApprovalDto, instanceOfTimePeriodDecisionResponse, instanceOfTimePeriodDto, instanceOfTimekeepingEntryDto, instanceOfUpdateEmployeeRequest, instanceOfUpdateStaffingAssignmentRequest, instanceOfUserPersonLinkResponse, instanceOfUserRoleDto, instanceOfWorkSessionDto, instanceOfWorkSessionRequest, instanceOfWorkSessionSubmitRequest, provideApi };
//# sourceMappingURL=durion-sdk-people.mjs.map
