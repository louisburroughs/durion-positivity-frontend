export * from '../../models/contactPointDto';
