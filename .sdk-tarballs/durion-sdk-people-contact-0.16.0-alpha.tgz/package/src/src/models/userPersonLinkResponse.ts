export * from '../../models/userPersonLinkResponse';
