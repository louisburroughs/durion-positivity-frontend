export * from '../../models/resolvePersonResponse';
