import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/warranty';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantyClaimsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addLine(id, claimLineRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling addLine.');
        }
        if (claimLineRequest === null || claimLineRequest === undefined) {
            throw new Error('Required parameter claimLineRequest was null or undefined when calling addLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/lines`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimLineRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    addNote(id, claimNoteRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling addNote.');
        }
        if (claimNoteRequest === null || claimNoteRequest === undefined) {
            throw new Error('Required parameter claimNoteRequest was null or undefined when calling addNote.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/notes`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimNoteRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    addPhoto(id, claimPhotoRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling addPhoto.');
        }
        if (claimPhotoRequest === null || claimPhotoRequest === undefined) {
            throw new Error('Required parameter claimPhotoRequest was null or undefined when calling addPhoto.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/photos`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimPhotoRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    cancelClaim(id, claimActionRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling cancelClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/cancel`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimActionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    closeClaim(id, claimActionRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling closeClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/close`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimActionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createClaim(claimCreateRequest, observe = 'body', reportProgress = false, options) {
        if (claimCreateRequest === null || claimCreateRequest === undefined) {
            throw new Error('Required parameter claimCreateRequest was null or undefined when calling createClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    decideClaim(id, claimDecisionRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling decideClaim.');
        }
        if (claimDecisionRequest === null || claimDecisionRequest === undefined) {
            throw new Error('Required parameter claimDecisionRequest was null or undefined when calling decideClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/decision`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimDecisionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    evaluateEligibility(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling evaluateEligibility.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/eligibility`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getClaim(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeLine(id, lineId, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling removeLine.');
        }
        if (lineId === null || lineId === undefined) {
            throw new Error('Required parameter lineId was null or undefined when calling removeLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/lines/${this.configuration.encodeParam({ name: "lineId", value: lineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removePhoto(id, url, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling removePhoto.');
        }
        if (url === null || url === undefined) {
            throw new Error('Required parameter url was null or undefined when calling removePhoto.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'url', url, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/photos`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchCandidateLines(customerId, vehicleId, sku, productEntityId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling searchCandidateLines.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vehicleId', vehicleId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productEntityId', productEntityId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/candidate-lines`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchClaims(pageable, customerId, vehicleId, status, claimCode, locationId, observe = 'body', reportProgress = false, options) {
        if (pageable === null || pageable === undefined) {
            throw new Error('Required parameter pageable was null or undefined when calling searchClaims.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vehicleId', vehicleId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'claimCode', claimCode, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageable', pageable, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitClaim(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling submitClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/submit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateClaim(id, claimUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateClaim.');
        }
        if (claimUpdateRequest === null || claimUpdateRequest === undefined) {
            throw new Error('Required parameter claimUpdateRequest was null or undefined when calling updateClaim.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: claimUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyClaimsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyClaimsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyClaimsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantyPartReturnsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPartReturn(id, partReturnCreateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling createPartReturn.');
        }
        if (partReturnCreateRequest === null || partReturnCreateRequest === undefined) {
            throw new Error('Required parameter partReturnCreateRequest was null or undefined when calling createPartReturn.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/part-returns`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: partReturnCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPartReturns(status, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/part-returns`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePartReturn(id, partReturnUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updatePartReturn.');
        }
        if (partReturnUpdateRequest === null || partReturnUpdateRequest === undefined) {
            throw new Error('Required parameter partReturnUpdateRequest was null or undefined when calling updatePartReturn.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/part-returns/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: partReturnUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyPartReturnsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyPartReturnsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyPartReturnsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantyPoliciesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPolicy(policyRequest, observe = 'body', reportProgress = false, options) {
        if (policyRequest === null || policyRequest === undefined) {
            throw new Error('Required parameter policyRequest was null or undefined when calling createPolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/policies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: policyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    findApplicablePolicies(saleDate, productEntityId, manufacturerId, categoryId, coverageType, observe = 'body', reportProgress = false, options) {
        if (saleDate === null || saleDate === undefined) {
            throw new Error('Required parameter saleDate was null or undefined when calling findApplicablePolicies.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productEntityId', productEntityId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'manufacturerId', manufacturerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'categoryId', categoryId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'saleDate', saleDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'coverageType', coverageType, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/policies/applicable`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPolicy(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getPolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/policies/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPolicies(providerId, coverageType, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'providerId', providerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'coverageType', coverageType, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/policies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePolicy(id, policyRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updatePolicy.');
        }
        if (policyRequest === null || policyRequest === undefined) {
            throw new Error('Required parameter policyRequest was null or undefined when calling updatePolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/policies/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: policyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyPoliciesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyPoliciesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyPoliciesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantyProvidersService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createProvider(providerRequest, observe = 'body', reportProgress = false, options) {
        if (providerRequest === null || providerRequest === undefined) {
            throw new Error('Required parameter providerRequest was null or undefined when calling createProvider.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/providers`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: providerRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getProvider(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getProvider.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/providers/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listProviders(status, providerType, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'providerType', providerType, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/providers`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateProvider(id, providerRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateProvider.');
        }
        if (providerRequest === null || providerRequest === undefined) {
            throw new Error('Required parameter providerRequest was null or undefined when calling updateProvider.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/providers/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: providerRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyProvidersService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyProvidersService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyProvidersService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantyRegistrationsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createRegistration(registrationRequest, observe = 'body', reportProgress = false, options) {
        if (registrationRequest === null || registrationRequest === undefined) {
            throw new Error('Required parameter registrationRequest was null or undefined when calling createRegistration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/registrations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: registrationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRegistration(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getRegistration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/registrations/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchRegistrations(customerId, vehicleId, status, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vehicleId', vehicleId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/registrations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateRegistration(id, registrationRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateRegistration.');
        }
        if (registrationRequest === null || registrationRequest === undefined) {
            throw new Error('Required parameter registrationRequest was null or undefined when calling updateRegistration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/registrations/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: registrationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyRegistrationsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyRegistrationsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyRegistrationsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantyReimbursementsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listReimbursements(status, providerId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'providerId', providerId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/reimbursements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitReimbursement(id, reimbursementSubmitRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling submitReimbursement.');
        }
        if (reimbursementSubmitRequest === null || reimbursementSubmitRequest === undefined) {
            throw new Error('Required parameter reimbursementSubmitRequest was null or undefined when calling submitReimbursement.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reimbursement/submit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reimbursementSubmitRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateReimbursement(id, reimbursementUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateReimbursement.');
        }
        if (reimbursementUpdateRequest === null || reimbursementUpdateRequest === undefined) {
            throw new Error('Required parameter reimbursementUpdateRequest was null or undefined when calling updateReimbursement.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reimbursement`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reimbursementUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyReimbursementsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyReimbursementsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantyReimbursementsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class WarrantySettlementsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createSettlement(id, settlementCreateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling createSettlement.');
        }
        if (settlementCreateRequest === null || settlementCreateRequest === undefined) {
            throw new Error('Required parameter settlementCreateRequest was null or undefined when calling createSettlement.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/claims/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/settlements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: settlementCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reconcileSettlements(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/warranty/settlements/reconciliation`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantySettlementsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantySettlementsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: WarrantySettlementsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CandidateLineSourceTypeEnum;
(function (CandidateLineSourceTypeEnum) {
    CandidateLineSourceTypeEnum["InvoiceLine"] = "INVOICE_LINE";
    CandidateLineSourceTypeEnum["WorkorderPart"] = "WORKORDER_PART";
    CandidateLineSourceTypeEnum["WorkorderService"] = "WORKORDER_SERVICE";
    CandidateLineSourceTypeEnum["Manual"] = "MANUAL";
})(CandidateLineSourceTypeEnum || (CandidateLineSourceTypeEnum = {}));
;
function isOptionalCandidateLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCandidateLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCandidateLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfCandidateLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCandidateLinePropertyNames();
    const optionalStringProperties = createCandidateLineOptionalProperties({ name: 'sourceType', nullable: false }, { name: 'sourceId', nullable: false }, { name: 'sourceLineId', nullable: false }, { name: 'sourceReference', nullable: false }, { name: 'productEntityId', nullable: false }, { name: 'sku', nullable: false }, { name: 'description', nullable: false }, { name: 'sourceCreatedAt', nullable: false }, { name: 'photoEvidenceUrl', nullable: false });
    const optionalNumberProperties = createCandidateLineOptionalProperties({ name: 'quantity', nullable: false }, { name: 'unitPrice', nullable: false }, { name: 'lineTotal', nullable: false });
    const optionalBooleanProperties = createCandidateLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCandidateLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCandidateLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCandidateLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalClaimActionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimActionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimActionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimActionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimActionRequestPropertyNames();
    const optionalStringProperties = createClaimActionRequestOptionalProperties({ name: 'reason', nullable: false });
    const optionalNumberProperties = createClaimActionRequestOptionalProperties();
    const optionalBooleanProperties = createClaimActionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimActionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimActionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimActionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ClaimCreateRequestClaimTypeEnum;
(function (ClaimCreateRequestClaimTypeEnum) {
    ClaimCreateRequestClaimTypeEnum["ManufacturerDefect"] = "MANUFACTURER_DEFECT";
    ClaimCreateRequestClaimTypeEnum["DealerWorkmanship"] = "DEALER_WORKMANSHIP";
    ClaimCreateRequestClaimTypeEnum["RoadHazard"] = "ROAD_HAZARD";
    ClaimCreateRequestClaimTypeEnum["ExtendedPlan"] = "EXTENDED_PLAN";
})(ClaimCreateRequestClaimTypeEnum || (ClaimCreateRequestClaimTypeEnum = {}));
;
function isOptionalClaimCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimCreateRequestPropertyNames('claimType', 'customerId', 'vehicleId');
    const optionalStringProperties = createClaimCreateRequestOptionalProperties({ name: 'claimType', nullable: false }, { name: 'customerId', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'originWorkorderId', nullable: false }, { name: 'originInvoiceId', nullable: false }, { name: 'originSaleDate', nullable: false }, { name: 'registrationId', nullable: false }, { name: 'failureDescription', nullable: false }, { name: 'failureDate', nullable: false });
    const optionalNumberProperties = createClaimCreateRequestOptionalProperties();
    const optionalBooleanProperties = createClaimCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ClaimDecisionRequestDecisionEnum;
(function (ClaimDecisionRequestDecisionEnum) {
    ClaimDecisionRequestDecisionEnum["Approve"] = "APPROVE";
    ClaimDecisionRequestDecisionEnum["Deny"] = "DENY";
    ClaimDecisionRequestDecisionEnum["RequestInfo"] = "REQUEST_INFO";
    ClaimDecisionRequestDecisionEnum["Appeal"] = "APPEAL";
})(ClaimDecisionRequestDecisionEnum || (ClaimDecisionRequestDecisionEnum = {}));
;
function isOptionalClaimDecisionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimDecisionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimDecisionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimDecisionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimDecisionRequestPropertyNames('decision');
    const optionalStringProperties = createClaimDecisionRequestOptionalProperties({ name: 'decision', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createClaimDecisionRequestOptionalProperties();
    const optionalBooleanProperties = createClaimDecisionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimDecisionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimDecisionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimDecisionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ClaimLineRequestSourceTypeEnum;
(function (ClaimLineRequestSourceTypeEnum) {
    ClaimLineRequestSourceTypeEnum["InvoiceLine"] = "INVOICE_LINE";
    ClaimLineRequestSourceTypeEnum["WorkorderPart"] = "WORKORDER_PART";
    ClaimLineRequestSourceTypeEnum["WorkorderService"] = "WORKORDER_SERVICE";
    ClaimLineRequestSourceTypeEnum["Manual"] = "MANUAL";
})(ClaimLineRequestSourceTypeEnum || (ClaimLineRequestSourceTypeEnum = {}));
;
function isOptionalClaimLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimLineRequestPropertyNames('sourceType');
    const optionalStringProperties = createClaimLineRequestOptionalProperties({ name: 'sourceType', nullable: false }, { name: 'sourceId', nullable: false }, { name: 'sourceLineId', nullable: false }, { name: 'productEntityId', nullable: false }, { name: 'sku', nullable: false }, { name: 'description', nullable: false }, { name: 'serialNumber', nullable: false }, { name: 'dotNumber', nullable: false });
    const optionalNumberProperties = createClaimLineRequestOptionalProperties({ name: 'quantity', nullable: false }, { name: 'originalUnitPrice', nullable: false }, { name: 'originalTreadDepth', nullable: false }, { name: 'measuredTreadDepth', nullable: false });
    const optionalBooleanProperties = createClaimLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ClaimLineResponseSourceTypeEnum;
(function (ClaimLineResponseSourceTypeEnum) {
    ClaimLineResponseSourceTypeEnum["InvoiceLine"] = "INVOICE_LINE";
    ClaimLineResponseSourceTypeEnum["WorkorderPart"] = "WORKORDER_PART";
    ClaimLineResponseSourceTypeEnum["WorkorderService"] = "WORKORDER_SERVICE";
    ClaimLineResponseSourceTypeEnum["Manual"] = "MANUAL";
})(ClaimLineResponseSourceTypeEnum || (ClaimLineResponseSourceTypeEnum = {}));
;
var ClaimLineResponseLineDispositionEnum;
(function (ClaimLineResponseLineDispositionEnum) {
    ClaimLineResponseLineDispositionEnum["Pending"] = "PENDING";
    ClaimLineResponseLineDispositionEnum["Approved"] = "APPROVED";
    ClaimLineResponseLineDispositionEnum["PartiallyApproved"] = "PARTIALLY_APPROVED";
    ClaimLineResponseLineDispositionEnum["Denied"] = "DENIED";
    ClaimLineResponseLineDispositionEnum["Withdrawn"] = "WITHDRAWN";
})(ClaimLineResponseLineDispositionEnum || (ClaimLineResponseLineDispositionEnum = {}));
;
function isOptionalClaimLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimLineResponsePropertyNames();
    const optionalStringProperties = createClaimLineResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'sourceType', nullable: false }, { name: 'sourceId', nullable: false }, { name: 'sourceLineId', nullable: false }, { name: 'productEntityId', nullable: false }, { name: 'sku', nullable: false }, { name: 'description', nullable: false }, { name: 'serialNumber', nullable: false }, { name: 'dotNumber', nullable: false }, { name: 'lineDisposition', nullable: false });
    const optionalNumberProperties = createClaimLineResponseOptionalProperties({ name: 'quantity', nullable: false }, { name: 'originalUnitPrice', nullable: false }, { name: 'originalTreadDepth', nullable: false }, { name: 'measuredTreadDepth', nullable: false }, { name: 'prorationPct', nullable: false }, { name: 'amountRequested', nullable: false }, { name: 'amountApproved', nullable: false });
    const optionalBooleanProperties = createClaimLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalClaimNoteRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimNoteRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimNoteRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimNoteRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimNoteRequestPropertyNames('note');
    const optionalStringProperties = createClaimNoteRequestOptionalProperties({ name: 'note', nullable: false });
    const optionalNumberProperties = createClaimNoteRequestOptionalProperties();
    const optionalBooleanProperties = createClaimNoteRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimNoteRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimNoteRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimNoteRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalClaimPhotoRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimPhotoRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimPhotoRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimPhotoRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimPhotoRequestPropertyNames('url');
    const optionalStringProperties = createClaimPhotoRequestOptionalProperties({ name: 'url', nullable: false });
    const optionalNumberProperties = createClaimPhotoRequestOptionalProperties();
    const optionalBooleanProperties = createClaimPhotoRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimPhotoRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimPhotoRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimPhotoRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ClaimResponseClaimTypeEnum;
(function (ClaimResponseClaimTypeEnum) {
    ClaimResponseClaimTypeEnum["ManufacturerDefect"] = "MANUFACTURER_DEFECT";
    ClaimResponseClaimTypeEnum["DealerWorkmanship"] = "DEALER_WORKMANSHIP";
    ClaimResponseClaimTypeEnum["RoadHazard"] = "ROAD_HAZARD";
    ClaimResponseClaimTypeEnum["ExtendedPlan"] = "EXTENDED_PLAN";
})(ClaimResponseClaimTypeEnum || (ClaimResponseClaimTypeEnum = {}));
;
var ClaimResponseStatusEnum;
(function (ClaimResponseStatusEnum) {
    ClaimResponseStatusEnum["Draft"] = "DRAFT";
    ClaimResponseStatusEnum["Submitted"] = "SUBMITTED";
    ClaimResponseStatusEnum["InReview"] = "IN_REVIEW";
    ClaimResponseStatusEnum["InfoNeeded"] = "INFO_NEEDED";
    ClaimResponseStatusEnum["Approved"] = "APPROVED";
    ClaimResponseStatusEnum["Denied"] = "DENIED";
    ClaimResponseStatusEnum["Settled"] = "SETTLED";
    ClaimResponseStatusEnum["Closed"] = "CLOSED";
    ClaimResponseStatusEnum["Cancelled"] = "CANCELLED";
})(ClaimResponseStatusEnum || (ClaimResponseStatusEnum = {}));
;
var ClaimResponseEligibilityResultEnum;
(function (ClaimResponseEligibilityResultEnum) {
    ClaimResponseEligibilityResultEnum["Eligible"] = "ELIGIBLE";
    ClaimResponseEligibilityResultEnum["Ineligible"] = "INELIGIBLE";
    ClaimResponseEligibilityResultEnum["Indeterminate"] = "INDETERMINATE";
})(ClaimResponseEligibilityResultEnum || (ClaimResponseEligibilityResultEnum = {}));
;
var ClaimResponseDecisionEnum;
(function (ClaimResponseDecisionEnum) {
    ClaimResponseDecisionEnum["Approve"] = "APPROVE";
    ClaimResponseDecisionEnum["Deny"] = "DENY";
    ClaimResponseDecisionEnum["RequestInfo"] = "REQUEST_INFO";
})(ClaimResponseDecisionEnum || (ClaimResponseDecisionEnum = {}));
;
function isOptionalClaimResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimResponsePropertyNames();
    const optionalStringProperties = createClaimResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'claimCode', nullable: false }, { name: 'claimType', nullable: false }, { name: 'status', nullable: false }, { name: 'locationId', nullable: false }, { name: 'customerId', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'vin', nullable: false }, { name: 'odometerUnit', nullable: false }, { name: 'originWorkorderId', nullable: false }, { name: 'originInvoiceId', nullable: false }, { name: 'originSaleDate', nullable: false }, { name: 'providerId', nullable: false }, { name: 'policyId', nullable: false }, { name: 'registrationId', nullable: false }, { name: 'failureDescription', nullable: false }, { name: 'failureDate', nullable: false }, { name: 'eligibilityResult', nullable: false }, { name: 'decision', nullable: false }, { name: 'decisionReason', nullable: false }, { name: 'decidedBy', nullable: false }, { name: 'decidedAt', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createClaimResponseOptionalProperties({ name: 'odometerAtClaim', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createClaimResponseOptionalProperties({ name: 'originUnverified', nullable: false }, { name: 'overrodeSuggestion', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ClaimSummaryResponseClaimTypeEnum;
(function (ClaimSummaryResponseClaimTypeEnum) {
    ClaimSummaryResponseClaimTypeEnum["ManufacturerDefect"] = "MANUFACTURER_DEFECT";
    ClaimSummaryResponseClaimTypeEnum["DealerWorkmanship"] = "DEALER_WORKMANSHIP";
    ClaimSummaryResponseClaimTypeEnum["RoadHazard"] = "ROAD_HAZARD";
    ClaimSummaryResponseClaimTypeEnum["ExtendedPlan"] = "EXTENDED_PLAN";
})(ClaimSummaryResponseClaimTypeEnum || (ClaimSummaryResponseClaimTypeEnum = {}));
;
var ClaimSummaryResponseStatusEnum;
(function (ClaimSummaryResponseStatusEnum) {
    ClaimSummaryResponseStatusEnum["Draft"] = "DRAFT";
    ClaimSummaryResponseStatusEnum["Submitted"] = "SUBMITTED";
    ClaimSummaryResponseStatusEnum["InReview"] = "IN_REVIEW";
    ClaimSummaryResponseStatusEnum["InfoNeeded"] = "INFO_NEEDED";
    ClaimSummaryResponseStatusEnum["Approved"] = "APPROVED";
    ClaimSummaryResponseStatusEnum["Denied"] = "DENIED";
    ClaimSummaryResponseStatusEnum["Settled"] = "SETTLED";
    ClaimSummaryResponseStatusEnum["Closed"] = "CLOSED";
    ClaimSummaryResponseStatusEnum["Cancelled"] = "CANCELLED";
})(ClaimSummaryResponseStatusEnum || (ClaimSummaryResponseStatusEnum = {}));
;
var ClaimSummaryResponseEligibilityResultEnum;
(function (ClaimSummaryResponseEligibilityResultEnum) {
    ClaimSummaryResponseEligibilityResultEnum["Eligible"] = "ELIGIBLE";
    ClaimSummaryResponseEligibilityResultEnum["Ineligible"] = "INELIGIBLE";
    ClaimSummaryResponseEligibilityResultEnum["Indeterminate"] = "INDETERMINATE";
})(ClaimSummaryResponseEligibilityResultEnum || (ClaimSummaryResponseEligibilityResultEnum = {}));
;
function isOptionalClaimSummaryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimSummaryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimSummaryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimSummaryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimSummaryResponsePropertyNames();
    const optionalStringProperties = createClaimSummaryResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'claimCode', nullable: false }, { name: 'claimType', nullable: false }, { name: 'status', nullable: false }, { name: 'customerId', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'vin', nullable: false }, { name: 'locationId', nullable: false }, { name: 'failureDate', nullable: false }, { name: 'eligibilityResult', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createClaimSummaryResponseOptionalProperties();
    const optionalBooleanProperties = createClaimSummaryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimSummaryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimSummaryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimSummaryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ClaimUpdateRequestClaimTypeEnum;
(function (ClaimUpdateRequestClaimTypeEnum) {
    ClaimUpdateRequestClaimTypeEnum["ManufacturerDefect"] = "MANUFACTURER_DEFECT";
    ClaimUpdateRequestClaimTypeEnum["DealerWorkmanship"] = "DEALER_WORKMANSHIP";
    ClaimUpdateRequestClaimTypeEnum["RoadHazard"] = "ROAD_HAZARD";
    ClaimUpdateRequestClaimTypeEnum["ExtendedPlan"] = "EXTENDED_PLAN";
})(ClaimUpdateRequestClaimTypeEnum || (ClaimUpdateRequestClaimTypeEnum = {}));
;
function isOptionalClaimUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createClaimUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createClaimUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfClaimUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createClaimUpdateRequestPropertyNames();
    const optionalStringProperties = createClaimUpdateRequestOptionalProperties({ name: 'claimType', nullable: false }, { name: 'locationId', nullable: false }, { name: 'originWorkorderId', nullable: false }, { name: 'originInvoiceId', nullable: false }, { name: 'originSaleDate', nullable: false }, { name: 'registrationId', nullable: false }, { name: 'failureDescription', nullable: false }, { name: 'failureDate', nullable: false });
    const optionalNumberProperties = createClaimUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createClaimUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalClaimUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalClaimUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalClaimUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LineDecisionLineDispositionEnum;
(function (LineDecisionLineDispositionEnum) {
    LineDecisionLineDispositionEnum["Pending"] = "PENDING";
    LineDecisionLineDispositionEnum["Approved"] = "APPROVED";
    LineDecisionLineDispositionEnum["PartiallyApproved"] = "PARTIALLY_APPROVED";
    LineDecisionLineDispositionEnum["Denied"] = "DENIED";
    LineDecisionLineDispositionEnum["Withdrawn"] = "WITHDRAWN";
})(LineDecisionLineDispositionEnum || (LineDecisionLineDispositionEnum = {}));
;
function isOptionalLineDecisionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLineDecisionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLineDecisionOptionalProperties(...properties) {
    return properties;
}
function instanceOfLineDecision(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLineDecisionPropertyNames('lineId');
    const optionalStringProperties = createLineDecisionOptionalProperties({ name: 'lineId', nullable: false }, { name: 'lineDisposition', nullable: false }, { name: 'overrideReason', nullable: false });
    const optionalNumberProperties = createLineDecisionOptionalProperties({ name: 'amountApproved', nullable: false });
    const optionalBooleanProperties = createLineDecisionOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLineDecisionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLineDecisionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLineDecisionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalNoteViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createNoteViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createNoteViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfNoteView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createNoteViewPropertyNames();
    const optionalStringProperties = createNoteViewOptionalProperties({ name: 'id', nullable: false }, { name: 'note', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'createdAt', nullable: false });
    const optionalNumberProperties = createNoteViewOptionalProperties();
    const optionalBooleanProperties = createNoteViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalNoteViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalNoteViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalNoteViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageClaimSummaryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageClaimSummaryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageClaimSummaryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageClaimSummaryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageClaimSummaryResponsePropertyNames();
    const optionalStringProperties = createPageClaimSummaryResponseOptionalProperties();
    const optionalNumberProperties = createPageClaimSummaryResponseOptionalProperties({ name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false }, { name: 'size', nullable: false }, { name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false });
    const optionalBooleanProperties = createPageClaimSummaryResponseOptionalProperties({ name: 'first', nullable: false }, { name: 'last', nullable: false }, { name: 'empty', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageClaimSummaryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageClaimSummaryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageClaimSummaryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPageablePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageablePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageable(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageablePropertyNames();
    const optionalStringProperties = createPageableOptionalProperties();
    const optionalNumberProperties = createPageableOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false });
    const optionalBooleanProperties = createPageableOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageablePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageablePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageablePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageableObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageableObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageableObjectPropertyNames();
    const optionalStringProperties = createPageableObjectOptionalProperties();
    const optionalNumberProperties = createPageableObjectOptionalProperties({ name: 'offset', nullable: false }, { name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createPageableObjectOptionalProperties({ name: 'paged', nullable: false }, { name: 'unpaged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartReturnCreateRequestDispositionEnum;
(function (PartReturnCreateRequestDispositionEnum) {
    PartReturnCreateRequestDispositionEnum["HoldForInspection"] = "HOLD_FOR_INSPECTION";
    PartReturnCreateRequestDispositionEnum["ReturnToVendor"] = "RETURN_TO_VENDOR";
    PartReturnCreateRequestDispositionEnum["ScrapAuthorized"] = "SCRAP_AUTHORIZED";
    PartReturnCreateRequestDispositionEnum["CustomerRetained"] = "CUSTOMER_RETAINED";
})(PartReturnCreateRequestDispositionEnum || (PartReturnCreateRequestDispositionEnum = {}));
;
function isOptionalPartReturnCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartReturnCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartReturnCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartReturnCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartReturnCreateRequestPropertyNames('claimLineId', 'disposition');
    const optionalStringProperties = createPartReturnCreateRequestOptionalProperties({ name: 'claimLineId', nullable: false }, { name: 'disposition', nullable: false }, { name: 'rmaNumber', nullable: false }, { name: 'holdLocationNote', nullable: false });
    const optionalNumberProperties = createPartReturnCreateRequestOptionalProperties();
    const optionalBooleanProperties = createPartReturnCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartReturnCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartReturnCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartReturnCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartReturnResponseDispositionEnum;
(function (PartReturnResponseDispositionEnum) {
    PartReturnResponseDispositionEnum["HoldForInspection"] = "HOLD_FOR_INSPECTION";
    PartReturnResponseDispositionEnum["ReturnToVendor"] = "RETURN_TO_VENDOR";
    PartReturnResponseDispositionEnum["ScrapAuthorized"] = "SCRAP_AUTHORIZED";
    PartReturnResponseDispositionEnum["CustomerRetained"] = "CUSTOMER_RETAINED";
})(PartReturnResponseDispositionEnum || (PartReturnResponseDispositionEnum = {}));
;
var PartReturnResponseStatusEnum;
(function (PartReturnResponseStatusEnum) {
    PartReturnResponseStatusEnum["AwaitingPart"] = "AWAITING_PART";
    PartReturnResponseStatusEnum["OnHold"] = "ON_HOLD";
    PartReturnResponseStatusEnum["Shipped"] = "SHIPPED";
    PartReturnResponseStatusEnum["ReceivedByVendor"] = "RECEIVED_BY_VENDOR";
    PartReturnResponseStatusEnum["Scrapped"] = "SCRAPPED";
    PartReturnResponseStatusEnum["Closed"] = "CLOSED";
})(PartReturnResponseStatusEnum || (PartReturnResponseStatusEnum = {}));
;
function isOptionalPartReturnResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartReturnResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartReturnResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartReturnResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartReturnResponsePropertyNames();
    const optionalStringProperties = createPartReturnResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'claimId', nullable: false }, { name: 'claimLineId', nullable: false }, { name: 'rmaNumber', nullable: false }, { name: 'disposition', nullable: false }, { name: 'status', nullable: false }, { name: 'carrier', nullable: false }, { name: 'trackingNumber', nullable: false }, { name: 'shippedAt', nullable: false }, { name: 'holdLocationNote', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createPartReturnResponseOptionalProperties();
    const optionalBooleanProperties = createPartReturnResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartReturnResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartReturnResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartReturnResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartReturnUpdateRequestStatusEnum;
(function (PartReturnUpdateRequestStatusEnum) {
    PartReturnUpdateRequestStatusEnum["AwaitingPart"] = "AWAITING_PART";
    PartReturnUpdateRequestStatusEnum["OnHold"] = "ON_HOLD";
    PartReturnUpdateRequestStatusEnum["Shipped"] = "SHIPPED";
    PartReturnUpdateRequestStatusEnum["ReceivedByVendor"] = "RECEIVED_BY_VENDOR";
    PartReturnUpdateRequestStatusEnum["Scrapped"] = "SCRAPPED";
    PartReturnUpdateRequestStatusEnum["Closed"] = "CLOSED";
})(PartReturnUpdateRequestStatusEnum || (PartReturnUpdateRequestStatusEnum = {}));
;
var PartReturnUpdateRequestDispositionEnum;
(function (PartReturnUpdateRequestDispositionEnum) {
    PartReturnUpdateRequestDispositionEnum["HoldForInspection"] = "HOLD_FOR_INSPECTION";
    PartReturnUpdateRequestDispositionEnum["ReturnToVendor"] = "RETURN_TO_VENDOR";
    PartReturnUpdateRequestDispositionEnum["ScrapAuthorized"] = "SCRAP_AUTHORIZED";
    PartReturnUpdateRequestDispositionEnum["CustomerRetained"] = "CUSTOMER_RETAINED";
})(PartReturnUpdateRequestDispositionEnum || (PartReturnUpdateRequestDispositionEnum = {}));
;
function isOptionalPartReturnUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartReturnUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartReturnUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartReturnUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartReturnUpdateRequestPropertyNames();
    const optionalStringProperties = createPartReturnUpdateRequestOptionalProperties({ name: 'status', nullable: false }, { name: 'disposition', nullable: false }, { name: 'carrier', nullable: false }, { name: 'trackingNumber', nullable: false }, { name: 'shippedAt', nullable: false }, { name: 'rmaNumber', nullable: false }, { name: 'holdLocationNote', nullable: false });
    const optionalNumberProperties = createPartReturnUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createPartReturnUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartReturnUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartReturnUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartReturnUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartReturnViewDispositionEnum;
(function (PartReturnViewDispositionEnum) {
    PartReturnViewDispositionEnum["HoldForInspection"] = "HOLD_FOR_INSPECTION";
    PartReturnViewDispositionEnum["ReturnToVendor"] = "RETURN_TO_VENDOR";
    PartReturnViewDispositionEnum["ScrapAuthorized"] = "SCRAP_AUTHORIZED";
    PartReturnViewDispositionEnum["CustomerRetained"] = "CUSTOMER_RETAINED";
})(PartReturnViewDispositionEnum || (PartReturnViewDispositionEnum = {}));
;
var PartReturnViewStatusEnum;
(function (PartReturnViewStatusEnum) {
    PartReturnViewStatusEnum["AwaitingPart"] = "AWAITING_PART";
    PartReturnViewStatusEnum["OnHold"] = "ON_HOLD";
    PartReturnViewStatusEnum["Shipped"] = "SHIPPED";
    PartReturnViewStatusEnum["ReceivedByVendor"] = "RECEIVED_BY_VENDOR";
    PartReturnViewStatusEnum["Scrapped"] = "SCRAPPED";
    PartReturnViewStatusEnum["Closed"] = "CLOSED";
})(PartReturnViewStatusEnum || (PartReturnViewStatusEnum = {}));
;
function isOptionalPartReturnViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartReturnViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartReturnViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartReturnView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartReturnViewPropertyNames();
    const optionalStringProperties = createPartReturnViewOptionalProperties({ name: 'id', nullable: false }, { name: 'claimLineId', nullable: false }, { name: 'rmaNumber', nullable: false }, { name: 'disposition', nullable: false }, { name: 'status', nullable: false }, { name: 'carrier', nullable: false }, { name: 'trackingNumber', nullable: false }, { name: 'shippedAt', nullable: false }, { name: 'holdLocationNote', nullable: false });
    const optionalNumberProperties = createPartReturnViewOptionalProperties();
    const optionalBooleanProperties = createPartReturnViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartReturnViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartReturnViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartReturnViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PolicyRequestCoverageTypeEnum;
(function (PolicyRequestCoverageTypeEnum) {
    PolicyRequestCoverageTypeEnum["ManufacturerDefect"] = "MANUFACTURER_DEFECT";
    PolicyRequestCoverageTypeEnum["DealerWorkmanship"] = "DEALER_WORKMANSHIP";
    PolicyRequestCoverageTypeEnum["RoadHazard"] = "ROAD_HAZARD";
    PolicyRequestCoverageTypeEnum["ExtendedPlan"] = "EXTENDED_PLAN";
})(PolicyRequestCoverageTypeEnum || (PolicyRequestCoverageTypeEnum = {}));
;
var PolicyRequestAppliesToTypeEnum;
(function (PolicyRequestAppliesToTypeEnum) {
    PolicyRequestAppliesToTypeEnum["ProductList"] = "PRODUCT_LIST";
    PolicyRequestAppliesToTypeEnum["Category"] = "CATEGORY";
    PolicyRequestAppliesToTypeEnum["Manufacturer"] = "MANUFACTURER";
    PolicyRequestAppliesToTypeEnum["All"] = "ALL";
})(PolicyRequestAppliesToTypeEnum || (PolicyRequestAppliesToTypeEnum = {}));
;
var PolicyRequestProrationMethodEnum;
(function (PolicyRequestProrationMethodEnum) {
    PolicyRequestProrationMethodEnum["None"] = "NONE";
    PolicyRequestProrationMethodEnum["TreadDepth"] = "TREAD_DEPTH";
    PolicyRequestProrationMethodEnum["Mileage"] = "MILEAGE";
    PolicyRequestProrationMethodEnum["Time"] = "TIME";
})(PolicyRequestProrationMethodEnum || (PolicyRequestProrationMethodEnum = {}));
;
function isOptionalPolicyRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPolicyRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPolicyRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPolicyRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPolicyRequestPropertyNames('providerId', 'name', 'coverageType', 'appliesToType', 'effectiveFrom', 'prorationMethod');
    const optionalStringProperties = createPolicyRequestOptionalProperties({ name: 'providerId', nullable: false }, { name: 'name', nullable: false }, { name: 'coverageType', nullable: false }, { name: 'appliesToType', nullable: false }, { name: 'appliesToCategoryId', nullable: false }, { name: 'appliesToManufacturerId', nullable: false }, { name: 'effectiveFrom', nullable: false }, { name: 'effectiveTo', nullable: false }, { name: 'prorationMethod', nullable: false }, { name: 'termsText', nullable: false });
    const optionalNumberProperties = createPolicyRequestOptionalProperties({ name: 'durationMonths', nullable: false }, { name: 'mileageLimit', nullable: false }, { name: 'treadPullPointThirtySeconds', nullable: false }, { name: 'laborHoursCap', nullable: false }, { name: 'laborRateCap', nullable: false });
    const optionalBooleanProperties = createPolicyRequestOptionalProperties({ name: 'laborCovered', nullable: false }, { name: 'requiresPartReturn', nullable: false }, { name: 'requiresPhotoEvidence', nullable: false }, { name: 'transferable', nullable: false }, { name: 'autoRegister', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPolicyRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPolicyRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPolicyRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PolicyResponseCoverageTypeEnum;
(function (PolicyResponseCoverageTypeEnum) {
    PolicyResponseCoverageTypeEnum["ManufacturerDefect"] = "MANUFACTURER_DEFECT";
    PolicyResponseCoverageTypeEnum["DealerWorkmanship"] = "DEALER_WORKMANSHIP";
    PolicyResponseCoverageTypeEnum["RoadHazard"] = "ROAD_HAZARD";
    PolicyResponseCoverageTypeEnum["ExtendedPlan"] = "EXTENDED_PLAN";
})(PolicyResponseCoverageTypeEnum || (PolicyResponseCoverageTypeEnum = {}));
;
var PolicyResponseAppliesToTypeEnum;
(function (PolicyResponseAppliesToTypeEnum) {
    PolicyResponseAppliesToTypeEnum["ProductList"] = "PRODUCT_LIST";
    PolicyResponseAppliesToTypeEnum["Category"] = "CATEGORY";
    PolicyResponseAppliesToTypeEnum["Manufacturer"] = "MANUFACTURER";
    PolicyResponseAppliesToTypeEnum["All"] = "ALL";
})(PolicyResponseAppliesToTypeEnum || (PolicyResponseAppliesToTypeEnum = {}));
;
var PolicyResponseProrationMethodEnum;
(function (PolicyResponseProrationMethodEnum) {
    PolicyResponseProrationMethodEnum["None"] = "NONE";
    PolicyResponseProrationMethodEnum["TreadDepth"] = "TREAD_DEPTH";
    PolicyResponseProrationMethodEnum["Mileage"] = "MILEAGE";
    PolicyResponseProrationMethodEnum["Time"] = "TIME";
})(PolicyResponseProrationMethodEnum || (PolicyResponseProrationMethodEnum = {}));
;
function isOptionalPolicyResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPolicyResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPolicyResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPolicyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPolicyResponsePropertyNames();
    const optionalStringProperties = createPolicyResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'providerId', nullable: false }, { name: 'name', nullable: false }, { name: 'coverageType', nullable: false }, { name: 'appliesToType', nullable: false }, { name: 'appliesToCategoryId', nullable: false }, { name: 'appliesToManufacturerId', nullable: false }, { name: 'effectiveFrom', nullable: false }, { name: 'effectiveTo', nullable: false }, { name: 'prorationMethod', nullable: false }, { name: 'termsText', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createPolicyResponseOptionalProperties({ name: 'durationMonths', nullable: false }, { name: 'mileageLimit', nullable: false }, { name: 'treadPullPointThirtySeconds', nullable: false }, { name: 'laborHoursCap', nullable: false }, { name: 'laborRateCap', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createPolicyResponseOptionalProperties({ name: 'laborCovered', nullable: false }, { name: 'requiresPartReturn', nullable: false }, { name: 'requiresPhotoEvidence', nullable: false }, { name: 'transferable', nullable: false }, { name: 'autoRegister', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPolicyResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPolicyResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPolicyResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProviderRequestProviderTypeEnum;
(function (ProviderRequestProviderTypeEnum) {
    ProviderRequestProviderTypeEnum["Manufacturer"] = "MANUFACTURER";
    ProviderRequestProviderTypeEnum["DistributorProgram"] = "DISTRIBUTOR_PROGRAM";
    ProviderRequestProviderTypeEnum["ThirdPartyAdmin"] = "THIRD_PARTY_ADMIN";
    ProviderRequestProviderTypeEnum["Dealer"] = "DEALER";
})(ProviderRequestProviderTypeEnum || (ProviderRequestProviderTypeEnum = {}));
;
function isOptionalProviderRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProviderRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProviderRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfProviderRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProviderRequestPropertyNames('name', 'providerType');
    const optionalStringProperties = createProviderRequestOptionalProperties({ name: 'name', nullable: false }, { name: 'providerType', nullable: false }, { name: 'status', nullable: false }, { name: 'apVendorId', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'claimSubmissionMethod', nullable: false }, { name: 'portalUrl', nullable: false }, { name: 'contactName', nullable: false }, { name: 'contactPhone', nullable: false }, { name: 'contactEmail', nullable: false });
    const optionalNumberProperties = createProviderRequestOptionalProperties();
    const optionalBooleanProperties = createProviderRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProviderRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProviderRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProviderRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProviderResponseProviderTypeEnum;
(function (ProviderResponseProviderTypeEnum) {
    ProviderResponseProviderTypeEnum["Manufacturer"] = "MANUFACTURER";
    ProviderResponseProviderTypeEnum["DistributorProgram"] = "DISTRIBUTOR_PROGRAM";
    ProviderResponseProviderTypeEnum["ThirdPartyAdmin"] = "THIRD_PARTY_ADMIN";
    ProviderResponseProviderTypeEnum["Dealer"] = "DEALER";
})(ProviderResponseProviderTypeEnum || (ProviderResponseProviderTypeEnum = {}));
;
function isOptionalProviderResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProviderResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createProviderResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfProviderResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProviderResponsePropertyNames();
    const optionalStringProperties = createProviderResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'name', nullable: false }, { name: 'status', nullable: false }, { name: 'providerType', nullable: false }, { name: 'apVendorId', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'claimSubmissionMethod', nullable: false }, { name: 'portalUrl', nullable: false }, { name: 'contactName', nullable: false }, { name: 'contactPhone', nullable: false }, { name: 'contactEmail', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createProviderResponseOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createProviderResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProviderResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProviderResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProviderResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RegistrationRequestStatusEnum;
(function (RegistrationRequestStatusEnum) {
    RegistrationRequestStatusEnum["Active"] = "ACTIVE";
    RegistrationRequestStatusEnum["Expired"] = "EXPIRED";
    RegistrationRequestStatusEnum["Cancelled"] = "CANCELLED";
    RegistrationRequestStatusEnum["Exhausted"] = "EXHAUSTED";
})(RegistrationRequestStatusEnum || (RegistrationRequestStatusEnum = {}));
;
function isOptionalRegistrationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRegistrationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRegistrationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRegistrationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRegistrationRequestPropertyNames('policyId', 'customerId', 'purchaseDate');
    const optionalStringProperties = createRegistrationRequestOptionalProperties({ name: 'policyId', nullable: false }, { name: 'customerId', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'sourceInvoiceId', nullable: false }, { name: 'sourceInvoiceLineId', nullable: false }, { name: 'contractNumber', nullable: false }, { name: 'purchaseDate', nullable: false }, { name: 'expiresAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createRegistrationRequestOptionalProperties();
    const optionalBooleanProperties = createRegistrationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRegistrationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRegistrationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRegistrationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RegistrationResponseStatusEnum;
(function (RegistrationResponseStatusEnum) {
    RegistrationResponseStatusEnum["Active"] = "ACTIVE";
    RegistrationResponseStatusEnum["Expired"] = "EXPIRED";
    RegistrationResponseStatusEnum["Cancelled"] = "CANCELLED";
    RegistrationResponseStatusEnum["Exhausted"] = "EXHAUSTED";
})(RegistrationResponseStatusEnum || (RegistrationResponseStatusEnum = {}));
;
function isOptionalRegistrationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRegistrationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createRegistrationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfRegistrationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRegistrationResponsePropertyNames();
    const optionalStringProperties = createRegistrationResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'policyId', nullable: false }, { name: 'customerId', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'sourceInvoiceId', nullable: false }, { name: 'sourceInvoiceLineId', nullable: false }, { name: 'contractNumber', nullable: false }, { name: 'purchaseDate', nullable: false }, { name: 'expiresAt', nullable: false }, { name: 'status', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createRegistrationResponseOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createRegistrationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRegistrationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRegistrationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRegistrationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReimbursementResponseStatusEnum;
(function (ReimbursementResponseStatusEnum) {
    ReimbursementResponseStatusEnum["NotSubmitted"] = "NOT_SUBMITTED";
    ReimbursementResponseStatusEnum["Submitted"] = "SUBMITTED";
    ReimbursementResponseStatusEnum["Approved"] = "APPROVED";
    ReimbursementResponseStatusEnum["PartiallyApproved"] = "PARTIALLY_APPROVED";
    ReimbursementResponseStatusEnum["Denied"] = "DENIED";
    ReimbursementResponseStatusEnum["CreditReceived"] = "CREDIT_RECEIVED";
    ReimbursementResponseStatusEnum["WrittenOff"] = "WRITTEN_OFF";
    ReimbursementResponseStatusEnum["NotApplicable"] = "NOT_APPLICABLE";
})(ReimbursementResponseStatusEnum || (ReimbursementResponseStatusEnum = {}));
;
function isOptionalReimbursementResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReimbursementResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReimbursementResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReimbursementResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReimbursementResponsePropertyNames();
    const optionalStringProperties = createReimbursementResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'claimId', nullable: false }, { name: 'providerId', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorClaimReference', nullable: false }, { name: 'submittedAt', nullable: false }, { name: 'submittedBy', nullable: false }, { name: 'resolvedAt', nullable: false }, { name: 'creditReference', nullable: false }, { name: 'creditReceivedAt', nullable: false }, { name: 'notes', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createReimbursementResponseOptionalProperties({ name: 'amountRequested', nullable: false }, { name: 'amountApproved', nullable: false });
    const optionalBooleanProperties = createReimbursementResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReimbursementResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReimbursementResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReimbursementResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReimbursementSubmitRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReimbursementSubmitRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReimbursementSubmitRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReimbursementSubmitRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReimbursementSubmitRequestPropertyNames('amountRequested');
    const optionalStringProperties = createReimbursementSubmitRequestOptionalProperties({ name: 'vendorClaimReference', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createReimbursementSubmitRequestOptionalProperties({ name: 'amountRequested', nullable: false });
    const optionalBooleanProperties = createReimbursementSubmitRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReimbursementSubmitRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReimbursementSubmitRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReimbursementSubmitRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReimbursementUpdateRequestStatusEnum;
(function (ReimbursementUpdateRequestStatusEnum) {
    ReimbursementUpdateRequestStatusEnum["Approved"] = "APPROVED";
    ReimbursementUpdateRequestStatusEnum["PartiallyApproved"] = "PARTIALLY_APPROVED";
    ReimbursementUpdateRequestStatusEnum["Denied"] = "DENIED";
    ReimbursementUpdateRequestStatusEnum["CreditReceived"] = "CREDIT_RECEIVED";
    ReimbursementUpdateRequestStatusEnum["WrittenOff"] = "WRITTEN_OFF";
})(ReimbursementUpdateRequestStatusEnum || (ReimbursementUpdateRequestStatusEnum = {}));
;
function isOptionalReimbursementUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReimbursementUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReimbursementUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReimbursementUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReimbursementUpdateRequestPropertyNames('status');
    const optionalStringProperties = createReimbursementUpdateRequestOptionalProperties({ name: 'status', nullable: false }, { name: 'creditReference', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createReimbursementUpdateRequestOptionalProperties({ name: 'amountApproved', nullable: false });
    const optionalBooleanProperties = createReimbursementUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReimbursementUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReimbursementUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReimbursementUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReimbursementViewStatusEnum;
(function (ReimbursementViewStatusEnum) {
    ReimbursementViewStatusEnum["NotSubmitted"] = "NOT_SUBMITTED";
    ReimbursementViewStatusEnum["Submitted"] = "SUBMITTED";
    ReimbursementViewStatusEnum["Approved"] = "APPROVED";
    ReimbursementViewStatusEnum["PartiallyApproved"] = "PARTIALLY_APPROVED";
    ReimbursementViewStatusEnum["Denied"] = "DENIED";
    ReimbursementViewStatusEnum["CreditReceived"] = "CREDIT_RECEIVED";
    ReimbursementViewStatusEnum["WrittenOff"] = "WRITTEN_OFF";
    ReimbursementViewStatusEnum["NotApplicable"] = "NOT_APPLICABLE";
})(ReimbursementViewStatusEnum || (ReimbursementViewStatusEnum = {}));
;
function isOptionalReimbursementViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReimbursementViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReimbursementViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfReimbursementView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReimbursementViewPropertyNames();
    const optionalStringProperties = createReimbursementViewOptionalProperties({ name: 'id', nullable: false }, { name: 'providerId', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorClaimReference', nullable: false }, { name: 'submittedAt', nullable: false }, { name: 'submittedBy', nullable: false }, { name: 'resolvedAt', nullable: false }, { name: 'creditReference', nullable: false }, { name: 'creditReceivedAt', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createReimbursementViewOptionalProperties({ name: 'amountRequested', nullable: false }, { name: 'amountApproved', nullable: false });
    const optionalBooleanProperties = createReimbursementViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReimbursementViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReimbursementViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReimbursementViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SettlementCreateRequestSettlementTypeEnum;
(function (SettlementCreateRequestSettlementTypeEnum) {
    SettlementCreateRequestSettlementTypeEnum["ReplacementWorkorder"] = "REPLACEMENT_WORKORDER";
    SettlementCreateRequestSettlementTypeEnum["InvoiceCredit"] = "INVOICE_CREDIT";
    SettlementCreateRequestSettlementTypeEnum["Refund"] = "REFUND";
    SettlementCreateRequestSettlementTypeEnum["ProratedCredit"] = "PRORATED_CREDIT";
    SettlementCreateRequestSettlementTypeEnum["Goodwill"] = "GOODWILL";
    SettlementCreateRequestSettlementTypeEnum["NoAction"] = "NO_ACTION";
})(SettlementCreateRequestSettlementTypeEnum || (SettlementCreateRequestSettlementTypeEnum = {}));
;
function isOptionalSettlementCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementCreateRequestPropertyNames('settlementType', 'coveredAmount', 'customerAmount');
    const optionalStringProperties = createSettlementCreateRequestOptionalProperties({ name: 'settlementType', nullable: false }, { name: 'replacementWorkorderId', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'paymentId', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createSettlementCreateRequestOptionalProperties({ name: 'coveredAmount', nullable: false }, { name: 'customerAmount', nullable: false });
    const optionalBooleanProperties = createSettlementCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SettlementReconciliationRowSettlementTypeEnum;
(function (SettlementReconciliationRowSettlementTypeEnum) {
    SettlementReconciliationRowSettlementTypeEnum["ReplacementWorkorder"] = "REPLACEMENT_WORKORDER";
    SettlementReconciliationRowSettlementTypeEnum["InvoiceCredit"] = "INVOICE_CREDIT";
    SettlementReconciliationRowSettlementTypeEnum["Refund"] = "REFUND";
    SettlementReconciliationRowSettlementTypeEnum["ProratedCredit"] = "PRORATED_CREDIT";
    SettlementReconciliationRowSettlementTypeEnum["Goodwill"] = "GOODWILL";
    SettlementReconciliationRowSettlementTypeEnum["NoAction"] = "NO_ACTION";
})(SettlementReconciliationRowSettlementTypeEnum || (SettlementReconciliationRowSettlementTypeEnum = {}));
;
var SettlementReconciliationRowSettlementStatusEnum;
(function (SettlementReconciliationRowSettlementStatusEnum) {
    SettlementReconciliationRowSettlementStatusEnum["Pending"] = "PENDING";
    SettlementReconciliationRowSettlementStatusEnum["Completed"] = "COMPLETED";
    SettlementReconciliationRowSettlementStatusEnum["Failed"] = "FAILED";
})(SettlementReconciliationRowSettlementStatusEnum || (SettlementReconciliationRowSettlementStatusEnum = {}));
;
var SettlementReconciliationRowCheckStatusEnum;
(function (SettlementReconciliationRowCheckStatusEnum) {
    SettlementReconciliationRowCheckStatusEnum["ConfirmedCommitted"] = "CONFIRMED_COMMITTED";
    SettlementReconciliationRowCheckStatusEnum["ConfirmedAbsent"] = "CONFIRMED_ABSENT";
    SettlementReconciliationRowCheckStatusEnum["Unknown"] = "UNKNOWN";
})(SettlementReconciliationRowCheckStatusEnum || (SettlementReconciliationRowCheckStatusEnum = {}));
;
function isOptionalSettlementReconciliationRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementReconciliationRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementReconciliationRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementReconciliationRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementReconciliationRowPropertyNames();
    const optionalStringProperties = createSettlementReconciliationRowOptionalProperties({ name: 'settlementId', nullable: false }, { name: 'claimId', nullable: false }, { name: 'settlementType', nullable: false }, { name: 'settlementStatus', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'externalReference', nullable: false }, { name: 'matchedAdjustmentId', nullable: false }, { name: 'matchedRefundId', nullable: false }, { name: 'checkStatus', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createSettlementReconciliationRowOptionalProperties({ name: 'coveredAmount', nullable: false }, { name: 'customerAmount', nullable: false });
    const optionalBooleanProperties = createSettlementReconciliationRowOptionalProperties({ name: 'committedOnInvoice', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementReconciliationRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementReconciliationRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementReconciliationRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SettlementResponseSettlementTypeEnum;
(function (SettlementResponseSettlementTypeEnum) {
    SettlementResponseSettlementTypeEnum["ReplacementWorkorder"] = "REPLACEMENT_WORKORDER";
    SettlementResponseSettlementTypeEnum["InvoiceCredit"] = "INVOICE_CREDIT";
    SettlementResponseSettlementTypeEnum["Refund"] = "REFUND";
    SettlementResponseSettlementTypeEnum["ProratedCredit"] = "PRORATED_CREDIT";
    SettlementResponseSettlementTypeEnum["Goodwill"] = "GOODWILL";
    SettlementResponseSettlementTypeEnum["NoAction"] = "NO_ACTION";
})(SettlementResponseSettlementTypeEnum || (SettlementResponseSettlementTypeEnum = {}));
;
var SettlementResponseStatusEnum;
(function (SettlementResponseStatusEnum) {
    SettlementResponseStatusEnum["Pending"] = "PENDING";
    SettlementResponseStatusEnum["Completed"] = "COMPLETED";
    SettlementResponseStatusEnum["Failed"] = "FAILED";
})(SettlementResponseStatusEnum || (SettlementResponseStatusEnum = {}));
;
var SettlementResponseClaimStatusEnum;
(function (SettlementResponseClaimStatusEnum) {
    SettlementResponseClaimStatusEnum["Draft"] = "DRAFT";
    SettlementResponseClaimStatusEnum["Submitted"] = "SUBMITTED";
    SettlementResponseClaimStatusEnum["InReview"] = "IN_REVIEW";
    SettlementResponseClaimStatusEnum["InfoNeeded"] = "INFO_NEEDED";
    SettlementResponseClaimStatusEnum["Approved"] = "APPROVED";
    SettlementResponseClaimStatusEnum["Denied"] = "DENIED";
    SettlementResponseClaimStatusEnum["Settled"] = "SETTLED";
    SettlementResponseClaimStatusEnum["Closed"] = "CLOSED";
    SettlementResponseClaimStatusEnum["Cancelled"] = "CANCELLED";
})(SettlementResponseClaimStatusEnum || (SettlementResponseClaimStatusEnum = {}));
;
function isOptionalSettlementResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementResponsePropertyNames();
    const optionalStringProperties = createSettlementResponseOptionalProperties({ name: 'id', nullable: false }, { name: 'claimId', nullable: false }, { name: 'settlementType', nullable: false }, { name: 'status', nullable: false }, { name: 'replacementWorkorderId', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'invoiceAdjustmentId', nullable: false }, { name: 'refundRecordId', nullable: false }, { name: 'claimStatus', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createSettlementResponseOptionalProperties({ name: 'coveredAmount', nullable: false }, { name: 'customerAmount', nullable: false });
    const optionalBooleanProperties = createSettlementResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SettlementViewSettlementTypeEnum;
(function (SettlementViewSettlementTypeEnum) {
    SettlementViewSettlementTypeEnum["ReplacementWorkorder"] = "REPLACEMENT_WORKORDER";
    SettlementViewSettlementTypeEnum["InvoiceCredit"] = "INVOICE_CREDIT";
    SettlementViewSettlementTypeEnum["Refund"] = "REFUND";
    SettlementViewSettlementTypeEnum["ProratedCredit"] = "PRORATED_CREDIT";
    SettlementViewSettlementTypeEnum["Goodwill"] = "GOODWILL";
    SettlementViewSettlementTypeEnum["NoAction"] = "NO_ACTION";
})(SettlementViewSettlementTypeEnum || (SettlementViewSettlementTypeEnum = {}));
;
var SettlementViewStatusEnum;
(function (SettlementViewStatusEnum) {
    SettlementViewStatusEnum["Pending"] = "PENDING";
    SettlementViewStatusEnum["Completed"] = "COMPLETED";
    SettlementViewStatusEnum["Failed"] = "FAILED";
})(SettlementViewStatusEnum || (SettlementViewStatusEnum = {}));
;
function isOptionalSettlementViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementViewPropertyNames();
    const optionalStringProperties = createSettlementViewOptionalProperties({ name: 'id', nullable: false }, { name: 'settlementType', nullable: false }, { name: 'status', nullable: false }, { name: 'replacementWorkorderId', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'invoiceAdjustmentId', nullable: false }, { name: 'refundRecordId', nullable: false }, { name: 'createdAt', nullable: false });
    const optionalNumberProperties = createSettlementViewOptionalProperties({ name: 'coveredAmount', nullable: false }, { name: 'customerAmount', nullable: false });
    const optionalBooleanProperties = createSettlementViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSortObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSortObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSortObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSortObjectPropertyNames();
    const optionalStringProperties = createSortObjectOptionalProperties();
    const optionalNumberProperties = createSortObjectOptionalProperties();
    const optionalBooleanProperties = createSortObjectOptionalProperties({ name: 'empty', nullable: false }, { name: 'sorted', nullable: false }, { name: 'unsorted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Warranty API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var StatusHistoryViewFromStatusEnum;
(function (StatusHistoryViewFromStatusEnum) {
    StatusHistoryViewFromStatusEnum["Draft"] = "DRAFT";
    StatusHistoryViewFromStatusEnum["Submitted"] = "SUBMITTED";
    StatusHistoryViewFromStatusEnum["InReview"] = "IN_REVIEW";
    StatusHistoryViewFromStatusEnum["InfoNeeded"] = "INFO_NEEDED";
    StatusHistoryViewFromStatusEnum["Approved"] = "APPROVED";
    StatusHistoryViewFromStatusEnum["Denied"] = "DENIED";
    StatusHistoryViewFromStatusEnum["Settled"] = "SETTLED";
    StatusHistoryViewFromStatusEnum["Closed"] = "CLOSED";
    StatusHistoryViewFromStatusEnum["Cancelled"] = "CANCELLED";
})(StatusHistoryViewFromStatusEnum || (StatusHistoryViewFromStatusEnum = {}));
;
var StatusHistoryViewToStatusEnum;
(function (StatusHistoryViewToStatusEnum) {
    StatusHistoryViewToStatusEnum["Draft"] = "DRAFT";
    StatusHistoryViewToStatusEnum["Submitted"] = "SUBMITTED";
    StatusHistoryViewToStatusEnum["InReview"] = "IN_REVIEW";
    StatusHistoryViewToStatusEnum["InfoNeeded"] = "INFO_NEEDED";
    StatusHistoryViewToStatusEnum["Approved"] = "APPROVED";
    StatusHistoryViewToStatusEnum["Denied"] = "DENIED";
    StatusHistoryViewToStatusEnum["Settled"] = "SETTLED";
    StatusHistoryViewToStatusEnum["Closed"] = "CLOSED";
    StatusHistoryViewToStatusEnum["Cancelled"] = "CANCELLED";
})(StatusHistoryViewToStatusEnum || (StatusHistoryViewToStatusEnum = {}));
;
function isOptionalStatusHistoryViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStatusHistoryViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createStatusHistoryViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfStatusHistoryView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStatusHistoryViewPropertyNames();
    const optionalStringProperties = createStatusHistoryViewOptionalProperties({ name: 'id', nullable: false }, { name: 'fromStatus', nullable: false }, { name: 'toStatus', nullable: false }, { name: 'actor', nullable: false }, { name: 'reason', nullable: false }, { name: 'createdAt', nullable: false });
    const optionalNumberProperties = createStatusHistoryViewOptionalProperties();
    const optionalBooleanProperties = createStatusHistoryViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStatusHistoryViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStatusHistoryViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStatusHistoryViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { ApiModule, BASE_PATH, COLLECTION_FORMATS, CandidateLineSourceTypeEnum, ClaimCreateRequestClaimTypeEnum, ClaimDecisionRequestDecisionEnum, ClaimLineRequestSourceTypeEnum, ClaimLineResponseLineDispositionEnum, ClaimLineResponseSourceTypeEnum, ClaimResponseClaimTypeEnum, ClaimResponseDecisionEnum, ClaimResponseEligibilityResultEnum, ClaimResponseStatusEnum, ClaimSummaryResponseClaimTypeEnum, ClaimSummaryResponseEligibilityResultEnum, ClaimSummaryResponseStatusEnum, ClaimUpdateRequestClaimTypeEnum, Configuration, LineDecisionLineDispositionEnum, PartReturnCreateRequestDispositionEnum, PartReturnResponseDispositionEnum, PartReturnResponseStatusEnum, PartReturnUpdateRequestDispositionEnum, PartReturnUpdateRequestStatusEnum, PartReturnViewDispositionEnum, PartReturnViewStatusEnum, PolicyRequestAppliesToTypeEnum, PolicyRequestCoverageTypeEnum, PolicyRequestProrationMethodEnum, PolicyResponseAppliesToTypeEnum, PolicyResponseCoverageTypeEnum, PolicyResponseProrationMethodEnum, ProviderRequestProviderTypeEnum, ProviderResponseProviderTypeEnum, RegistrationRequestStatusEnum, RegistrationResponseStatusEnum, ReimbursementResponseStatusEnum, ReimbursementUpdateRequestStatusEnum, ReimbursementViewStatusEnum, SettlementCreateRequestSettlementTypeEnum, SettlementReconciliationRowCheckStatusEnum, SettlementReconciliationRowSettlementStatusEnum, SettlementReconciliationRowSettlementTypeEnum, SettlementResponseClaimStatusEnum, SettlementResponseSettlementTypeEnum, SettlementResponseStatusEnum, SettlementViewSettlementTypeEnum, SettlementViewStatusEnum, StatusHistoryViewFromStatusEnum, StatusHistoryViewToStatusEnum, WarrantyClaimsService, WarrantyPartReturnsService, WarrantyPoliciesService, WarrantyProvidersService, WarrantyRegistrationsService, WarrantyReimbursementsService, WarrantySettlementsService, instanceOfCandidateLine, instanceOfClaimActionRequest, instanceOfClaimCreateRequest, instanceOfClaimDecisionRequest, instanceOfClaimLineRequest, instanceOfClaimLineResponse, instanceOfClaimNoteRequest, instanceOfClaimPhotoRequest, instanceOfClaimResponse, instanceOfClaimSummaryResponse, instanceOfClaimUpdateRequest, instanceOfLineDecision, instanceOfNoteView, instanceOfPageClaimSummaryResponse, instanceOfPageable, instanceOfPageableObject, instanceOfPartReturnCreateRequest, instanceOfPartReturnResponse, instanceOfPartReturnUpdateRequest, instanceOfPartReturnView, instanceOfPolicyRequest, instanceOfPolicyResponse, instanceOfProviderRequest, instanceOfProviderResponse, instanceOfRegistrationRequest, instanceOfRegistrationResponse, instanceOfReimbursementResponse, instanceOfReimbursementSubmitRequest, instanceOfReimbursementUpdateRequest, instanceOfReimbursementView, instanceOfSettlementCreateRequest, instanceOfSettlementReconciliationRow, instanceOfSettlementResponse, instanceOfSettlementView, instanceOfSortObject, instanceOfStatusHistoryView, provideApi };
//# sourceMappingURL=durion-sdk-warranty.mjs.map
