import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/accounting';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class APPaymentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    executeApPayment(executeAPPaymentRequest, observe = 'body', reportProgress = false, options) {
        if (executeAPPaymentRequest === null || executeAPPaymentRequest === undefined) {
            throw new Error('Required parameter executeAPPaymentRequest was null or undefined when calling executeApPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/ap/payments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: executeAPPaymentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getApPayment(paymentId, observe = 'body', reportProgress = false, options) {
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling getApPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/ap/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getApPaymentByRef(paymentRef, observe = 'body', reportProgress = false, options) {
        if (paymentRef === null || paymentRef === undefined) {
            throw new Error('Required parameter paymentRef was null or undefined when calling getApPaymentByRef.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/ap/payments/by-ref/${this.configuration.encodeParam({ name: "paymentRef", value: paymentRef, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listApBills(vendorId, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vendorId', vendorId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/ap/bills`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: APPaymentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: APPaymentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: APPaymentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AccountingAnalyticsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getCollectionsAnalytics(startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getCollectionsAnalytics.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getCollectionsAnalytics.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/analytics/collections`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPaymentLagCohorts(issuedFrom, issuedTo, limit, observe = 'body', reportProgress = false, options) {
        if (issuedFrom === null || issuedFrom === undefined) {
            throw new Error('Required parameter issuedFrom was null or undefined when calling getPaymentLagCohorts.');
        }
        if (issuedTo === null || issuedTo === undefined) {
            throw new Error('Required parameter issuedTo was null or undefined when calling getPaymentLagCohorts.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'issuedFrom', issuedFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'issuedTo', issuedTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/analytics/payment-lag-cohorts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getVendorSpend(startDate, endDate, limit, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getVendorSpend.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getVendorSpend.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/analytics/vendor-spend`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingAnalyticsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingAnalyticsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingAnalyticsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AccountingEventsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getAccountingEvent(eventId, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling getAccountingEvent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEventContract(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events/contract`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEventProcessingLog(eventId, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling getEventProcessingLog.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/processing-log`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEventReprocessingHistory(eventId, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling getEventReprocessingHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reprocessing-history`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listAccountingEvents(organizationId, eventType, idempotencyOutcome, receivedAtFrom, receivedAtTo, eventId, ingestionId, domainKeyId, invoiceId, status, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'organizationId', organizationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'eventType', eventType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'idempotencyOutcome', idempotencyOutcome, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'receivedAtFrom', receivedAtFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'receivedAtTo', receivedAtTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'eventId', eventId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'ingestionId', ingestionId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'domainKeyId', domainKeyId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'invoiceId', invoiceId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reprocessSuspendedEvent(eventId, reprocessEventRequest, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling reprocessSuspendedEvent.');
        }
        if (reprocessEventRequest === null || reprocessEventRequest === undefined) {
            throw new Error('Required parameter reprocessEventRequest was null or undefined when calling reprocessSuspendedEvent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reprocess`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reprocessEventRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    retryAccountingEvent(eventId, body, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling retryAccountingEvent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/retry`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitAccountingEvent(accountingEventSubmitRequest, observe = 'body', reportProgress = false, options) {
        if (accountingEventSubmitRequest === null || accountingEventSubmitRequest === undefined) {
            throw new Error('Required parameter accountingEventSubmitRequest was null or undefined when calling submitAccountingEvent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/events`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: accountingEventSubmitRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingEventsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingEventsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingEventsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AccountingExportsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getExportStatus(jobId, observe = 'body', reportProgress = false, options) {
        if (jobId === null || jobId === undefined) {
            throw new Error('Required parameter jobId was null or undefined when calling getExportStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/export/status/${this.configuration.encodeParam({ name: "jobId", value: jobId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listExportHistory(page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/export/history`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    requestExport(exportJobRequest, observe = 'body', reportProgress = false, options) {
        if (exportJobRequest === null || exportJobRequest === undefined) {
            throw new Error('Required parameter exportJobRequest was null or undefined when calling requestExport.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/export`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: exportJobRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingExportsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingExportsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingExportsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AccountingPeriodsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    closeAccountingPeriod(periodCode, observe = 'body', reportProgress = false, options) {
        if (periodCode === null || periodCode === undefined) {
            throw new Error('Required parameter periodCode was null or undefined when calling closeAccountingPeriod.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/periods/${this.configuration.encodeParam({ name: "periodCode", value: periodCode, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/close`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAccountingHardLockDate(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/periods/hard-lock`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listAccountingPeriods(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/periods`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reopenAccountingPeriod(periodCode, accountingPeriodReopenRequest, observe = 'body', reportProgress = false, options) {
        if (periodCode === null || periodCode === undefined) {
            throw new Error('Required parameter periodCode was null or undefined when calling reopenAccountingPeriod.');
        }
        if (accountingPeriodReopenRequest === null || accountingPeriodReopenRequest === undefined) {
            throw new Error('Required parameter accountingPeriodReopenRequest was null or undefined when calling reopenAccountingPeriod.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/periods/${this.configuration.encodeParam({ name: "periodCode", value: periodCode, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/reopen`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: accountingPeriodReopenRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    setAccountingHardLockDate(hardLockDateUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (hardLockDateUpdateRequest === null || hardLockDateUpdateRequest === undefined) {
            throw new Error('Required parameter hardLockDateUpdateRequest was null or undefined when calling setAccountingHardLockDate.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/periods/hard-lock`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: hardLockDateUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingPeriodsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingPeriodsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AccountingPeriodsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AuditTrailService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getAuditTrailByActor(actorId, startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (actorId === null || actorId === undefined) {
            throw new Error('Required parameter actorId was null or undefined when calling getAuditTrailByActor.');
        }
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getAuditTrailByActor.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getAuditTrailByActor.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/actor/${this.configuration.encodeParam({ name: "actorId", value: actorId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAuditTrailByDateRange(startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getAuditTrailByDateRange.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getAuditTrailByDateRange.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/range`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAuditTrailByInvoice(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling getAuditTrailByInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/invoice/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAuditTrailByOrder(orderId, observe = 'body', reportProgress = false, options) {
        if (orderId === null || orderId === undefined) {
            throw new Error('Required parameter orderId was null or undefined when calling getAuditTrailByOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/order/${this.configuration.encodeParam({ name: "orderId", value: orderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAuditTrailByOrder1(orderId, observe = 'body', reportProgress = false, options) {
        if (orderId === null || orderId === undefined) {
            throw new Error('Required parameter orderId was null or undefined when calling getAuditTrailByOrder1.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/by-order/${this.configuration.encodeParam({ name: "orderId", value: orderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAuditTrailByType(type, startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (type === null || type === undefined) {
            throw new Error('Required parameter type was null or undefined when calling getAuditTrailByType.');
        }
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling getAuditTrailByType.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling getAuditTrailByType.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/type/${this.configuration.encodeParam({ name: "type", value: type, in: "path", style: "simple", explode: false, dataType: "'PRICE_OVERRIDE' | 'REFUND' | 'CANCELLATION'", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordCancellationAudit(cancellationRequest, observe = 'body', reportProgress = false, options) {
        if (cancellationRequest === null || cancellationRequest === undefined) {
            throw new Error('Required parameter cancellationRequest was null or undefined when calling recordCancellationAudit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/cancellation`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: cancellationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordPriceOverrideAudit(priceOverrideRequest, observe = 'body', reportProgress = false, options) {
        if (priceOverrideRequest === null || priceOverrideRequest === undefined) {
            throw new Error('Required parameter priceOverrideRequest was null or undefined when calling recordPriceOverrideAudit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/price-override`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: priceOverrideRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordRefundAudit(refundRequest, observe = 'body', reportProgress = false, options) {
        if (refundRequest === null || refundRequest === undefined) {
            throw new Error('Required parameter refundRequest was null or undefined when calling recordRefundAudit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/audit/refund`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: refundRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditTrailService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditTrailService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditTrailService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class BankReconciliationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addReconciliationAdjustment(reconciliationId, reconciliationAdjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling addReconciliationAdjustment.');
        }
        if (reconciliationAdjustmentRequest === null || reconciliationAdjustmentRequest === undefined) {
            throw new Error('Required parameter reconciliationAdjustmentRequest was null or undefined when calling addReconciliationAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reconciliationAdjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    finalizeReconciliation(reconciliationId, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling finalizeReconciliation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/finalize`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getReconciliation(reconciliationId, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling getReconciliation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getReconciliationAudit(reconciliationId, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling getReconciliationAudit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/audit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getReconciliationReport(reconciliationId, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling getReconciliationReport.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/report`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    importReconciliation(bankReconciliationImportRequest, observe = 'body', reportProgress = false, options) {
        if (bankReconciliationImportRequest === null || bankReconciliationImportRequest === undefined) {
            throw new Error('Required parameter bankReconciliationImportRequest was null or undefined when calling importReconciliation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/import`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bankReconciliationImportRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReconciliationAdjustmentTypes(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/adjustment-types`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReconciliations(glAccountId, status, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'glAccountId', glAccountId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    matchReconciliation(reconciliationId, reconciliationMatchRequest, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling matchReconciliation.');
        }
        if (reconciliationMatchRequest === null || reconciliationMatchRequest === undefined) {
            throw new Error('Required parameter reconciliationMatchRequest was null or undefined when calling matchReconciliation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/match`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reconciliationMatchRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    unmatchReconciliation(reconciliationId, reconciliationUnmatchRequest, observe = 'body', reportProgress = false, options) {
        if (reconciliationId === null || reconciliationId === undefined) {
            throw new Error('Required parameter reconciliationId was null or undefined when calling unmatchReconciliation.');
        }
        if (reconciliationUnmatchRequest === null || reconciliationUnmatchRequest === undefined) {
            throw new Error('Required parameter reconciliationUnmatchRequest was null or undefined when calling unmatchReconciliation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reconciliations/${this.configuration.encodeParam({ name: "reconciliationId", value: reconciliationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/unmatch`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reconciliationUnmatchRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BankReconciliationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BankReconciliationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BankReconciliationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CreditMemosService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCreditMemo(createCreditMemoRequest, observe = 'body', reportProgress = false, options) {
        if (createCreditMemoRequest === null || createCreditMemoRequest === undefined) {
            throw new Error('Required parameter createCreditMemoRequest was null or undefined when calling createCreditMemo.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/credit-memos`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createCreditMemoRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCreditMemo(creditMemoId, observe = 'body', reportProgress = false, options) {
        if (creditMemoId === null || creditMemoId === undefined) {
            throw new Error('Required parameter creditMemoId was null or undefined when calling getCreditMemo.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/credit-memos/${this.configuration.encodeParam({ name: "creditMemoId", value: creditMemoId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCreditMemos(customerId, originalInvoiceId, status, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'originalInvoiceId', originalInvoiceId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/credit-memos`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    voidCreditMemo(creditMemoId, voidCreditMemoRequest, observe = 'body', reportProgress = false, options) {
        if (creditMemoId === null || creditMemoId === undefined) {
            throw new Error('Required parameter creditMemoId was null or undefined when calling voidCreditMemo.');
        }
        if (voidCreditMemoRequest === null || voidCreditMemoRequest === undefined) {
            throw new Error('Required parameter voidCreditMemoRequest was null or undefined when calling voidCreditMemo.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/credit-memos/${this.configuration.encodeParam({ name: "creditMemoId", value: creditMemoId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/void`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: voidCreditMemoRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CreditMemosService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CreditMemosService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CreditMemosService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CustomerCreditsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    applyCustomerCredit(creditId, customerCreditApplicationRequest, observe = 'body', reportProgress = false, options) {
        if (creditId === null || creditId === undefined) {
            throw new Error('Required parameter creditId was null or undefined when calling applyCustomerCredit.');
        }
        if (customerCreditApplicationRequest === null || customerCreditApplicationRequest === undefined) {
            throw new Error('Required parameter customerCreditApplicationRequest was null or undefined when calling applyCustomerCredit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/customer-credits/${this.configuration.encodeParam({ name: "creditId", value: creditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/applications`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: customerCreditApplicationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCustomerCredit(creditId, observe = 'body', reportProgress = false, options) {
        if (creditId === null || creditId === undefined) {
            throw new Error('Required parameter creditId was null or undefined when calling getCustomerCredit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/customer-credits/${this.configuration.encodeParam({ name: "creditId", value: creditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCustomerCredits(customerId, status, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerId', customerId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/customer-credits`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    refundCustomerCredit(creditId, customerCreditRefundRequest, observe = 'body', reportProgress = false, options) {
        if (creditId === null || creditId === undefined) {
            throw new Error('Required parameter creditId was null or undefined when calling refundCustomerCredit.');
        }
        if (customerCreditRefundRequest === null || customerCreditRefundRequest === undefined) {
            throw new Error('Required parameter customerCreditRefundRequest was null or undefined when calling refundCustomerCredit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/customer-credits/${this.configuration.encodeParam({ name: "creditId", value: creditId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/refunds`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: customerCreditRefundRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerCreditsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerCreditsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerCreditsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class DefaultGLMappingsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createDefaultMapping(defaultGLMappingRequest, observe = 'body', reportProgress = false, options) {
        if (defaultGLMappingRequest === null || defaultGLMappingRequest === undefined) {
            throw new Error('Required parameter defaultGLMappingRequest was null or undefined when calling createDefaultMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: defaultGLMappingRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivateDefaultMapping(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling deactivateDefaultMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getDefaultMapping(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getDefaultMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listDefaultMappings(page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listGlobalDefaultMappings(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings/global`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveDefaultMapping(eventType, organizationId, observe = 'body', reportProgress = false, options) {
        if (eventType === null || eventType === undefined) {
            throw new Error('Required parameter eventType was null or undefined when calling resolveDefaultMapping.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'eventType', eventType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'organizationId', organizationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchDefaultMappings(eventType, organizationId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'eventType', eventType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'organizationId', organizationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateDefaultMapping(id, defaultGLMappingRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateDefaultMapping.');
        }
        if (defaultGLMappingRequest === null || defaultGLMappingRequest === undefined) {
            throw new Error('Required parameter defaultGLMappingRequest was null or undefined when calling updateDefaultMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/default-mappings/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: defaultGLMappingRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DefaultGLMappingsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DefaultGLMappingsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DefaultGLMappingsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class FinancialReportingService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    downloadReportExport(exportId, observe = 'body', reportProgress = false, options) {
        if (exportId === null || exportId === undefined) {
            throw new Error('Required parameter exportId was null or undefined when calling downloadReportExport.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/octet-stream',
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let localVarPath = `/v1/accounting/reports/export/${this.configuration.encodeParam({ name: "exportId", value: exportId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/download`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: "blob",
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    drilldownToAccounts(statementLineCode, startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (statementLineCode === null || statementLineCode === undefined) {
            throw new Error('Required parameter statementLineCode was null or undefined when calling drilldownToAccounts.');
        }
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling drilldownToAccounts.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling drilldownToAccounts.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/drilldown/accounts/${this.configuration.encodeParam({ name: "statementLineCode", value: statementLineCode, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    drilldownToJournalLines(accountId, startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (accountId === null || accountId === undefined) {
            throw new Error('Required parameter accountId was null or undefined when calling drilldownToJournalLines.');
        }
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling drilldownToJournalLines.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling drilldownToJournalLines.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/drilldown/journal-lines/${this.configuration.encodeParam({ name: "accountId", value: accountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    freezeTaxLiabilitySnapshot(periodCode, supersede, observe = 'body', reportProgress = false, options) {
        if (periodCode === null || periodCode === undefined) {
            throw new Error('Required parameter periodCode was null or undefined when calling freezeTaxLiabilitySnapshot.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'periodCode', periodCode, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'supersede', supersede, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateAgedPayables(asOfDate, observe = 'body', reportProgress = false, options) {
        if (asOfDate === null || asOfDate === undefined) {
            throw new Error('Required parameter asOfDate was null or undefined when calling generateAgedPayables.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOfDate', asOfDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/aged-payables`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateAgedReceivables(asOfDate, observe = 'body', reportProgress = false, options) {
        if (asOfDate === null || asOfDate === undefined) {
            throw new Error('Required parameter asOfDate was null or undefined when calling generateAgedReceivables.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOfDate', asOfDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/aged-receivables`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateBalanceSheet(asOfDate, observe = 'body', reportProgress = false, options) {
        if (asOfDate === null || asOfDate === undefined) {
            throw new Error('Required parameter asOfDate was null or undefined when calling generateBalanceSheet.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOfDate', asOfDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/balance-sheet`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateGeneralLedger(startDate, endDate, accountId, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling generateGeneralLedger.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling generateGeneralLedger.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'accountId', accountId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/general-ledger`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateIncomeStatement(startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling generateIncomeStatement.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling generateIncomeStatement.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/income-statement`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateTaxLiabilityReport(startDate, endDate, observe = 'body', reportProgress = false, options) {
        if (startDate === null || startDate === undefined) {
            throw new Error('Required parameter startDate was null or undefined when calling generateTaxLiabilityReport.');
        }
        if (endDate === null || endDate === undefined) {
            throw new Error('Required parameter endDate was null or undefined when calling generateTaxLiabilityReport.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'startDate', startDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generateTrialBalance(asOf, observe = 'body', reportProgress = false, options) {
        if (asOf === null || asOf === undefined) {
            throw new Error('Required parameter asOf was null or undefined when calling generateTrialBalance.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/trial-balance`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getReportExportStatus(exportId, observe = 'body', reportProgress = false, options) {
        if (exportId === null || exportId === undefined) {
            throw new Error('Required parameter exportId was null or undefined when calling getReportExportStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/export/${this.configuration.encodeParam({ name: "exportId", value: exportId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTaxLiabilitySnapshot(snapshotId, observe = 'body', reportProgress = false, options) {
        if (snapshotId === null || snapshotId === undefined) {
            throw new Error('Required parameter snapshotId was null or undefined when calling getTaxLiabilitySnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots/${this.configuration.encodeParam({ name: "snapshotId", value: snapshotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReportExports(page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/export`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTaxLiabilitySnapshots(periodCode, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'periodCode', periodCode, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    requestReportExport(reportExportRequest, observe = 'body', reportProgress = false, options) {
        if (reportExportRequest === null || reportExportRequest === undefined) {
            throw new Error('Required parameter reportExportRequest was null or undefined when calling requestReportExport.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/export`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reportExportRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    verifyTaxLiabilitySnapshot(snapshotId, observe = 'body', reportProgress = false, options) {
        if (snapshotId === null || snapshotId === undefined) {
            throw new Error('Required parameter snapshotId was null or undefined when calling verifyTaxLiabilitySnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots/${this.configuration.encodeParam({ name: "snapshotId", value: snapshotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/verify`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FinancialReportingService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FinancialReportingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FinancialReportingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class FinancialReportingForTaxLiabilityService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    freezeTaxLiabilitySnapshot(periodCode, supersede, observe = 'body', reportProgress = false, options) {
        if (periodCode === null || periodCode === undefined) {
            throw new Error('Required parameter periodCode was null or undefined when calling freezeTaxLiabilitySnapshot.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'periodCode', periodCode, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'supersede', supersede, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTaxLiabilitySnapshot(snapshotId, observe = 'body', reportProgress = false, options) {
        if (snapshotId === null || snapshotId === undefined) {
            throw new Error('Required parameter snapshotId was null or undefined when calling getTaxLiabilitySnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots/${this.configuration.encodeParam({ name: "snapshotId", value: snapshotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTaxLiabilitySnapshots(periodCode, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'periodCode', periodCode, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    verifyTaxLiabilitySnapshot(snapshotId, observe = 'body', reportProgress = false, options) {
        if (snapshotId === null || snapshotId === undefined) {
            throw new Error('Required parameter snapshotId was null or undefined when calling verifyTaxLiabilitySnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/financial/tax-liability/snapshots/${this.configuration.encodeParam({ name: "snapshotId", value: snapshotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/verify`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FinancialReportingForTaxLiabilityService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FinancialReportingForTaxLiabilityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FinancialReportingForTaxLiabilityService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class GLAccountsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    activateGLAccount(glAccountId, gLAccountActivateRequest, observe = 'body', reportProgress = false, options) {
        if (glAccountId === null || glAccountId === undefined) {
            throw new Error('Required parameter glAccountId was null or undefined when calling activateGLAccount.');
        }
        if (gLAccountActivateRequest === null || gLAccountActivateRequest === undefined) {
            throw new Error('Required parameter gLAccountActivateRequest was null or undefined when calling activateGLAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts/${this.configuration.encodeParam({ name: "glAccountId", value: glAccountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/activate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: gLAccountActivateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    archiveGLAccount(glAccountId, body, observe = 'body', reportProgress = false, options) {
        if (glAccountId === null || glAccountId === undefined) {
            throw new Error('Required parameter glAccountId was null or undefined when calling archiveGLAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts/${this.configuration.encodeParam({ name: "glAccountId", value: glAccountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/archive`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createGLAccount(gLAccountCreateRequest, observe = 'body', reportProgress = false, options) {
        if (gLAccountCreateRequest === null || gLAccountCreateRequest === undefined) {
            throw new Error('Required parameter gLAccountCreateRequest was null or undefined when calling createGLAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: gLAccountCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivateGLAccount(glAccountId, body, observe = 'body', reportProgress = false, options) {
        if (glAccountId === null || glAccountId === undefined) {
            throw new Error('Required parameter glAccountId was null or undefined when calling deactivateGLAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts/${this.configuration.encodeParam({ name: "glAccountId", value: glAccountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/deactivate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getGLAccount(glAccountId, observe = 'body', reportProgress = false, options) {
        if (glAccountId === null || glAccountId === undefined) {
            throw new Error('Required parameter glAccountId was null or undefined when calling getGLAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts/${this.configuration.encodeParam({ name: "glAccountId", value: glAccountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getGLAccountBalance(glAccountId, observe = 'body', reportProgress = false, options) {
        if (glAccountId === null || glAccountId === undefined) {
            throw new Error('Required parameter glAccountId was null or undefined when calling getGLAccountBalance.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts/${this.configuration.encodeParam({ name: "glAccountId", value: glAccountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/balance`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listGLAccounts(sort, page, size, status, observe = 'body', reportProgress = false, options) {
        if (sort === null || sort === undefined) {
            throw new Error('Required parameter sort was null or undefined when calling listGLAccounts.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateGLAccount(glAccountId, gLAccountUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (glAccountId === null || glAccountId === undefined) {
            throw new Error('Required parameter glAccountId was null or undefined when calling updateGLAccount.');
        }
        if (gLAccountUpdateRequest === null || gLAccountUpdateRequest === undefined) {
            throw new Error('Required parameter gLAccountUpdateRequest was null or undefined when calling updateGLAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/gl-accounts/${this.configuration.encodeParam({ name: "glAccountId", value: glAccountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: gLAccountUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: GLAccountsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: GLAccountsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: GLAccountsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class GLMappingAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createGLMapping(gLMappingCreateRequest, observe = 'body', reportProgress = false, options) {
        if (gLMappingCreateRequest === null || gLMappingCreateRequest === undefined) {
            throw new Error('Required parameter gLMappingCreateRequest was null or undefined when calling createGLMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mappings`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: gLMappingCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveGLMapping(gLMappingResolveRequest, observe = 'body', reportProgress = false, options) {
        if (gLMappingResolveRequest === null || gLMappingResolveRequest === undefined) {
            throw new Error('Required parameter gLMappingResolveRequest was null or undefined when calling resolveGLMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mappings/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: gLMappingResolveRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveTestMapping(mappingResolutionTestRequest, observe = 'body', reportProgress = false, options) {
        if (mappingResolutionTestRequest === null || mappingResolutionTestRequest === undefined) {
            throw new Error('Required parameter mappingResolutionTestRequest was null or undefined when calling resolveTestMapping.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mappings/resolve-test`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: mappingResolutionTestRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: GLMappingAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: GLMappingAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: GLMappingAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InvoicePaymentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getAccountingBillingRules(customerId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling getAccountingBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/invoice/rules/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getInvoiceStatus(invoiceId, observe = 'body', reportProgress = false, options) {
        if (invoiceId === null || invoiceId === undefined) {
            throw new Error('Required parameter invoiceId was null or undefined when calling getInvoiceStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/invoice/${this.configuration.encodeParam({ name: "invoiceId", value: invoiceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/status`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    regenerateInvoiceFromWorkorder(regenerateInvoiceFromWorkorderRequest, observe = 'body', reportProgress = false, options) {
        if (regenerateInvoiceFromWorkorderRequest === null || regenerateInvoiceFromWorkorderRequest === undefined) {
            throw new Error('Required parameter regenerateInvoiceFromWorkorderRequest was null or undefined when calling regenerateInvoiceFromWorkorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/invoice/invoices`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: regenerateInvoiceFromWorkorderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoicePaymentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoicePaymentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InvoicePaymentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class JournalEntriesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createJournalEntry(journalEntryCreateRequest, observe = 'body', reportProgress = false, options) {
        if (journalEntryCreateRequest === null || journalEntryCreateRequest === undefined) {
            throw new Error('Required parameter journalEntryCreateRequest was null or undefined when calling createJournalEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: journalEntryCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getJournalEntry(journalEntryId, observe = 'body', reportProgress = false, options) {
        if (journalEntryId === null || journalEntryId === undefined) {
            throw new Error('Required parameter journalEntryId was null or undefined when calling getJournalEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries/${this.configuration.encodeParam({ name: "journalEntryId", value: journalEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getJournalEntryTraceability(journalEntryId, observe = 'body', reportProgress = false, options) {
        if (journalEntryId === null || journalEntryId === undefined) {
            throw new Error('Required parameter journalEntryId was null or undefined when calling getJournalEntryTraceability.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries/${this.configuration.encodeParam({ name: "journalEntryId", value: journalEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/traceability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listJournalEntries(sort, page, size, entryNumber, observe = 'body', reportProgress = false, options) {
        if (sort === null || sort === undefined) {
            throw new Error('Required parameter sort was null or undefined when calling listJournalEntries.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'entryNumber', entryNumber, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    postJournalEntry(journalEntryId, journalEntryPostRequest, observe = 'body', reportProgress = false, options) {
        if (journalEntryId === null || journalEntryId === undefined) {
            throw new Error('Required parameter journalEntryId was null or undefined when calling postJournalEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries/${this.configuration.encodeParam({ name: "journalEntryId", value: journalEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/post`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: journalEntryPostRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reverseJournalEntry(journalEntryId, journalEntryReversalRequest, observe = 'body', reportProgress = false, options) {
        if (journalEntryId === null || journalEntryId === undefined) {
            throw new Error('Required parameter journalEntryId was null or undefined when calling reverseJournalEntry.');
        }
        if (journalEntryReversalRequest === null || journalEntryReversalRequest === undefined) {
            throw new Error('Required parameter journalEntryReversalRequest was null or undefined when calling reverseJournalEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries/${this.configuration.encodeParam({ name: "journalEntryId", value: journalEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reverse`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: journalEntryReversalRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateJournalEntry(journalEntryId, journalEntryCreateRequest, observe = 'body', reportProgress = false, options) {
        if (journalEntryId === null || journalEntryId === undefined) {
            throw new Error('Required parameter journalEntryId was null or undefined when calling updateJournalEntry.');
        }
        if (journalEntryCreateRequest === null || journalEntryCreateRequest === undefined) {
            throw new Error('Required parameter journalEntryCreateRequest was null or undefined when calling updateJournalEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/journal-entries/${this.configuration.encodeParam({ name: "journalEntryId", value: journalEntryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: journalEntryCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: JournalEntriesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: JournalEntriesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: JournalEntriesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LocationCostReportingService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    generateLaborOverheadReport(locationId, fiscalYear, asOfMonth, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling generateLaborOverheadReport.');
        }
        if (fiscalYear === null || fiscalYear === undefined) {
            throw new Error('Required parameter fiscalYear was null or undefined when calling generateLaborOverheadReport.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'fiscalYear', fiscalYear, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOfMonth', asOfMonth, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/reports/location/labor-overhead`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LocationCostReportingService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LocationCostReportingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LocationCostReportingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class MappingKeysService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createMappingKey(mappingKeyCreateRequest, observe = 'body', reportProgress = false, options) {
        if (mappingKeyCreateRequest === null || mappingKeyCreateRequest === undefined) {
            throw new Error('Required parameter mappingKeyCreateRequest was null or undefined when calling createMappingKey.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mapping-keys`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: mappingKeyCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivateMappingKey(mappingKeyId, observe = 'body', reportProgress = false, options) {
        if (mappingKeyId === null || mappingKeyId === undefined) {
            throw new Error('Required parameter mappingKeyId was null or undefined when calling deactivateMappingKey.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mapping-keys/${this.configuration.encodeParam({ name: "mappingKeyId", value: mappingKeyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/deactivate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getMappingKey(mappingKeyId, observe = 'body', reportProgress = false, options) {
        if (mappingKeyId === null || mappingKeyId === undefined) {
            throw new Error('Required parameter mappingKeyId was null or undefined when calling getMappingKey.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mapping-keys/${this.configuration.encodeParam({ name: "mappingKeyId", value: mappingKeyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listMappingKeysByCategory(postingCategoryId, sort, page, size, isActive, observe = 'body', reportProgress = false, options) {
        if (postingCategoryId === null || postingCategoryId === undefined) {
            throw new Error('Required parameter postingCategoryId was null or undefined when calling listMappingKeysByCategory.');
        }
        if (sort === null || sort === undefined) {
            throw new Error('Required parameter sort was null or undefined when calling listMappingKeysByCategory.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'isActive', isActive, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-categories/${this.configuration.encodeParam({ name: "postingCategoryId", value: postingCategoryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/mapping-keys`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateMappingKey(mappingKeyId, mappingKeyUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (mappingKeyId === null || mappingKeyId === undefined) {
            throw new Error('Required parameter mappingKeyId was null or undefined when calling updateMappingKey.');
        }
        if (mappingKeyUpdateRequest === null || mappingKeyUpdateRequest === undefined) {
            throw new Error('Required parameter mappingKeyUpdateRequest was null or undefined when calling updateMappingKey.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/mapping-keys/${this.configuration.encodeParam({ name: "mappingKeyId", value: mappingKeyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: mappingKeyUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MappingKeysService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MappingKeysService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MappingKeysService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PaymentApplicationsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    applyPayment(paymentId, paymentApplicationRequest, observe = 'body', reportProgress = false, options) {
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling applyPayment.');
        }
        if (paymentApplicationRequest === null || paymentApplicationRequest === undefined) {
            throw new Error('Required parameter paymentApplicationRequest was null or undefined when calling applyPayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/applications`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: paymentApplicationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPaymentApplications(appliedFrom, appliedTo, includeReversed, page, size, sort, observe = 'body', reportProgress = false, options) {
        if (appliedFrom === null || appliedFrom === undefined) {
            throw new Error('Required parameter appliedFrom was null or undefined when calling listPaymentApplications.');
        }
        if (appliedTo === null || appliedTo === undefined) {
            throw new Error('Required parameter appliedTo was null or undefined when calling listPaymentApplications.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'appliedFrom', appliedFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'appliedTo', appliedTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeReversed', includeReversed, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/payment-applications`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reversePayment(paymentId, paymentApplicationReversalRequest, observe = 'body', reportProgress = false, options) {
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling reversePayment.');
        }
        if (paymentApplicationReversalRequest === null || paymentApplicationReversalRequest === undefined) {
            throw new Error('Required parameter paymentApplicationReversalRequest was null or undefined when calling reversePayment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reverse`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: paymentApplicationReversalRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reversePaymentApplication(applicationId, paymentApplicationReversalRequest, observe = 'body', reportProgress = false, options) {
        if (applicationId === null || applicationId === undefined) {
            throw new Error('Required parameter applicationId was null or undefined when calling reversePaymentApplication.');
        }
        if (paymentApplicationReversalRequest === null || paymentApplicationReversalRequest === undefined) {
            throw new Error('Required parameter paymentApplicationReversalRequest was null or undefined when calling reversePaymentApplication.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/payment-applications/${this.configuration.encodeParam({ name: "applicationId", value: applicationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reverse`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: paymentApplicationReversalRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    voidPaymentApplication(paymentId, body, observe = 'body', reportProgress = false, options) {
        if (paymentId === null || paymentId === undefined) {
            throw new Error('Required parameter paymentId was null or undefined when calling voidPaymentApplication.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/payments/${this.configuration.encodeParam({ name: "paymentId", value: paymentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/void`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentApplicationsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentApplicationsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PaymentApplicationsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PostingCategoriesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPostingCategory(postingCategoryCreateRequest, observe = 'body', reportProgress = false, options) {
        if (postingCategoryCreateRequest === null || postingCategoryCreateRequest === undefined) {
            throw new Error('Required parameter postingCategoryCreateRequest was null or undefined when calling createPostingCategory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-categories`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: postingCategoryCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivatePostingCategory(postingCategoryId, observe = 'body', reportProgress = false, options) {
        if (postingCategoryId === null || postingCategoryId === undefined) {
            throw new Error('Required parameter postingCategoryId was null or undefined when calling deactivatePostingCategory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-categories/${this.configuration.encodeParam({ name: "postingCategoryId", value: postingCategoryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/deactivate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPostingCategory(postingCategoryId, observe = 'body', reportProgress = false, options) {
        if (postingCategoryId === null || postingCategoryId === undefined) {
            throw new Error('Required parameter postingCategoryId was null or undefined when calling getPostingCategory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-categories/${this.configuration.encodeParam({ name: "postingCategoryId", value: postingCategoryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPostingCategories(sort, page, size, isActive, observe = 'body', reportProgress = false, options) {
        if (sort === null || sort === undefined) {
            throw new Error('Required parameter sort was null or undefined when calling listPostingCategories.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'isActive', isActive, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-categories`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePostingCategory(postingCategoryId, postingCategoryUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (postingCategoryId === null || postingCategoryId === undefined) {
            throw new Error('Required parameter postingCategoryId was null or undefined when calling updatePostingCategory.');
        }
        if (postingCategoryUpdateRequest === null || postingCategoryUpdateRequest === undefined) {
            throw new Error('Required parameter postingCategoryUpdateRequest was null or undefined when calling updatePostingCategory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-categories/${this.configuration.encodeParam({ name: "postingCategoryId", value: postingCategoryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: postingCategoryUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PostingCategoriesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PostingCategoriesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PostingCategoriesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PostingRulesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    archivePostingRuleSet(postingRuleSetId, observe = 'body', reportProgress = false, options) {
        if (postingRuleSetId === null || postingRuleSetId === undefined) {
            throw new Error('Required parameter postingRuleSetId was null or undefined when calling archivePostingRuleSet.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules/${this.configuration.encodeParam({ name: "postingRuleSetId", value: postingRuleSetId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/archive`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createPostingRuleSet(postingRuleSetCreateRequest, observe = 'body', reportProgress = false, options) {
        if (postingRuleSetCreateRequest === null || postingRuleSetCreateRequest === undefined) {
            throw new Error('Required parameter postingRuleSetCreateRequest was null or undefined when calling createPostingRuleSet.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: postingRuleSetCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPostingRuleSet(postingRuleSetId, observe = 'body', reportProgress = false, options) {
        if (postingRuleSetId === null || postingRuleSetId === undefined) {
            throw new Error('Required parameter postingRuleSetId was null or undefined when calling getPostingRuleSet.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules/${this.configuration.encodeParam({ name: "postingRuleSetId", value: postingRuleSetId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPostingRuleSets(sort, page, size, observe = 'body', reportProgress = false, options) {
        if (sort === null || sort === undefined) {
            throw new Error('Required parameter sort was null or undefined when calling listPostingRuleSets.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPostingRuleVersions(postingRuleSetId, page, size, observe = 'body', reportProgress = false, options) {
        if (postingRuleSetId === null || postingRuleSetId === undefined) {
            throw new Error('Required parameter postingRuleSetId was null or undefined when calling listPostingRuleVersions.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules/${this.configuration.encodeParam({ name: "postingRuleSetId", value: postingRuleSetId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/versions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    publishPostingRuleSet(postingRuleSetId, observe = 'body', reportProgress = false, options) {
        if (postingRuleSetId === null || postingRuleSetId === undefined) {
            throw new Error('Required parameter postingRuleSetId was null or undefined when calling publishPostingRuleSet.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules/${this.configuration.encodeParam({ name: "postingRuleSetId", value: postingRuleSetId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/publish`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePostingRuleSet(postingRuleSetId, postingRuleSetCreateRequest, observe = 'body', reportProgress = false, options) {
        if (postingRuleSetId === null || postingRuleSetId === undefined) {
            throw new Error('Required parameter postingRuleSetId was null or undefined when calling updatePostingRuleSet.');
        }
        if (postingRuleSetCreateRequest === null || postingRuleSetCreateRequest === undefined) {
            throw new Error('Required parameter postingRuleSetCreateRequest was null or undefined when calling updatePostingRuleSet.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/posting-rules/${this.configuration.encodeParam({ name: "postingRuleSetId", value: postingRuleSetId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: postingRuleSetCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PostingRulesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PostingRulesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PostingRulesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SettlementReconciliationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listSettlementLines(settlementId, unmatchedOnly, observe = 'body', reportProgress = false, options) {
        if (settlementId === null || settlementId === undefined) {
            throw new Error('Required parameter settlementId was null or undefined when calling listSettlementLines.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'unmatchedOnly', unmatchedOnly, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/settlements/${this.configuration.encodeParam({ name: "settlementId", value: settlementId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/lines`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    matchSettlementLine(lineId, settlementManualMatchRequest, observe = 'body', reportProgress = false, options) {
        if (lineId === null || lineId === undefined) {
            throw new Error('Required parameter lineId was null or undefined when calling matchSettlementLine.');
        }
        if (settlementManualMatchRequest === null || settlementManualMatchRequest === undefined) {
            throw new Error('Required parameter settlementManualMatchRequest was null or undefined when calling matchSettlementLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/settlements/lines/${this.configuration.encodeParam({ name: "lineId", value: lineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/match`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: settlementManualMatchRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    writeOffSettlementLine(lineId, settlementWriteOffRequest, observe = 'body', reportProgress = false, options) {
        if (lineId === null || lineId === undefined) {
            throw new Error('Required parameter lineId was null or undefined when calling writeOffSettlementLine.');
        }
        if (settlementWriteOffRequest === null || settlementWriteOffRequest === undefined) {
            throw new Error('Required parameter settlementWriteOffRequest was null or undefined when calling writeOffSettlementLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/settlements/lines/${this.configuration.encodeParam({ name: "lineId", value: lineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/write-off`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: settlementWriteOffRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SettlementReconciliationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SettlementReconciliationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SettlementReconciliationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class VendorBillAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createVendorBillFromGoodsReceived(goodsReceivedEvent, observe = 'body', reportProgress = false, options) {
        if (goodsReceivedEvent === null || goodsReceivedEvent === undefined) {
            throw new Error('Required parameter goodsReceivedEvent was null or undefined when calling createVendorBillFromGoodsReceived.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: goodsReceivedEvent,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getVendorBillById(billId, observe = 'body', reportProgress = false, options) {
        if (billId === null || billId === undefined) {
            throw new Error('Required parameter billId was null or undefined when calling getVendorBillById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills/${this.configuration.encodeParam({ name: "billId", value: billId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getVendorBillByOriginEventId(eventId, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling getVendorBillByOriginEventId.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills/event/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listVendorBillMatchCandidates(invoiceEventId, observe = 'body', reportProgress = false, options) {
        if (invoiceEventId === null || invoiceEventId === undefined) {
            throw new Error('Required parameter invoiceEventId was null or undefined when calling listVendorBillMatchCandidates.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills/match-candidates/${this.configuration.encodeParam({ name: "invoiceEventId", value: invoiceEventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listVendorBills(dueFrom, dueTo, status, page, size, sort, observe = 'body', reportProgress = false, options) {
        if (dueFrom === null || dueFrom === undefined) {
            throw new Error('Required parameter dueFrom was null or undefined when calling listVendorBills.');
        }
        if (dueTo === null || dueTo === undefined) {
            throw new Error('Required parameter dueTo was null or undefined when calling listVendorBills.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dueFrom', dueFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dueTo', dueTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    matchVendorInvoice(vendorInvoiceReceivedEvent, observe = 'body', reportProgress = false, options) {
        if (vendorInvoiceReceivedEvent === null || vendorInvoiceReceivedEvent === undefined) {
            throw new Error('Required parameter vendorInvoiceReceivedEvent was null or undefined when calling matchVendorInvoice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills/match`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: vendorInvoiceReceivedEvent,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveVendorBillMatchException(billId, exceptionResolutionRequest, observe = 'body', reportProgress = false, options) {
        if (billId === null || billId === undefined) {
            throw new Error('Required parameter billId was null or undefined when calling resolveVendorBillMatchException.');
        }
        if (exceptionResolutionRequest === null || exceptionResolutionRequest === undefined) {
            throw new Error('Required parameter exceptionResolutionRequest was null or undefined when calling resolveVendorBillMatchException.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills/${this.configuration.encodeParam({ name: "billId", value: billId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/resolve-exception`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: exceptionResolutionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    selectVendorBillMatchCandidate(candidateId, candidateSelectionRequest, observe = 'body', reportProgress = false, options) {
        if (candidateId === null || candidateId === undefined) {
            throw new Error('Required parameter candidateId was null or undefined when calling selectVendorBillMatchCandidate.');
        }
        if (candidateSelectionRequest === null || candidateSelectionRequest === undefined) {
            throw new Error('Required parameter candidateSelectionRequest was null or undefined when calling selectVendorBillMatchCandidate.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendor-bills/match-candidates/${this.configuration.encodeParam({ name: "candidateId", value: candidateId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/select`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: candidateSelectionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: VendorBillAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: VendorBillAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: VendorBillAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class VendorDirectoryAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getVendorById(vendorId, observe = 'body', reportProgress = false, options) {
        if (vendorId === null || vendorId === undefined) {
            throw new Error('Required parameter vendorId was null or undefined when calling getVendorById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendors/${this.configuration.encodeParam({ name: "vendorId", value: vendorId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchVendors(name, limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'name', name, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/accounting/vendors`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: VendorDirectoryAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: VendorDirectoryAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: VendorDirectoryAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

var APPaymentResponseStatusEnum;
(function (APPaymentResponseStatusEnum) {
    APPaymentResponseStatusEnum["Initiated"] = "INITIATED";
    APPaymentResponseStatusEnum["GatewayPending"] = "GATEWAY_PENDING";
    APPaymentResponseStatusEnum["GatewayFailed"] = "GATEWAY_FAILED";
    APPaymentResponseStatusEnum["GatewaySucceeded"] = "GATEWAY_SUCCEEDED";
    APPaymentResponseStatusEnum["GlPostPending"] = "GL_POST_PENDING";
    APPaymentResponseStatusEnum["GlPosted"] = "GL_POSTED";
    APPaymentResponseStatusEnum["GlPostFailed"] = "GL_POST_FAILED";
})(APPaymentResponseStatusEnum || (APPaymentResponseStatusEnum = {}));
;
function isOptionalAPPaymentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAPPaymentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAPPaymentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAPPaymentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAPPaymentResponsePropertyNames();
    const optionalStringProperties = createAPPaymentResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'currency', nullable: false }, { name: 'gatewayTimestamp', nullable: false }, { name: 'gatewayTransactionId', nullable: false }, { name: 'glJournalEntryId', nullable: false }, { name: 'glPostError', nullable: false }, { name: 'glPostedAt', nullable: false }, { name: 'memo', nullable: false }, { name: 'paymentId', nullable: false }, { name: 'paymentRef', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorId', nullable: false }, { name: 'vendorName', nullable: false });
    const optionalNumberProperties = createAPPaymentResponseOptionalProperties({ name: 'feeAmount', nullable: false }, { name: 'grossAmount', nullable: false }, { name: 'netAmount', nullable: false }, { name: 'unappliedAmount', nullable: false });
    const optionalBooleanProperties = createAPPaymentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAPPaymentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAPPaymentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAPPaymentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAccountDrilldownResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountDrilldownResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountDrilldownResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountDrilldownResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountDrilldownResponsePropertyNames('accountId', 'accountName', 'balance', 'statementLineCode');
    const optionalStringProperties = createAccountDrilldownResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'accountName', nullable: false }, { name: 'statementLineCode', nullable: false });
    const optionalNumberProperties = createAccountDrilldownResponseOptionalProperties({ name: 'balance', nullable: false });
    const optionalBooleanProperties = createAccountDrilldownResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountDrilldownResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountDrilldownResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountDrilldownResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AccountingEventResponseStatusEnum;
(function (AccountingEventResponseStatusEnum) {
    AccountingEventResponseStatusEnum["Received"] = "RECEIVED";
    AccountingEventResponseStatusEnum["Processing"] = "PROCESSING";
    AccountingEventResponseStatusEnum["Processed"] = "PROCESSED";
    AccountingEventResponseStatusEnum["Failed"] = "FAILED";
    AccountingEventResponseStatusEnum["Suspended"] = "SUSPENDED";
})(AccountingEventResponseStatusEnum || (AccountingEventResponseStatusEnum = {}));
;
function isOptionalAccountingEventResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountingEventResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountingEventResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountingEventResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountingEventResponsePropertyNames('eventId', 'eventType', 'organizationId', 'receivedAt', 'status');
    const optionalStringProperties = createAccountingEventResponseOptionalProperties({ name: 'domainKeyId', nullable: false }, { name: 'errorMessage', nullable: false }, { name: 'eventId', nullable: false }, { name: 'eventType', nullable: false }, { name: 'failureDetails', nullable: false }, { name: 'failureReasonCode', nullable: false }, { name: 'finalPostingReferenceId', nullable: false }, { name: 'idempotencyOutcome', nullable: false }, { name: 'ingestionId', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'journalEntryId', nullable: false }, { name: 'mappingVersionAttempted', nullable: false }, { name: 'organizationId', nullable: false }, { name: 'processedAt', nullable: false }, { name: 'receivedAt', nullable: false }, { name: 'resolvedByUserId', nullable: false }, { name: 'sourceSystem', nullable: false }, { name: 'status', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createAccountingEventResponseOptionalProperties({ name: 'attemptCount', nullable: false }, { name: 'sequenceNumber', nullable: false });
    const optionalBooleanProperties = createAccountingEventResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountingEventResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountingEventResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountingEventResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAccountingEventSubmitRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountingEventSubmitRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountingEventSubmitRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountingEventSubmitRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountingEventSubmitRequestPropertyNames('eventType', 'organizationId', 'payload');
    const optionalStringProperties = createAccountingEventSubmitRequestOptionalProperties({ name: 'eventId', nullable: false }, { name: 'eventType', nullable: false }, { name: 'organizationId', nullable: false }, { name: 'sourceSystem', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createAccountingEventSubmitRequestOptionalProperties();
    const optionalBooleanProperties = createAccountingEventSubmitRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountingEventSubmitRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountingEventSubmitRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountingEventSubmitRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAccountingPeriodReopenRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountingPeriodReopenRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountingPeriodReopenRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountingPeriodReopenRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountingPeriodReopenRequestPropertyNames('justification');
    const optionalStringProperties = createAccountingPeriodReopenRequestOptionalProperties({ name: 'justification', nullable: false });
    const optionalNumberProperties = createAccountingPeriodReopenRequestOptionalProperties();
    const optionalBooleanProperties = createAccountingPeriodReopenRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountingPeriodReopenRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountingPeriodReopenRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountingPeriodReopenRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AccountingPeriodResponseStatusEnum;
(function (AccountingPeriodResponseStatusEnum) {
    AccountingPeriodResponseStatusEnum["Open"] = "OPEN";
    AccountingPeriodResponseStatusEnum["Closed"] = "CLOSED";
})(AccountingPeriodResponseStatusEnum || (AccountingPeriodResponseStatusEnum = {}));
;
function isOptionalAccountingPeriodResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountingPeriodResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountingPeriodResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountingPeriodResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountingPeriodResponsePropertyNames();
    const optionalStringProperties = createAccountingPeriodResponseOptionalProperties({ name: 'closedAt', nullable: false }, { name: 'closedBy', nullable: false }, { name: 'endDate', nullable: false }, { name: 'periodCode', nullable: false }, { name: 'periodId', nullable: false }, { name: 'reopenJustification', nullable: false }, { name: 'reopenedAt', nullable: false }, { name: 'reopenedBy', nullable: false }, { name: 'startDate', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createAccountingPeriodResponseOptionalProperties();
    const optionalBooleanProperties = createAccountingPeriodResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountingPeriodResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountingPeriodResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountingPeriodResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AdjustmentTypeResponseCodeEnum;
(function (AdjustmentTypeResponseCodeEnum) {
    AdjustmentTypeResponseCodeEnum["BankFee"] = "BANK_FEE";
    AdjustmentTypeResponseCodeEnum["NsfFee"] = "NSF_FEE";
    AdjustmentTypeResponseCodeEnum["InterestEarned"] = "INTEREST_EARNED";
    AdjustmentTypeResponseCodeEnum["Other"] = "OTHER";
})(AdjustmentTypeResponseCodeEnum || (AdjustmentTypeResponseCodeEnum = {}));
;
function isOptionalAdjustmentTypeResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAdjustmentTypeResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAdjustmentTypeResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAdjustmentTypeResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAdjustmentTypeResponsePropertyNames();
    const optionalStringProperties = createAdjustmentTypeResponseOptionalProperties({ name: 'code', nullable: false });
    const optionalNumberProperties = createAdjustmentTypeResponseOptionalProperties();
    const optionalBooleanProperties = createAdjustmentTypeResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAdjustmentTypeResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAdjustmentTypeResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAdjustmentTypeResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalAgedPayablesReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAgedPayablesReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAgedPayablesReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfAgedPayablesReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAgedPayablesReportPropertyNames('asOfDate', 'generatedAt', 'rows', 'totals');
    const optionalStringProperties = createAgedPayablesReportOptionalProperties({ name: 'asOfDate', nullable: false }, { name: 'generatedAt', nullable: false });
    const optionalNumberProperties = createAgedPayablesReportOptionalProperties();
    const optionalBooleanProperties = createAgedPayablesReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAgedPayablesReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAgedPayablesReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAgedPayablesReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAgedPayablesRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAgedPayablesRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAgedPayablesRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfAgedPayablesRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAgedPayablesRowPropertyNames('current', 'days31To60', 'days61To90', 'days90Plus', 'totalOutstanding', 'vendorId');
    const optionalStringProperties = createAgedPayablesRowOptionalProperties({ name: 'vendorId', nullable: false }, { name: 'vendorName', nullable: false });
    const optionalNumberProperties = createAgedPayablesRowOptionalProperties({ name: 'current', nullable: false }, { name: 'days31To60', nullable: false }, { name: 'days61To90', nullable: false }, { name: 'days90Plus', nullable: false }, { name: 'totalOutstanding', nullable: false });
    const optionalBooleanProperties = createAgedPayablesRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAgedPayablesRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAgedPayablesRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAgedPayablesRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalAgedReceivablesReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAgedReceivablesReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAgedReceivablesReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfAgedReceivablesReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAgedReceivablesReportPropertyNames('asOfDate', 'generatedAt', 'rows', 'totals');
    const optionalStringProperties = createAgedReceivablesReportOptionalProperties({ name: 'asOfDate', nullable: false }, { name: 'generatedAt', nullable: false });
    const optionalNumberProperties = createAgedReceivablesReportOptionalProperties();
    const optionalBooleanProperties = createAgedReceivablesReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAgedReceivablesReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAgedReceivablesReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAgedReceivablesReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAgedReceivablesRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAgedReceivablesRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAgedReceivablesRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfAgedReceivablesRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAgedReceivablesRowPropertyNames('current', 'customerId', 'days31To60', 'days61To90', 'days90Plus', 'totalOutstanding');
    const optionalStringProperties = createAgedReceivablesRowOptionalProperties({ name: 'customerId', nullable: false }, { name: 'customerName', nullable: false });
    const optionalNumberProperties = createAgedReceivablesRowOptionalProperties({ name: 'current', nullable: false }, { name: 'days31To60', nullable: false }, { name: 'days61To90', nullable: false }, { name: 'days90Plus', nullable: false }, { name: 'totalOutstanding', nullable: false });
    const optionalBooleanProperties = createAgedReceivablesRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAgedReceivablesRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAgedReceivablesRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAgedReceivablesRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAgingSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAgingSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAgingSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfAgingSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAgingSummaryPropertyNames('current', 'days31To60', 'days61To90', 'days90Plus', 'totalOutstanding');
    const optionalStringProperties = createAgingSummaryOptionalProperties();
    const optionalNumberProperties = createAgingSummaryOptionalProperties({ name: 'current', nullable: false }, { name: 'days31To60', nullable: false }, { name: 'days61To90', nullable: false }, { name: 'days90Plus', nullable: false }, { name: 'totalOutstanding', nullable: false });
    const optionalBooleanProperties = createAgingSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAgingSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAgingSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAgingSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAllocationLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAllocationLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAllocationLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAllocationLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAllocationLineRequestPropertyNames('appliedAmount', 'vendorBillId');
    const optionalStringProperties = createAllocationLineRequestOptionalProperties({ name: 'vendorBillId', nullable: false });
    const optionalNumberProperties = createAllocationLineRequestOptionalProperties({ name: 'appliedAmount', nullable: false });
    const optionalBooleanProperties = createAllocationLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAllocationLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAllocationLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAllocationLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAllocationLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAllocationLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAllocationLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAllocationLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAllocationLineResponsePropertyNames();
    const optionalStringProperties = createAllocationLineResponseOptionalProperties({ name: 'allocationId', nullable: false }, { name: 'vendorBillId', nullable: false });
    const optionalNumberProperties = createAllocationLineResponseOptionalProperties({ name: 'allocationSequence', nullable: false }, { name: 'appliedAmount', nullable: false });
    const optionalBooleanProperties = createAllocationLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAllocationLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAllocationLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAllocationLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ApplicationDetailInvoiceStatusEnum;
(function (ApplicationDetailInvoiceStatusEnum) {
    ApplicationDetailInvoiceStatusEnum["Open"] = "OPEN";
    ApplicationDetailInvoiceStatusEnum["PartiallyPaid"] = "PARTIALLY_PAID";
    ApplicationDetailInvoiceStatusEnum["PaidInFull"] = "PAID_IN_FULL";
    ApplicationDetailInvoiceStatusEnum["Voided"] = "VOIDED";
    ApplicationDetailInvoiceStatusEnum["Cancelled"] = "CANCELLED";
    ApplicationDetailInvoiceStatusEnum["Unknown"] = "UNKNOWN";
})(ApplicationDetailInvoiceStatusEnum || (ApplicationDetailInvoiceStatusEnum = {}));
;
function isOptionalApplicationDetailPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApplicationDetailPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApplicationDetailOptionalProperties(...properties) {
    return properties;
}
function instanceOfApplicationDetail(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApplicationDetailPropertyNames();
    const optionalStringProperties = createApplicationDetailOptionalProperties({ name: 'invoiceId', nullable: false }, { name: 'invoiceStatus', nullable: false }, { name: 'paymentApplicationId', nullable: false });
    const optionalNumberProperties = createApplicationDetailOptionalProperties({ name: 'appliedAmount', nullable: false }, { name: 'invoiceBalanceAfter', nullable: false }, { name: 'invoiceBalanceBefore', nullable: false });
    const optionalBooleanProperties = createApplicationDetailOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApplicationDetailPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApplicationDetailPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApplicationDetailPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AuditTrailResponseAccountingIntentEnum;
(function (AuditTrailResponseAccountingIntentEnum) {
    AuditTrailResponseAccountingIntentEnum["RevenueAdjustment"] = "REVENUE_ADJUSTMENT";
    AuditTrailResponseAccountingIntentEnum["PaymentReversal"] = "PAYMENT_REVERSAL";
    AuditTrailResponseAccountingIntentEnum["CustomerCredit"] = "CUSTOMER_CREDIT";
    AuditTrailResponseAccountingIntentEnum["WriteOff"] = "WRITE_OFF";
    AuditTrailResponseAccountingIntentEnum["RevenueReversal"] = "REVENUE_REVERSAL";
    AuditTrailResponseAccountingIntentEnum["PaymentRecovery"] = "PAYMENT_RECOVERY";
})(AuditTrailResponseAccountingIntentEnum || (AuditTrailResponseAccountingIntentEnum = {}));
;
var AuditTrailResponseAccountingStatusEnum;
(function (AuditTrailResponseAccountingStatusEnum) {
    AuditTrailResponseAccountingStatusEnum["PendingPosting"] = "PENDING_POSTING";
    AuditTrailResponseAccountingStatusEnum["Posted"] = "POSTED";
    AuditTrailResponseAccountingStatusEnum["Reconciled"] = "RECONCILED";
    AuditTrailResponseAccountingStatusEnum["Rejected"] = "REJECTED";
    AuditTrailResponseAccountingStatusEnum["Reversed"] = "REVERSED";
    AuditTrailResponseAccountingStatusEnum["Voided"] = "VOIDED";
    AuditTrailResponseAccountingStatusEnum["OnHold"] = "ON_HOLD";
    AuditTrailResponseAccountingStatusEnum["Disputed"] = "DISPUTED";
})(AuditTrailResponseAccountingStatusEnum || (AuditTrailResponseAccountingStatusEnum = {}));
;
var AuditTrailResponseCancellationTypeEnum;
(function (AuditTrailResponseCancellationTypeEnum) {
    AuditTrailResponseCancellationTypeEnum["OrderCancelled"] = "ORDER_CANCELLED";
    AuditTrailResponseCancellationTypeEnum["InvoiceCancelled"] = "INVOICE_CANCELLED";
    AuditTrailResponseCancellationTypeEnum["PaymentFailed"] = "PAYMENT_FAILED";
})(AuditTrailResponseCancellationTypeEnum || (AuditTrailResponseCancellationTypeEnum = {}));
;
var AuditTrailResponseExceptionTypeEnum;
(function (AuditTrailResponseExceptionTypeEnum) {
    AuditTrailResponseExceptionTypeEnum["PriceOverride"] = "PRICE_OVERRIDE";
    AuditTrailResponseExceptionTypeEnum["Refund"] = "REFUND";
    AuditTrailResponseExceptionTypeEnum["Cancellation"] = "CANCELLATION";
})(AuditTrailResponseExceptionTypeEnum || (AuditTrailResponseExceptionTypeEnum = {}));
;
var AuditTrailResponseOriginalPaymentStatusEnum;
(function (AuditTrailResponseOriginalPaymentStatusEnum) {
    AuditTrailResponseOriginalPaymentStatusEnum["Pending"] = "PENDING";
    AuditTrailResponseOriginalPaymentStatusEnum["Settled"] = "SETTLED";
    AuditTrailResponseOriginalPaymentStatusEnum["Failed"] = "FAILED";
    AuditTrailResponseOriginalPaymentStatusEnum["Authorized"] = "AUTHORIZED";
})(AuditTrailResponseOriginalPaymentStatusEnum || (AuditTrailResponseOriginalPaymentStatusEnum = {}));
;
var AuditTrailResponsePolicyValidationResultEnum;
(function (AuditTrailResponsePolicyValidationResultEnum) {
    AuditTrailResponsePolicyValidationResultEnum["Approved"] = "APPROVED";
    AuditTrailResponsePolicyValidationResultEnum["RejectedForbidden"] = "REJECTED_FORBIDDEN";
    AuditTrailResponsePolicyValidationResultEnum["RejectedThresholdExceeded"] = "REJECTED_THRESHOLD_EXCEEDED";
})(AuditTrailResponsePolicyValidationResultEnum || (AuditTrailResponsePolicyValidationResultEnum = {}));
;
var AuditTrailResponseRefundMethodEnum;
(function (AuditTrailResponseRefundMethodEnum) {
    AuditTrailResponseRefundMethodEnum["Void"] = "VOID";
    AuditTrailResponseRefundMethodEnum["Chargeback"] = "CHARGEBACK";
    AuditTrailResponseRefundMethodEnum["CashRefund"] = "CASH_REFUND";
    AuditTrailResponseRefundMethodEnum["CreditMemo"] = "CREDIT_MEMO";
})(AuditTrailResponseRefundMethodEnum || (AuditTrailResponseRefundMethodEnum = {}));
;
var AuditTrailResponseRefundTypeEnum;
(function (AuditTrailResponseRefundTypeEnum) {
    AuditTrailResponseRefundTypeEnum["Reversal"] = "REVERSAL";
    AuditTrailResponseRefundTypeEnum["CreditMemo"] = "CREDIT_MEMO";
    AuditTrailResponseRefundTypeEnum["Adjustment"] = "ADJUSTMENT";
})(AuditTrailResponseRefundTypeEnum || (AuditTrailResponseRefundTypeEnum = {}));
;
function isOptionalAuditTrailResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditTrailResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditTrailResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditTrailResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditTrailResponsePropertyNames('auditId', 'exceptionType', 'timestamp');
    const optionalStringProperties = createAuditTrailResponseOptionalProperties({ name: 'accountingIntent', nullable: false }, { name: 'accountingStatus', nullable: false }, { name: 'actorId', nullable: false }, { name: 'actorRole', nullable: false }, { name: 'afterSnapshot', nullable: false }, { name: 'auditId', nullable: false }, { name: 'authorizationLevel', nullable: false }, { name: 'beforeSnapshot', nullable: false }, { name: 'cancellationType', nullable: false }, { name: 'exceptionType', nullable: false }, { name: 'expectedAccountingOutcome', nullable: false }, { name: 'forbiddenCategoryCode', nullable: false }, { name: 'glReversalStatus', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'lineItemId', nullable: false }, { name: 'linkedSourceIds', nullable: false }, { name: 'orderId', nullable: false }, { name: 'originalPaymentStatus', nullable: false }, { name: 'overrideAmountOrPercent', nullable: false }, { name: 'partialPaymentInfo', nullable: false }, { name: 'paymentId', nullable: false }, { name: 'policyValidationResult', nullable: false }, { name: 'policyVersion', nullable: false }, { name: 'reason', nullable: false }, { name: 'refundMethod', nullable: false }, { name: 'refundType', nullable: false }, { name: 'sourceDocumentId', nullable: false }, { name: 'sourceEventId', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createAuditTrailResponseOptionalProperties({ name: 'adjustedPrice', nullable: false }, { name: 'originalPrice', nullable: false }, { name: 'refundAmount', nullable: false });
    const optionalBooleanProperties = createAuditTrailResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditTrailResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditTrailResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditTrailResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBalanceSheetReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBalanceSheetReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBalanceSheetReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfBalanceSheetReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBalanceSheetReportPropertyNames('asOfDate', 'balanced', 'generatedAt', 'lineItems', 'totalAssets', 'totalEquity', 'totalLiabilities');
    const optionalStringProperties = createBalanceSheetReportOptionalProperties({ name: 'asOfDate', nullable: false }, { name: 'generatedAt', nullable: false });
    const optionalNumberProperties = createBalanceSheetReportOptionalProperties({ name: 'totalAssets', nullable: false }, { name: 'totalEquity', nullable: false }, { name: 'totalLiabilities', nullable: false });
    const optionalBooleanProperties = createBalanceSheetReportOptionalProperties({ name: 'balanced', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBalanceSheetReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBalanceSheetReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBalanceSheetReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BankReconciliationAdjustmentResponseTypeEnum;
(function (BankReconciliationAdjustmentResponseTypeEnum) {
    BankReconciliationAdjustmentResponseTypeEnum["BankFee"] = "BANK_FEE";
    BankReconciliationAdjustmentResponseTypeEnum["NsfFee"] = "NSF_FEE";
    BankReconciliationAdjustmentResponseTypeEnum["InterestEarned"] = "INTEREST_EARNED";
    BankReconciliationAdjustmentResponseTypeEnum["Other"] = "OTHER";
})(BankReconciliationAdjustmentResponseTypeEnum || (BankReconciliationAdjustmentResponseTypeEnum = {}));
;
function isOptionalBankReconciliationAdjustmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBankReconciliationAdjustmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBankReconciliationAdjustmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBankReconciliationAdjustmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBankReconciliationAdjustmentResponsePropertyNames();
    const optionalStringProperties = createBankReconciliationAdjustmentResponseOptionalProperties({ name: 'adjustmentId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'journalEntryId', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createBankReconciliationAdjustmentResponseOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createBankReconciliationAdjustmentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBankReconciliationAdjustmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBankReconciliationAdjustmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBankReconciliationAdjustmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBankReconciliationImportRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBankReconciliationImportRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBankReconciliationImportRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfBankReconciliationImportRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBankReconciliationImportRequestPropertyNames('csv', 'currency', 'glAccountId', 'periodEndDate', 'periodStartDate', 'statementDate', 'statementEndingBalance');
    const optionalStringProperties = createBankReconciliationImportRequestOptionalProperties({ name: 'csv', nullable: false }, { name: 'currency', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'periodEndDate', nullable: false }, { name: 'periodStartDate', nullable: false }, { name: 'statementDate', nullable: false });
    const optionalNumberProperties = createBankReconciliationImportRequestOptionalProperties({ name: 'statementEndingBalance', nullable: false });
    const optionalBooleanProperties = createBankReconciliationImportRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBankReconciliationImportRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBankReconciliationImportRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBankReconciliationImportRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BankReconciliationLineResponseStatusEnum;
(function (BankReconciliationLineResponseStatusEnum) {
    BankReconciliationLineResponseStatusEnum["Unmatched"] = "UNMATCHED";
    BankReconciliationLineResponseStatusEnum["Matched"] = "MATCHED";
})(BankReconciliationLineResponseStatusEnum || (BankReconciliationLineResponseStatusEnum = {}));
;
function isOptionalBankReconciliationLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBankReconciliationLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBankReconciliationLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBankReconciliationLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBankReconciliationLineResponsePropertyNames();
    const optionalStringProperties = createBankReconciliationLineResponseOptionalProperties({ name: 'description', nullable: false }, { name: 'lineDate', nullable: false }, { name: 'lineId', nullable: false }, { name: 'matchId', nullable: false }, { name: 'reference', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createBankReconciliationLineResponseOptionalProperties({ name: 'amount', nullable: false }, { name: 'lineNumber', nullable: false });
    const optionalBooleanProperties = createBankReconciliationLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBankReconciliationLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBankReconciliationLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBankReconciliationLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBankReconciliationListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBankReconciliationListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBankReconciliationListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBankReconciliationListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBankReconciliationListResponsePropertyNames('pageNumber', 'pageSize', 'reconciliations', 'totalElements', 'totalPages');
    const optionalStringProperties = createBankReconciliationListResponseOptionalProperties();
    const optionalNumberProperties = createBankReconciliationListResponseOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createBankReconciliationListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBankReconciliationListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBankReconciliationListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBankReconciliationListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var BankReconciliationResponseStatusEnum;
(function (BankReconciliationResponseStatusEnum) {
    BankReconciliationResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    BankReconciliationResponseStatusEnum["Finalized"] = "FINALIZED";
    BankReconciliationResponseStatusEnum["Cancelled"] = "CANCELLED";
})(BankReconciliationResponseStatusEnum || (BankReconciliationResponseStatusEnum = {}));
;
function isOptionalBankReconciliationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBankReconciliationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBankReconciliationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBankReconciliationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBankReconciliationResponsePropertyNames();
    const optionalStringProperties = createBankReconciliationResponseOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'currency', nullable: false }, { name: 'finalizedAt', nullable: false }, { name: 'finalizedBy', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'periodEndDate', nullable: false }, { name: 'periodStartDate', nullable: false }, { name: 'reconciliationId', nullable: false }, { name: 'statementDate', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createBankReconciliationResponseOptionalProperties({ name: 'difference', nullable: false }, { name: 'glEndingBalance', nullable: false }, { name: 'statementEndingBalance', nullable: false });
    const optionalBooleanProperties = createBankReconciliationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBankReconciliationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBankReconciliationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBankReconciliationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBillingRuleRefResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingRuleRefResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingRuleRefResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingRuleRefResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingRuleRefResponsePropertyNames('autoPayEnabled', 'creditHold', 'poRequired', 'taxExempt');
    const optionalStringProperties = createBillingRuleRefResponseOptionalProperties({ name: 'billingAddressId', nullable: false }, { name: 'currency', nullable: false }, { name: 'discountPolicyRef', nullable: false }, { name: 'invoiceDeliveryMethod', nullable: false }, { name: 'paymentTerms', nullable: false });
    const optionalNumberProperties = createBillingRuleRefResponseOptionalProperties({ name: 'creditLimit', nullable: false });
    const optionalBooleanProperties = createBillingRuleRefResponseOptionalProperties({ name: 'autoPayEnabled', nullable: false }, { name: 'creditHold', nullable: false }, { name: 'poRequired', nullable: false }, { name: 'taxExempt', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingRuleRefResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingRuleRefResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingRuleRefResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CancellationRequestCancellationTypeEnum;
(function (CancellationRequestCancellationTypeEnum) {
    CancellationRequestCancellationTypeEnum["OrderCancelled"] = "ORDER_CANCELLED";
    CancellationRequestCancellationTypeEnum["InvoiceCancelled"] = "INVOICE_CANCELLED";
    CancellationRequestCancellationTypeEnum["PaymentFailed"] = "PAYMENT_FAILED";
})(CancellationRequestCancellationTypeEnum || (CancellationRequestCancellationTypeEnum = {}));
;
function isOptionalCancellationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCancellationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCancellationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCancellationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCancellationRequestPropertyNames('actorRole', 'afterSnapshot', 'beforeSnapshot', 'cancellationType', 'reason');
    const optionalStringProperties = createCancellationRequestOptionalProperties({ name: 'actorId', nullable: false }, { name: 'actorRole', nullable: false }, { name: 'afterSnapshot', nullable: false }, { name: 'beforeSnapshot', nullable: false }, { name: 'cancellationType', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'orderId', nullable: false }, { name: 'partialPaymentInfo', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createCancellationRequestOptionalProperties();
    const optionalBooleanProperties = createCancellationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCancellationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCancellationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCancellationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCandidateSelectionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCandidateSelectionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCandidateSelectionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCandidateSelectionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCandidateSelectionRequestPropertyNames('operatorId');
    const optionalStringProperties = createCandidateSelectionRequestOptionalProperties({ name: 'operatorId', nullable: false });
    const optionalNumberProperties = createCandidateSelectionRequestOptionalProperties();
    const optionalBooleanProperties = createCandidateSelectionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCandidateSelectionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCandidateSelectionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCandidateSelectionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCollectionsAnalyticsReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCollectionsAnalyticsReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCollectionsAnalyticsReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfCollectionsAnalyticsReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCollectionsAnalyticsReportPropertyNames('applicationReversals', 'collected', 'endDate', 'generatedAt', 'invoiced', 'startDate');
    const optionalStringProperties = createCollectionsAnalyticsReportOptionalProperties({ name: 'endDate', nullable: false }, { name: 'generatedAt', nullable: false }, { name: 'startDate', nullable: false });
    const optionalNumberProperties = createCollectionsAnalyticsReportOptionalProperties({ name: 'applicationReversals', nullable: false }, { name: 'collected', nullable: false }, { name: 'collectionRatePct', nullable: true }, { name: 'invoiced', nullable: false });
    const optionalBooleanProperties = createCollectionsAnalyticsReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCollectionsAnalyticsReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCollectionsAnalyticsReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCollectionsAnalyticsReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalContractFieldPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContractFieldPropertyNames(...propertyNames) {
    return propertyNames;
}
function createContractFieldOptionalProperties(...properties) {
    return properties;
}
function instanceOfContractField(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContractFieldPropertyNames('jsonPath', 'name', 'required', 'type');
    const optionalStringProperties = createContractFieldOptionalProperties({ name: 'description', nullable: false }, { name: 'jsonPath', nullable: false }, { name: 'name', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createContractFieldOptionalProperties();
    const optionalBooleanProperties = createContractFieldOptionalProperties({ name: 'required', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContractFieldPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContractFieldPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContractFieldPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateCreditMemoRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateCreditMemoRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateCreditMemoRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateCreditMemoRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateCreditMemoRequestPropertyNames('creditAmount', 'originalInvoiceId', 'reasonCode');
    const optionalStringProperties = createCreateCreditMemoRequestOptionalProperties({ name: 'justificationNote', nullable: false }, { name: 'originalInvoiceId', nullable: false }, { name: 'reasonCode', nullable: false });
    const optionalNumberProperties = createCreateCreditMemoRequestOptionalProperties({ name: 'creditAmount', nullable: false });
    const optionalBooleanProperties = createCreateCreditMemoRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateCreditMemoRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateCreditMemoRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateCreditMemoRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreditMemoResponseStatusEnum;
(function (CreditMemoResponseStatusEnum) {
    CreditMemoResponseStatusEnum["Draft"] = "DRAFT";
    CreditMemoResponseStatusEnum["Posted"] = "POSTED";
    CreditMemoResponseStatusEnum["Applied"] = "APPLIED";
    CreditMemoResponseStatusEnum["Voided"] = "VOIDED";
})(CreditMemoResponseStatusEnum || (CreditMemoResponseStatusEnum = {}));
;
function isOptionalCreditMemoResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreditMemoResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreditMemoResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreditMemoResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreditMemoResponsePropertyNames('creationTimestamp', 'creditAmount', 'creditMemoId', 'originalInvoiceId', 'status');
    const optionalStringProperties = createCreditMemoResponseOptionalProperties({ name: 'createdByUserId', nullable: false }, { name: 'creationTimestamp', nullable: false }, { name: 'creditMemoId', nullable: false }, { name: 'currency', nullable: false }, { name: 'customerId', nullable: false }, { name: 'justificationNote', nullable: false }, { name: 'originalInvoiceId', nullable: false }, { name: 'originalPeriodId', nullable: false }, { name: 'postedTimestamp', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'status', nullable: false }, { name: 'voidReason', nullable: false }, { name: 'voidedByUserId', nullable: false }, { name: 'voidedTimestamp', nullable: false });
    const optionalNumberProperties = createCreditMemoResponseOptionalProperties({ name: 'creditAmount', nullable: false }, { name: 'invoiceBalanceAfter', nullable: false }, { name: 'taxAmountReversed', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createCreditMemoResponseOptionalProperties({ name: 'priorPeriodAdjustment', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreditMemoResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreditMemoResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreditMemoResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCustomerCreditApplicationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerCreditApplicationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerCreditApplicationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerCreditApplicationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerCreditApplicationRequestPropertyNames('amount', 'invoiceId', 'requestId');
    const optionalStringProperties = createCustomerCreditApplicationRequestOptionalProperties({ name: 'invoiceId', nullable: false }, { name: 'requestId', nullable: false });
    const optionalNumberProperties = createCustomerCreditApplicationRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createCustomerCreditApplicationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerCreditApplicationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerCreditApplicationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerCreditApplicationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCustomerCreditInfoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerCreditInfoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerCreditInfoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerCreditInfo(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerCreditInfoPropertyNames();
    const optionalStringProperties = createCustomerCreditInfoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'creditId', nullable: false });
    const optionalNumberProperties = createCustomerCreditInfoOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createCustomerCreditInfoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerCreditInfoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerCreditInfoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerCreditInfoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCustomerCreditRefundRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerCreditRefundRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerCreditRefundRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerCreditRefundRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerCreditRefundRequestPropertyNames('amount', 'requestId');
    const optionalStringProperties = createCustomerCreditRefundRequestOptionalProperties({ name: 'note', nullable: false }, { name: 'requestId', nullable: false });
    const optionalNumberProperties = createCustomerCreditRefundRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createCustomerCreditRefundRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerCreditRefundRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerCreditRefundRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerCreditRefundRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CustomerCreditResponseStatusEnum;
(function (CustomerCreditResponseStatusEnum) {
    CustomerCreditResponseStatusEnum["Available"] = "AVAILABLE";
    CustomerCreditResponseStatusEnum["PartiallyConsumed"] = "PARTIALLY_CONSUMED";
    CustomerCreditResponseStatusEnum["Consumed"] = "CONSUMED";
})(CustomerCreditResponseStatusEnum || (CustomerCreditResponseStatusEnum = {}));
;
function isOptionalCustomerCreditResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerCreditResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerCreditResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerCreditResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerCreditResponsePropertyNames();
    const optionalStringProperties = createCustomerCreditResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'creditId', nullable: false }, { name: 'currency', nullable: false }, { name: 'customerId', nullable: false }, { name: 'sourcePaymentId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createCustomerCreditResponseOptionalProperties({ name: 'amount', nullable: false }, { name: 'appliedAmount', nullable: false }, { name: 'openAmount', nullable: false }, { name: 'refundedAmount', nullable: false });
    const optionalBooleanProperties = createCustomerCreditResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerCreditResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerCreditResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerCreditResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CustomerCreditTransactionResponseTransactionTypeEnum;
(function (CustomerCreditTransactionResponseTransactionTypeEnum) {
    CustomerCreditTransactionResponseTransactionTypeEnum["Application"] = "APPLICATION";
    CustomerCreditTransactionResponseTransactionTypeEnum["Refund"] = "REFUND";
})(CustomerCreditTransactionResponseTransactionTypeEnum || (CustomerCreditTransactionResponseTransactionTypeEnum = {}));
;
function isOptionalCustomerCreditTransactionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerCreditTransactionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerCreditTransactionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerCreditTransactionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerCreditTransactionResponsePropertyNames();
    const optionalStringProperties = createCustomerCreditTransactionResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'creditId', nullable: false }, { name: 'creditTransactionId', nullable: false }, { name: 'currency', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'requestId', nullable: false }, { name: 'transactionType', nullable: false });
    const optionalNumberProperties = createCustomerCreditTransactionResponseOptionalProperties({ name: 'amount', nullable: false }, { name: 'creditOpenAmountAfter', nullable: false }, { name: 'invoiceBalanceAfter', nullable: false });
    const optionalBooleanProperties = createCustomerCreditTransactionResponseOptionalProperties({ name: 'replayed', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerCreditTransactionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerCreditTransactionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerCreditTransactionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalDefaultGLMappingListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDefaultGLMappingListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createDefaultGLMappingListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfDefaultGLMappingListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDefaultGLMappingListResponsePropertyNames('mappings', 'page', 'size', 'totalElements', 'totalPages');
    const optionalStringProperties = createDefaultGLMappingListResponseOptionalProperties();
    const optionalNumberProperties = createDefaultGLMappingListResponseOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createDefaultGLMappingListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDefaultGLMappingListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDefaultGLMappingListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDefaultGLMappingListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalDefaultGLMappingRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDefaultGLMappingRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDefaultGLMappingRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfDefaultGLMappingRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDefaultGLMappingRequestPropertyNames('creditAccountId', 'debitAccountId', 'eventType');
    const optionalStringProperties = createDefaultGLMappingRequestOptionalProperties({ name: 'creditAccountId', nullable: false }, { name: 'debitAccountId', nullable: false }, { name: 'description', nullable: false }, { name: 'eventType', nullable: false }, { name: 'organizationId', nullable: false });
    const optionalNumberProperties = createDefaultGLMappingRequestOptionalProperties();
    const optionalBooleanProperties = createDefaultGLMappingRequestOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDefaultGLMappingRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDefaultGLMappingRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDefaultGLMappingRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalDefaultGLMappingResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDefaultGLMappingResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createDefaultGLMappingResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfDefaultGLMappingResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDefaultGLMappingResponsePropertyNames('creditAccountId', 'debitAccountId', 'eventType', 'mappingId');
    const optionalStringProperties = createDefaultGLMappingResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'creditAccountCode', nullable: false }, { name: 'creditAccountId', nullable: false }, { name: 'creditAccountName', nullable: false }, { name: 'debitAccountCode', nullable: false }, { name: 'debitAccountId', nullable: false }, { name: 'debitAccountName', nullable: false }, { name: 'description', nullable: false }, { name: 'eventType', nullable: false }, { name: 'mappingId', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'organizationId', nullable: false });
    const optionalNumberProperties = createDefaultGLMappingResponseOptionalProperties();
    const optionalBooleanProperties = createDefaultGLMappingResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDefaultGLMappingResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDefaultGLMappingResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDefaultGLMappingResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEntryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEntryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEntryOptionalProperties(...properties) {
    return properties;
}
function instanceOfEntry(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEntryPropertyNames();
    const optionalStringProperties = createEntryOptionalProperties({ name: 'action', nullable: false }, { name: 'at', nullable: false }, { name: 'by', nullable: false }, { name: 'detail', nullable: false });
    const optionalNumberProperties = createEntryOptionalProperties();
    const optionalBooleanProperties = createEntryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEntryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEntryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEntryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEntryNumberGapCheckPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEntryNumberGapCheckPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEntryNumberGapCheckOptionalProperties(...properties) {
    return properties;
}
function instanceOfEntryNumberGapCheck(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEntryNumberGapCheckPropertyNames('missingNumbers', 'scopeKey');
    const optionalStringProperties = createEntryNumberGapCheckOptionalProperties({ name: 'scopeKey', nullable: false });
    const optionalNumberProperties = createEntryNumberGapCheckOptionalProperties();
    const optionalBooleanProperties = createEntryNumberGapCheckOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEntryNumberGapCheckPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEntryNumberGapCheckPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEntryNumberGapCheckPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalEventEnvelopeContractPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEventEnvelopeContractPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEventEnvelopeContractOptionalProperties(...properties) {
    return properties;
}
function instanceOfEventEnvelopeContract(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEventEnvelopeContractPropertyNames('fields', 'version');
    const optionalStringProperties = createEventEnvelopeContractOptionalProperties({ name: 'version', nullable: false });
    const optionalNumberProperties = createEventEnvelopeContractOptionalProperties();
    const optionalBooleanProperties = createEventEnvelopeContractOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEventEnvelopeContractPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEventEnvelopeContractPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEventEnvelopeContractPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEventProcessingLogEntryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEventProcessingLogEntryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEventProcessingLogEntryOptionalProperties(...properties) {
    return properties;
}
function instanceOfEventProcessingLogEntry(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEventProcessingLogEntryPropertyNames('entryId', 'message', 'occurredAt', 'severity');
    const optionalStringProperties = createEventProcessingLogEntryOptionalProperties({ name: 'contextJson', nullable: true }, { name: 'entryId', nullable: false }, { name: 'message', nullable: false }, { name: 'occurredAt', nullable: false }, { name: 'severity', nullable: false });
    const optionalNumberProperties = createEventProcessingLogEntryOptionalProperties();
    const optionalBooleanProperties = createEventProcessingLogEntryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEventProcessingLogEntryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEventProcessingLogEntryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEventProcessingLogEntryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ExceptionResolutionRequestResolutionActionEnum;
(function (ExceptionResolutionRequestResolutionActionEnum) {
    ExceptionResolutionRequestResolutionActionEnum["Accept"] = "ACCEPT";
    ExceptionResolutionRequestResolutionActionEnum["Void"] = "VOID";
    ExceptionResolutionRequestResolutionActionEnum["Correct"] = "CORRECT";
})(ExceptionResolutionRequestResolutionActionEnum || (ExceptionResolutionRequestResolutionActionEnum = {}));
;
function isOptionalExceptionResolutionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExceptionResolutionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createExceptionResolutionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfExceptionResolutionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExceptionResolutionRequestPropertyNames('operatorId', 'reason', 'resolutionAction');
    const optionalStringProperties = createExceptionResolutionRequestOptionalProperties({ name: 'operatorId', nullable: false }, { name: 'reason', nullable: false }, { name: 'resolutionAction', nullable: false });
    const optionalNumberProperties = createExceptionResolutionRequestOptionalProperties();
    const optionalBooleanProperties = createExceptionResolutionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExceptionResolutionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExceptionResolutionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExceptionResolutionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ExecuteAPPaymentRequestPaymentMethodEnum;
(function (ExecuteAPPaymentRequestPaymentMethodEnum) {
    ExecuteAPPaymentRequestPaymentMethodEnum["Ach"] = "ACH";
    ExecuteAPPaymentRequestPaymentMethodEnum["Check"] = "CHECK";
    ExecuteAPPaymentRequestPaymentMethodEnum["Wire"] = "WIRE";
    ExecuteAPPaymentRequestPaymentMethodEnum["CreditCard"] = "CREDIT_CARD";
    ExecuteAPPaymentRequestPaymentMethodEnum["Other"] = "OTHER";
})(ExecuteAPPaymentRequestPaymentMethodEnum || (ExecuteAPPaymentRequestPaymentMethodEnum = {}));
;
function isOptionalExecuteAPPaymentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExecuteAPPaymentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createExecuteAPPaymentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfExecuteAPPaymentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExecuteAPPaymentRequestPropertyNames('currency', 'grossAmount', 'paymentMethod', 'paymentRef', 'vendorId');
    const optionalStringProperties = createExecuteAPPaymentRequestOptionalProperties({ name: 'currency', nullable: false }, { name: 'memo', nullable: false }, { name: 'paymentMethod', nullable: false }, { name: 'paymentRef', nullable: false }, { name: 'paymentSource', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createExecuteAPPaymentRequestOptionalProperties({ name: 'feeAmount', nullable: false }, { name: 'grossAmount', nullable: false }, { name: 'netAmount', nullable: false });
    const optionalBooleanProperties = createExecuteAPPaymentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExecuteAPPaymentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExecuteAPPaymentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExecuteAPPaymentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalExportJobRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExportJobRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createExportJobRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfExportJobRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExportJobRequestPropertyNames('exportType', 'format');
    const optionalStringProperties = createExportJobRequestOptionalProperties({ name: 'deliveryMode', nullable: false }, { name: 'exportType', nullable: false }, { name: 'format', nullable: false });
    const optionalNumberProperties = createExportJobRequestOptionalProperties();
    const optionalBooleanProperties = createExportJobRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExportJobRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExportJobRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExportJobRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalExportJobResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createExportJobResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createExportJobResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfExportJobResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createExportJobResponsePropertyNames('jobId', 'requestedAt', 'status');
    const optionalStringProperties = createExportJobResponseOptionalProperties({ name: 'completedAt', nullable: true }, { name: 'downloadUrl', nullable: true }, { name: 'errorMessage', nullable: true }, { name: 'jobId', nullable: false }, { name: 'requestedAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createExportJobResponseOptionalProperties();
    const optionalBooleanProperties = createExportJobResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalExportJobResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalExportJobResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalExportJobResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGLAccountActivateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLAccountActivateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLAccountActivateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLAccountActivateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLAccountActivateRequestPropertyNames('effectiveDate');
    const optionalStringProperties = createGLAccountActivateRequestOptionalProperties({ name: 'effectiveDate', nullable: false });
    const optionalNumberProperties = createGLAccountActivateRequestOptionalProperties();
    const optionalBooleanProperties = createGLAccountActivateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLAccountActivateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLAccountActivateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLAccountActivateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGLAccountBalanceResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLAccountBalanceResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLAccountBalanceResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLAccountBalanceResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLAccountBalanceResponsePropertyNames('asOfDate', 'balance', 'glAccountId');
    const optionalStringProperties = createGLAccountBalanceResponseOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'asOfDate', nullable: false }, { name: 'glAccountId', nullable: false });
    const optionalNumberProperties = createGLAccountBalanceResponseOptionalProperties({ name: 'balance', nullable: false });
    const optionalBooleanProperties = createGLAccountBalanceResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLAccountBalanceResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLAccountBalanceResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLAccountBalanceResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var GLAccountCreateRequestAccountSubtypeEnum;
(function (GLAccountCreateRequestAccountSubtypeEnum) {
    GLAccountCreateRequestAccountSubtypeEnum["Receivable"] = "RECEIVABLE";
    GLAccountCreateRequestAccountSubtypeEnum["Payable"] = "PAYABLE";
    GLAccountCreateRequestAccountSubtypeEnum["BankCash"] = "BANK_CASH";
    GLAccountCreateRequestAccountSubtypeEnum["UndepositedFunds"] = "UNDEPOSITED_FUNDS";
    GLAccountCreateRequestAccountSubtypeEnum["TaxPayable"] = "TAX_PAYABLE";
    GLAccountCreateRequestAccountSubtypeEnum["CurrentAsset"] = "CURRENT_ASSET";
    GLAccountCreateRequestAccountSubtypeEnum["FixedAsset"] = "FIXED_ASSET";
    GLAccountCreateRequestAccountSubtypeEnum["CurrentLiability"] = "CURRENT_LIABILITY";
    GLAccountCreateRequestAccountSubtypeEnum["Sales"] = "SALES";
    GLAccountCreateRequestAccountSubtypeEnum["CostOfSales"] = "COST_OF_SALES";
    GLAccountCreateRequestAccountSubtypeEnum["OperatingExpense"] = "OPERATING_EXPENSE";
    GLAccountCreateRequestAccountSubtypeEnum["Other"] = "OTHER";
})(GLAccountCreateRequestAccountSubtypeEnum || (GLAccountCreateRequestAccountSubtypeEnum = {}));
;
var GLAccountCreateRequestAccountTypeEnum;
(function (GLAccountCreateRequestAccountTypeEnum) {
    GLAccountCreateRequestAccountTypeEnum["Asset"] = "ASSET";
    GLAccountCreateRequestAccountTypeEnum["Liability"] = "LIABILITY";
    GLAccountCreateRequestAccountTypeEnum["Equity"] = "EQUITY";
    GLAccountCreateRequestAccountTypeEnum["Revenue"] = "REVENUE";
    GLAccountCreateRequestAccountTypeEnum["Expense"] = "EXPENSE";
})(GLAccountCreateRequestAccountTypeEnum || (GLAccountCreateRequestAccountTypeEnum = {}));
;
function isOptionalGLAccountCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLAccountCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLAccountCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLAccountCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLAccountCreateRequestPropertyNames('accountCode', 'accountName', 'accountType', 'activationDate');
    const optionalStringProperties = createGLAccountCreateRequestOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'accountSubtype', nullable: false }, { name: 'accountType', nullable: false }, { name: 'activationDate', nullable: false }, { name: 'description', nullable: false }, { name: 'parentAccountId', nullable: false });
    const optionalNumberProperties = createGLAccountCreateRequestOptionalProperties();
    const optionalBooleanProperties = createGLAccountCreateRequestOptionalProperties({ name: 'reconcilable', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLAccountCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLAccountCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLAccountCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGLAccountListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLAccountListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLAccountListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLAccountListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLAccountListResponsePropertyNames('glAccounts', 'pageNumber', 'pageSize', 'totalElements', 'totalPages');
    const optionalStringProperties = createGLAccountListResponseOptionalProperties();
    const optionalNumberProperties = createGLAccountListResponseOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createGLAccountListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLAccountListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLAccountListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLAccountListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var GLAccountResponseAccountSubtypeEnum;
(function (GLAccountResponseAccountSubtypeEnum) {
    GLAccountResponseAccountSubtypeEnum["Receivable"] = "RECEIVABLE";
    GLAccountResponseAccountSubtypeEnum["Payable"] = "PAYABLE";
    GLAccountResponseAccountSubtypeEnum["BankCash"] = "BANK_CASH";
    GLAccountResponseAccountSubtypeEnum["UndepositedFunds"] = "UNDEPOSITED_FUNDS";
    GLAccountResponseAccountSubtypeEnum["TaxPayable"] = "TAX_PAYABLE";
    GLAccountResponseAccountSubtypeEnum["CurrentAsset"] = "CURRENT_ASSET";
    GLAccountResponseAccountSubtypeEnum["FixedAsset"] = "FIXED_ASSET";
    GLAccountResponseAccountSubtypeEnum["CurrentLiability"] = "CURRENT_LIABILITY";
    GLAccountResponseAccountSubtypeEnum["Sales"] = "SALES";
    GLAccountResponseAccountSubtypeEnum["CostOfSales"] = "COST_OF_SALES";
    GLAccountResponseAccountSubtypeEnum["OperatingExpense"] = "OPERATING_EXPENSE";
    GLAccountResponseAccountSubtypeEnum["Other"] = "OTHER";
})(GLAccountResponseAccountSubtypeEnum || (GLAccountResponseAccountSubtypeEnum = {}));
;
var GLAccountResponseAccountTypeEnum;
(function (GLAccountResponseAccountTypeEnum) {
    GLAccountResponseAccountTypeEnum["Asset"] = "ASSET";
    GLAccountResponseAccountTypeEnum["Liability"] = "LIABILITY";
    GLAccountResponseAccountTypeEnum["Equity"] = "EQUITY";
    GLAccountResponseAccountTypeEnum["Revenue"] = "REVENUE";
    GLAccountResponseAccountTypeEnum["Expense"] = "EXPENSE";
})(GLAccountResponseAccountTypeEnum || (GLAccountResponseAccountTypeEnum = {}));
;
var GLAccountResponseStatusEnum;
(function (GLAccountResponseStatusEnum) {
    GLAccountResponseStatusEnum["Active"] = "ACTIVE";
    GLAccountResponseStatusEnum["Inactive"] = "INACTIVE";
    GLAccountResponseStatusEnum["NotYetActive"] = "NOT_YET_ACTIVE";
})(GLAccountResponseStatusEnum || (GLAccountResponseStatusEnum = {}));
;
function isOptionalGLAccountResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLAccountResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLAccountResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLAccountResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLAccountResponsePropertyNames('glAccountId', 'reconcilable');
    const optionalStringProperties = createGLAccountResponseOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'accountSubtype', nullable: false }, { name: 'accountType', nullable: false }, { name: 'activationDate', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'deactivationDate', nullable: false }, { name: 'description', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'parentAccountId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createGLAccountResponseOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createGLAccountResponseOptionalProperties({ name: 'reconcilable', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLAccountResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLAccountResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLAccountResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var GLAccountUpdateRequestAccountSubtypeEnum;
(function (GLAccountUpdateRequestAccountSubtypeEnum) {
    GLAccountUpdateRequestAccountSubtypeEnum["Receivable"] = "RECEIVABLE";
    GLAccountUpdateRequestAccountSubtypeEnum["Payable"] = "PAYABLE";
    GLAccountUpdateRequestAccountSubtypeEnum["BankCash"] = "BANK_CASH";
    GLAccountUpdateRequestAccountSubtypeEnum["UndepositedFunds"] = "UNDEPOSITED_FUNDS";
    GLAccountUpdateRequestAccountSubtypeEnum["TaxPayable"] = "TAX_PAYABLE";
    GLAccountUpdateRequestAccountSubtypeEnum["CurrentAsset"] = "CURRENT_ASSET";
    GLAccountUpdateRequestAccountSubtypeEnum["FixedAsset"] = "FIXED_ASSET";
    GLAccountUpdateRequestAccountSubtypeEnum["CurrentLiability"] = "CURRENT_LIABILITY";
    GLAccountUpdateRequestAccountSubtypeEnum["Sales"] = "SALES";
    GLAccountUpdateRequestAccountSubtypeEnum["CostOfSales"] = "COST_OF_SALES";
    GLAccountUpdateRequestAccountSubtypeEnum["OperatingExpense"] = "OPERATING_EXPENSE";
    GLAccountUpdateRequestAccountSubtypeEnum["Other"] = "OTHER";
})(GLAccountUpdateRequestAccountSubtypeEnum || (GLAccountUpdateRequestAccountSubtypeEnum = {}));
;
function isOptionalGLAccountUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLAccountUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLAccountUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLAccountUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLAccountUpdateRequestPropertyNames();
    const optionalStringProperties = createGLAccountUpdateRequestOptionalProperties({ name: 'accountName', nullable: false }, { name: 'accountSubtype', nullable: false }, { name: 'description', nullable: false });
    const optionalNumberProperties = createGLAccountUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createGLAccountUpdateRequestOptionalProperties({ name: 'reconcilable', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLAccountUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLAccountUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLAccountUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGLMappingCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLMappingCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLMappingCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLMappingCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLMappingCreateRequestPropertyNames('effectiveStartDate', 'externalCode', 'glAccountId', 'sourceSystem');
    const optionalStringProperties = createGLMappingCreateRequestOptionalProperties({ name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'externalCode', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'sourceSystem', nullable: false });
    const optionalNumberProperties = createGLMappingCreateRequestOptionalProperties();
    const optionalBooleanProperties = createGLMappingCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLMappingCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLMappingCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLMappingCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGLMappingCreateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLMappingCreateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLMappingCreateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLMappingCreateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLMappingCreateResponsePropertyNames('mapping');
    const optionalStringProperties = createGLMappingCreateResponseOptionalProperties();
    const optionalNumberProperties = createGLMappingCreateResponseOptionalProperties();
    const optionalBooleanProperties = createGLMappingCreateResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLMappingCreateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLMappingCreateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLMappingCreateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGLMappingResolveRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLMappingResolveRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLMappingResolveRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLMappingResolveRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLMappingResolveRequestPropertyNames('externalCode', 'sourceSystem', 'transactionDate');
    const optionalStringProperties = createGLMappingResolveRequestOptionalProperties({ name: 'externalCode', nullable: false }, { name: 'sourceSystem', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createGLMappingResolveRequestOptionalProperties();
    const optionalBooleanProperties = createGLMappingResolveRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLMappingResolveRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLMappingResolveRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLMappingResolveRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGLMappingResolveResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLMappingResolveResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLMappingResolveResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLMappingResolveResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLMappingResolveResponsePropertyNames('glAccountId');
    const optionalStringProperties = createGLMappingResolveResponseOptionalProperties({ name: 'glAccountId', nullable: false });
    const optionalNumberProperties = createGLMappingResolveResponseOptionalProperties();
    const optionalBooleanProperties = createGLMappingResolveResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLMappingResolveResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLMappingResolveResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLMappingResolveResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGLMappingResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGLMappingResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGLMappingResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGLMappingResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGLMappingResponsePropertyNames('glMappingId');
    const optionalStringProperties = createGLMappingResponseOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'externalCode', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'glMappingId', nullable: false }, { name: 'sourceSystem', nullable: false });
    const optionalNumberProperties = createGLMappingResponseOptionalProperties({ name: 'priority', nullable: false });
    const optionalBooleanProperties = createGLMappingResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGLMappingResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGLMappingResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGLMappingResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGeneralLedgerAccountSectionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGeneralLedgerAccountSectionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGeneralLedgerAccountSectionOptionalProperties(...properties) {
    return properties;
}
function instanceOfGeneralLedgerAccountSection(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGeneralLedgerAccountSectionPropertyNames('accountId', 'accountName', 'accountNumber', 'closingBalance', 'lines', 'openingBalance', 'totalCredit', 'totalDebit');
    const optionalStringProperties = createGeneralLedgerAccountSectionOptionalProperties({ name: 'accountId', nullable: false }, { name: 'accountName', nullable: false }, { name: 'accountNumber', nullable: false });
    const optionalNumberProperties = createGeneralLedgerAccountSectionOptionalProperties({ name: 'closingBalance', nullable: false }, { name: 'openingBalance', nullable: false }, { name: 'totalCredit', nullable: false }, { name: 'totalDebit', nullable: false });
    const optionalBooleanProperties = createGeneralLedgerAccountSectionOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGeneralLedgerAccountSectionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGeneralLedgerAccountSectionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGeneralLedgerAccountSectionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGeneralLedgerLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGeneralLedgerLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGeneralLedgerLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfGeneralLedgerLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGeneralLedgerLinePropertyNames('journalEntryId', 'runningBalance', 'transactionDate');
    const optionalStringProperties = createGeneralLedgerLineOptionalProperties({ name: 'description', nullable: false }, { name: 'entryNumber', nullable: false }, { name: 'journalEntryId', nullable: false }, { name: 'sourceEventType', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createGeneralLedgerLineOptionalProperties({ name: 'creditAmount', nullable: false }, { name: 'debitAmount', nullable: false }, { name: 'runningBalance', nullable: false });
    const optionalBooleanProperties = createGeneralLedgerLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGeneralLedgerLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGeneralLedgerLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGeneralLedgerLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGeneralLedgerReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGeneralLedgerReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGeneralLedgerReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfGeneralLedgerReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGeneralLedgerReportPropertyNames('accounts', 'endDate', 'generatedAt', 'startDate', 'totalCredit', 'totalDebit');
    const optionalStringProperties = createGeneralLedgerReportOptionalProperties({ name: 'accountId', nullable: false }, { name: 'endDate', nullable: false }, { name: 'generatedAt', nullable: false }, { name: 'startDate', nullable: false });
    const optionalNumberProperties = createGeneralLedgerReportOptionalProperties({ name: 'totalCredit', nullable: false }, { name: 'totalDebit', nullable: false });
    const optionalBooleanProperties = createGeneralLedgerReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGeneralLedgerReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGeneralLedgerReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGeneralLedgerReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGoodsReceivedEventPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGoodsReceivedEventPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGoodsReceivedEventOptionalProperties(...properties) {
    return properties;
}
function instanceOfGoodsReceivedEvent(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGoodsReceivedEventPropertyNames('eventId', 'lineItems', 'organizationId', 'purchaseOrderId', 'receivedDate', 'vendorId');
    const optionalStringProperties = createGoodsReceivedEventOptionalProperties({ name: 'eventId', nullable: false }, { name: 'organizationId', nullable: false }, { name: 'purchaseOrderId', nullable: false }, { name: 'receivedDate', nullable: false }, { name: 'vendorId', nullable: false }, { name: 'vendorName', nullable: false });
    const optionalNumberProperties = createGoodsReceivedEventOptionalProperties();
    const optionalBooleanProperties = createGoodsReceivedEventOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGoodsReceivedEventPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGoodsReceivedEventPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGoodsReceivedEventPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalHardLockDateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createHardLockDateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createHardLockDateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfHardLockDateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createHardLockDateResponsePropertyNames();
    const optionalStringProperties = createHardLockDateResponseOptionalProperties({ name: 'hardLockDate', nullable: true });
    const optionalNumberProperties = createHardLockDateResponseOptionalProperties();
    const optionalBooleanProperties = createHardLockDateResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalHardLockDateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalHardLockDateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalHardLockDateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalHardLockDateUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createHardLockDateUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createHardLockDateUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfHardLockDateUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createHardLockDateUpdateRequestPropertyNames('hardLockDate', 'justification');
    const optionalStringProperties = createHardLockDateUpdateRequestOptionalProperties({ name: 'hardLockDate', nullable: false }, { name: 'justification', nullable: false });
    const optionalNumberProperties = createHardLockDateUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createHardLockDateUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalHardLockDateUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalHardLockDateUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalHardLockDateUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalIncomeStatementReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createIncomeStatementReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createIncomeStatementReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfIncomeStatementReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createIncomeStatementReportPropertyNames('endDate', 'generatedAt', 'lineItems', 'netIncome', 'startDate', 'totalExpenses', 'totalRevenue');
    const optionalStringProperties = createIncomeStatementReportOptionalProperties({ name: 'endDate', nullable: false }, { name: 'generatedAt', nullable: false }, { name: 'startDate', nullable: false });
    const optionalNumberProperties = createIncomeStatementReportOptionalProperties({ name: 'netIncome', nullable: false }, { name: 'totalExpenses', nullable: false }, { name: 'totalRevenue', nullable: false });
    const optionalBooleanProperties = createIncomeStatementReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalIncomeStatementReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalIncomeStatementReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalIncomeStatementReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceApplicationPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceApplicationPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceApplicationOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceApplication(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceApplicationPropertyNames('amountToApply', 'invoiceId');
    const optionalStringProperties = createInvoiceApplicationOptionalProperties({ name: 'invoiceId', nullable: false });
    const optionalNumberProperties = createInvoiceApplicationOptionalProperties({ name: 'amountToApply', nullable: false });
    const optionalBooleanProperties = createInvoiceApplicationOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceApplicationPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceApplicationPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceApplicationPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceGenerationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceGenerationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceGenerationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceGenerationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceGenerationResponsePropertyNames('createdAt', 'invoiceId', 'status', 'subtotal', 'taxAmount', 'totalAmount', 'workorderId');
    const optionalStringProperties = createInvoiceGenerationResponseOptionalProperties({ name: 'approvalId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'estimateId', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'status', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createInvoiceGenerationResponseOptionalProperties({ name: 'subtotal', nullable: false }, { name: 'taxAmount', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createInvoiceGenerationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceGenerationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceGenerationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceGenerationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInvoiceLineItemPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceLineItemPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceLineItemOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceLineItem(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceLineItemPropertyNames('description', 'productId', 'quantity', 'unitPrice');
    const optionalStringProperties = createInvoiceLineItemOptionalProperties({ name: 'description', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createInvoiceLineItemOptionalProperties({ name: 'quantity', nullable: false }, { name: 'unitPrice', nullable: false });
    const optionalBooleanProperties = createInvoiceLineItemOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceLineItemPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceLineItemPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceLineItemPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InvoiceStatusResponseStatusEnum;
(function (InvoiceStatusResponseStatusEnum) {
    InvoiceStatusResponseStatusEnum["Paid"] = "PAID";
    InvoiceStatusResponseStatusEnum["PartiallyPaid"] = "PARTIALLY_PAID";
    InvoiceStatusResponseStatusEnum["Unpaid"] = "UNPAID";
    InvoiceStatusResponseStatusEnum["Failed"] = "FAILED";
    InvoiceStatusResponseStatusEnum["Chargeback"] = "CHARGEBACK";
})(InvoiceStatusResponseStatusEnum || (InvoiceStatusResponseStatusEnum = {}));
;
function isOptionalInvoiceStatusResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInvoiceStatusResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInvoiceStatusResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInvoiceStatusResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInvoiceStatusResponsePropertyNames('invoiceId', 'status');
    const optionalStringProperties = createInvoiceStatusResponseOptionalProperties({ name: 'invoiceId', nullable: false }, { name: 'lastUpdated', nullable: false }, { name: 'latestTransactionReference', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createInvoiceStatusResponseOptionalProperties({ name: 'invoiceTotal', nullable: false }, { name: 'remainingBalance', nullable: false }, { name: 'totalPaid', nullable: false });
    const optionalBooleanProperties = createInvoiceStatusResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInvoiceStatusResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInvoiceStatusResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInvoiceStatusResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalJournalEntryCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryCreateRequestPropertyNames('lines', 'transactionDate');
    const optionalStringProperties = createJournalEntryCreateRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'organizationId', nullable: false }, { name: 'postingRuleSetId', nullable: false }, { name: 'postingRuleVersionId', nullable: false }, { name: 'sourceEventId', nullable: false }, { name: 'sourceEventType', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createJournalEntryCreateRequestOptionalProperties();
    const optionalBooleanProperties = createJournalEntryCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalJournalEntryLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryLineRequestPropertyNames('glAccountId');
    const optionalStringProperties = createJournalEntryLineRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'glAccountId', nullable: false });
    const optionalNumberProperties = createJournalEntryLineRequestOptionalProperties({ name: 'creditAmount', nullable: false }, { name: 'debitAmount', nullable: false });
    const optionalBooleanProperties = createJournalEntryLineRequestOptionalProperties({ name: 'singleSidedAmount', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalJournalEntryLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryLineResponsePropertyNames();
    const optionalStringProperties = createJournalEntryLineResponseOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'description', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'lineId', nullable: false });
    const optionalNumberProperties = createJournalEntryLineResponseOptionalProperties({ name: 'creditAmount', nullable: false }, { name: 'debitAmount', nullable: false }, { name: 'lineNumber', nullable: false });
    const optionalBooleanProperties = createJournalEntryLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalJournalEntryPostRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryPostRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryPostRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryPostRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryPostRequestPropertyNames();
    const optionalStringProperties = createJournalEntryPostRequestOptionalProperties({ name: 'overrideJustification', nullable: false });
    const optionalNumberProperties = createJournalEntryPostRequestOptionalProperties();
    const optionalBooleanProperties = createJournalEntryPostRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryPostRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryPostRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryPostRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var JournalEntryResponseStatusEnum;
(function (JournalEntryResponseStatusEnum) {
    JournalEntryResponseStatusEnum["Draft"] = "DRAFT";
    JournalEntryResponseStatusEnum["Pending"] = "PENDING";
    JournalEntryResponseStatusEnum["Posted"] = "POSTED";
    JournalEntryResponseStatusEnum["Reversed"] = "REVERSED";
})(JournalEntryResponseStatusEnum || (JournalEntryResponseStatusEnum = {}));
;
function isOptionalJournalEntryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryResponsePropertyNames();
    const optionalStringProperties = createJournalEntryResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'entryNumber', nullable: true }, { name: 'journalEntryId', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'postedAt', nullable: false }, { name: 'postedBy', nullable: false }, { name: 'postingRuleSetId', nullable: false }, { name: 'postingRuleVersionId', nullable: false }, { name: 'reversalJournalEntryId', nullable: false }, { name: 'reversedAt', nullable: false }, { name: 'reversedByJournalEntryId', nullable: false }, { name: 'sourceEventId', nullable: false }, { name: 'sourceEventType', nullable: false }, { name: 'status', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createJournalEntryResponseOptionalProperties({ name: 'totalCredits', nullable: false }, { name: 'totalDebits', nullable: false });
    const optionalBooleanProperties = createJournalEntryResponseOptionalProperties({ name: 'isBalanced', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalJournalEntryReversalRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryReversalRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryReversalRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryReversalRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryReversalRequestPropertyNames('reason');
    const optionalStringProperties = createJournalEntryReversalRequestOptionalProperties({ name: 'overrideJustification', nullable: false }, { name: 'reason', nullable: false }, { name: 'reversalDate', nullable: false });
    const optionalNumberProperties = createJournalEntryReversalRequestOptionalProperties();
    const optionalBooleanProperties = createJournalEntryReversalRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryReversalRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryReversalRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryReversalRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalJournalEntryTraceabilityResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalEntryTraceabilityResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalEntryTraceabilityResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalEntryTraceabilityResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalEntryTraceabilityResponsePropertyNames('journalEntryId');
    const optionalStringProperties = createJournalEntryTraceabilityResponseOptionalProperties({ name: 'journalEntryId', nullable: false }, { name: 'sourceEventId', nullable: false });
    const optionalNumberProperties = createJournalEntryTraceabilityResponseOptionalProperties();
    const optionalBooleanProperties = createJournalEntryTraceabilityResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalEntryTraceabilityResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalEntryTraceabilityResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalEntryTraceabilityResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalJournalLineDrilldownResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createJournalLineDrilldownResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createJournalLineDrilldownResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfJournalLineDrilldownResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createJournalLineDrilldownResponsePropertyNames('journalEntryId', 'transactionDate');
    const optionalStringProperties = createJournalLineDrilldownResponseOptionalProperties({ name: 'description', nullable: false }, { name: 'journalEntryId', nullable: false }, { name: 'sourceEventId', nullable: false }, { name: 'sourceEventType', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createJournalLineDrilldownResponseOptionalProperties({ name: 'creditAmount', nullable: false }, { name: 'debitAmount', nullable: false });
    const optionalBooleanProperties = createJournalLineDrilldownResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalJournalLineDrilldownResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalJournalLineDrilldownResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalJournalLineDrilldownResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalLaborOverheadCostReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborOverheadCostReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborOverheadCostReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborOverheadCostReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborOverheadCostReportPropertyNames('asOfMonth', 'averageRate', 'currency', 'fiscalYear', 'lines', 'localCurrencyPerUsd', 'locationId');
    const optionalStringProperties = createLaborOverheadCostReportOptionalProperties({ name: 'currency', nullable: false }, { name: 'locationId', nullable: false }, { name: 'locationLabel', nullable: false });
    const optionalNumberProperties = createLaborOverheadCostReportOptionalProperties({ name: 'asOfMonth', nullable: false }, { name: 'averageRate', nullable: false }, { name: 'fiscalYear', nullable: false }, { name: 'localCurrencyPerUsd', nullable: false });
    const optionalBooleanProperties = createLaborOverheadCostReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborOverheadCostReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborOverheadCostReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborOverheadCostReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LaborOverheadReportLineCostTypeEnum;
(function (LaborOverheadReportLineCostTypeEnum) {
    LaborOverheadReportLineCostTypeEnum["Fixed"] = "FIXED";
    LaborOverheadReportLineCostTypeEnum["Variable"] = "VARIABLE";
    LaborOverheadReportLineCostTypeEnum["FixedIfLowVolume"] = "FIXED_IF_LOW_VOLUME";
})(LaborOverheadReportLineCostTypeEnum || (LaborOverheadReportLineCostTypeEnum = {}));
;
function isOptionalLaborOverheadReportLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborOverheadReportLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborOverheadReportLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborOverheadReportLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborOverheadReportLinePropertyNames('code', 'isSubtotal', 'label', 'level', 'monthly', 'usdOnly', 'ytd');
    const optionalStringProperties = createLaborOverheadReportLineOptionalProperties({ name: 'code', nullable: false }, { name: 'costType', nullable: false }, { name: 'definition', nullable: false }, { name: 'label', nullable: false }, { name: 'parentCode', nullable: false });
    const optionalNumberProperties = createLaborOverheadReportLineOptionalProperties({ name: 'level', nullable: false }, { name: 'ytd', nullable: false });
    const optionalBooleanProperties = createLaborOverheadReportLineOptionalProperties({ name: 'isSubtotal', nullable: false }, { name: 'subtotal', nullable: false }, { name: 'usdOnly', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborOverheadReportLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborOverheadReportLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborOverheadReportLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMappingKeyCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMappingKeyCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMappingKeyCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfMappingKeyCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMappingKeyCreateRequestPropertyNames('createdBy', 'keyName', 'postingCategoryId');
    const optionalStringProperties = createMappingKeyCreateRequestOptionalProperties({ name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'keyName', nullable: false }, { name: 'postingCategoryId', nullable: false });
    const optionalNumberProperties = createMappingKeyCreateRequestOptionalProperties();
    const optionalBooleanProperties = createMappingKeyCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMappingKeyCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMappingKeyCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMappingKeyCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalMappingKeyListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMappingKeyListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createMappingKeyListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfMappingKeyListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMappingKeyListResponsePropertyNames('results');
    const optionalStringProperties = createMappingKeyListResponseOptionalProperties();
    const optionalNumberProperties = createMappingKeyListResponseOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalCount', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createMappingKeyListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMappingKeyListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMappingKeyListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMappingKeyListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMappingKeyResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMappingKeyResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createMappingKeyResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfMappingKeyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMappingKeyResponsePropertyNames('keyName', 'mappingKeyId', 'postingCategoryId');
    const optionalStringProperties = createMappingKeyResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'keyName', nullable: false }, { name: 'mappingKeyId', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'postingCategoryId', nullable: false }, { name: 'postingCategoryName', nullable: false });
    const optionalNumberProperties = createMappingKeyResponseOptionalProperties();
    const optionalBooleanProperties = createMappingKeyResponseOptionalProperties({ name: 'isActive', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMappingKeyResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMappingKeyResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMappingKeyResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMappingKeyUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMappingKeyUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMappingKeyUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfMappingKeyUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMappingKeyUpdateRequestPropertyNames('keyName', 'modifiedBy');
    const optionalStringProperties = createMappingKeyUpdateRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'keyName', nullable: false }, { name: 'modifiedBy', nullable: false });
    const optionalNumberProperties = createMappingKeyUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createMappingKeyUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMappingKeyUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMappingKeyUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMappingKeyUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMappingResolutionTestRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMappingResolutionTestRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMappingResolutionTestRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfMappingResolutionTestRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMappingResolutionTestRequestPropertyNames('eventType', 'transactionDate');
    const optionalStringProperties = createMappingResolutionTestRequestOptionalProperties({ name: 'eventType', nullable: false }, { name: 'transactionDate', nullable: false });
    const optionalNumberProperties = createMappingResolutionTestRequestOptionalProperties();
    const optionalBooleanProperties = createMappingResolutionTestRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMappingResolutionTestRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMappingResolutionTestRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMappingResolutionTestRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalMappingResolutionTestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMappingResolutionTestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createMappingResolutionTestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfMappingResolutionTestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMappingResolutionTestResponsePropertyNames('matched');
    const optionalStringProperties = createMappingResolutionTestResponseOptionalProperties({ name: 'noMatchDetail', nullable: false }, { name: 'noMatchReason', nullable: false });
    const optionalNumberProperties = createMappingResolutionTestResponseOptionalProperties();
    const optionalBooleanProperties = createMappingResolutionTestResponseOptionalProperties({ name: 'matched', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMappingResolutionTestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMappingResolutionTestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMappingResolutionTestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMatchedMappingPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMatchedMappingPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMatchedMappingOptionalProperties(...properties) {
    return properties;
}
function instanceOfMatchedMapping(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMatchedMappingPropertyNames();
    const optionalStringProperties = createMatchedMappingOptionalProperties({ name: 'mappingKey', nullable: false }, { name: 'mappingType', nullable: false });
    const optionalNumberProperties = createMatchedMappingOptionalProperties();
    const optionalBooleanProperties = createMatchedMappingOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMatchedMappingPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMatchedMappingPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMatchedMappingPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMatchedRulePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMatchedRulePropertyNames(...propertyNames) {
    return propertyNames;
}
function createMatchedRuleOptionalProperties(...properties) {
    return properties;
}
function instanceOfMatchedRule(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMatchedRulePropertyNames('postingRuleSetId', 'ruleSetName', 'ruleVersionId', 'versionNumber');
    const optionalStringProperties = createMatchedRuleOptionalProperties({ name: 'postingRuleSetId', nullable: false }, { name: 'ruleSetName', nullable: false }, { name: 'ruleVersionId', nullable: false });
    const optionalNumberProperties = createMatchedRuleOptionalProperties({ name: 'versionNumber', nullable: false });
    const optionalBooleanProperties = createMatchedRuleOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMatchedRulePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMatchedRulePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMatchedRulePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageAccountingEventResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageAccountingEventResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageAccountingEventResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageAccountingEventResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageAccountingEventResponsePropertyNames();
    const optionalStringProperties = createPageAccountingEventResponseOptionalProperties();
    const optionalNumberProperties = createPageAccountingEventResponseOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageAccountingEventResponseOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageAccountingEventResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageAccountingEventResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageAccountingEventResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageCreditMemoResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageCreditMemoResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageCreditMemoResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageCreditMemoResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageCreditMemoResponsePropertyNames();
    const optionalStringProperties = createPageCreditMemoResponseOptionalProperties();
    const optionalNumberProperties = createPageCreditMemoResponseOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageCreditMemoResponseOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageCreditMemoResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageCreditMemoResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageCreditMemoResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageCustomerCreditResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageCustomerCreditResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageCustomerCreditResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageCustomerCreditResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageCustomerCreditResponsePropertyNames();
    const optionalStringProperties = createPageCustomerCreditResponseOptionalProperties();
    const optionalNumberProperties = createPageCustomerCreditResponseOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageCustomerCreditResponseOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageCustomerCreditResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageCustomerCreditResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageCustomerCreditResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageExportJobResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageExportJobResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageExportJobResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageExportJobResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageExportJobResponsePropertyNames();
    const optionalStringProperties = createPageExportJobResponseOptionalProperties();
    const optionalNumberProperties = createPageExportJobResponseOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageExportJobResponseOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageExportJobResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageExportJobResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageExportJobResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPagePaymentApplicationListRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagePaymentApplicationListRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPagePaymentApplicationListRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfPagePaymentApplicationListRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagePaymentApplicationListRowPropertyNames();
    const optionalStringProperties = createPagePaymentApplicationListRowOptionalProperties();
    const optionalNumberProperties = createPagePaymentApplicationListRowOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPagePaymentApplicationListRowOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagePaymentApplicationListRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagePaymentApplicationListRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagePaymentApplicationListRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageReportExportResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageReportExportResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageReportExportResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageReportExportResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageReportExportResponsePropertyNames();
    const optionalStringProperties = createPageReportExportResponseOptionalProperties();
    const optionalNumberProperties = createPageReportExportResponseOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageReportExportResponseOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageReportExportResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageReportExportResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageReportExportResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageVendorBillListRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageVendorBillListRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageVendorBillListRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageVendorBillListRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageVendorBillListRowPropertyNames();
    const optionalStringProperties = createPageVendorBillListRowOptionalProperties();
    const optionalNumberProperties = createPageVendorBillListRowOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageVendorBillListRowOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageVendorBillListRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageVendorBillListRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageVendorBillListRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageVendorBillSummaryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageVendorBillSummaryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageVendorBillSummaryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageVendorBillSummaryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageVendorBillSummaryResponsePropertyNames();
    const optionalStringProperties = createPageVendorBillSummaryResponseOptionalProperties();
    const optionalNumberProperties = createPageVendorBillSummaryResponseOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageVendorBillSummaryResponseOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageVendorBillSummaryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageVendorBillSummaryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageVendorBillSummaryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageableObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageableObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageableObjectPropertyNames();
    const optionalStringProperties = createPageableObjectOptionalProperties();
    const optionalNumberProperties = createPageableObjectOptionalProperties({ name: 'offset', nullable: false }, { name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createPageableObjectOptionalProperties({ name: 'paged', nullable: false }, { name: 'unpaged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPagedResponseJournalEntryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagedResponseJournalEntryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPagedResponseJournalEntryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPagedResponseJournalEntryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagedResponseJournalEntryResponsePropertyNames('items');
    const optionalStringProperties = createPagedResponseJournalEntryResponseOptionalProperties();
    const optionalNumberProperties = createPagedResponseJournalEntryResponseOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalCount', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPagedResponseJournalEntryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagedResponseJournalEntryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagedResponseJournalEntryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagedResponseJournalEntryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPaymentApplicationListRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPaymentApplicationListRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPaymentApplicationListRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfPaymentApplicationListRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPaymentApplicationListRowPropertyNames('amount', 'applicationId', 'appliedAt', 'invoiceId', 'paymentId', 'reversed');
    const optionalStringProperties = createPaymentApplicationListRowOptionalProperties({ name: 'applicationId', nullable: false }, { name: 'appliedAt', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'paymentId', nullable: false });
    const optionalNumberProperties = createPaymentApplicationListRowOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createPaymentApplicationListRowOptionalProperties({ name: 'reversed', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPaymentApplicationListRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPaymentApplicationListRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPaymentApplicationListRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var PaymentApplicationRequestAllocationStrategyEnum;
(function (PaymentApplicationRequestAllocationStrategyEnum) {
    PaymentApplicationRequestAllocationStrategyEnum["CallerOrder"] = "CALLER_ORDER";
    PaymentApplicationRequestAllocationStrategyEnum["OldestFirst"] = "OLDEST_FIRST";
})(PaymentApplicationRequestAllocationStrategyEnum || (PaymentApplicationRequestAllocationStrategyEnum = {}));
;
function isOptionalPaymentApplicationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPaymentApplicationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPaymentApplicationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPaymentApplicationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPaymentApplicationRequestPropertyNames('applicationRequestId', 'applications');
    const optionalStringProperties = createPaymentApplicationRequestOptionalProperties({ name: 'allocationStrategy', nullable: true }, { name: 'applicationRequestId', nullable: false });
    const optionalNumberProperties = createPaymentApplicationRequestOptionalProperties();
    const optionalBooleanProperties = createPaymentApplicationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPaymentApplicationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPaymentApplicationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPaymentApplicationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPaymentApplicationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPaymentApplicationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPaymentApplicationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPaymentApplicationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPaymentApplicationResponsePropertyNames('paymentId');
    const optionalStringProperties = createPaymentApplicationResponseOptionalProperties({ name: 'applicationRequestId', nullable: false }, { name: 'applicationTimestamp', nullable: false }, { name: 'currency', nullable: false }, { name: 'customerId', nullable: false }, { name: 'paymentId', nullable: false });
    const optionalNumberProperties = createPaymentApplicationResponseOptionalProperties({ name: 'appliedAmount', nullable: false }, { name: 'remainingAmount', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createPaymentApplicationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPaymentApplicationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPaymentApplicationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPaymentApplicationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPaymentApplicationReversalRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPaymentApplicationReversalRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPaymentApplicationReversalRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPaymentApplicationReversalRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPaymentApplicationReversalRequestPropertyNames('reason');
    const optionalStringProperties = createPaymentApplicationReversalRequestOptionalProperties({ name: 'reason', nullable: false });
    const optionalNumberProperties = createPaymentApplicationReversalRequestOptionalProperties();
    const optionalBooleanProperties = createPaymentApplicationReversalRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPaymentApplicationReversalRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPaymentApplicationReversalRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPaymentApplicationReversalRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPaymentLagCohortRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPaymentLagCohortRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPaymentLagCohortRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfPaymentLagCohortRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPaymentLagCohortRowPropertyNames('amount', 'cohort', 'invoiceCount');
    const optionalStringProperties = createPaymentLagCohortRowOptionalProperties({ name: 'cohort', nullable: false });
    const optionalNumberProperties = createPaymentLagCohortRowOptionalProperties({ name: 'amount', nullable: false }, { name: 'invoiceCount', nullable: false });
    const optionalBooleanProperties = createPaymentLagCohortRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPaymentLagCohortRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPaymentLagCohortRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPaymentLagCohortRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPaymentLagCohortsReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPaymentLagCohortsReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPaymentLagCohortsReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfPaymentLagCohortsReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPaymentLagCohortsReportPropertyNames('cohorts', 'generatedAt', 'issuedFrom', 'issuedTo', 'truncated');
    const optionalStringProperties = createPaymentLagCohortsReportOptionalProperties({ name: 'generatedAt', nullable: false }, { name: 'issuedFrom', nullable: false }, { name: 'issuedTo', nullable: false });
    const optionalNumberProperties = createPaymentLagCohortsReportOptionalProperties();
    const optionalBooleanProperties = createPaymentLagCohortsReportOptionalProperties({ name: 'truncated', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPaymentLagCohortsReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPaymentLagCohortsReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPaymentLagCohortsReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPostingCategoryCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingCategoryCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingCategoryCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingCategoryCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingCategoryCreateRequestPropertyNames('categoryName', 'createdBy');
    const optionalStringProperties = createPostingCategoryCreateRequestOptionalProperties({ name: 'categoryName', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false });
    const optionalNumberProperties = createPostingCategoryCreateRequestOptionalProperties();
    const optionalBooleanProperties = createPostingCategoryCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingCategoryCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingCategoryCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingCategoryCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPostingCategoryListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingCategoryListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingCategoryListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingCategoryListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingCategoryListResponsePropertyNames('results');
    const optionalStringProperties = createPostingCategoryListResponseOptionalProperties();
    const optionalNumberProperties = createPostingCategoryListResponseOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalCount', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPostingCategoryListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingCategoryListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingCategoryListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingCategoryListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPostingCategoryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingCategoryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingCategoryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingCategoryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingCategoryResponsePropertyNames('categoryName', 'postingCategoryId');
    const optionalStringProperties = createPostingCategoryResponseOptionalProperties({ name: 'categoryName', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'postingCategoryId', nullable: false });
    const optionalNumberProperties = createPostingCategoryResponseOptionalProperties();
    const optionalBooleanProperties = createPostingCategoryResponseOptionalProperties({ name: 'isActive', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingCategoryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingCategoryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingCategoryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPostingCategoryUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingCategoryUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingCategoryUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingCategoryUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingCategoryUpdateRequestPropertyNames('categoryName', 'modifiedBy');
    const optionalStringProperties = createPostingCategoryUpdateRequestOptionalProperties({ name: 'categoryName', nullable: false }, { name: 'description', nullable: false }, { name: 'modifiedBy', nullable: false });
    const optionalNumberProperties = createPostingCategoryUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createPostingCategoryUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingCategoryUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingCategoryUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingCategoryUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPostingRuleSetCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingRuleSetCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingRuleSetCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingRuleSetCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingRuleSetCreateRequestPropertyNames('createdBy', 'eventType', 'name', 'rulesDefinition');
    const optionalStringProperties = createPostingRuleSetCreateRequestOptionalProperties({ name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'eventType', nullable: false }, { name: 'name', nullable: false }, { name: 'rulesDefinition', nullable: false });
    const optionalNumberProperties = createPostingRuleSetCreateRequestOptionalProperties();
    const optionalBooleanProperties = createPostingRuleSetCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingRuleSetCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingRuleSetCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingRuleSetCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPostingRuleSetListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingRuleSetListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingRuleSetListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingRuleSetListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingRuleSetListResponsePropertyNames();
    const optionalStringProperties = createPostingRuleSetListResponseOptionalProperties();
    const optionalNumberProperties = createPostingRuleSetListResponseOptionalProperties({ name: 'currentPage', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPostingRuleSetListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingRuleSetListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingRuleSetListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingRuleSetListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPostingRuleSetResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingRuleSetResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingRuleSetResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingRuleSetResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingRuleSetResponsePropertyNames('postingRuleSetId');
    const optionalStringProperties = createPostingRuleSetResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'eventType', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'name', nullable: false }, { name: 'postingRuleSetId', nullable: false });
    const optionalNumberProperties = createPostingRuleSetResponseOptionalProperties();
    const optionalBooleanProperties = createPostingRuleSetResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingRuleSetResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingRuleSetResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingRuleSetResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PostingRuleVersionResponseStateEnum;
(function (PostingRuleVersionResponseStateEnum) {
    PostingRuleVersionResponseStateEnum["Draft"] = "DRAFT";
    PostingRuleVersionResponseStateEnum["Published"] = "PUBLISHED";
    PostingRuleVersionResponseStateEnum["Archived"] = "ARCHIVED";
})(PostingRuleVersionResponseStateEnum || (PostingRuleVersionResponseStateEnum = {}));
;
function isOptionalPostingRuleVersionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPostingRuleVersionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPostingRuleVersionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPostingRuleVersionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPostingRuleVersionResponsePropertyNames('postingRuleSetId', 'versionId');
    const optionalStringProperties = createPostingRuleVersionResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'modifiedBy', nullable: false }, { name: 'postingRuleSetId', nullable: false }, { name: 'rulesDefinition', nullable: false }, { name: 'state', nullable: false }, { name: 'versionId', nullable: false });
    const optionalNumberProperties = createPostingRuleVersionResponseOptionalProperties({ name: 'versionNumber', nullable: false });
    const optionalBooleanProperties = createPostingRuleVersionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPostingRuleVersionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPostingRuleVersionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPostingRuleVersionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPredicateEvaluationPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPredicateEvaluationPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPredicateEvaluationOptionalProperties(...properties) {
    return properties;
}
function instanceOfPredicateEvaluation(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPredicateEvaluationPropertyNames('matched', 'predicate');
    const optionalStringProperties = createPredicateEvaluationOptionalProperties({ name: 'detail', nullable: false }, { name: 'predicate', nullable: false });
    const optionalNumberProperties = createPredicateEvaluationOptionalProperties();
    const optionalBooleanProperties = createPredicateEvaluationOptionalProperties({ name: 'matched', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPredicateEvaluationPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPredicateEvaluationPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPredicateEvaluationPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPriceOverrideRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceOverrideRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceOverrideRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceOverrideRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceOverrideRequestPropertyNames('actorRole', 'adjustedPrice', 'lineItemId', 'orderId', 'originalPrice', 'reason');
    const optionalStringProperties = createPriceOverrideRequestOptionalProperties({ name: 'actorRole', nullable: false }, { name: 'categoryCode', nullable: false }, { name: 'lineItemId', nullable: false }, { name: 'orderId', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createPriceOverrideRequestOptionalProperties({ name: 'adjustedPrice', nullable: false }, { name: 'originalPrice', nullable: false });
    const optionalBooleanProperties = createPriceOverrideRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceOverrideRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceOverrideRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceOverrideRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReceivedLineItemPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceivedLineItemPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceivedLineItemOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceivedLineItem(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceivedLineItemPropertyNames('description', 'productId', 'quantity', 'unitPrice');
    const optionalStringProperties = createReceivedLineItemOptionalProperties({ name: 'description', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createReceivedLineItemOptionalProperties({ name: 'quantity', nullable: false }, { name: 'unitPrice', nullable: false });
    const optionalBooleanProperties = createReceivedLineItemOptionalProperties({ name: 'inventoryItem', nullable: false }, { name: 'isInventoryItem', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceivedLineItemPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceivedLineItemPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceivedLineItemPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReconciliationAdjustmentRequestTypeEnum;
(function (ReconciliationAdjustmentRequestTypeEnum) {
    ReconciliationAdjustmentRequestTypeEnum["BankFee"] = "BANK_FEE";
    ReconciliationAdjustmentRequestTypeEnum["NsfFee"] = "NSF_FEE";
    ReconciliationAdjustmentRequestTypeEnum["InterestEarned"] = "INTEREST_EARNED";
    ReconciliationAdjustmentRequestTypeEnum["Other"] = "OTHER";
})(ReconciliationAdjustmentRequestTypeEnum || (ReconciliationAdjustmentRequestTypeEnum = {}));
;
function isOptionalReconciliationAdjustmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReconciliationAdjustmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReconciliationAdjustmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReconciliationAdjustmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReconciliationAdjustmentRequestPropertyNames('amount', 'type');
    const optionalStringProperties = createReconciliationAdjustmentRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createReconciliationAdjustmentRequestOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createReconciliationAdjustmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReconciliationAdjustmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReconciliationAdjustmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReconciliationAdjustmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReconciliationAuditResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReconciliationAuditResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReconciliationAuditResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReconciliationAuditResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReconciliationAuditResponsePropertyNames();
    const optionalStringProperties = createReconciliationAuditResponseOptionalProperties({ name: 'reconciliationId', nullable: false });
    const optionalNumberProperties = createReconciliationAuditResponseOptionalProperties();
    const optionalBooleanProperties = createReconciliationAuditResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReconciliationAuditResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReconciliationAuditResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReconciliationAuditResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReconciliationMatchRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReconciliationMatchRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReconciliationMatchRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReconciliationMatchRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReconciliationMatchRequestPropertyNames('glLineIds', 'statementLineIds');
    const optionalStringProperties = createReconciliationMatchRequestOptionalProperties();
    const optionalNumberProperties = createReconciliationMatchRequestOptionalProperties();
    const optionalBooleanProperties = createReconciliationMatchRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReconciliationMatchRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReconciliationMatchRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReconciliationMatchRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReconciliationReportResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReconciliationReportResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReconciliationReportResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReconciliationReportResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReconciliationReportResponsePropertyNames();
    const optionalStringProperties = createReconciliationReportResponseOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'currency', nullable: false }, { name: 'reconciliationId', nullable: false }, { name: 'statementDate', nullable: false });
    const optionalNumberProperties = createReconciliationReportResponseOptionalProperties({ name: 'difference', nullable: false }, { name: 'glEndingBalance', nullable: false }, { name: 'matchedLineCount', nullable: false }, { name: 'outstandingLineCount', nullable: false }, { name: 'statementEndingBalance', nullable: false }, { name: 'totalAdjustments', nullable: false }, { name: 'totalMatched', nullable: false }, { name: 'totalOutstanding', nullable: false });
    const optionalBooleanProperties = createReconciliationReportResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReconciliationReportResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReconciliationReportResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReconciliationReportResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReconciliationUnmatchRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReconciliationUnmatchRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReconciliationUnmatchRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReconciliationUnmatchRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReconciliationUnmatchRequestPropertyNames();
    const optionalStringProperties = createReconciliationUnmatchRequestOptionalProperties({ name: 'matchId', nullable: false });
    const optionalNumberProperties = createReconciliationUnmatchRequestOptionalProperties();
    const optionalBooleanProperties = createReconciliationUnmatchRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReconciliationUnmatchRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReconciliationUnmatchRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReconciliationUnmatchRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RefundRequestOriginalPaymentStatusEnum;
(function (RefundRequestOriginalPaymentStatusEnum) {
    RefundRequestOriginalPaymentStatusEnum["Pending"] = "PENDING";
    RefundRequestOriginalPaymentStatusEnum["Settled"] = "SETTLED";
    RefundRequestOriginalPaymentStatusEnum["Failed"] = "FAILED";
    RefundRequestOriginalPaymentStatusEnum["Authorized"] = "AUTHORIZED";
})(RefundRequestOriginalPaymentStatusEnum || (RefundRequestOriginalPaymentStatusEnum = {}));
;
var RefundRequestRefundTypeEnum;
(function (RefundRequestRefundTypeEnum) {
    RefundRequestRefundTypeEnum["Reversal"] = "REVERSAL";
    RefundRequestRefundTypeEnum["CreditMemo"] = "CREDIT_MEMO";
    RefundRequestRefundTypeEnum["Adjustment"] = "ADJUSTMENT";
})(RefundRequestRefundTypeEnum || (RefundRequestRefundTypeEnum = {}));
;
function isOptionalRefundRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRefundRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRefundRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRefundRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRefundRequestPropertyNames('actorRole', 'invoiceId', 'originalPaymentStatus', 'paymentId', 'reason', 'refundAmount', 'refundType');
    const optionalStringProperties = createRefundRequestOptionalProperties({ name: 'actorId', nullable: false }, { name: 'actorRole', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'originalPaymentStatus', nullable: false }, { name: 'paymentId', nullable: false }, { name: 'reason', nullable: false }, { name: 'refundType', nullable: false });
    const optionalNumberProperties = createRefundRequestOptionalProperties({ name: 'refundAmount', nullable: false });
    const optionalBooleanProperties = createRefundRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRefundRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRefundRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRefundRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRegenerateInvoiceFromWorkorderRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRegenerateInvoiceFromWorkorderRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRegenerateInvoiceFromWorkorderRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRegenerateInvoiceFromWorkorderRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRegenerateInvoiceFromWorkorderRequestPropertyNames('workorderId');
    const optionalStringProperties = createRegenerateInvoiceFromWorkorderRequestOptionalProperties({ name: 'idempotencyKey', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createRegenerateInvoiceFromWorkorderRequestOptionalProperties();
    const optionalBooleanProperties = createRegenerateInvoiceFromWorkorderRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRegenerateInvoiceFromWorkorderRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRegenerateInvoiceFromWorkorderRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRegenerateInvoiceFromWorkorderRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReportExportRequestFormatEnum;
(function (ReportExportRequestFormatEnum) {
    ReportExportRequestFormatEnum["Pdf"] = "PDF";
    ReportExportRequestFormatEnum["Csv"] = "CSV";
    ReportExportRequestFormatEnum["Xlsx"] = "XLSX";
    ReportExportRequestFormatEnum["Json"] = "JSON";
})(ReportExportRequestFormatEnum || (ReportExportRequestFormatEnum = {}));
;
function isOptionalReportExportRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReportExportRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReportExportRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReportExportRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReportExportRequestPropertyNames('endDate', 'format', 'organizationId', 'reportType', 'startDate');
    const optionalStringProperties = createReportExportRequestOptionalProperties({ name: 'accountId', nullable: false }, { name: 'endDate', nullable: false }, { name: 'filename', nullable: false }, { name: 'format', nullable: false }, { name: 'organizationId', nullable: false }, { name: 'reportType', nullable: false }, { name: 'startDate', nullable: false });
    const optionalNumberProperties = createReportExportRequestOptionalProperties();
    const optionalBooleanProperties = createReportExportRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReportExportRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReportExportRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReportExportRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReportExportResponseFormatEnum;
(function (ReportExportResponseFormatEnum) {
    ReportExportResponseFormatEnum["Pdf"] = "PDF";
    ReportExportResponseFormatEnum["Csv"] = "CSV";
    ReportExportResponseFormatEnum["Xlsx"] = "XLSX";
    ReportExportResponseFormatEnum["Json"] = "JSON";
})(ReportExportResponseFormatEnum || (ReportExportResponseFormatEnum = {}));
;
var ReportExportResponseStatusEnum;
(function (ReportExportResponseStatusEnum) {
    ReportExportResponseStatusEnum["Pending"] = "PENDING";
    ReportExportResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    ReportExportResponseStatusEnum["Completed"] = "COMPLETED";
    ReportExportResponseStatusEnum["Failed"] = "FAILED";
})(ReportExportResponseStatusEnum || (ReportExportResponseStatusEnum = {}));
;
function isOptionalReportExportResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReportExportResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReportExportResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReportExportResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReportExportResponsePropertyNames('exportId', 'status');
    const optionalStringProperties = createReportExportResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'downloadUrl', nullable: false }, { name: 'exportId', nullable: false }, { name: 'failureReason', nullable: false }, { name: 'format', nullable: false }, { name: 'reportType', nullable: false }, { name: 'requestedAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createReportExportResponseOptionalProperties();
    const optionalBooleanProperties = createReportExportResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReportExportResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReportExportResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReportExportResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReprocessEventRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReprocessEventRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReprocessEventRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReprocessEventRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReprocessEventRequestPropertyNames('triggeredByUserId');
    const optionalStringProperties = createReprocessEventRequestOptionalProperties({ name: 'mappingVersionToUse', nullable: false }, { name: 'reprocessingNotes', nullable: false }, { name: 'triggeredByUserId', nullable: false });
    const optionalNumberProperties = createReprocessEventRequestOptionalProperties();
    const optionalBooleanProperties = createReprocessEventRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReprocessEventRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReprocessEventRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReprocessEventRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReprocessingAttemptHistoryResponseOutcomeEnum;
(function (ReprocessingAttemptHistoryResponseOutcomeEnum) {
    ReprocessingAttemptHistoryResponseOutcomeEnum["Success"] = "SUCCESS";
    ReprocessingAttemptHistoryResponseOutcomeEnum["Failure"] = "FAILURE";
})(ReprocessingAttemptHistoryResponseOutcomeEnum || (ReprocessingAttemptHistoryResponseOutcomeEnum = {}));
;
function isOptionalReprocessingAttemptHistoryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReprocessingAttemptHistoryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReprocessingAttemptHistoryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReprocessingAttemptHistoryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReprocessingAttemptHistoryResponsePropertyNames('attemptId', 'eventId');
    const optionalStringProperties = createReprocessingAttemptHistoryResponseOptionalProperties({ name: 'attemptId', nullable: false }, { name: 'attemptedAt', nullable: false }, { name: 'eventId', nullable: false }, { name: 'mappingVersionUsed', nullable: false }, { name: 'outcome', nullable: false }, { name: 'outcomeDetails', nullable: false }, { name: 'triggeredByUserId', nullable: false });
    const optionalNumberProperties = createReprocessingAttemptHistoryResponseOptionalProperties();
    const optionalBooleanProperties = createReprocessingAttemptHistoryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReprocessingAttemptHistoryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReprocessingAttemptHistoryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReprocessingAttemptHistoryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalResolvedLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolvedLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolvedLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolvedLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolvedLinePropertyNames('creditAmount', 'debitAmount', 'glAccountId');
    const optionalStringProperties = createResolvedLineOptionalProperties({ name: 'accountCode', nullable: false }, { name: 'accountName', nullable: false }, { name: 'description', nullable: false }, { name: 'glAccountId', nullable: false }, { name: 'splitGroup', nullable: false });
    const optionalNumberProperties = createResolvedLineOptionalProperties({ name: 'creditAmount', nullable: false }, { name: 'debitAmount', nullable: false }, { name: 'factorPercent', nullable: false });
    const optionalBooleanProperties = createResolvedLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolvedLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolvedLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolvedLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SettlementLineResponseLineTypeEnum;
(function (SettlementLineResponseLineTypeEnum) {
    SettlementLineResponseLineTypeEnum["Charge"] = "CHARGE";
    SettlementLineResponseLineTypeEnum["Refund"] = "REFUND";
    SettlementLineResponseLineTypeEnum["Chargeback"] = "CHARGEBACK";
    SettlementLineResponseLineTypeEnum["Fee"] = "FEE";
    SettlementLineResponseLineTypeEnum["Adjustment"] = "ADJUSTMENT";
    SettlementLineResponseLineTypeEnum["ReserveHold"] = "RESERVE_HOLD";
    SettlementLineResponseLineTypeEnum["ReserveRelease"] = "RESERVE_RELEASE";
    SettlementLineResponseLineTypeEnum["PayoutCorrection"] = "PAYOUT_CORRECTION";
})(SettlementLineResponseLineTypeEnum || (SettlementLineResponseLineTypeEnum = {}));
;
var SettlementLineResponseMatchStatusEnum;
(function (SettlementLineResponseMatchStatusEnum) {
    SettlementLineResponseMatchStatusEnum["Matched"] = "MATCHED";
    SettlementLineResponseMatchStatusEnum["Unmatched"] = "UNMATCHED";
    SettlementLineResponseMatchStatusEnum["WrittenOff"] = "WRITTEN_OFF";
})(SettlementLineResponseMatchStatusEnum || (SettlementLineResponseMatchStatusEnum = {}));
;
var SettlementLineResponseMatchedPaymentTypeEnum;
(function (SettlementLineResponseMatchedPaymentTypeEnum) {
    SettlementLineResponseMatchedPaymentTypeEnum["Ar"] = "AR";
    SettlementLineResponseMatchedPaymentTypeEnum["Ap"] = "AP";
})(SettlementLineResponseMatchedPaymentTypeEnum || (SettlementLineResponseMatchedPaymentTypeEnum = {}));
;
function isOptionalSettlementLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementLineResponsePropertyNames();
    const optionalStringProperties = createSettlementLineResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'lineId', nullable: false }, { name: 'lineType', nullable: false }, { name: 'matchStatus', nullable: false }, { name: 'matchedPaymentId', nullable: false }, { name: 'matchedPaymentType', nullable: false }, { name: 'paymentReference', nullable: false }, { name: 'providerLineRef', nullable: false }, { name: 'settlementId', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'writeoffJournalEntryId', nullable: false }, { name: 'writeoffReason', nullable: false });
    const optionalNumberProperties = createSettlementLineResponseOptionalProperties({ name: 'feeAmount', nullable: false }, { name: 'grossAmount', nullable: false }, { name: 'netAmount', nullable: false });
    const optionalBooleanProperties = createSettlementLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSettlementManualMatchRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementManualMatchRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementManualMatchRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementManualMatchRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementManualMatchRequestPropertyNames('receivablePaymentId');
    const optionalStringProperties = createSettlementManualMatchRequestOptionalProperties({ name: 'receivablePaymentId', nullable: false });
    const optionalNumberProperties = createSettlementManualMatchRequestOptionalProperties();
    const optionalBooleanProperties = createSettlementManualMatchRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementManualMatchRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementManualMatchRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementManualMatchRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSettlementWriteOffRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSettlementWriteOffRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSettlementWriteOffRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSettlementWriteOffRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSettlementWriteOffRequestPropertyNames('reason');
    const optionalStringProperties = createSettlementWriteOffRequestOptionalProperties({ name: 'reason', nullable: false });
    const optionalNumberProperties = createSettlementWriteOffRequestOptionalProperties();
    const optionalBooleanProperties = createSettlementWriteOffRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSettlementWriteOffRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSettlementWriteOffRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSettlementWriteOffRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSortObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSortObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSortObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSortObjectPropertyNames();
    const optionalStringProperties = createSortObjectOptionalProperties();
    const optionalNumberProperties = createSortObjectOptionalProperties();
    const optionalBooleanProperties = createSortObjectOptionalProperties({ name: 'empty', nullable: false }, { name: 'sorted', nullable: false }, { name: 'unsorted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTaxLiabilityReconciliationPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTaxLiabilityReconciliationPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTaxLiabilityReconciliationOptionalProperties(...properties) {
    return properties;
}
function instanceOfTaxLiabilityReconciliation(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTaxLiabilityReconciliationPropertyNames('drift', 'glNetActivity', 'reconciled', 'reportNetTax', 'taxPayableAccountCode', 'unattributedCredits');
    const optionalStringProperties = createTaxLiabilityReconciliationOptionalProperties({ name: 'taxPayableAccountCode', nullable: false });
    const optionalNumberProperties = createTaxLiabilityReconciliationOptionalProperties({ name: 'drift', nullable: false }, { name: 'glNetActivity', nullable: false }, { name: 'reportNetTax', nullable: false }, { name: 'unattributedCredits', nullable: false });
    const optionalBooleanProperties = createTaxLiabilityReconciliationOptionalProperties({ name: 'reconciled', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTaxLiabilityReconciliationPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTaxLiabilityReconciliationPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTaxLiabilityReconciliationPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalTaxLiabilityReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTaxLiabilityReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTaxLiabilityReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfTaxLiabilityReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTaxLiabilityReportPropertyNames('endDate', 'generatedAt', 'reconciliation', 'rows', 'startDate', 'totalCreditsNetted', 'totalExemptBase', 'totalNetTax', 'totalTaxCollectedGross', 'totalTaxableBase');
    const optionalStringProperties = createTaxLiabilityReportOptionalProperties({ name: 'endDate', nullable: false }, { name: 'generatedAt', nullable: false }, { name: 'startDate', nullable: false });
    const optionalNumberProperties = createTaxLiabilityReportOptionalProperties({ name: 'totalCreditsNetted', nullable: false }, { name: 'totalExemptBase', nullable: false }, { name: 'totalNetTax', nullable: false }, { name: 'totalTaxCollectedGross', nullable: false }, { name: 'totalTaxableBase', nullable: false });
    const optionalBooleanProperties = createTaxLiabilityReportOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTaxLiabilityReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTaxLiabilityReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTaxLiabilityReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTaxLiabilityRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTaxLiabilityRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTaxLiabilityRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfTaxLiabilityRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTaxLiabilityRowPropertyNames('creditsNetted', 'exemptBase', 'exemptionReasons', 'jurisdictionCode', 'jurisdictionType', 'netTax', 'taxCollectedGross', 'taxableBase');
    const optionalStringProperties = createTaxLiabilityRowOptionalProperties({ name: 'jurisdictionCode', nullable: false }, { name: 'jurisdictionName', nullable: false }, { name: 'jurisdictionType', nullable: false });
    const optionalNumberProperties = createTaxLiabilityRowOptionalProperties({ name: 'creditsNetted', nullable: false }, { name: 'exemptBase', nullable: false }, { name: 'netTax', nullable: false }, { name: 'taxCollectedGross', nullable: false }, { name: 'taxableBase', nullable: false });
    const optionalBooleanProperties = createTaxLiabilityRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTaxLiabilityRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTaxLiabilityRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTaxLiabilityRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalTaxLiabilitySnapshotResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTaxLiabilitySnapshotResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTaxLiabilitySnapshotResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTaxLiabilitySnapshotResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTaxLiabilitySnapshotResponsePropertyNames('contentHash', 'endDate', 'frozenAt', 'frozenBy', 'periodClosedAt', 'periodCode', 'periodId', 'reconciliation', 'rows', 'snapshotId', 'startDate', 'status', 'totalCreditsNetted', 'totalExemptBase', 'totalNetTax', 'totalTaxCollectedGross', 'totalTaxableBase');
    const optionalStringProperties = createTaxLiabilitySnapshotResponseOptionalProperties({ name: 'contentHash', nullable: false }, { name: 'endDate', nullable: false }, { name: 'frozenAt', nullable: false }, { name: 'frozenBy', nullable: false }, { name: 'periodClosedAt', nullable: false }, { name: 'periodCode', nullable: false }, { name: 'periodId', nullable: false }, { name: 'snapshotId', nullable: false }, { name: 'startDate', nullable: false }, { name: 'status', nullable: false }, { name: 'supersededAt', nullable: false }, { name: 'supersededBy', nullable: false }, { name: 'supersedesSnapshotId', nullable: false });
    const optionalNumberProperties = createTaxLiabilitySnapshotResponseOptionalProperties({ name: 'totalCreditsNetted', nullable: false }, { name: 'totalExemptBase', nullable: false }, { name: 'totalNetTax', nullable: false }, { name: 'totalTaxCollectedGross', nullable: false }, { name: 'totalTaxableBase', nullable: false });
    const optionalBooleanProperties = createTaxLiabilitySnapshotResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTaxLiabilitySnapshotResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTaxLiabilitySnapshotResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTaxLiabilitySnapshotResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTaxLiabilitySnapshotSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTaxLiabilitySnapshotSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTaxLiabilitySnapshotSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfTaxLiabilitySnapshotSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTaxLiabilitySnapshotSummaryPropertyNames('contentHash', 'frozenAt', 'frozenBy', 'periodCode', 'reconciled', 'snapshotId', 'status', 'totalNetTax');
    const optionalStringProperties = createTaxLiabilitySnapshotSummaryOptionalProperties({ name: 'contentHash', nullable: false }, { name: 'frozenAt', nullable: false }, { name: 'frozenBy', nullable: false }, { name: 'periodCode', nullable: false }, { name: 'snapshotId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createTaxLiabilitySnapshotSummaryOptionalProperties({ name: 'totalNetTax', nullable: false });
    const optionalBooleanProperties = createTaxLiabilitySnapshotSummaryOptionalProperties({ name: 'reconciled', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTaxLiabilitySnapshotSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTaxLiabilitySnapshotSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTaxLiabilitySnapshotSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTaxLiabilitySnapshotVerificationPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTaxLiabilitySnapshotVerificationPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTaxLiabilitySnapshotVerificationOptionalProperties(...properties) {
    return properties;
}
function instanceOfTaxLiabilitySnapshotVerification(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTaxLiabilitySnapshotVerificationPropertyNames('consistent', 'frozenTotalNetTax', 'netTaxDelta', 'periodCode', 'recomputedContentHash', 'recomputedTotalNetTax', 'snapshotContentHash', 'snapshotId', 'verifiedAt');
    const optionalStringProperties = createTaxLiabilitySnapshotVerificationOptionalProperties({ name: 'periodCode', nullable: false }, { name: 'recomputedContentHash', nullable: false }, { name: 'snapshotContentHash', nullable: false }, { name: 'snapshotId', nullable: false }, { name: 'verifiedAt', nullable: false });
    const optionalNumberProperties = createTaxLiabilitySnapshotVerificationOptionalProperties({ name: 'frozenTotalNetTax', nullable: false }, { name: 'netTaxDelta', nullable: false }, { name: 'recomputedTotalNetTax', nullable: false });
    const optionalBooleanProperties = createTaxLiabilitySnapshotVerificationOptionalProperties({ name: 'consistent', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTaxLiabilitySnapshotVerificationPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTaxLiabilitySnapshotVerificationPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTaxLiabilitySnapshotVerificationPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalTrialBalanceReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTrialBalanceReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTrialBalanceReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfTrialBalanceReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTrialBalanceReportPropertyNames('asOfDate', 'balanced', 'entryNumberGaps', 'generatedAt', 'rows', 'totalCredit', 'totalDebit');
    const optionalStringProperties = createTrialBalanceReportOptionalProperties({ name: 'asOfDate', nullable: false }, { name: 'generatedAt', nullable: false });
    const optionalNumberProperties = createTrialBalanceReportOptionalProperties({ name: 'totalCredit', nullable: false }, { name: 'totalDebit', nullable: false });
    const optionalBooleanProperties = createTrialBalanceReportOptionalProperties({ name: 'balanced', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTrialBalanceReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTrialBalanceReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTrialBalanceReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTrialBalanceRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTrialBalanceRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTrialBalanceRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfTrialBalanceRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTrialBalanceRowPropertyNames('accountId', 'accountName', 'accountNumber', 'balance', 'totalCredit', 'totalDebit');
    const optionalStringProperties = createTrialBalanceRowOptionalProperties({ name: 'accountId', nullable: false }, { name: 'accountName', nullable: false }, { name: 'accountNumber', nullable: false });
    const optionalNumberProperties = createTrialBalanceRowOptionalProperties({ name: 'balance', nullable: false }, { name: 'totalCredit', nullable: false }, { name: 'totalDebit', nullable: false });
    const optionalBooleanProperties = createTrialBalanceRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTrialBalanceRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTrialBalanceRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTrialBalanceRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VendorBillListRowStatusEnum;
(function (VendorBillListRowStatusEnum) {
    VendorBillListRowStatusEnum["PendingReceiptMatch"] = "PENDING_RECEIPT_MATCH";
    VendorBillListRowStatusEnum["MatchException"] = "MATCH_EXCEPTION";
    VendorBillListRowStatusEnum["Approved"] = "APPROVED";
    VendorBillListRowStatusEnum["Rejected"] = "REJECTED";
    VendorBillListRowStatusEnum["Paid"] = "PAID";
    VendorBillListRowStatusEnum["Voided"] = "VOIDED";
})(VendorBillListRowStatusEnum || (VendorBillListRowStatusEnum = {}));
;
function isOptionalVendorBillListRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorBillListRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorBillListRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorBillListRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorBillListRowPropertyNames('amount', 'billId', 'status', 'vendorId');
    const optionalStringProperties = createVendorBillListRowOptionalProperties({ name: 'billId', nullable: false }, { name: 'dueDate', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createVendorBillListRowOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createVendorBillListRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorBillListRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorBillListRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorBillListRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalVendorBillMatchCandidateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorBillMatchCandidateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorBillMatchCandidateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorBillMatchCandidateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorBillMatchCandidateResponsePropertyNames('candidateId', 'invoiceEventId', 'vendorBillId');
    const optionalStringProperties = createVendorBillMatchCandidateResponseOptionalProperties({ name: 'billNumber', nullable: false }, { name: 'candidateId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'invoiceEventId', nullable: false }, { name: 'scoreBreakdown', nullable: false }, { name: 'vendorBillId', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createVendorBillMatchCandidateResponseOptionalProperties({ name: 'billTotalAmount', nullable: false }, { name: 'matchScore', nullable: false });
    const optionalBooleanProperties = createVendorBillMatchCandidateResponseOptionalProperties({ name: 'resolved', nullable: false }, { name: 'selected', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorBillMatchCandidateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorBillMatchCandidateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorBillMatchCandidateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VendorBillResponseStatusEnum;
(function (VendorBillResponseStatusEnum) {
    VendorBillResponseStatusEnum["PendingReceiptMatch"] = "PENDING_RECEIPT_MATCH";
    VendorBillResponseStatusEnum["MatchException"] = "MATCH_EXCEPTION";
    VendorBillResponseStatusEnum["Approved"] = "APPROVED";
    VendorBillResponseStatusEnum["Rejected"] = "REJECTED";
    VendorBillResponseStatusEnum["Paid"] = "PAID";
    VendorBillResponseStatusEnum["Voided"] = "VOIDED";
})(VendorBillResponseStatusEnum || (VendorBillResponseStatusEnum = {}));
;
function isOptionalVendorBillResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorBillResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorBillResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorBillResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorBillResponsePropertyNames('billNumber', 'createdAt', 'status', 'totalAmount', 'vendorBillId', 'vendorId');
    const optionalStringProperties = createVendorBillResponseOptionalProperties({ name: 'approvalJustification', nullable: false }, { name: 'billDate', nullable: false }, { name: 'billNumber', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'dueDate', nullable: false }, { name: 'journalEntryId', nullable: false }, { name: 'originEventId', nullable: false }, { name: 'originEventType', nullable: false }, { name: 'paymentTransactionId', nullable: false }, { name: 'rejectionReason', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorBillId', nullable: false }, { name: 'vendorId', nullable: false }, { name: 'vendorName', nullable: false });
    const optionalNumberProperties = createVendorBillResponseOptionalProperties({ name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createVendorBillResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorBillResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorBillResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorBillResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VendorBillSummaryResponseStatusEnum;
(function (VendorBillSummaryResponseStatusEnum) {
    VendorBillSummaryResponseStatusEnum["PendingReceiptMatch"] = "PENDING_RECEIPT_MATCH";
    VendorBillSummaryResponseStatusEnum["MatchException"] = "MATCH_EXCEPTION";
    VendorBillSummaryResponseStatusEnum["Approved"] = "APPROVED";
    VendorBillSummaryResponseStatusEnum["Rejected"] = "REJECTED";
    VendorBillSummaryResponseStatusEnum["Paid"] = "PAID";
    VendorBillSummaryResponseStatusEnum["Voided"] = "VOIDED";
})(VendorBillSummaryResponseStatusEnum || (VendorBillSummaryResponseStatusEnum = {}));
;
function isOptionalVendorBillSummaryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorBillSummaryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorBillSummaryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorBillSummaryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorBillSummaryResponsePropertyNames('billNumber', 'status', 'totalAmount', 'vendorBillId', 'vendorId');
    const optionalStringProperties = createVendorBillSummaryResponseOptionalProperties({ name: 'billDate', nullable: false }, { name: 'billNumber', nullable: false }, { name: 'dueDate', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorBillId', nullable: false }, { name: 'vendorId', nullable: false }, { name: 'vendorName', nullable: false });
    const optionalNumberProperties = createVendorBillSummaryResponseOptionalProperties({ name: 'openAmount', nullable: false }, { name: 'totalAmount', nullable: false });
    const optionalBooleanProperties = createVendorBillSummaryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorBillSummaryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorBillSummaryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorBillSummaryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalVendorInvoiceReceivedEventPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorInvoiceReceivedEventPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorInvoiceReceivedEventOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorInvoiceReceivedEvent(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorInvoiceReceivedEventPropertyNames('eventId', 'invoiceDate', 'invoiceReference', 'lineItems', 'organizationId', 'vendorId');
    const optionalStringProperties = createVendorInvoiceReceivedEventOptionalProperties({ name: 'dueDate', nullable: false }, { name: 'eventId', nullable: false }, { name: 'invoiceDate', nullable: false }, { name: 'invoiceReference', nullable: false }, { name: 'organizationId', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createVendorInvoiceReceivedEventOptionalProperties();
    const optionalBooleanProperties = createVendorInvoiceReceivedEventOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorInvoiceReceivedEventPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorInvoiceReceivedEventPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorInvoiceReceivedEventPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VendorResponseStatusEnum;
(function (VendorResponseStatusEnum) {
    VendorResponseStatusEnum["Active"] = "ACTIVE";
    VendorResponseStatusEnum["Inactive"] = "INACTIVE";
})(VendorResponseStatusEnum || (VendorResponseStatusEnum = {}));
;
function isOptionalVendorResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorResponsePropertyNames('name', 'vendorId');
    const optionalStringProperties = createVendorResponseOptionalProperties({ name: 'name', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorId', nullable: false }, { name: 'vendorNumber', nullable: false });
    const optionalNumberProperties = createVendorResponseOptionalProperties();
    const optionalBooleanProperties = createVendorResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalVendorSpendReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorSpendReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorSpendReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorSpendReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorSpendReportPropertyNames('endDate', 'generatedAt', 'limit', 'rows', 'startDate', 'truncated');
    const optionalStringProperties = createVendorSpendReportOptionalProperties({ name: 'endDate', nullable: false }, { name: 'generatedAt', nullable: false }, { name: 'startDate', nullable: false });
    const optionalNumberProperties = createVendorSpendReportOptionalProperties({ name: 'limit', nullable: false });
    const optionalBooleanProperties = createVendorSpendReportOptionalProperties({ name: 'truncated', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorSpendReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorSpendReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorSpendReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalVendorSpendRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVendorSpendRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVendorSpendRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfVendorSpendRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVendorSpendRowPropertyNames('avgBillAmount', 'billCount', 'paidAmount', 'vendorId');
    const optionalStringProperties = createVendorSpendRowOptionalProperties({ name: 'name', nullable: true }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createVendorSpendRowOptionalProperties({ name: 'avgBillAmount', nullable: false }, { name: 'billCount', nullable: false }, { name: 'paidAmount', nullable: false });
    const optionalBooleanProperties = createVendorSpendRowOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVendorSpendRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVendorSpendRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVendorSpendRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Accounting Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalVoidCreditMemoRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVoidCreditMemoRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVoidCreditMemoRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfVoidCreditMemoRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVoidCreditMemoRequestPropertyNames('voidReason');
    const optionalStringProperties = createVoidCreditMemoRequestOptionalProperties({ name: 'voidReason', nullable: false });
    const optionalNumberProperties = createVoidCreditMemoRequestOptionalProperties();
    const optionalBooleanProperties = createVoidCreditMemoRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVoidCreditMemoRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVoidCreditMemoRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVoidCreditMemoRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { APPaymentResponseStatusEnum, APPaymentsService, AccountingAnalyticsService, AccountingEventResponseStatusEnum, AccountingEventsService, AccountingExportsService, AccountingPeriodResponseStatusEnum, AccountingPeriodsService, AdjustmentTypeResponseCodeEnum, ApiModule, ApplicationDetailInvoiceStatusEnum, AuditTrailResponseAccountingIntentEnum, AuditTrailResponseAccountingStatusEnum, AuditTrailResponseCancellationTypeEnum, AuditTrailResponseExceptionTypeEnum, AuditTrailResponseOriginalPaymentStatusEnum, AuditTrailResponsePolicyValidationResultEnum, AuditTrailResponseRefundMethodEnum, AuditTrailResponseRefundTypeEnum, AuditTrailService, BASE_PATH, BankReconciliationAdjustmentResponseTypeEnum, BankReconciliationLineResponseStatusEnum, BankReconciliationResponseStatusEnum, BankReconciliationService, COLLECTION_FORMATS, CancellationRequestCancellationTypeEnum, Configuration, CreditMemoResponseStatusEnum, CreditMemosService, CustomerCreditResponseStatusEnum, CustomerCreditTransactionResponseTransactionTypeEnum, CustomerCreditsService, DefaultGLMappingsService, ExceptionResolutionRequestResolutionActionEnum, ExecuteAPPaymentRequestPaymentMethodEnum, FinancialReportingForTaxLiabilityService, FinancialReportingService, GLAccountCreateRequestAccountSubtypeEnum, GLAccountCreateRequestAccountTypeEnum, GLAccountResponseAccountSubtypeEnum, GLAccountResponseAccountTypeEnum, GLAccountResponseStatusEnum, GLAccountUpdateRequestAccountSubtypeEnum, GLAccountsService, GLMappingAPIService, InvoicePaymentsService, InvoiceStatusResponseStatusEnum, JournalEntriesService, JournalEntryResponseStatusEnum, LaborOverheadReportLineCostTypeEnum, LocationCostReportingService, MappingKeysService, PaymentApplicationRequestAllocationStrategyEnum, PaymentApplicationsService, PostingCategoriesService, PostingRuleVersionResponseStateEnum, PostingRulesService, ReconciliationAdjustmentRequestTypeEnum, RefundRequestOriginalPaymentStatusEnum, RefundRequestRefundTypeEnum, ReportExportRequestFormatEnum, ReportExportResponseFormatEnum, ReportExportResponseStatusEnum, ReprocessingAttemptHistoryResponseOutcomeEnum, SettlementLineResponseLineTypeEnum, SettlementLineResponseMatchStatusEnum, SettlementLineResponseMatchedPaymentTypeEnum, SettlementReconciliationService, VendorBillAPIService, VendorBillListRowStatusEnum, VendorBillResponseStatusEnum, VendorBillSummaryResponseStatusEnum, VendorDirectoryAPIService, VendorResponseStatusEnum, instanceOfAPPaymentResponse, instanceOfAccountDrilldownResponse, instanceOfAccountingEventResponse, instanceOfAccountingEventSubmitRequest, instanceOfAccountingPeriodReopenRequest, instanceOfAccountingPeriodResponse, instanceOfAdjustmentTypeResponse, instanceOfAgedPayablesReport, instanceOfAgedPayablesRow, instanceOfAgedReceivablesReport, instanceOfAgedReceivablesRow, instanceOfAgingSummary, instanceOfAllocationLineRequest, instanceOfAllocationLineResponse, instanceOfApiError, instanceOfApplicationDetail, instanceOfAuditTrailResponse, instanceOfBalanceSheetReport, instanceOfBankReconciliationAdjustmentResponse, instanceOfBankReconciliationImportRequest, instanceOfBankReconciliationLineResponse, instanceOfBankReconciliationListResponse, instanceOfBankReconciliationResponse, instanceOfBillingRuleRefResponse, instanceOfCancellationRequest, instanceOfCandidateSelectionRequest, instanceOfCollectionsAnalyticsReport, instanceOfContractField, instanceOfCreateCreditMemoRequest, instanceOfCreditMemoResponse, instanceOfCustomerCreditApplicationRequest, instanceOfCustomerCreditInfo, instanceOfCustomerCreditRefundRequest, instanceOfCustomerCreditResponse, instanceOfCustomerCreditTransactionResponse, instanceOfDefaultGLMappingListResponse, instanceOfDefaultGLMappingRequest, instanceOfDefaultGLMappingResponse, instanceOfEntry, instanceOfEntryNumberGapCheck, instanceOfEventEnvelopeContract, instanceOfEventProcessingLogEntry, instanceOfExceptionResolutionRequest, instanceOfExecuteAPPaymentRequest, instanceOfExportJobRequest, instanceOfExportJobResponse, instanceOfFieldError, instanceOfGLAccountActivateRequest, instanceOfGLAccountBalanceResponse, instanceOfGLAccountCreateRequest, instanceOfGLAccountListResponse, instanceOfGLAccountResponse, instanceOfGLAccountUpdateRequest, instanceOfGLMappingCreateRequest, instanceOfGLMappingCreateResponse, instanceOfGLMappingResolveRequest, instanceOfGLMappingResolveResponse, instanceOfGLMappingResponse, instanceOfGeneralLedgerAccountSection, instanceOfGeneralLedgerLine, instanceOfGeneralLedgerReport, instanceOfGoodsReceivedEvent, instanceOfHardLockDateResponse, instanceOfHardLockDateUpdateRequest, instanceOfIncomeStatementReport, instanceOfInvoiceApplication, instanceOfInvoiceGenerationResponse, instanceOfInvoiceLineItem, instanceOfInvoiceStatusResponse, instanceOfJournalEntryCreateRequest, instanceOfJournalEntryLineRequest, instanceOfJournalEntryLineResponse, instanceOfJournalEntryPostRequest, instanceOfJournalEntryResponse, instanceOfJournalEntryReversalRequest, instanceOfJournalEntryTraceabilityResponse, instanceOfJournalLineDrilldownResponse, instanceOfLaborOverheadCostReport, instanceOfLaborOverheadReportLine, instanceOfMappingKeyCreateRequest, instanceOfMappingKeyListResponse, instanceOfMappingKeyResponse, instanceOfMappingKeyUpdateRequest, instanceOfMappingResolutionTestRequest, instanceOfMappingResolutionTestResponse, instanceOfMatchedMapping, instanceOfMatchedRule, instanceOfPageAccountingEventResponse, instanceOfPageCreditMemoResponse, instanceOfPageCustomerCreditResponse, instanceOfPageExportJobResponse, instanceOfPagePaymentApplicationListRow, instanceOfPageReportExportResponse, instanceOfPageVendorBillListRow, instanceOfPageVendorBillSummaryResponse, instanceOfPageableObject, instanceOfPagedResponseJournalEntryResponse, instanceOfPaymentApplicationListRow, instanceOfPaymentApplicationRequest, instanceOfPaymentApplicationResponse, instanceOfPaymentApplicationReversalRequest, instanceOfPaymentLagCohortRow, instanceOfPaymentLagCohortsReport, instanceOfPostingCategoryCreateRequest, instanceOfPostingCategoryListResponse, instanceOfPostingCategoryResponse, instanceOfPostingCategoryUpdateRequest, instanceOfPostingRuleSetCreateRequest, instanceOfPostingRuleSetListResponse, instanceOfPostingRuleSetResponse, instanceOfPostingRuleVersionResponse, instanceOfPredicateEvaluation, instanceOfPriceOverrideRequest, instanceOfReceivedLineItem, instanceOfReconciliationAdjustmentRequest, instanceOfReconciliationAuditResponse, instanceOfReconciliationMatchRequest, instanceOfReconciliationReportResponse, instanceOfReconciliationUnmatchRequest, instanceOfRefundRequest, instanceOfRegenerateInvoiceFromWorkorderRequest, instanceOfReportExportRequest, instanceOfReportExportResponse, instanceOfReprocessEventRequest, instanceOfReprocessingAttemptHistoryResponse, instanceOfResolvedLine, instanceOfSettlementLineResponse, instanceOfSettlementManualMatchRequest, instanceOfSettlementWriteOffRequest, instanceOfSortObject, instanceOfTaxLiabilityReconciliation, instanceOfTaxLiabilityReport, instanceOfTaxLiabilityRow, instanceOfTaxLiabilitySnapshotResponse, instanceOfTaxLiabilitySnapshotSummary, instanceOfTaxLiabilitySnapshotVerification, instanceOfTrialBalanceReport, instanceOfTrialBalanceRow, instanceOfVendorBillListRow, instanceOfVendorBillMatchCandidateResponse, instanceOfVendorBillResponse, instanceOfVendorBillSummaryResponse, instanceOfVendorInvoiceReceivedEvent, instanceOfVendorResponse, instanceOfVendorSpendReport, instanceOfVendorSpendRow, instanceOfVoidCreditMemoRequest, provideApi };
//# sourceMappingURL=durion-sdk-accounting.mjs.map
