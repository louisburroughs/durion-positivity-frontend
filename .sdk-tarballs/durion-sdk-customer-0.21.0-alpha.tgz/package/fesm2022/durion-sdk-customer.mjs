import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/customer';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMAccountsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    browseParties(page, size, sort, name, status, partyType, customerNumber, sortField, sortOrder, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'name', name, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'partyType', partyType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerNumber', customerNumber, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sortField', sortField, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sortOrder', sortOrder, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    checkPartyDuplicates(legalName, observe = 'body', reportProgress = false, options) {
        if (legalName === null || legalName === undefined) {
            throw new Error('Required parameter legalName was null or undefined when calling checkPartyDuplicates.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'legalName', legalName, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/duplicate-check`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createCrmCommercialAccount(createCommercialAccountRequest, observe = 'body', reportProgress = false, options) {
        if (createCommercialAccountRequest === null || createCommercialAccountRequest === undefined) {
            throw new Error('Required parameter createCommercialAccountRequest was null or undefined when calling createCrmCommercialAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createCommercialAccountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createVehicleForParty(partyId, createVehicleForPartyRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling createVehicleForParty.');
        }
        if (createVehicleForPartyRequest === null || createVehicleForPartyRequest === undefined) {
            throw new Error('Required parameter createVehicleForPartyRequest was null or undefined when calling createVehicleForParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createVehicleForPartyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAccountCommunicationPreferences(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getAccountCommunicationPreferences.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAccountTier(accountId, observe = 'body', reportProgress = false, options) {
        if (accountId === null || accountId === undefined) {
            throw new Error('Required parameter accountId was null or undefined when calling getAccountTier.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/${this.configuration.encodeParam({ name: "accountId", value: accountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tier`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getParty(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listBillingTerms(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/billing-terms`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    mergeParties(partyId, mergePartiesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling mergeParties.');
        }
        if (mergePartiesRequest === null || mergePartiesRequest === undefined) {
            throw new Error('Required parameter mergePartiesRequest was null or undefined when calling mergeParties.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/merge`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: mergePartiesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    replayPartyFacts(afterPartyId, updatedSince, limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'afterPartyId', afterPartyId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'updatedSince', updatedSince, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/facts/replay`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveAccountTier(resolveAccountTierRequest, observe = 'body', reportProgress = false, options) {
        if (resolveAccountTierRequest === null || resolveAccountTierRequest === undefined) {
            throw new Error('Required parameter resolveAccountTierRequest was null or undefined when calling resolveAccountTier.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/tierResolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: resolveAccountTierRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolvePartyNames(partyNameResolveRequest, observe = 'body', reportProgress = false, options) {
        if (partyNameResolveRequest === null || partyNameResolveRequest === undefined) {
            throw new Error('Required parameter partyNameResolveRequest was null or undefined when calling resolvePartyNames.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties:resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: partyNameResolveRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchParties(searchPartiesRequest, observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: searchPartiesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertAccountCommunicationPreferences(partyId, upsertCommunicationPreferencesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertAccountCommunicationPreferences.');
        }
        if (upsertCommunicationPreferencesRequest === null || upsertCommunicationPreferencesRequest === undefined) {
            throw new Error('Required parameter upsertCommunicationPreferencesRequest was null or undefined when calling upsertAccountCommunicationPreferences.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertCommunicationPreferencesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertPartyBillingRules(partyId, upsertBillingRulesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertPartyBillingRules.');
        }
        if (upsertBillingRulesRequest === null || upsertBillingRulesRequest === undefined) {
            throw new Error('Required parameter upsertBillingRulesRequest was null or undefined when calling upsertPartyBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/billing-rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertBillingRulesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMAccountsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMAccountsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMAccountsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMCommunicationPreferencesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getCommunicationPreferences(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getCommunicationPreferences.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertCommunicationPreferences(partyId, upsertCommunicationPreferencesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertCommunicationPreferences.');
        }
        if (upsertCommunicationPreferencesRequest === null || upsertCommunicationPreferencesRequest === undefined) {
            throw new Error('Required parameter upsertCommunicationPreferencesRequest was null or undefined when calling upsertCommunicationPreferences.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertCommunicationPreferencesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMCommunicationPreferencesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMCommunicationPreferencesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMCommunicationPreferencesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMContactsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getContactsWithRoles(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getContactsWithRoles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateContactRoles(partyId, contactId, updateContactRolesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling updateContactRoles.');
        }
        if (contactId === null || contactId === undefined) {
            throw new Error('Required parameter contactId was null or undefined when calling updateContactRoles.');
        }
        if (updateContactRolesRequest === null || updateContactRolesRequest === undefined) {
            throw new Error('Required parameter updateContactRolesRequest was null or undefined when calling updateContactRoles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts/${this.configuration.encodeParam({ name: "contactId", value: contactId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateContactRolesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMContactsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMContactsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMContactsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMFollowUpsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignFollowUpTask(taskId, assignedTo, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling assignFollowUpTask.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'assignedTo', assignedTo, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/follow-ups/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/assignee`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    completeFollowUpTask(taskId, closeFollowUpTaskRequest, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling completeFollowUpTask.');
        }
        if (closeFollowUpTaskRequest === null || closeFollowUpTaskRequest === undefined) {
            throw new Error('Required parameter closeFollowUpTaskRequest was null or undefined when calling completeFollowUpTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/follow-ups/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/complete`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: closeFollowUpTaskRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createFollowUpTask(partyId, createFollowUpTaskRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling createFollowUpTask.');
        }
        if (createFollowUpTaskRequest === null || createFollowUpTaskRequest === undefined) {
            throw new Error('Required parameter createFollowUpTaskRequest was null or undefined when calling createFollowUpTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/follow-ups`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createFollowUpTaskRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    dismissFollowUpTask(taskId, closeFollowUpTaskRequest, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling dismissFollowUpTask.');
        }
        if (closeFollowUpTaskRequest === null || closeFollowUpTaskRequest === undefined) {
            throw new Error('Required parameter closeFollowUpTaskRequest was null or undefined when calling dismissFollowUpTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/follow-ups/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/dismiss`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: closeFollowUpTaskRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getFollowUpQueue(status, assignedTo, type, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'assignedTo', assignedTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'type', type, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/follow-ups`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getFollowUpTask(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling getFollowUpTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/follow-ups/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPartyFollowUps(partyId, status, page, size, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling listPartyFollowUps.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/follow-ups`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMFollowUpsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMFollowUpsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMFollowUpsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMInquiriesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignInquiry(inquiryId, assignedTo, observe = 'body', reportProgress = false, options) {
        if (inquiryId === null || inquiryId === undefined) {
            throw new Error('Required parameter inquiryId was null or undefined when calling assignInquiry.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'assignedTo', assignedTo, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/inquiries/${this.configuration.encodeParam({ name: "inquiryId", value: inquiryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/assignee`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    captureInquiry(submitInquiryRequest, observe = 'body', reportProgress = false, options) {
        if (submitInquiryRequest === null || submitInquiryRequest === undefined) {
            throw new Error('Required parameter submitInquiryRequest was null or undefined when calling captureInquiry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/inquiries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitInquiryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    convertInquiry(inquiryId, existingPartyId, observe = 'body', reportProgress = false, options) {
        if (inquiryId === null || inquiryId === undefined) {
            throw new Error('Required parameter inquiryId was null or undefined when calling convertInquiry.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'existingPartyId', existingPartyId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/inquiries/${this.configuration.encodeParam({ name: "inquiryId", value: inquiryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/convert`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getInquiry(inquiryId, observe = 'body', reportProgress = false, options) {
        if (inquiryId === null || inquiryId === undefined) {
            throw new Error('Required parameter inquiryId was null or undefined when calling getInquiry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/inquiries/${this.configuration.encodeParam({ name: "inquiryId", value: inquiryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listInquiries(status, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/inquiries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateInquiryStatus(inquiryId, status, resolutionNote, observe = 'body', reportProgress = false, options) {
        if (inquiryId === null || inquiryId === undefined) {
            throw new Error('Required parameter inquiryId was null or undefined when calling updateInquiryStatus.');
        }
        if (status === null || status === undefined) {
            throw new Error('Required parameter status was null or undefined when calling updateInquiryStatus.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'resolutionNote', resolutionNote, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/inquiries/${this.configuration.encodeParam({ name: "inquiryId", value: inquiryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/status`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMInquiriesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMInquiriesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMInquiriesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMInteractionsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listPartyInteractions(partyId, type, page, size, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling listPartyInteractions.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'type', type, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/interactions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordInteraction(partyId, recordInteractionRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling recordInteraction.');
        }
        if (recordInteractionRequest === null || recordInteractionRequest === undefined) {
            throw new Error('Required parameter recordInteractionRequest was null or undefined when calling recordInteraction.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/interactions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: recordInteractionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMInteractionsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMInteractionsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMInteractionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMMarketingConsentService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getConsentHistory(partyId, page, size, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getConsentHistory.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/consent-history`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getMarketingConsent(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getMarketingConsent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/marketing-consent`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveMarketingEligibility(partyId, channel, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling resolveMarketingEligibility.');
        }
        if (channel === null || channel === undefined) {
            throw new Error('Required parameter channel was null or undefined when calling resolveMarketingEligibility.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'channel', channel, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/marketing-eligibility`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    setAccountMarketingGate(partyId, optOut, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling setAccountMarketingGate.');
        }
        if (optOut === null || optOut === undefined) {
            throw new Error('Required parameter optOut was null or undefined when calling setAccountMarketingGate.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'optOut', optOut, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/marketing-consent/account-gate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateMarketingConsent(partyId, updateMarketingConsentRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling updateMarketingConsent.');
        }
        if (updateMarketingConsentRequest === null || updateMarketingConsentRequest === undefined) {
            throw new Error('Required parameter updateMarketingConsentRequest was null or undefined when calling updateMarketingConsent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/marketing-consent`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateMarketingConsentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMMarketingConsentService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMMarketingConsentService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMMarketingConsentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMPartyRelationshipsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPartyRelationship(partyId, createPartyRelationshipRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling createPartyRelationship.');
        }
        if (createPartyRelationshipRequest === null || createPartyRelationshipRequest === undefined) {
            throw new Error('Required parameter createPartyRelationshipRequest was null or undefined when calling createPartyRelationship.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/relationships`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createPartyRelationshipRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivatePartyRelationship(partyId, relationshipId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling deactivatePartyRelationship.');
        }
        if (relationshipId === null || relationshipId === undefined) {
            throw new Error('Required parameter relationshipId was null or undefined when calling deactivatePartyRelationship.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/relationships/${this.configuration.encodeParam({ name: "relationshipId", value: relationshipId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    designatePrimaryBillingContact(partyId, relationshipId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling designatePrimaryBillingContact.');
        }
        if (relationshipId === null || relationshipId === undefined) {
            throw new Error('Required parameter relationshipId was null or undefined when calling designatePrimaryBillingContact.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/relationships/${this.configuration.encodeParam({ name: "relationshipId", value: relationshipId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/primary-billing`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCommercialAccountContacts(partyId, roles, status, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getCommercialAccountContacts.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'roles', roles, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPartyRelationshipsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPartyRelationshipsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPartyRelationshipsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMPersonLinkReconciliationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    reconcilePersonLinks(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/admin/person-links/reconcile`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPersonLinkReconciliationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPersonLinkReconciliationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPersonLinkReconciliationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMPersonsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCrmPerson(createPersonRequest, observe = 'body', reportProgress = false, options) {
        if (createPersonRequest === null || createPersonRequest === undefined) {
            throw new Error('Required parameter createPersonRequest was null or undefined when calling createCrmPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/persons`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createPersonRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPerson(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/persons/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchPersons(name, email, phone, limit, offset, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'name', name, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'email', email, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'phone', phone, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'offset', offset, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/persons`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPersonsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPersonsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPersonsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMPublicInquiryService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    submitPublicInquiry(submitInquiryRequest, observe = 'body', reportProgress = false, options) {
        if (submitInquiryRequest === null || submitInquiryRequest === undefined) {
            throw new Error('Required parameter submitInquiryRequest was null or undefined when calling submitPublicInquiry.');
        }
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/public/inquiries`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitInquiryRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPublicInquiryService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPublicInquiryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMPublicInquiryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMSegmentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addSegmentMembers(segmentId, segmentMembersRequest, observe = 'body', reportProgress = false, options) {
        if (segmentId === null || segmentId === undefined) {
            throw new Error('Required parameter segmentId was null or undefined when calling addSegmentMembers.');
        }
        if (segmentMembersRequest === null || segmentMembersRequest === undefined) {
            throw new Error('Required parameter segmentMembersRequest was null or undefined when calling addSegmentMembers.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/${this.configuration.encodeParam({ name: "segmentId", value: segmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/members`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: segmentMembersRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createSegment(upsertSegmentRequest, observe = 'body', reportProgress = false, options) {
        if (upsertSegmentRequest === null || upsertSegmentRequest === undefined) {
            throw new Error('Required parameter upsertSegmentRequest was null or undefined when calling createSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertSegmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteSegment(segmentId, observe = 'body', reportProgress = false, options) {
        if (segmentId === null || segmentId === undefined) {
            throw new Error('Required parameter segmentId was null or undefined when calling deleteSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/${this.configuration.encodeParam({ name: "segmentId", value: segmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getSegment(segmentId, observe = 'body', reportProgress = false, options) {
        if (segmentId === null || segmentId === undefined) {
            throw new Error('Required parameter segmentId was null or undefined when calling getSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/${this.configuration.encodeParam({ name: "segmentId", value: segmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSegmentAttributes(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/attributes`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSegments(audienceType, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'audienceType', audienceType, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeSegmentMember(segmentId, partyId, observe = 'body', reportProgress = false, options) {
        if (segmentId === null || segmentId === undefined) {
            throw new Error('Required parameter segmentId was null or undefined when calling removeSegmentMember.');
        }
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling removeSegmentMember.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/${this.configuration.encodeParam({ name: "segmentId", value: segmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/members/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveSegment(segmentId, channel, sampleSize, observe = 'body', reportProgress = false, options) {
        if (segmentId === null || segmentId === undefined) {
            throw new Error('Required parameter segmentId was null or undefined when calling resolveSegment.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'channel', channel, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sampleSize', sampleSize, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/${this.configuration.encodeParam({ name: "segmentId", value: segmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateSegment(segmentId, upsertSegmentRequest, observe = 'body', reportProgress = false, options) {
        if (segmentId === null || segmentId === undefined) {
            throw new Error('Required parameter segmentId was null or undefined when calling updateSegment.');
        }
        if (upsertSegmentRequest === null || upsertSegmentRequest === undefined) {
            throw new Error('Required parameter upsertSegmentRequest was null or undefined when calling updateSegment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/segments/${this.configuration.encodeParam({ name: "segmentId", value: segmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertSegmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSegmentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSegmentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSegmentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMSnapshotsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getPartyBillingRules(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getPartyBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/snapshot/party/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/billing-rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getSnapshotByParty(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getSnapshotByParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/snapshot/party/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getSnapshotByVehicle(vehicleId, observe = 'body', reportProgress = false, options) {
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling getSnapshotByVehicle.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/snapshot/vehicle/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSnapshotsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSnapshotsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSnapshotsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMSuppressionService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addSuppressionEntry(addSuppressionRequest, observe = 'body', reportProgress = false, options) {
        if (addSuppressionRequest === null || addSuppressionRequest === undefined) {
            throw new Error('Required parameter addSuppressionRequest was null or undefined when calling addSuppressionEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/suppression`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: addSuppressionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    checkAddressSuppression(channel, address, observe = 'body', reportProgress = false, options) {
        if (channel === null || channel === undefined) {
            throw new Error('Required parameter channel was null or undefined when calling checkAddressSuppression.');
        }
        if (address === null || address === undefined) {
            throw new Error('Required parameter address was null or undefined when calling checkAddressSuppression.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'channel', channel, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'address', address, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/suppression/check`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSuppressionEntries(channel, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'channel', channel, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/suppression`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeSuppressionEntry(suppressionId, observe = 'body', reportProgress = false, options) {
        if (suppressionId === null || suppressionId === undefined) {
            throw new Error('Required parameter suppressionId was null or undefined when calling removeSuppressionEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/suppression/${this.configuration.encodeParam({ name: "suppressionId", value: suppressionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSuppressionService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSuppressionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMSuppressionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMTagsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignTagToParty(partyId, assignPartyTagRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling assignTagToParty.');
        }
        if (assignPartyTagRequest === null || assignPartyTagRequest === undefined) {
            throw new Error('Required parameter assignPartyTagRequest was null or undefined when calling assignTagToParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tags`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: assignPartyTagRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createTag(upsertPartyTagRequest, observe = 'body', reportProgress = false, options) {
        if (upsertPartyTagRequest === null || upsertPartyTagRequest === undefined) {
            throw new Error('Required parameter upsertPartyTagRequest was null or undefined when calling createTag.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/tags`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertPartyTagRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteTag(tagId, observe = 'body', reportProgress = false, options) {
        if (tagId === null || tagId === undefined) {
            throw new Error('Required parameter tagId was null or undefined when calling deleteTag.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/tags/${this.configuration.encodeParam({ name: "tagId", value: tagId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTag(tagId, observe = 'body', reportProgress = false, options) {
        if (tagId === null || tagId === undefined) {
            throw new Error('Required parameter tagId was null or undefined when calling getTag.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/tags/${this.configuration.encodeParam({ name: "tagId", value: tagId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPartyTags(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling listPartyTags.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tags`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTags(includeInactive, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeInactive', includeInactive, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/tags`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeTagFromParty(partyId, tagId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling removeTagFromParty.');
        }
        if (tagId === null || tagId === undefined) {
            throw new Error('Required parameter tagId was null or undefined when calling removeTagFromParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tags/${this.configuration.encodeParam({ name: "tagId", value: tagId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateTag(tagId, upsertPartyTagRequest, observe = 'body', reportProgress = false, options) {
        if (tagId === null || tagId === undefined) {
            throw new Error('Required parameter tagId was null or undefined when calling updateTag.');
        }
        if (upsertPartyTagRequest === null || upsertPartyTagRequest === undefined) {
            throw new Error('Required parameter upsertPartyTagRequest was null or undefined when calling updateTag.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/tags/${this.configuration.encodeParam({ name: "tagId", value: tagId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertPartyTagRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMTagsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMTagsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMTagsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMVehiclesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getVehicleForCustomer(customerId, vehicleId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling getVehicleForCustomer.');
        }
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling getVehicleForCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listVehiclesForCustomer(customerId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling listVehiclesForCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMVehiclesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMVehiclesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CRMVehiclesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CommercialBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestCommercialAccounts(bulkIngestRequestCommercialBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestCommercialBulkIngestRecord === null || bulkIngestRequestCommercialBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestCommercialBulkIngestRecord was null or undefined when calling bulkIngestCommercialAccounts.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/customer/commercial/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestCommercialBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CommercialBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CommercialBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CommercialBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CustomerAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCustomer(customerDTO, observe = 'body', reportProgress = false, options) {
        if (customerDTO === null || customerDTO === undefined) {
            throw new Error('Required parameter customerDTO was null or undefined when calling createCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: customerDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteCustomer(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling deleteCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCustomerById(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getCustomerById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCustomers(customerType, name, email, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerType', customerType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'name', name, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'email', email, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCustomer(id, customerDTO, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateCustomer.');
        }
        if (customerDTO === null || customerDTO === undefined) {
            throw new Error('Required parameter customerDTO was null or undefined when calling updateCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: customerDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CustomerBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestCustomers(bulkIngestRequestCustomerBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestCustomerBulkIngestRecord === null || bulkIngestRequestCustomerBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestCustomerBulkIngestRecord was null or undefined when calling bulkIngestCustomers.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/customer/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestCustomerBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CustomerRequirementsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    checkCustomerRequirementsMet(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling checkCustomerRequirementsMet.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/customers/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/requirements-met`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerRequirementsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerRequirementsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CustomerRequirementsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PromotionRedemptionsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listPromotionRedemptionsByCustomer(customerId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling listPromotionRedemptionsByCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/promotions/redemptions/by-customer/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordPromotionRedemption(recordRedemptionRequest, observe = 'body', reportProgress = false, options) {
        if (recordRedemptionRequest === null || recordRedemptionRequest === undefined) {
            throw new Error('Required parameter recordRedemptionRequest was null or undefined when calling recordPromotionRedemption.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/promotions/redemptions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: recordRedemptionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PromotionRedemptionsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PromotionRedemptionsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PromotionRedemptionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAccountSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountSummaryPropertyNames('accountName', 'accountNumber', 'accountType', 'partyId');
    const optionalStringProperties = createAccountSummaryOptionalProperties({ name: 'accountName', nullable: false }, { name: 'accountNumber', nullable: false }, { name: 'accountType', nullable: false }, { name: 'partyId', nullable: false });
    const optionalNumberProperties = createAccountSummaryOptionalProperties();
    const optionalBooleanProperties = createAccountSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AddSuppressionRequestChannelEnum;
(function (AddSuppressionRequestChannelEnum) {
    AddSuppressionRequestChannelEnum["Email"] = "EMAIL";
    AddSuppressionRequestChannelEnum["Sms"] = "SMS";
})(AddSuppressionRequestChannelEnum || (AddSuppressionRequestChannelEnum = {}));
;
var AddSuppressionRequestReasonEnum;
(function (AddSuppressionRequestReasonEnum) {
    AddSuppressionRequestReasonEnum["HardBounce"] = "HARD_BOUNCE";
    AddSuppressionRequestReasonEnum["SpamComplaint"] = "SPAM_COMPLAINT";
    AddSuppressionRequestReasonEnum["LegalDnc"] = "LEGAL_DNC";
    AddSuppressionRequestReasonEnum["Manual"] = "MANUAL";
    AddSuppressionRequestReasonEnum["UnsubscribeLink"] = "UNSUBSCRIBE_LINK";
})(AddSuppressionRequestReasonEnum || (AddSuppressionRequestReasonEnum = {}));
;
var AddSuppressionRequestSourceEnum;
(function (AddSuppressionRequestSourceEnum) {
    AddSuppressionRequestSourceEnum["Csr"] = "CSR";
    AddSuppressionRequestSourceEnum["SelfService"] = "SELF_SERVICE";
    AddSuppressionRequestSourceEnum["UnsubscribeLink"] = "UNSUBSCRIBE_LINK";
    AddSuppressionRequestSourceEnum["Import"] = "IMPORT";
    AddSuppressionRequestSourceEnum["Api"] = "API";
    AddSuppressionRequestSourceEnum["System"] = "SYSTEM";
})(AddSuppressionRequestSourceEnum || (AddSuppressionRequestSourceEnum = {}));
;
function isOptionalAddSuppressionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAddSuppressionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAddSuppressionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAddSuppressionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAddSuppressionRequestPropertyNames('address', 'channel', 'reason');
    const optionalStringProperties = createAddSuppressionRequestOptionalProperties({ name: 'address', nullable: false }, { name: 'channel', nullable: false }, { name: 'partyId', nullable: false }, { name: 'reason', nullable: false }, { name: 'source', nullable: false });
    const optionalNumberProperties = createAddSuppressionRequestOptionalProperties();
    const optionalBooleanProperties = createAddSuppressionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAddSuppressionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAddSuppressionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAddSuppressionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalAndPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAndPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAndOptionalProperties(...properties) {
    return properties;
}
function instanceOfAnd(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAndPropertyNames();
    const optionalStringProperties = createAndOptionalProperties();
    const optionalNumberProperties = createAndOptionalProperties();
    const optionalBooleanProperties = createAndOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAndPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAndPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAndPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AssignPartyTagRequestSourceEnum;
(function (AssignPartyTagRequestSourceEnum) {
    AssignPartyTagRequestSourceEnum["Manual"] = "MANUAL";
    AssignPartyTagRequestSourceEnum["Campaign"] = "CAMPAIGN";
    AssignPartyTagRequestSourceEnum["Import"] = "IMPORT";
    AssignPartyTagRequestSourceEnum["Rule"] = "RULE";
})(AssignPartyTagRequestSourceEnum || (AssignPartyTagRequestSourceEnum = {}));
;
function isOptionalAssignPartyTagRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAssignPartyTagRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAssignPartyTagRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAssignPartyTagRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAssignPartyTagRequestPropertyNames('tagId');
    const optionalStringProperties = createAssignPartyTagRequestOptionalProperties({ name: 'source', nullable: false }, { name: 'tagId', nullable: false });
    const optionalNumberProperties = createAssignPartyTagRequestOptionalProperties();
    const optionalBooleanProperties = createAssignPartyTagRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAssignPartyTagRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAssignPartyTagRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAssignPartyTagRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AssignedRoleRoleCodeEnum;
(function (AssignedRoleRoleCodeEnum) {
    AssignedRoleRoleCodeEnum["Billing"] = "BILLING";
    AssignedRoleRoleCodeEnum["Approver"] = "APPROVER";
    AssignedRoleRoleCodeEnum["Driver"] = "DRIVER";
})(AssignedRoleRoleCodeEnum || (AssignedRoleRoleCodeEnum = {}));
;
function isOptionalAssignedRolePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAssignedRolePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAssignedRoleOptionalProperties(...properties) {
    return properties;
}
function instanceOfAssignedRole(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAssignedRolePropertyNames('roleCode');
    const optionalStringProperties = createAssignedRoleOptionalProperties({ name: 'roleCode', nullable: false }, { name: 'roleLabel', nullable: false });
    const optionalNumberProperties = createAssignedRoleOptionalProperties();
    const optionalBooleanProperties = createAssignedRoleOptionalProperties({ name: 'isPrimary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAssignedRolePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAssignedRolePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAssignedRolePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBillingPreferencesPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingPreferencesPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingPreferencesOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingPreferences(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingPreferencesPropertyNames('doNotContact', 'marketingOptOut');
    const optionalStringProperties = createBillingPreferencesOptionalProperties({ name: 'invoiceDeliveryMethod', nullable: false });
    const optionalNumberProperties = createBillingPreferencesOptionalProperties();
    const optionalBooleanProperties = createBillingPreferencesOptionalProperties({ name: 'doNotContact', nullable: false }, { name: 'marketingOptOut', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingPreferencesPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingPreferencesPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingPreferencesPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BillingRuleRefInvoiceDeliveryMethodEnum;
(function (BillingRuleRefInvoiceDeliveryMethodEnum) {
    BillingRuleRefInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    BillingRuleRefInvoiceDeliveryMethodEnum["Mail"] = "MAIL";
    BillingRuleRefInvoiceDeliveryMethodEnum["Portal"] = "PORTAL";
    BillingRuleRefInvoiceDeliveryMethodEnum["Edi"] = "EDI";
})(BillingRuleRefInvoiceDeliveryMethodEnum || (BillingRuleRefInvoiceDeliveryMethodEnum = {}));
;
function isOptionalBillingRuleRefPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingRuleRefPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingRuleRefOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingRuleRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingRuleRefPropertyNames('autoPayEnabled', 'creditHold', 'poRequired', 'taxExempt');
    const optionalStringProperties = createBillingRuleRefOptionalProperties({ name: 'billingAddressId', nullable: false }, { name: 'currency', nullable: false }, { name: 'discountPolicyRef', nullable: false }, { name: 'invoiceDeliveryMethod', nullable: false }, { name: 'paymentTerms', nullable: false });
    const optionalNumberProperties = createBillingRuleRefOptionalProperties({ name: 'creditLimit', nullable: false });
    const optionalBooleanProperties = createBillingRuleRefOptionalProperties({ name: 'autoPayEnabled', nullable: false }, { name: 'creditHold', nullable: false }, { name: 'poRequired', nullable: false }, { name: 'taxExempt', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingRuleRefPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingRuleRefPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingRuleRefPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBillingTermsRefPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingTermsRefPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingTermsRefOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingTermsRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingTermsRefPropertyNames('code', 'label', 'netDays');
    const optionalStringProperties = createBillingTermsRefOptionalProperties({ name: 'code', nullable: false }, { name: 'label', nullable: false });
    const optionalNumberProperties = createBillingTermsRefOptionalProperties({ name: 'netDays', nullable: false });
    const optionalBooleanProperties = createBillingTermsRefOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingTermsRefPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingTermsRefPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingTermsRefPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestCommercialBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestCommercialBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestCommercialBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestCommercialBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestCommercialBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestCommercialBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestCommercialBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestCommercialBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestCommercialBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestCommercialBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestCommercialBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestCustomerBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestCustomerBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestCustomerBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestCustomerBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestCustomerBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestCustomerBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestCustomerBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestCustomerBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestCustomerBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestCustomerBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestCustomerBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResponsePropertyNames('failureCount', 'results', 'successCount', 'totalSubmitted');
    const optionalStringProperties = createBulkIngestResponseOptionalProperties();
    const optionalNumberProperties = createBulkIngestResponseOptionalProperties({ name: 'failureCount', nullable: false }, { name: 'successCount', nullable: false }, { name: 'totalSubmitted', nullable: false });
    const optionalBooleanProperties = createBulkIngestResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBulkIngestResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResultPropertyNames('rowIndex', 'success');
    const optionalStringProperties = createBulkIngestResultOptionalProperties({ name: 'correlationId', nullable: false }, { name: 'entityId', nullable: false }, { name: 'errorCode', nullable: false }, { name: 'errorMessage', nullable: false });
    const optionalNumberProperties = createBulkIngestResultOptionalProperties({ name: 'rowIndex', nullable: false });
    const optionalBooleanProperties = createBulkIngestResultOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCloseFollowUpTaskRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCloseFollowUpTaskRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCloseFollowUpTaskRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCloseFollowUpTaskRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCloseFollowUpTaskRequestPropertyNames('outcome');
    const optionalStringProperties = createCloseFollowUpTaskRequestOptionalProperties({ name: 'bookedAppointmentId', nullable: false }, { name: 'bookedWorkorderId', nullable: false }, { name: 'outcome', nullable: false });
    const optionalNumberProperties = createCloseFollowUpTaskRequestOptionalProperties();
    const optionalBooleanProperties = createCloseFollowUpTaskRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCloseFollowUpTaskRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCloseFollowUpTaskRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCloseFollowUpTaskRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCommercialBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCommercialBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCommercialBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfCommercialBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCommercialBulkIngestRecordPropertyNames('legalName');
    const optionalStringProperties = createCommercialBulkIngestRecordOptionalProperties({ name: 'billingTermsId', nullable: false }, { name: 'contactEmail', nullable: false }, { name: 'contactFirstName', nullable: false }, { name: 'contactLastName', nullable: false }, { name: 'contactPhone', nullable: false }, { name: 'displayName', nullable: false }, { name: 'legalName', nullable: false }, { name: 'taxId', nullable: false });
    const optionalNumberProperties = createCommercialBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createCommercialBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCommercialBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCommercialBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCommercialBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ComparisonOperatorEnum;
(function (ComparisonOperatorEnum) {
    ComparisonOperatorEnum["Equals"] = "EQUALS";
    ComparisonOperatorEnum["NotEquals"] = "NOT_EQUALS";
    ComparisonOperatorEnum["In"] = "IN";
    ComparisonOperatorEnum["NotIn"] = "NOT_IN";
    ComparisonOperatorEnum["GreaterThan"] = "GREATER_THAN";
    ComparisonOperatorEnum["GreaterThanOrEqual"] = "GREATER_THAN_OR_EQUAL";
    ComparisonOperatorEnum["LessThan"] = "LESS_THAN";
    ComparisonOperatorEnum["LessThanOrEqual"] = "LESS_THAN_OR_EQUAL";
    ComparisonOperatorEnum["IsTrue"] = "IS_TRUE";
    ComparisonOperatorEnum["IsFalse"] = "IS_FALSE";
    ComparisonOperatorEnum["IsNull"] = "IS_NULL";
    ComparisonOperatorEnum["IsNotNull"] = "IS_NOT_NULL";
    ComparisonOperatorEnum["ContainsAny"] = "CONTAINS_ANY";
    ComparisonOperatorEnum["ContainsAll"] = "CONTAINS_ALL";
})(ComparisonOperatorEnum || (ComparisonOperatorEnum = {}));
;
function isOptionalComparisonPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createComparisonPropertyNames(...propertyNames) {
    return propertyNames;
}
function createComparisonOptionalProperties(...properties) {
    return properties;
}
function instanceOfComparison(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createComparisonPropertyNames();
    const optionalStringProperties = createComparisonOptionalProperties({ name: 'attribute', nullable: false }, { name: 'operator', nullable: false });
    const optionalNumberProperties = createComparisonOptionalProperties();
    const optionalBooleanProperties = createComparisonOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalComparisonPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalComparisonPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalComparisonPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ContactPointDtoContactTypeEnum;
(function (ContactPointDtoContactTypeEnum) {
    ContactPointDtoContactTypeEnum["Email"] = "EMAIL";
    ContactPointDtoContactTypeEnum["PhoneMobile"] = "PHONE_MOBILE";
    ContactPointDtoContactTypeEnum["PhoneHome"] = "PHONE_HOME";
    ContactPointDtoContactTypeEnum["PhoneWork"] = "PHONE_WORK";
    ContactPointDtoContactTypeEnum["Fax"] = "FAX";
})(ContactPointDtoContactTypeEnum || (ContactPointDtoContactTypeEnum = {}));
;
function isOptionalContactPointDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContactPointDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createContactPointDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfContactPointDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContactPointDtoPropertyNames('contactPointId', 'contactType', 'value');
    const optionalStringProperties = createContactPointDtoOptionalProperties({ name: 'contactPointId', nullable: false }, { name: 'contactType', nullable: false }, { name: 'value', nullable: false });
    const optionalNumberProperties = createContactPointDtoOptionalProperties();
    const optionalBooleanProperties = createContactPointDtoOptionalProperties({ name: 'primary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContactPointDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContactPointDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContactPointDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalContactPreferencesPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContactPreferencesPropertyNames(...propertyNames) {
    return propertyNames;
}
function createContactPreferencesOptionalProperties(...properties) {
    return properties;
}
function instanceOfContactPreferences(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContactPreferencesPropertyNames('doNotContact', 'emailOptIn', 'phoneOptIn', 'smsOptIn');
    const optionalStringProperties = createContactPreferencesOptionalProperties({ name: 'preferredContactMethod', nullable: false }, { name: 'preferredLanguage', nullable: false });
    const optionalNumberProperties = createContactPreferencesOptionalProperties();
    const optionalBooleanProperties = createContactPreferencesOptionalProperties({ name: 'doNotContact', nullable: false }, { name: 'emailOptIn', nullable: false }, { name: 'phoneOptIn', nullable: false }, { name: 'smsOptIn', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContactPreferencesPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContactPreferencesPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContactPreferencesPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalContactSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContactSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createContactSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfContactSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContactSummaryPropertyNames('contactId', 'emailAddresses', 'name', 'phoneNumbers', 'roles');
    const optionalStringProperties = createContactSummaryOptionalProperties({ name: 'contactId', nullable: false }, { name: 'name', nullable: false });
    const optionalNumberProperties = createContactSummaryOptionalProperties();
    const optionalBooleanProperties = createContactSummaryOptionalProperties({ name: 'primary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContactSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContactSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContactSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ContactWithRoleRolesEnum;
(function (ContactWithRoleRolesEnum) {
    ContactWithRoleRolesEnum["Approver"] = "APPROVER";
    ContactWithRoleRolesEnum["Billing"] = "BILLING";
    ContactWithRoleRolesEnum["PrimaryContact"] = "PRIMARY_CONTACT";
    ContactWithRoleRolesEnum["Driver"] = "DRIVER";
    ContactWithRoleRolesEnum["Technical"] = "TECHNICAL";
})(ContactWithRoleRolesEnum || (ContactWithRoleRolesEnum = {}));
;
function isOptionalContactWithRolePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContactWithRolePropertyNames(...propertyNames) {
    return propertyNames;
}
function createContactWithRoleOptionalProperties(...properties) {
    return properties;
}
function instanceOfContactWithRole(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContactWithRolePropertyNames('individualId', 'relationshipId', 'status');
    const optionalStringProperties = createContactWithRoleOptionalProperties({ name: 'effectiveFrom', nullable: false }, { name: 'effectiveTo', nullable: false }, { name: 'individualId', nullable: false }, { name: 'relationshipId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createContactWithRoleOptionalProperties();
    const optionalBooleanProperties = createContactWithRoleOptionalProperties({ name: 'primaryBilling', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContactWithRolePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContactWithRolePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContactWithRolePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ContactWithRolesInvoiceDeliveryMethodEnum;
(function (ContactWithRolesInvoiceDeliveryMethodEnum) {
    ContactWithRolesInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    ContactWithRolesInvoiceDeliveryMethodEnum["Phone"] = "PHONE";
    ContactWithRolesInvoiceDeliveryMethodEnum["None"] = "NONE";
})(ContactWithRolesInvoiceDeliveryMethodEnum || (ContactWithRolesInvoiceDeliveryMethodEnum = {}));
;
function isOptionalContactWithRolesPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createContactWithRolesPropertyNames(...propertyNames) {
    return propertyNames;
}
function createContactWithRolesOptionalProperties(...properties) {
    return properties;
}
function instanceOfContactWithRoles(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createContactWithRolesPropertyNames('contactId', 'contactName');
    const optionalStringProperties = createContactWithRolesOptionalProperties({ name: 'contactId', nullable: false }, { name: 'contactName', nullable: false }, { name: 'email', nullable: false }, { name: 'invoiceDeliveryMethod', nullable: false }, { name: 'phone', nullable: false });
    const optionalNumberProperties = createContactWithRolesOptionalProperties();
    const optionalBooleanProperties = createContactWithRolesOptionalProperties({ name: 'hasPrimaryEmail', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalContactWithRolesPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalContactWithRolesPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalContactWithRolesPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateCommercialAccountRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateCommercialAccountRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateCommercialAccountRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateCommercialAccountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateCommercialAccountRequestPropertyNames('legalName');
    const optionalStringProperties = createCreateCommercialAccountRequestOptionalProperties({ name: 'billingTermsId', nullable: false }, { name: 'contactFirstName', nullable: false }, { name: 'contactLastName', nullable: false }, { name: 'displayName', nullable: false }, { name: 'email', nullable: false }, { name: 'legalName', nullable: false }, { name: 'partyType', nullable: false }, { name: 'phone', nullable: false }, { name: 'taxId', nullable: false });
    const optionalNumberProperties = createCreateCommercialAccountRequestOptionalProperties();
    const optionalBooleanProperties = createCreateCommercialAccountRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateCommercialAccountRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateCommercialAccountRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateCommercialAccountRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalCreateCommercialAccountResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateCommercialAccountResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateCommercialAccountResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateCommercialAccountResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateCommercialAccountResponsePropertyNames('createdAt', 'customerNumber', 'legalName', 'partyId', 'status');
    const optionalStringProperties = createCreateCommercialAccountResponseOptionalProperties({ name: 'billingTermsId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'customerNumber', nullable: false }, { name: 'displayName', nullable: false }, { name: 'legalName', nullable: false }, { name: 'partyId', nullable: false }, { name: 'partyType', nullable: false }, { name: 'primaryAddress', nullable: false }, { name: 'status', nullable: false }, { name: 'taxId', nullable: false });
    const optionalNumberProperties = createCreateCommercialAccountResponseOptionalProperties();
    const optionalBooleanProperties = createCreateCommercialAccountResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateCommercialAccountResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateCommercialAccountResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateCommercialAccountResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreateFollowUpTaskRequestTypeEnum;
(function (CreateFollowUpTaskRequestTypeEnum) {
    CreateFollowUpTaskRequestTypeEnum["DeclinedServiceFollowup"] = "DECLINED_SERVICE_FOLLOWUP";
    CreateFollowUpTaskRequestTypeEnum["ServiceDueReminder"] = "SERVICE_DUE_REMINDER";
    CreateFollowUpTaskRequestTypeEnum["FleetCheckin"] = "FLEET_CHECKIN";
    CreateFollowUpTaskRequestTypeEnum["CampaignResponse"] = "CAMPAIGN_RESPONSE";
    CreateFollowUpTaskRequestTypeEnum["General"] = "GENERAL";
})(CreateFollowUpTaskRequestTypeEnum || (CreateFollowUpTaskRequestTypeEnum = {}));
;
function isOptionalCreateFollowUpTaskRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateFollowUpTaskRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateFollowUpTaskRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateFollowUpTaskRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateFollowUpTaskRequestPropertyNames('type');
    const optionalStringProperties = createCreateFollowUpTaskRequestOptionalProperties({ name: 'assignedTo', nullable: false }, { name: 'dueDate', nullable: false }, { name: 'notes', nullable: false }, { name: 'reason', nullable: false }, { name: 'sourceWorkorderId', nullable: false }, { name: 'type', nullable: false }, { name: 'vehicleId', nullable: false });
    const optionalNumberProperties = createCreateFollowUpTaskRequestOptionalProperties();
    const optionalBooleanProperties = createCreateFollowUpTaskRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateFollowUpTaskRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateFollowUpTaskRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateFollowUpTaskRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreatePartyRelationshipRequestRolesEnum;
(function (CreatePartyRelationshipRequestRolesEnum) {
    CreatePartyRelationshipRequestRolesEnum["Approver"] = "APPROVER";
    CreatePartyRelationshipRequestRolesEnum["Billing"] = "BILLING";
    CreatePartyRelationshipRequestRolesEnum["PrimaryContact"] = "PRIMARY_CONTACT";
    CreatePartyRelationshipRequestRolesEnum["Driver"] = "DRIVER";
    CreatePartyRelationshipRequestRolesEnum["Technical"] = "TECHNICAL";
})(CreatePartyRelationshipRequestRolesEnum || (CreatePartyRelationshipRequestRolesEnum = {}));
;
function isOptionalCreatePartyRelationshipRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreatePartyRelationshipRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreatePartyRelationshipRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreatePartyRelationshipRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreatePartyRelationshipRequestPropertyNames('effectiveStartDate', 'personId', 'roles');
    const optionalStringProperties = createCreatePartyRelationshipRequestOptionalProperties({ name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'personId', nullable: false });
    const optionalNumberProperties = createCreatePartyRelationshipRequestOptionalProperties();
    const optionalBooleanProperties = createCreatePartyRelationshipRequestOptionalProperties({ name: 'primaryBillingContact', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreatePartyRelationshipRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreatePartyRelationshipRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreatePartyRelationshipRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreatePartyRelationshipResponseRolesEnum;
(function (CreatePartyRelationshipResponseRolesEnum) {
    CreatePartyRelationshipResponseRolesEnum["Approver"] = "APPROVER";
    CreatePartyRelationshipResponseRolesEnum["Billing"] = "BILLING";
    CreatePartyRelationshipResponseRolesEnum["PrimaryContact"] = "PRIMARY_CONTACT";
    CreatePartyRelationshipResponseRolesEnum["Driver"] = "DRIVER";
    CreatePartyRelationshipResponseRolesEnum["Technical"] = "TECHNICAL";
})(CreatePartyRelationshipResponseRolesEnum || (CreatePartyRelationshipResponseRolesEnum = {}));
;
function isOptionalCreatePartyRelationshipResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreatePartyRelationshipResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreatePartyRelationshipResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreatePartyRelationshipResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreatePartyRelationshipResponsePropertyNames('createdAt', 'effectiveStartDate', 'partyId', 'personId', 'previousPrimaryDemoted', 'relationshipId', 'roles');
    const optionalStringProperties = createCreatePartyRelationshipResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'partyId', nullable: false }, { name: 'personId', nullable: false }, { name: 'relationshipId', nullable: false });
    const optionalNumberProperties = createCreatePartyRelationshipResponseOptionalProperties();
    const optionalBooleanProperties = createCreatePartyRelationshipResponseOptionalProperties({ name: 'previousPrimaryDemoted', nullable: false }, { name: 'primaryBillingContact', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreatePartyRelationshipResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreatePartyRelationshipResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreatePartyRelationshipResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var CreatePersonRequestPreferredContactMethodEnum;
(function (CreatePersonRequestPreferredContactMethodEnum) {
    CreatePersonRequestPreferredContactMethodEnum["Email"] = "EMAIL";
    CreatePersonRequestPreferredContactMethodEnum["PhoneCall"] = "PHONE_CALL";
    CreatePersonRequestPreferredContactMethodEnum["Sms"] = "SMS";
    CreatePersonRequestPreferredContactMethodEnum["None"] = "NONE";
})(CreatePersonRequestPreferredContactMethodEnum || (CreatePersonRequestPreferredContactMethodEnum = {}));
;
function isOptionalCreatePersonRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreatePersonRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreatePersonRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreatePersonRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreatePersonRequestPropertyNames('firstName', 'lastName', 'preferredContactMethod');
    const optionalStringProperties = createCreatePersonRequestOptionalProperties({ name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'preferredContactMethod', nullable: false });
    const optionalNumberProperties = createCreatePersonRequestOptionalProperties();
    const optionalBooleanProperties = createCreatePersonRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreatePersonRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreatePersonRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreatePersonRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreatePersonResponsePreferredContactMethodEnum;
(function (CreatePersonResponsePreferredContactMethodEnum) {
    CreatePersonResponsePreferredContactMethodEnum["Email"] = "EMAIL";
    CreatePersonResponsePreferredContactMethodEnum["PhoneCall"] = "PHONE_CALL";
    CreatePersonResponsePreferredContactMethodEnum["Sms"] = "SMS";
    CreatePersonResponsePreferredContactMethodEnum["None"] = "NONE";
})(CreatePersonResponsePreferredContactMethodEnum || (CreatePersonResponsePreferredContactMethodEnum = {}));
;
function isOptionalCreatePersonResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreatePersonResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreatePersonResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreatePersonResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreatePersonResponsePropertyNames('contactPointsCreated', 'createdAt', 'firstName', 'lastName', 'personId', 'preferredContactMethod');
    const optionalStringProperties = createCreatePersonResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'personId', nullable: false }, { name: 'preferredContactMethod', nullable: false });
    const optionalNumberProperties = createCreatePersonResponseOptionalProperties({ name: 'contactPointsCreated', nullable: false });
    const optionalBooleanProperties = createCreatePersonResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreatePersonResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreatePersonResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreatePersonResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateVehicleForPartyRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateVehicleForPartyRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateVehicleForPartyRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateVehicleForPartyRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateVehicleForPartyRequestPropertyNames('vinNumber');
    const optionalStringProperties = createCreateVehicleForPartyRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'licensePlate', nullable: false }, { name: 'licensePlateRegion', nullable: false }, { name: 'unitNumber', nullable: false }, { name: 'vinNumber', nullable: false });
    const optionalNumberProperties = createCreateVehicleForPartyRequestOptionalProperties();
    const optionalBooleanProperties = createCreateVehicleForPartyRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateVehicleForPartyRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateVehicleForPartyRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateVehicleForPartyRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreateVehicleForPartyResponseStatusEnum;
(function (CreateVehicleForPartyResponseStatusEnum) {
    CreateVehicleForPartyResponseStatusEnum["Active"] = "ACTIVE";
    CreateVehicleForPartyResponseStatusEnum["Inactive"] = "INACTIVE";
})(CreateVehicleForPartyResponseStatusEnum || (CreateVehicleForPartyResponseStatusEnum = {}));
;
function isOptionalCreateVehicleForPartyResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateVehicleForPartyResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateVehicleForPartyResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateVehicleForPartyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateVehicleForPartyResponsePropertyNames('partyId', 'status', 'vehicleId');
    const optionalStringProperties = createCreateVehicleForPartyResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'description', nullable: false }, { name: 'licensePlate', nullable: false }, { name: 'partyId', nullable: false }, { name: 'status', nullable: false }, { name: 'unitNumber', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'vinNumber', nullable: false });
    const optionalNumberProperties = createCreateVehicleForPartyResponseOptionalProperties();
    const optionalBooleanProperties = createCreateVehicleForPartyResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateVehicleForPartyResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateVehicleForPartyResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateVehicleForPartyResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalCrmSnapshotDTOPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCrmSnapshotDTOPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCrmSnapshotDTOOptionalProperties(...properties) {
    return properties;
}
function instanceOfCrmSnapshotDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCrmSnapshotDTOPropertyNames('account', 'contacts', 'snapshotMetadata', 'vehicles');
    const optionalStringProperties = createCrmSnapshotDTOOptionalProperties();
    const optionalNumberProperties = createCrmSnapshotDTOOptionalProperties();
    const optionalBooleanProperties = createCrmSnapshotDTOOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCrmSnapshotDTOPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCrmSnapshotDTOPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCrmSnapshotDTOPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCustomerBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerBulkIngestRecordPropertyNames('firstName', 'lastName');
    const optionalStringProperties = createCustomerBulkIngestRecordOptionalProperties({ name: 'customerNumber', nullable: false }, { name: 'email', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'phoneNumber', nullable: false }, { name: 'primaryAddress', nullable: false });
    const optionalNumberProperties = createCustomerBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createCustomerBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCustomerDTOPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerDTOPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerDTOOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerDTOPropertyNames();
    const optionalStringProperties = createCustomerDTOOptionalProperties({ name: 'customerNumber', nullable: false }, { name: 'customerType', nullable: false }, { name: 'firstName', nullable: false }, { name: 'id', nullable: false }, { name: 'lastName', nullable: false }, { name: 'partyId', nullable: false }, { name: 'primaryAddress', nullable: false });
    const optionalNumberProperties = createCustomerDTOOptionalProperties();
    const optionalBooleanProperties = createCustomerDTOOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerDTOPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerDTOPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerDTOPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CustomerInteractionResponseChannelEnum;
(function (CustomerInteractionResponseChannelEnum) {
    CustomerInteractionResponseChannelEnum["Email"] = "EMAIL";
    CustomerInteractionResponseChannelEnum["Sms"] = "SMS";
})(CustomerInteractionResponseChannelEnum || (CustomerInteractionResponseChannelEnum = {}));
;
var CustomerInteractionResponseDirectionEnum;
(function (CustomerInteractionResponseDirectionEnum) {
    CustomerInteractionResponseDirectionEnum["Outbound"] = "OUTBOUND";
    CustomerInteractionResponseDirectionEnum["Inbound"] = "INBOUND";
})(CustomerInteractionResponseDirectionEnum || (CustomerInteractionResponseDirectionEnum = {}));
;
var CustomerInteractionResponseTypeEnum;
(function (CustomerInteractionResponseTypeEnum) {
    CustomerInteractionResponseTypeEnum["CampaignSend"] = "CAMPAIGN_SEND";
    CustomerInteractionResponseTypeEnum["Email"] = "EMAIL";
    CustomerInteractionResponseTypeEnum["Sms"] = "SMS";
    CustomerInteractionResponseTypeEnum["Call"] = "CALL";
    CustomerInteractionResponseTypeEnum["FollowUp"] = "FOLLOW_UP";
    CustomerInteractionResponseTypeEnum["Note"] = "NOTE";
    CustomerInteractionResponseTypeEnum["WorkorderNote"] = "WORKORDER_NOTE";
})(CustomerInteractionResponseTypeEnum || (CustomerInteractionResponseTypeEnum = {}));
;
function isOptionalCustomerInteractionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCustomerInteractionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCustomerInteractionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCustomerInteractionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCustomerInteractionResponsePropertyNames('direction', 'interactionId', 'occurredAt', 'partyId', 'type');
    const optionalStringProperties = createCustomerInteractionResponseOptionalProperties({ name: 'actor', nullable: false }, { name: 'body', nullable: false }, { name: 'campaignCode', nullable: false }, { name: 'campaignId', nullable: false }, { name: 'channel', nullable: false }, { name: 'contactId', nullable: false }, { name: 'direction', nullable: false }, { name: 'interactionId', nullable: false }, { name: 'occurredAt', nullable: false }, { name: 'partyId', nullable: false }, { name: 'sourceWorkorderId', nullable: false }, { name: 'subject', nullable: false }, { name: 'summary', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createCustomerInteractionResponseOptionalProperties();
    const optionalBooleanProperties = createCustomerInteractionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCustomerInteractionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCustomerInteractionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCustomerInteractionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalDuplicateCandidatePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDuplicateCandidatePropertyNames(...propertyNames) {
    return propertyNames;
}
function createDuplicateCandidateOptionalProperties(...properties) {
    return properties;
}
function instanceOfDuplicateCandidate(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDuplicateCandidatePropertyNames('legalName', 'matchReason', 'partyId');
    const optionalStringProperties = createDuplicateCandidateOptionalProperties({ name: 'legalName', nullable: false }, { name: 'matchReason', nullable: false }, { name: 'partyId', nullable: false });
    const optionalNumberProperties = createDuplicateCandidateOptionalProperties();
    const optionalBooleanProperties = createDuplicateCandidateOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDuplicateCandidatePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDuplicateCandidatePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDuplicateCandidatePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalDuplicateCheckResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDuplicateCheckResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createDuplicateCheckResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfDuplicateCheckResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDuplicateCheckResponsePropertyNames('duplicatesFound', 'potentialDuplicates');
    const optionalStringProperties = createDuplicateCheckResponseOptionalProperties({ name: 'exactMatchPartyId', nullable: false });
    const optionalNumberProperties = createDuplicateCheckResponseOptionalProperties();
    const optionalBooleanProperties = createDuplicateCheckResponseOptionalProperties({ name: 'duplicatesFound', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDuplicateCheckResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDuplicateCheckResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDuplicateCheckResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEmailAddressDTOPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmailAddressDTOPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmailAddressDTOOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmailAddressDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmailAddressDTOPropertyNames('address', 'type');
    const optionalStringProperties = createEmailAddressDTOOptionalProperties({ name: 'address', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createEmailAddressDTOOptionalProperties();
    const optionalBooleanProperties = createEmailAddressDTOOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmailAddressDTOPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmailAddressDTOPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmailAddressDTOPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalEmailInputPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEmailInputPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEmailInputOptionalProperties(...properties) {
    return properties;
}
function instanceOfEmailInput(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEmailInputPropertyNames('value');
    const optionalStringProperties = createEmailInputOptionalProperties({ name: 'value', nullable: false });
    const optionalNumberProperties = createEmailInputOptionalProperties();
    const optionalBooleanProperties = createEmailInputOptionalProperties({ name: 'primary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEmailInputPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEmailInputPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEmailInputPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var FollowUpTaskResponseStatusEnum;
(function (FollowUpTaskResponseStatusEnum) {
    FollowUpTaskResponseStatusEnum["Open"] = "OPEN";
    FollowUpTaskResponseStatusEnum["Done"] = "DONE";
    FollowUpTaskResponseStatusEnum["Dismissed"] = "DISMISSED";
})(FollowUpTaskResponseStatusEnum || (FollowUpTaskResponseStatusEnum = {}));
;
var FollowUpTaskResponseTypeEnum;
(function (FollowUpTaskResponseTypeEnum) {
    FollowUpTaskResponseTypeEnum["DeclinedServiceFollowup"] = "DECLINED_SERVICE_FOLLOWUP";
    FollowUpTaskResponseTypeEnum["ServiceDueReminder"] = "SERVICE_DUE_REMINDER";
    FollowUpTaskResponseTypeEnum["FleetCheckin"] = "FLEET_CHECKIN";
    FollowUpTaskResponseTypeEnum["CampaignResponse"] = "CAMPAIGN_RESPONSE";
    FollowUpTaskResponseTypeEnum["General"] = "GENERAL";
})(FollowUpTaskResponseTypeEnum || (FollowUpTaskResponseTypeEnum = {}));
;
function isOptionalFollowUpTaskResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFollowUpTaskResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createFollowUpTaskResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfFollowUpTaskResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFollowUpTaskResponsePropertyNames('partyId', 'status', 'taskId', 'type');
    const optionalStringProperties = createFollowUpTaskResponseOptionalProperties({ name: 'assignedTo', nullable: false }, { name: 'bookedAppointmentId', nullable: false }, { name: 'bookedWorkorderId', nullable: false }, { name: 'closedAt', nullable: false }, { name: 'closedBy', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'dueDate', nullable: false }, { name: 'notes', nullable: false }, { name: 'outcome', nullable: false }, { name: 'partyId', nullable: false }, { name: 'reason', nullable: false }, { name: 'sourceWorkorderId', nullable: false }, { name: 'status', nullable: false }, { name: 'taskId', nullable: false }, { name: 'type', nullable: false }, { name: 'vehicleId', nullable: false });
    const optionalNumberProperties = createFollowUpTaskResponseOptionalProperties();
    const optionalBooleanProperties = createFollowUpTaskResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFollowUpTaskResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFollowUpTaskResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFollowUpTaskResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var GetAccountTierResponseTierEnum;
(function (GetAccountTierResponseTierEnum) {
    GetAccountTierResponseTierEnum["Standard"] = "STANDARD";
    GetAccountTierResponseTierEnum["Bronze"] = "BRONZE";
    GetAccountTierResponseTierEnum["Silver"] = "SILVER";
    GetAccountTierResponseTierEnum["Gold"] = "GOLD";
    GetAccountTierResponseTierEnum["Platinum"] = "PLATINUM";
    GetAccountTierResponseTierEnum["Enterprise"] = "ENTERPRISE";
})(GetAccountTierResponseTierEnum || (GetAccountTierResponseTierEnum = {}));
;
function isOptionalGetAccountTierResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGetAccountTierResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGetAccountTierResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGetAccountTierResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGetAccountTierResponsePropertyNames('accountId', 'manualOverride', 'tier', 'tierDisplayName');
    const optionalStringProperties = createGetAccountTierResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'notes', nullable: false }, { name: 'tier', nullable: false }, { name: 'tierAssignedAt', nullable: false }, { name: 'tierAssignedBy', nullable: false }, { name: 'tierDisplayName', nullable: false });
    const optionalNumberProperties = createGetAccountTierResponseOptionalProperties();
    const optionalBooleanProperties = createGetAccountTierResponseOptionalProperties({ name: 'manualOverride', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGetAccountTierResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGetAccountTierResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGetAccountTierResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGetCommercialAccountContactsResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGetCommercialAccountContactsResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGetCommercialAccountContactsResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGetCommercialAccountContactsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGetCommercialAccountContactsResponsePropertyNames('commercialAccountId', 'contacts');
    const optionalStringProperties = createGetCommercialAccountContactsResponseOptionalProperties({ name: 'commercialAccountId', nullable: false });
    const optionalNumberProperties = createGetCommercialAccountContactsResponseOptionalProperties();
    const optionalBooleanProperties = createGetCommercialAccountContactsResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGetCommercialAccountContactsResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGetCommercialAccountContactsResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGetCommercialAccountContactsResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var GetCommunicationPreferencesResponseEmailPreferenceEnum;
(function (GetCommunicationPreferencesResponseEmailPreferenceEnum) {
    GetCommunicationPreferencesResponseEmailPreferenceEnum["OptIn"] = "OPT_IN";
    GetCommunicationPreferencesResponseEmailPreferenceEnum["OptOut"] = "OPT_OUT";
    GetCommunicationPreferencesResponseEmailPreferenceEnum["NotApplicable"] = "NOT_APPLICABLE";
})(GetCommunicationPreferencesResponseEmailPreferenceEnum || (GetCommunicationPreferencesResponseEmailPreferenceEnum = {}));
;
var GetCommunicationPreferencesResponseMarketingPreferenceEnum;
(function (GetCommunicationPreferencesResponseMarketingPreferenceEnum) {
    GetCommunicationPreferencesResponseMarketingPreferenceEnum["OptIn"] = "OPT_IN";
    GetCommunicationPreferencesResponseMarketingPreferenceEnum["OptOut"] = "OPT_OUT";
})(GetCommunicationPreferencesResponseMarketingPreferenceEnum || (GetCommunicationPreferencesResponseMarketingPreferenceEnum = {}));
;
var GetCommunicationPreferencesResponsePhonePreferenceEnum;
(function (GetCommunicationPreferencesResponsePhonePreferenceEnum) {
    GetCommunicationPreferencesResponsePhonePreferenceEnum["OptIn"] = "OPT_IN";
    GetCommunicationPreferencesResponsePhonePreferenceEnum["OptOut"] = "OPT_OUT";
    GetCommunicationPreferencesResponsePhonePreferenceEnum["NotApplicable"] = "NOT_APPLICABLE";
})(GetCommunicationPreferencesResponsePhonePreferenceEnum || (GetCommunicationPreferencesResponsePhonePreferenceEnum = {}));
;
var GetCommunicationPreferencesResponseSmsPreferenceEnum;
(function (GetCommunicationPreferencesResponseSmsPreferenceEnum) {
    GetCommunicationPreferencesResponseSmsPreferenceEnum["OptIn"] = "OPT_IN";
    GetCommunicationPreferencesResponseSmsPreferenceEnum["OptOut"] = "OPT_OUT";
    GetCommunicationPreferencesResponseSmsPreferenceEnum["NotApplicable"] = "NOT_APPLICABLE";
})(GetCommunicationPreferencesResponseSmsPreferenceEnum || (GetCommunicationPreferencesResponseSmsPreferenceEnum = {}));
;
var GetCommunicationPreferencesResponseUpdateSourceEnum;
(function (GetCommunicationPreferencesResponseUpdateSourceEnum) {
    GetCommunicationPreferencesResponseUpdateSourceEnum["App"] = "APP";
    GetCommunicationPreferencesResponseUpdateSourceEnum["Api"] = "API";
    GetCommunicationPreferencesResponseUpdateSourceEnum["Admin"] = "ADMIN";
    GetCommunicationPreferencesResponseUpdateSourceEnum["Import"] = "IMPORT";
})(GetCommunicationPreferencesResponseUpdateSourceEnum || (GetCommunicationPreferencesResponseUpdateSourceEnum = {}));
;
function isOptionalGetCommunicationPreferencesResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGetCommunicationPreferencesResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGetCommunicationPreferencesResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGetCommunicationPreferencesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGetCommunicationPreferencesResponsePropertyNames('partyId');
    const optionalStringProperties = createGetCommunicationPreferencesResponseOptionalProperties({ name: 'emailPreference', nullable: false }, { name: 'marketingPreference', nullable: false }, { name: 'partyId', nullable: false }, { name: 'phonePreference', nullable: false }, { name: 'preferencesNote', nullable: false }, { name: 'smsPreference', nullable: false }, { name: 'updateSource', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createGetCommunicationPreferencesResponseOptionalProperties();
    const optionalBooleanProperties = createGetCommunicationPreferencesResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGetCommunicationPreferencesResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGetCommunicationPreferencesResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGetCommunicationPreferencesResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGetContactsWithRolesResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGetContactsWithRolesResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGetContactsWithRolesResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGetContactsWithRolesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGetContactsWithRolesResponsePropertyNames('contacts', 'partyId');
    const optionalStringProperties = createGetContactsWithRolesResponseOptionalProperties({ name: 'partyId', nullable: false });
    const optionalNumberProperties = createGetContactsWithRolesResponseOptionalProperties();
    const optionalBooleanProperties = createGetContactsWithRolesResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGetContactsWithRolesResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGetContactsWithRolesResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGetContactsWithRolesResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGetPartyResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGetPartyResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGetPartyResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGetPartyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGetPartyResponsePropertyNames('createdAt', 'legalName', 'partyId', 'partyType', 'status');
    const optionalStringProperties = createGetPartyResponseOptionalProperties({ name: 'billingTermsId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'displayName', nullable: false }, { name: 'legalName', nullable: false }, { name: 'modifiedAt', nullable: false }, { name: 'partyId', nullable: false }, { name: 'partyType', nullable: false }, { name: 'status', nullable: false }, { name: 'taxId', nullable: false });
    const optionalNumberProperties = createGetPartyResponseOptionalProperties();
    const optionalBooleanProperties = createGetPartyResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGetPartyResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGetPartyResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGetPartyResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var GetPersonResponsePreferredContactMethodEnum;
(function (GetPersonResponsePreferredContactMethodEnum) {
    GetPersonResponsePreferredContactMethodEnum["Email"] = "EMAIL";
    GetPersonResponsePreferredContactMethodEnum["PhoneCall"] = "PHONE_CALL";
    GetPersonResponsePreferredContactMethodEnum["Sms"] = "SMS";
    GetPersonResponsePreferredContactMethodEnum["None"] = "NONE";
})(GetPersonResponsePreferredContactMethodEnum || (GetPersonResponsePreferredContactMethodEnum = {}));
;
function isOptionalGetPersonResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGetPersonResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGetPersonResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGetPersonResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGetPersonResponsePropertyNames('commercialAccountCount', 'commercialContact', 'createdAt', 'firstName', 'individualCustomer', 'lastName', 'personId');
    const optionalStringProperties = createGetPersonResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'displayName', nullable: false }, { name: 'firstName', nullable: false }, { name: 'lastName', nullable: false }, { name: 'personId', nullable: false }, { name: 'preferredContactMethod', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createGetPersonResponseOptionalProperties({ name: 'commercialAccountCount', nullable: false });
    const optionalBooleanProperties = createGetPersonResponseOptionalProperties({ name: 'commercialContact', nullable: false }, { name: 'individualCustomer', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGetPersonResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGetPersonResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGetPersonResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalIndividualDetailsPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createIndividualDetailsPropertyNames(...propertyNames) {
    return propertyNames;
}
function createIndividualDetailsOptionalProperties(...properties) {
    return properties;
}
function instanceOfIndividualDetails(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createIndividualDetailsPropertyNames('displayName');
    const optionalStringProperties = createIndividualDetailsOptionalProperties({ name: 'displayName', nullable: false }, { name: 'email', nullable: false }, { name: 'phone', nullable: false });
    const optionalNumberProperties = createIndividualDetailsOptionalProperties();
    const optionalBooleanProperties = createIndividualDetailsOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalIndividualDetailsPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalIndividualDetailsPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalIndividualDetailsPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInquiryAcceptedResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInquiryAcceptedResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInquiryAcceptedResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInquiryAcceptedResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInquiryAcceptedResponsePropertyNames('inquiryId', 'status');
    const optionalStringProperties = createInquiryAcceptedResponseOptionalProperties({ name: 'inquiryId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createInquiryAcceptedResponseOptionalProperties();
    const optionalBooleanProperties = createInquiryAcceptedResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInquiryAcceptedResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInquiryAcceptedResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInquiryAcceptedResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InquiryResponseAudienceTypeEnum;
(function (InquiryResponseAudienceTypeEnum) {
    InquiryResponseAudienceTypeEnum["Commercial"] = "COMMERCIAL";
    InquiryResponseAudienceTypeEnum["Individual"] = "INDIVIDUAL";
})(InquiryResponseAudienceTypeEnum || (InquiryResponseAudienceTypeEnum = {}));
;
var InquiryResponseChannelEnum;
(function (InquiryResponseChannelEnum) {
    InquiryResponseChannelEnum["WebForm"] = "WEB_FORM";
    InquiryResponseChannelEnum["Phone"] = "PHONE";
    InquiryResponseChannelEnum["WalkIn"] = "WALK_IN";
    InquiryResponseChannelEnum["Email"] = "EMAIL";
    InquiryResponseChannelEnum["Referral"] = "REFERRAL";
    InquiryResponseChannelEnum["Campaign"] = "CAMPAIGN";
})(InquiryResponseChannelEnum || (InquiryResponseChannelEnum = {}));
;
var InquiryResponseStatusEnum;
(function (InquiryResponseStatusEnum) {
    InquiryResponseStatusEnum["New"] = "NEW";
    InquiryResponseStatusEnum["Contacted"] = "CONTACTED";
    InquiryResponseStatusEnum["Converted"] = "CONVERTED";
    InquiryResponseStatusEnum["Closed"] = "CLOSED";
})(InquiryResponseStatusEnum || (InquiryResponseStatusEnum = {}));
;
function isOptionalInquiryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInquiryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInquiryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInquiryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInquiryResponsePropertyNames('audienceType', 'channel', 'contactName', 'createdAt', 'inquiryId', 'status');
    const optionalStringProperties = createInquiryResponseOptionalProperties({ name: 'assignedTo', nullable: false }, { name: 'audienceType', nullable: false }, { name: 'campaignCode', nullable: false }, { name: 'channel', nullable: false }, { name: 'contactName', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'email', nullable: false }, { name: 'inquiryId', nullable: false }, { name: 'message', nullable: false }, { name: 'organizationName', nullable: false }, { name: 'partyId', nullable: false }, { name: 'phone', nullable: false }, { name: 'resolutionNote', nullable: false }, { name: 'serviceOfInterest', nullable: false }, { name: 'status', nullable: false }, { name: 'vehicleOfInterest', nullable: false });
    const optionalNumberProperties = createInquiryResponseOptionalProperties();
    const optionalBooleanProperties = createInquiryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInquiryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInquiryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInquiryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var MarketingConsentDecisionChannelEnum;
(function (MarketingConsentDecisionChannelEnum) {
    MarketingConsentDecisionChannelEnum["Email"] = "EMAIL";
    MarketingConsentDecisionChannelEnum["Sms"] = "SMS";
})(MarketingConsentDecisionChannelEnum || (MarketingConsentDecisionChannelEnum = {}));
;
var MarketingConsentDecisionReasonEnum;
(function (MarketingConsentDecisionReasonEnum) {
    MarketingConsentDecisionReasonEnum["OptIn"] = "OPT_IN";
    MarketingConsentDecisionReasonEnum["AccountOptOut"] = "ACCOUNT_OPT_OUT";
    MarketingConsentDecisionReasonEnum["ConsentOptOut"] = "CONSENT_OPT_OUT";
    MarketingConsentDecisionReasonEnum["ConsentUnset"] = "CONSENT_UNSET";
    MarketingConsentDecisionReasonEnum["NoPrimaryContact"] = "NO_PRIMARY_CONTACT";
    MarketingConsentDecisionReasonEnum["Suppressed"] = "SUPPRESSED";
    MarketingConsentDecisionReasonEnum["PartyNotFound"] = "PARTY_NOT_FOUND";
})(MarketingConsentDecisionReasonEnum || (MarketingConsentDecisionReasonEnum = {}));
;
function isOptionalMarketingConsentDecisionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMarketingConsentDecisionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMarketingConsentDecisionOptionalProperties(...properties) {
    return properties;
}
function instanceOfMarketingConsentDecision(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMarketingConsentDecisionPropertyNames('allowed', 'channel', 'partyId', 'reason');
    const optionalStringProperties = createMarketingConsentDecisionOptionalProperties({ name: 'channel', nullable: false }, { name: 'governingPartyId', nullable: false }, { name: 'partyId', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createMarketingConsentDecisionOptionalProperties();
    const optionalBooleanProperties = createMarketingConsentDecisionOptionalProperties({ name: 'allowed', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMarketingConsentDecisionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMarketingConsentDecisionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMarketingConsentDecisionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var MarketingConsentSummaryResponseMarketingEmailConsentEnum;
(function (MarketingConsentSummaryResponseMarketingEmailConsentEnum) {
    MarketingConsentSummaryResponseMarketingEmailConsentEnum["OptIn"] = "OPT_IN";
    MarketingConsentSummaryResponseMarketingEmailConsentEnum["OptOut"] = "OPT_OUT";
    MarketingConsentSummaryResponseMarketingEmailConsentEnum["Unset"] = "UNSET";
})(MarketingConsentSummaryResponseMarketingEmailConsentEnum || (MarketingConsentSummaryResponseMarketingEmailConsentEnum = {}));
;
var MarketingConsentSummaryResponseMarketingSmsConsentEnum;
(function (MarketingConsentSummaryResponseMarketingSmsConsentEnum) {
    MarketingConsentSummaryResponseMarketingSmsConsentEnum["OptIn"] = "OPT_IN";
    MarketingConsentSummaryResponseMarketingSmsConsentEnum["OptOut"] = "OPT_OUT";
    MarketingConsentSummaryResponseMarketingSmsConsentEnum["Unset"] = "UNSET";
})(MarketingConsentSummaryResponseMarketingSmsConsentEnum || (MarketingConsentSummaryResponseMarketingSmsConsentEnum = {}));
;
function isOptionalMarketingConsentSummaryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMarketingConsentSummaryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createMarketingConsentSummaryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfMarketingConsentSummaryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMarketingConsentSummaryResponsePropertyNames('emailEligibility', 'marketingEmailConsent', 'marketingSmsConsent', 'partyId', 'smsEligibility');
    const optionalStringProperties = createMarketingConsentSummaryResponseOptionalProperties({ name: 'marketingEmailConsent', nullable: false }, { name: 'marketingSmsConsent', nullable: false }, { name: 'optOutAt', nullable: false }, { name: 'optOutReason', nullable: false }, { name: 'partyId', nullable: false }, { name: 'quietHoursEnd', nullable: false }, { name: 'quietHoursStart', nullable: false });
    const optionalNumberProperties = createMarketingConsentSummaryResponseOptionalProperties({ name: 'maxMarketingSendsPerMonth', nullable: false });
    const optionalBooleanProperties = createMarketingConsentSummaryResponseOptionalProperties({ name: 'accountMarketingOptOut', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMarketingConsentSummaryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMarketingConsentSummaryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMarketingConsentSummaryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMergePartiesRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMergePartiesRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMergePartiesRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfMergePartiesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMergePartiesRequestPropertyNames('justification', 'losingPartyId');
    const optionalStringProperties = createMergePartiesRequestOptionalProperties({ name: 'justification', nullable: false }, { name: 'losingPartyId', nullable: false }, { name: 'survivorPartyId', nullable: false });
    const optionalNumberProperties = createMergePartiesRequestOptionalProperties();
    const optionalBooleanProperties = createMergePartiesRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMergePartiesRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMergePartiesRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMergePartiesRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMergePartiesResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMergePartiesResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createMergePartiesResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfMergePartiesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMergePartiesResponsePropertyNames('losingPartyId', 'mergeAuditId', 'status', 'survivorPartyId');
    const optionalStringProperties = createMergePartiesResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'losingPartyId', nullable: false }, { name: 'mergeAuditId', nullable: false }, { name: 'mergedPartyAlias', nullable: false }, { name: 'status', nullable: false }, { name: 'survivorPartyId', nullable: false });
    const optionalNumberProperties = createMergePartiesResponseOptionalProperties();
    const optionalBooleanProperties = createMergePartiesResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMergePartiesResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMergePartiesResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMergePartiesResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalNotPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createNotPropertyNames(...propertyNames) {
    return propertyNames;
}
function createNotOptionalProperties(...properties) {
    return properties;
}
function instanceOfNot(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createNotPropertyNames();
    const optionalStringProperties = createNotOptionalProperties();
    const optionalNumberProperties = createNotOptionalProperties();
    const optionalBooleanProperties = createNotOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalNotPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalNotPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalNotPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalOrPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createOrPropertyNames(...propertyNames) {
    return propertyNames;
}
function createOrOptionalProperties(...properties) {
    return properties;
}
function instanceOfOr(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createOrPropertyNames();
    const optionalStringProperties = createOrOptionalProperties();
    const optionalNumberProperties = createOrOptionalProperties();
    const optionalBooleanProperties = createOrOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalOrPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalOrPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalOrPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageCustomerDTOPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageCustomerDTOPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageCustomerDTOOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageCustomerDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageCustomerDTOPropertyNames();
    const optionalStringProperties = createPageCustomerDTOOptionalProperties();
    const optionalNumberProperties = createPageCustomerDTOOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageCustomerDTOOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageCustomerDTOPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageCustomerDTOPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageCustomerDTOPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageableObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageableObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageableObjectPropertyNames();
    const optionalStringProperties = createPageableObjectOptionalProperties();
    const optionalNumberProperties = createPageableObjectOptionalProperties({ name: 'offset', nullable: false }, { name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createPageableObjectOptionalProperties({ name: 'paged', nullable: false }, { name: 'unpaged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPagedResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagedResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPagedResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPagedResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagedResponsePropertyNames('items', 'page', 'size', 'totalElements', 'totalPages');
    const optionalStringProperties = createPagedResponseOptionalProperties();
    const optionalNumberProperties = createPagedResponseOptionalProperties({ name: 'page', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPagedResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagedResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagedResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagedResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPartyFactReplayResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyFactReplayResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyFactReplayResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyFactReplayResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyFactReplayResultDtoPropertyNames();
    const optionalStringProperties = createPartyFactReplayResultDtoOptionalProperties({ name: 'nextAfterId', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'updatedSince', nullable: false });
    const optionalNumberProperties = createPartyFactReplayResultDtoOptionalProperties({ name: 'emitted', nullable: false });
    const optionalBooleanProperties = createPartyFactReplayResultDtoOptionalProperties({ name: 'complete', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyFactReplayResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyFactReplayResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyFactReplayResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartyMatchMatchTypeEnum;
(function (PartyMatchMatchTypeEnum) {
    PartyMatchMatchTypeEnum["Exact"] = "EXACT";
    PartyMatchMatchTypeEnum["Fuzzy"] = "FUZZY";
})(PartyMatchMatchTypeEnum || (PartyMatchMatchTypeEnum = {}));
;
function isOptionalPartyMatchPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyMatchPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyMatchOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyMatch(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyMatchPropertyNames('legalName', 'matchType', 'partyId', 'score');
    const optionalStringProperties = createPartyMatchOptionalProperties({ name: 'legalName', nullable: false }, { name: 'matchType', nullable: false }, { name: 'partyId', nullable: false });
    const optionalNumberProperties = createPartyMatchOptionalProperties();
    const optionalBooleanProperties = createPartyMatchOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyMatchPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyMatchPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyMatchPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPartyNameRefPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyNameRefPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyNameRefOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyNameRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyNameRefPropertyNames('partyId');
    const optionalStringProperties = createPartyNameRefOptionalProperties({ name: 'displayName', nullable: false }, { name: 'partyId', nullable: false }, { name: 'phoneNumber', nullable: false });
    const optionalNumberProperties = createPartyNameRefOptionalProperties();
    const optionalBooleanProperties = createPartyNameRefOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyNameRefPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyNameRefPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyNameRefPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPartyNameResolveRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyNameResolveRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyNameResolveRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyNameResolveRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyNameResolveRequestPropertyNames('partyIds');
    const optionalStringProperties = createPartyNameResolveRequestOptionalProperties();
    const optionalNumberProperties = createPartyNameResolveRequestOptionalProperties();
    const optionalBooleanProperties = createPartyNameResolveRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyNameResolveRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyNameResolveRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyNameResolveRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPartySummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartySummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartySummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartySummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartySummaryPropertyNames('partyId');
    const optionalStringProperties = createPartySummaryOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'customerNumber', nullable: false }, { name: 'displayName', nullable: false }, { name: 'legalName', nullable: false }, { name: 'partyId', nullable: false }, { name: 'partyType', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createPartySummaryOptionalProperties({ name: 'vehicleCount', nullable: false });
    const optionalBooleanProperties = createPartySummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartySummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartySummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartySummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartyTagAssignmentResponseSourceEnum;
(function (PartyTagAssignmentResponseSourceEnum) {
    PartyTagAssignmentResponseSourceEnum["Manual"] = "MANUAL";
    PartyTagAssignmentResponseSourceEnum["Campaign"] = "CAMPAIGN";
    PartyTagAssignmentResponseSourceEnum["Import"] = "IMPORT";
    PartyTagAssignmentResponseSourceEnum["Rule"] = "RULE";
})(PartyTagAssignmentResponseSourceEnum || (PartyTagAssignmentResponseSourceEnum = {}));
;
function isOptionalPartyTagAssignmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyTagAssignmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyTagAssignmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyTagAssignmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyTagAssignmentResponsePropertyNames('assignedAt', 'assignmentId', 'name', 'partyId', 'source', 'tagId');
    const optionalStringProperties = createPartyTagAssignmentResponseOptionalProperties({ name: 'assignedAt', nullable: false }, { name: 'assignedBy', nullable: false }, { name: 'assignmentId', nullable: false }, { name: 'category', nullable: false }, { name: 'name', nullable: false }, { name: 'partyId', nullable: false }, { name: 'source', nullable: false }, { name: 'tagId', nullable: false });
    const optionalNumberProperties = createPartyTagAssignmentResponseOptionalProperties();
    const optionalBooleanProperties = createPartyTagAssignmentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyTagAssignmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyTagAssignmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyTagAssignmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPartyTagResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPartyTagResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPartyTagResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPartyTagResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPartyTagResponsePropertyNames('active', 'assignmentCount', 'name', 'tagId');
    const optionalStringProperties = createPartyTagResponseOptionalProperties({ name: 'category', nullable: false }, { name: 'color', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'name', nullable: false }, { name: 'tagId', nullable: false });
    const optionalNumberProperties = createPartyTagResponseOptionalProperties({ name: 'assignmentCount', nullable: false });
    const optionalBooleanProperties = createPartyTagResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPartyTagResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPartyTagResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPartyTagResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPersonLinkReportPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPersonLinkReportPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPersonLinkReportOptionalProperties(...properties) {
    return properties;
}
function instanceOfPersonLinkReport(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPersonLinkReportPropertyNames('healthy', 'posPeopleReachable', 'resolved', 'totalLinks', 'unresolvedPersonIds');
    const optionalStringProperties = createPersonLinkReportOptionalProperties();
    const optionalNumberProperties = createPersonLinkReportOptionalProperties({ name: 'resolved', nullable: false }, { name: 'totalLinks', nullable: false });
    const optionalBooleanProperties = createPersonLinkReportOptionalProperties({ name: 'healthy', nullable: false }, { name: 'posPeopleReachable', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPersonLinkReportPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPersonLinkReportPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPersonLinkReportPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PhoneInputTypeEnum;
(function (PhoneInputTypeEnum) {
    PhoneInputTypeEnum["Email"] = "EMAIL";
    PhoneInputTypeEnum["PhoneMobile"] = "PHONE_MOBILE";
    PhoneInputTypeEnum["PhoneHome"] = "PHONE_HOME";
    PhoneInputTypeEnum["PhoneWork"] = "PHONE_WORK";
    PhoneInputTypeEnum["Fax"] = "FAX";
})(PhoneInputTypeEnum || (PhoneInputTypeEnum = {}));
;
function isOptionalPhoneInputPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPhoneInputPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPhoneInputOptionalProperties(...properties) {
    return properties;
}
function instanceOfPhoneInput(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPhoneInputPropertyNames('value');
    const optionalStringProperties = createPhoneInputOptionalProperties({ name: 'type', nullable: false }, { name: 'value', nullable: false });
    const optionalNumberProperties = createPhoneInputOptionalProperties();
    const optionalBooleanProperties = createPhoneInputOptionalProperties({ name: 'primary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPhoneInputPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPhoneInputPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPhoneInputPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPhoneNumberDTOPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPhoneNumberDTOPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPhoneNumberDTOOptionalProperties(...properties) {
    return properties;
}
function instanceOfPhoneNumberDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPhoneNumberDTOPropertyNames('number', 'type');
    const optionalStringProperties = createPhoneNumberDTOOptionalProperties({ name: 'number', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createPhoneNumberDTOOptionalProperties();
    const optionalBooleanProperties = createPhoneNumberDTOOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPhoneNumberDTOPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPhoneNumberDTOPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPhoneNumberDTOPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPrimaryContactPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPrimaryContactPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPrimaryContactOptionalProperties(...properties) {
    return properties;
}
function instanceOfPrimaryContact(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPrimaryContactPropertyNames();
    const optionalStringProperties = createPrimaryContactOptionalProperties({ name: 'email', nullable: false }, { name: 'name', nullable: false }, { name: 'phone', nullable: false });
    const optionalNumberProperties = createPrimaryContactOptionalProperties();
    const optionalBooleanProperties = createPrimaryContactOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPrimaryContactPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPrimaryContactPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPrimaryContactPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PromotionRedemptionResponseStatusEnum;
(function (PromotionRedemptionResponseStatusEnum) {
    PromotionRedemptionResponseStatusEnum["Recorded"] = "RECORDED";
    PromotionRedemptionResponseStatusEnum["RecordedOverLimit"] = "RECORDED_OVER_LIMIT";
})(PromotionRedemptionResponseStatusEnum || (PromotionRedemptionResponseStatusEnum = {}));
;
function isOptionalPromotionRedemptionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPromotionRedemptionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPromotionRedemptionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPromotionRedemptionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPromotionRedemptionResponsePropertyNames('createdAt', 'customerId', 'discountAmount', 'discountType', 'promotionCode', 'promotionId', 'promotionRedemptionId', 'status', 'workorderId');
    const optionalStringProperties = createPromotionRedemptionResponseOptionalProperties({ name: 'campaignCode', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'customerId', nullable: false }, { name: 'discountType', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'promotionCode', nullable: false }, { name: 'promotionId', nullable: false }, { name: 'promotionRedemptionId', nullable: false }, { name: 'recordedBy', nullable: false }, { name: 'redemptionTimestamp', nullable: false }, { name: 'status', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createPromotionRedemptionResponseOptionalProperties({ name: 'discountAmount', nullable: false });
    const optionalBooleanProperties = createPromotionRedemptionResponseOptionalProperties({ name: 'recordedOverLimit', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPromotionRedemptionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPromotionRedemptionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPromotionRedemptionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RecordInteractionRequestChannelEnum;
(function (RecordInteractionRequestChannelEnum) {
    RecordInteractionRequestChannelEnum["Email"] = "EMAIL";
    RecordInteractionRequestChannelEnum["Sms"] = "SMS";
})(RecordInteractionRequestChannelEnum || (RecordInteractionRequestChannelEnum = {}));
;
var RecordInteractionRequestDirectionEnum;
(function (RecordInteractionRequestDirectionEnum) {
    RecordInteractionRequestDirectionEnum["Outbound"] = "OUTBOUND";
    RecordInteractionRequestDirectionEnum["Inbound"] = "INBOUND";
})(RecordInteractionRequestDirectionEnum || (RecordInteractionRequestDirectionEnum = {}));
;
var RecordInteractionRequestTypeEnum;
(function (RecordInteractionRequestTypeEnum) {
    RecordInteractionRequestTypeEnum["CampaignSend"] = "CAMPAIGN_SEND";
    RecordInteractionRequestTypeEnum["Email"] = "EMAIL";
    RecordInteractionRequestTypeEnum["Sms"] = "SMS";
    RecordInteractionRequestTypeEnum["Call"] = "CALL";
    RecordInteractionRequestTypeEnum["FollowUp"] = "FOLLOW_UP";
    RecordInteractionRequestTypeEnum["Note"] = "NOTE";
    RecordInteractionRequestTypeEnum["WorkorderNote"] = "WORKORDER_NOTE";
})(RecordInteractionRequestTypeEnum || (RecordInteractionRequestTypeEnum = {}));
;
function isOptionalRecordInteractionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRecordInteractionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRecordInteractionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRecordInteractionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRecordInteractionRequestPropertyNames('type');
    const optionalStringProperties = createRecordInteractionRequestOptionalProperties({ name: 'body', nullable: false }, { name: 'channel', nullable: false }, { name: 'contactId', nullable: false }, { name: 'direction', nullable: false }, { name: 'occurredAt', nullable: false }, { name: 'subject', nullable: false }, { name: 'summary', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createRecordInteractionRequestOptionalProperties();
    const optionalBooleanProperties = createRecordInteractionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRecordInteractionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRecordInteractionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRecordInteractionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRecordRedemptionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRecordRedemptionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRecordRedemptionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRecordRedemptionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRecordRedemptionRequestPropertyNames('customerId', 'discountAmount', 'discountType', 'promotionCode', 'promotionId', 'workorderId');
    const optionalStringProperties = createRecordRedemptionRequestOptionalProperties({ name: 'campaignCode', nullable: false }, { name: 'customerId', nullable: false }, { name: 'discountType', nullable: false }, { name: 'invoiceId', nullable: false }, { name: 'promotionCode', nullable: false }, { name: 'promotionId', nullable: false }, { name: 'redemptionTimestamp', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createRecordRedemptionRequestOptionalProperties({ name: 'discountAmount', nullable: false });
    const optionalBooleanProperties = createRecordRedemptionRequestOptionalProperties({ name: 'recordedOverLimit', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRecordRedemptionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRecordRedemptionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRecordRedemptionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalResolveAccountTierRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolveAccountTierRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolveAccountTierRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolveAccountTierRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolveAccountTierRequestPropertyNames('accountId');
    const optionalStringProperties = createResolveAccountTierRequestOptionalProperties({ name: 'accountId', nullable: false });
    const optionalNumberProperties = createResolveAccountTierRequestOptionalProperties({ name: 'accountAgeMonths', nullable: false }, { name: 'activeContractCount', nullable: false }, { name: 'annualRevenue', nullable: false });
    const optionalBooleanProperties = createResolveAccountTierRequestOptionalProperties({ name: 'applyTier', nullable: false }, { name: 'forceRecalculation', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolveAccountTierRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolveAccountTierRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolveAccountTierRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ResolveAccountTierResponseCurrentTierEnum;
(function (ResolveAccountTierResponseCurrentTierEnum) {
    ResolveAccountTierResponseCurrentTierEnum["Standard"] = "STANDARD";
    ResolveAccountTierResponseCurrentTierEnum["Bronze"] = "BRONZE";
    ResolveAccountTierResponseCurrentTierEnum["Silver"] = "SILVER";
    ResolveAccountTierResponseCurrentTierEnum["Gold"] = "GOLD";
    ResolveAccountTierResponseCurrentTierEnum["Platinum"] = "PLATINUM";
    ResolveAccountTierResponseCurrentTierEnum["Enterprise"] = "ENTERPRISE";
})(ResolveAccountTierResponseCurrentTierEnum || (ResolveAccountTierResponseCurrentTierEnum = {}));
;
var ResolveAccountTierResponseRecommendedTierEnum;
(function (ResolveAccountTierResponseRecommendedTierEnum) {
    ResolveAccountTierResponseRecommendedTierEnum["Standard"] = "STANDARD";
    ResolveAccountTierResponseRecommendedTierEnum["Bronze"] = "BRONZE";
    ResolveAccountTierResponseRecommendedTierEnum["Silver"] = "SILVER";
    ResolveAccountTierResponseRecommendedTierEnum["Gold"] = "GOLD";
    ResolveAccountTierResponseRecommendedTierEnum["Platinum"] = "PLATINUM";
    ResolveAccountTierResponseRecommendedTierEnum["Enterprise"] = "ENTERPRISE";
})(ResolveAccountTierResponseRecommendedTierEnum || (ResolveAccountTierResponseRecommendedTierEnum = {}));
;
function isOptionalResolveAccountTierResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolveAccountTierResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolveAccountTierResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolveAccountTierResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolveAccountTierResponsePropertyNames('accountId', 'currentTier', 'manualOverrideActive', 'recommendedTier', 'tierApplied');
    const optionalStringProperties = createResolveAccountTierResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'currentTier', nullable: false }, { name: 'recommendedTier', nullable: false }, { name: 'resolutionReason', nullable: false });
    const optionalNumberProperties = createResolveAccountTierResponseOptionalProperties({ name: 'tierScore', nullable: false });
    const optionalBooleanProperties = createResolveAccountTierResponseOptionalProperties({ name: 'manualOverrideActive', nullable: false }, { name: 'tierApplied', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolveAccountTierResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolveAccountTierResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolveAccountTierResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleAssignmentPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleAssignmentPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleAssignmentOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleAssignment(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleAssignmentPropertyNames('roleCode');
    const optionalStringProperties = createRoleAssignmentOptionalProperties({ name: 'roleCode', nullable: false });
    const optionalNumberProperties = createRoleAssignmentOptionalProperties();
    const optionalBooleanProperties = createRoleAssignmentOptionalProperties({ name: 'isPrimary', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleAssignmentPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleAssignmentPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleAssignmentPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSearchPartiesRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSearchPartiesRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSearchPartiesRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSearchPartiesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSearchPartiesRequestPropertyNames();
    const optionalStringProperties = createSearchPartiesRequestOptionalProperties({ name: 'email', nullable: false }, { name: 'name', nullable: false }, { name: 'partyType', nullable: false }, { name: 'phone', nullable: false }, { name: 'sortField', nullable: false }, { name: 'sortOrder', nullable: false }, { name: 'status', nullable: false }, { name: 'taxId', nullable: false });
    const optionalNumberProperties = createSearchPartiesRequestOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createSearchPartiesRequestOptionalProperties({ name: 'includeMerged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSearchPartiesRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSearchPartiesRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSearchPartiesRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalSearchPartiesResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSearchPartiesResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSearchPartiesResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSearchPartiesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSearchPartiesResponsePropertyNames('pageNumber', 'pageSize', 'results', 'totalCount');
    const optionalStringProperties = createSearchPartiesResponseOptionalProperties();
    const optionalNumberProperties = createSearchPartiesResponseOptionalProperties({ name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false }, { name: 'totalCount', nullable: false });
    const optionalBooleanProperties = createSearchPartiesResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSearchPartiesResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSearchPartiesResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSearchPartiesResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SegmentAttributeResponseOperandKindEnum;
(function (SegmentAttributeResponseOperandKindEnum) {
    SegmentAttributeResponseOperandKindEnum["Text"] = "TEXT";
    SegmentAttributeResponseOperandKindEnum["EnumText"] = "ENUM_TEXT";
    SegmentAttributeResponseOperandKindEnum["Number"] = "NUMBER";
    SegmentAttributeResponseOperandKindEnum["Boolean"] = "BOOLEAN";
    SegmentAttributeResponseOperandKindEnum["UuidList"] = "UUID_LIST";
    SegmentAttributeResponseOperandKindEnum["KeyedText"] = "KEYED_TEXT";
})(SegmentAttributeResponseOperandKindEnum || (SegmentAttributeResponseOperandKindEnum = {}));
;
function isOptionalSegmentAttributeResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSegmentAttributeResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSegmentAttributeResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSegmentAttributeResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSegmentAttributeResponsePropertyNames('attribute', 'commercialOnly', 'description', 'keyed', 'operandKind', 'operators');
    const optionalStringProperties = createSegmentAttributeResponseOptionalProperties({ name: 'attribute', nullable: false }, { name: 'description', nullable: false }, { name: 'operandKind', nullable: false });
    const optionalNumberProperties = createSegmentAttributeResponseOptionalProperties();
    const optionalBooleanProperties = createSegmentAttributeResponseOptionalProperties({ name: 'commercialOnly', nullable: false }, { name: 'keyed', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSegmentAttributeResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSegmentAttributeResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSegmentAttributeResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSegmentMembersRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSegmentMembersRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSegmentMembersRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSegmentMembersRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSegmentMembersRequestPropertyNames('partyIds');
    const optionalStringProperties = createSegmentMembersRequestOptionalProperties();
    const optionalNumberProperties = createSegmentMembersRequestOptionalProperties();
    const optionalBooleanProperties = createSegmentMembersRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSegmentMembersRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSegmentMembersRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSegmentMembersRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSegmentPredicatePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSegmentPredicatePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSegmentPredicateOptionalProperties(...properties) {
    return properties;
}
function instanceOfSegmentPredicate(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSegmentPredicatePropertyNames('nodeType');
    const optionalStringProperties = createSegmentPredicateOptionalProperties({ name: 'nodeType', nullable: false });
    const optionalNumberProperties = createSegmentPredicateOptionalProperties();
    const optionalBooleanProperties = createSegmentPredicateOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSegmentPredicatePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSegmentPredicatePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSegmentPredicatePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var SegmentResolutionResponseAudienceTypeEnum;
(function (SegmentResolutionResponseAudienceTypeEnum) {
    SegmentResolutionResponseAudienceTypeEnum["Commercial"] = "COMMERCIAL";
    SegmentResolutionResponseAudienceTypeEnum["Individual"] = "INDIVIDUAL";
})(SegmentResolutionResponseAudienceTypeEnum || (SegmentResolutionResponseAudienceTypeEnum = {}));
;
var SegmentResolutionResponseChannelEnum;
(function (SegmentResolutionResponseChannelEnum) {
    SegmentResolutionResponseChannelEnum["Email"] = "EMAIL";
    SegmentResolutionResponseChannelEnum["Sms"] = "SMS";
})(SegmentResolutionResponseChannelEnum || (SegmentResolutionResponseChannelEnum = {}));
;
function isOptionalSegmentResolutionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSegmentResolutionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSegmentResolutionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSegmentResolutionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSegmentResolutionResponsePropertyNames('audienceType', 'sample', 'segmentId', 'totalMatched', 'truncated');
    const optionalStringProperties = createSegmentResolutionResponseOptionalProperties({ name: 'audienceType', nullable: false }, { name: 'channel', nullable: false }, { name: 'segmentId', nullable: false });
    const optionalNumberProperties = createSegmentResolutionResponseOptionalProperties({ name: 'eligibleCount', nullable: false }, { name: 'totalMatched', nullable: false });
    const optionalBooleanProperties = createSegmentResolutionResponseOptionalProperties({ name: 'truncated', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSegmentResolutionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSegmentResolutionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSegmentResolutionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var SegmentResponseAudienceTypeEnum;
(function (SegmentResponseAudienceTypeEnum) {
    SegmentResponseAudienceTypeEnum["Commercial"] = "COMMERCIAL";
    SegmentResponseAudienceTypeEnum["Individual"] = "INDIVIDUAL";
})(SegmentResponseAudienceTypeEnum || (SegmentResponseAudienceTypeEnum = {}));
;
var SegmentResponseTypeEnum;
(function (SegmentResponseTypeEnum) {
    SegmentResponseTypeEnum["Static"] = "STATIC";
    SegmentResponseTypeEnum["Dynamic"] = "DYNAMIC";
})(SegmentResponseTypeEnum || (SegmentResponseTypeEnum = {}));
;
function isOptionalSegmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSegmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSegmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSegmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSegmentResponsePropertyNames('active', 'audienceType', 'name', 'segmentId', 'type');
    const optionalStringProperties = createSegmentResponseOptionalProperties({ name: 'audienceType', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'description', nullable: false }, { name: 'name', nullable: false }, { name: 'segmentId', nullable: false }, { name: 'type', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createSegmentResponseOptionalProperties({ name: 'memberCount', nullable: false });
    const optionalBooleanProperties = createSegmentResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSegmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSegmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSegmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSegmentSampleEntryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSegmentSampleEntryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSegmentSampleEntryOptionalProperties(...properties) {
    return properties;
}
function instanceOfSegmentSampleEntry(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSegmentSampleEntryPropertyNames('partyId');
    const optionalStringProperties = createSegmentSampleEntryOptionalProperties({ name: 'maskedLabel', nullable: false }, { name: 'partyId', nullable: false });
    const optionalNumberProperties = createSegmentSampleEntryOptionalProperties();
    const optionalBooleanProperties = createSegmentSampleEntryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSegmentSampleEntryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSegmentSampleEntryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSegmentSampleEntryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SnapshotMetadataSourceEnum;
(function (SnapshotMetadataSourceEnum) {
    SnapshotMetadataSourceEnum["Cache"] = "CACHE";
    SnapshotMetadataSourceEnum["CrmApi"] = "CRM_API";
})(SnapshotMetadataSourceEnum || (SnapshotMetadataSourceEnum = {}));
;
function isOptionalSnapshotMetadataPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSnapshotMetadataPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSnapshotMetadataOptionalProperties(...properties) {
    return properties;
}
function instanceOfSnapshotMetadata(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSnapshotMetadataPropertyNames('createdAt', 'snapshotId', 'stale', 'version');
    const optionalStringProperties = createSnapshotMetadataOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'snapshotId', nullable: false }, { name: 'source', nullable: false }, { name: 'staleSince', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createSnapshotMetadataOptionalProperties();
    const optionalBooleanProperties = createSnapshotMetadataOptionalProperties({ name: 'stale', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSnapshotMetadataPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSnapshotMetadataPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSnapshotMetadataPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSortObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSortObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSortObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSortObjectPropertyNames();
    const optionalStringProperties = createSortObjectOptionalProperties();
    const optionalNumberProperties = createSortObjectOptionalProperties();
    const optionalBooleanProperties = createSortObjectOptionalProperties({ name: 'empty', nullable: false }, { name: 'sorted', nullable: false }, { name: 'unsorted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SubmitInquiryRequestAudienceTypeEnum;
(function (SubmitInquiryRequestAudienceTypeEnum) {
    SubmitInquiryRequestAudienceTypeEnum["Commercial"] = "COMMERCIAL";
    SubmitInquiryRequestAudienceTypeEnum["Individual"] = "INDIVIDUAL";
})(SubmitInquiryRequestAudienceTypeEnum || (SubmitInquiryRequestAudienceTypeEnum = {}));
;
var SubmitInquiryRequestChannelEnum;
(function (SubmitInquiryRequestChannelEnum) {
    SubmitInquiryRequestChannelEnum["WebForm"] = "WEB_FORM";
    SubmitInquiryRequestChannelEnum["Phone"] = "PHONE";
    SubmitInquiryRequestChannelEnum["WalkIn"] = "WALK_IN";
    SubmitInquiryRequestChannelEnum["Email"] = "EMAIL";
    SubmitInquiryRequestChannelEnum["Referral"] = "REFERRAL";
    SubmitInquiryRequestChannelEnum["Campaign"] = "CAMPAIGN";
})(SubmitInquiryRequestChannelEnum || (SubmitInquiryRequestChannelEnum = {}));
;
function isOptionalSubmitInquiryRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubmitInquiryRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubmitInquiryRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubmitInquiryRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubmitInquiryRequestPropertyNames('audienceType', 'channel', 'contactName');
    const optionalStringProperties = createSubmitInquiryRequestOptionalProperties({ name: 'audienceType', nullable: false }, { name: 'campaignCode', nullable: false }, { name: 'channel', nullable: false }, { name: 'contactName', nullable: false }, { name: 'email', nullable: false }, { name: 'message', nullable: false }, { name: 'organizationName', nullable: false }, { name: 'phone', nullable: false }, { name: 'serviceOfInterest', nullable: false }, { name: 'vehicleOfInterest', nullable: false });
    const optionalNumberProperties = createSubmitInquiryRequestOptionalProperties();
    const optionalBooleanProperties = createSubmitInquiryRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubmitInquiryRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubmitInquiryRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubmitInquiryRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SuppressionEntryResponseChannelEnum;
(function (SuppressionEntryResponseChannelEnum) {
    SuppressionEntryResponseChannelEnum["Email"] = "EMAIL";
    SuppressionEntryResponseChannelEnum["Sms"] = "SMS";
})(SuppressionEntryResponseChannelEnum || (SuppressionEntryResponseChannelEnum = {}));
;
function isOptionalSuppressionEntryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSuppressionEntryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSuppressionEntryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSuppressionEntryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSuppressionEntryResponsePropertyNames('channel', 'createdAt', 'reason', 'source', 'suppressionId');
    const optionalStringProperties = createSuppressionEntryResponseOptionalProperties({ name: 'addressHint', nullable: false }, { name: 'channel', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'partyId', nullable: false }, { name: 'reason', nullable: false }, { name: 'source', nullable: false }, { name: 'suppressionId', nullable: false });
    const optionalNumberProperties = createSuppressionEntryResponseOptionalProperties();
    const optionalBooleanProperties = createSuppressionEntryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSuppressionEntryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSuppressionEntryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSuppressionEntryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalUpdateContactRolesRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateContactRolesRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateContactRolesRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateContactRolesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateContactRolesRequestPropertyNames('roles');
    const optionalStringProperties = createUpdateContactRolesRequestOptionalProperties({ name: 'version', nullable: false });
    const optionalNumberProperties = createUpdateContactRolesRequestOptionalProperties();
    const optionalBooleanProperties = createUpdateContactRolesRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateContactRolesRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateContactRolesRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateContactRolesRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpdateContactRolesResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateContactRolesResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateContactRolesResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateContactRolesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateContactRolesResponsePropertyNames('contactId', 'partyId', 'status');
    const optionalStringProperties = createUpdateContactRolesResponseOptionalProperties({ name: 'contactId', nullable: false }, { name: 'partyId', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createUpdateContactRolesResponseOptionalProperties();
    const optionalBooleanProperties = createUpdateContactRolesResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateContactRolesResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateContactRolesResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateContactRolesResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var UpdateMarketingConsentRequestMarketingEmailConsentEnum;
(function (UpdateMarketingConsentRequestMarketingEmailConsentEnum) {
    UpdateMarketingConsentRequestMarketingEmailConsentEnum["OptIn"] = "OPT_IN";
    UpdateMarketingConsentRequestMarketingEmailConsentEnum["OptOut"] = "OPT_OUT";
    UpdateMarketingConsentRequestMarketingEmailConsentEnum["Unset"] = "UNSET";
})(UpdateMarketingConsentRequestMarketingEmailConsentEnum || (UpdateMarketingConsentRequestMarketingEmailConsentEnum = {}));
;
var UpdateMarketingConsentRequestMarketingSmsConsentEnum;
(function (UpdateMarketingConsentRequestMarketingSmsConsentEnum) {
    UpdateMarketingConsentRequestMarketingSmsConsentEnum["OptIn"] = "OPT_IN";
    UpdateMarketingConsentRequestMarketingSmsConsentEnum["OptOut"] = "OPT_OUT";
    UpdateMarketingConsentRequestMarketingSmsConsentEnum["Unset"] = "UNSET";
})(UpdateMarketingConsentRequestMarketingSmsConsentEnum || (UpdateMarketingConsentRequestMarketingSmsConsentEnum = {}));
;
var UpdateMarketingConsentRequestOptOutReasonEnum;
(function (UpdateMarketingConsentRequestOptOutReasonEnum) {
    UpdateMarketingConsentRequestOptOutReasonEnum["NotInterested"] = "NOT_INTERESTED";
    UpdateMarketingConsentRequestOptOutReasonEnum["TooFrequent"] = "TOO_FREQUENT";
    UpdateMarketingConsentRequestOptOutReasonEnum["NeverSignedUp"] = "NEVER_SIGNED_UP";
    UpdateMarketingConsentRequestOptOutReasonEnum["ContentNotRelevant"] = "CONTENT_NOT_RELEVANT";
    UpdateMarketingConsentRequestOptOutReasonEnum["LegalDnc"] = "LEGAL_DNC";
    UpdateMarketingConsentRequestOptOutReasonEnum["Other"] = "OTHER";
})(UpdateMarketingConsentRequestOptOutReasonEnum || (UpdateMarketingConsentRequestOptOutReasonEnum = {}));
;
var UpdateMarketingConsentRequestSourceEnum;
(function (UpdateMarketingConsentRequestSourceEnum) {
    UpdateMarketingConsentRequestSourceEnum["Csr"] = "CSR";
    UpdateMarketingConsentRequestSourceEnum["SelfService"] = "SELF_SERVICE";
    UpdateMarketingConsentRequestSourceEnum["UnsubscribeLink"] = "UNSUBSCRIBE_LINK";
    UpdateMarketingConsentRequestSourceEnum["Import"] = "IMPORT";
    UpdateMarketingConsentRequestSourceEnum["Api"] = "API";
    UpdateMarketingConsentRequestSourceEnum["System"] = "SYSTEM";
})(UpdateMarketingConsentRequestSourceEnum || (UpdateMarketingConsentRequestSourceEnum = {}));
;
function isOptionalUpdateMarketingConsentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateMarketingConsentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateMarketingConsentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateMarketingConsentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateMarketingConsentRequestPropertyNames();
    const optionalStringProperties = createUpdateMarketingConsentRequestOptionalProperties({ name: 'marketingEmailConsent', nullable: false }, { name: 'marketingSmsConsent', nullable: false }, { name: 'optOutReason', nullable: false }, { name: 'quietHoursEnd', nullable: false }, { name: 'quietHoursStart', nullable: false }, { name: 'source', nullable: false });
    const optionalNumberProperties = createUpdateMarketingConsentRequestOptionalProperties({ name: 'maxMarketingSendsPerMonth', nullable: false });
    const optionalBooleanProperties = createUpdateMarketingConsentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateMarketingConsentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateMarketingConsentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateMarketingConsentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var UpsertBillingRulesRequestInvoiceDeliveryMethodEnum;
(function (UpsertBillingRulesRequestInvoiceDeliveryMethodEnum) {
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Mail"] = "MAIL";
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Portal"] = "PORTAL";
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Edi"] = "EDI";
})(UpsertBillingRulesRequestInvoiceDeliveryMethodEnum || (UpsertBillingRulesRequestInvoiceDeliveryMethodEnum = {}));
;
function isOptionalUpsertBillingRulesRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpsertBillingRulesRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpsertBillingRulesRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpsertBillingRulesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpsertBillingRulesRequestPropertyNames();
    const optionalStringProperties = createUpsertBillingRulesRequestOptionalProperties({ name: 'billingAddressId', nullable: false }, { name: 'currency', nullable: false }, { name: 'discountPolicyRef', nullable: false }, { name: 'invoiceDeliveryMethod', nullable: false }, { name: 'paymentTerms', nullable: false });
    const optionalNumberProperties = createUpsertBillingRulesRequestOptionalProperties({ name: 'creditLimit', nullable: false });
    const optionalBooleanProperties = createUpsertBillingRulesRequestOptionalProperties({ name: 'autoPayEnabled', nullable: false }, { name: 'creditHold', nullable: false }, { name: 'poRequired', nullable: false }, { name: 'taxExempt', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpsertBillingRulesRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpsertBillingRulesRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpsertBillingRulesRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpsertCommunicationPreferencesRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpsertCommunicationPreferencesRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpsertCommunicationPreferencesRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpsertCommunicationPreferencesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpsertCommunicationPreferencesRequestPropertyNames();
    const optionalStringProperties = createUpsertCommunicationPreferencesRequestOptionalProperties({ name: 'emailPreference', nullable: false }, { name: 'marketingPreference', nullable: false }, { name: 'phonePreference', nullable: false }, { name: 'preferencesNote', nullable: false }, { name: 'smsPreference', nullable: false }, { name: 'updateSource', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createUpsertCommunicationPreferencesRequestOptionalProperties();
    const optionalBooleanProperties = createUpsertCommunicationPreferencesRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpsertCommunicationPreferencesRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpsertCommunicationPreferencesRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpsertCommunicationPreferencesRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpsertCommunicationPreferencesResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpsertCommunicationPreferencesResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpsertCommunicationPreferencesResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpsertCommunicationPreferencesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpsertCommunicationPreferencesResponsePropertyNames('operationType', 'partyId', 'status');
    const optionalStringProperties = createUpsertCommunicationPreferencesResponseOptionalProperties({ name: 'operationType', nullable: false }, { name: 'partyId', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createUpsertCommunicationPreferencesResponseOptionalProperties();
    const optionalBooleanProperties = createUpsertCommunicationPreferencesResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpsertCommunicationPreferencesResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpsertCommunicationPreferencesResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpsertCommunicationPreferencesResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpsertPartyTagRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpsertPartyTagRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpsertPartyTagRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpsertPartyTagRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpsertPartyTagRequestPropertyNames('name');
    const optionalStringProperties = createUpsertPartyTagRequestOptionalProperties({ name: 'category', nullable: false }, { name: 'color', nullable: false }, { name: 'name', nullable: false });
    const optionalNumberProperties = createUpsertPartyTagRequestOptionalProperties();
    const optionalBooleanProperties = createUpsertPartyTagRequestOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpsertPartyTagRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpsertPartyTagRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpsertPartyTagRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var UpsertSegmentRequestAudienceTypeEnum;
(function (UpsertSegmentRequestAudienceTypeEnum) {
    UpsertSegmentRequestAudienceTypeEnum["Commercial"] = "COMMERCIAL";
    UpsertSegmentRequestAudienceTypeEnum["Individual"] = "INDIVIDUAL";
})(UpsertSegmentRequestAudienceTypeEnum || (UpsertSegmentRequestAudienceTypeEnum = {}));
;
var UpsertSegmentRequestTypeEnum;
(function (UpsertSegmentRequestTypeEnum) {
    UpsertSegmentRequestTypeEnum["Static"] = "STATIC";
    UpsertSegmentRequestTypeEnum["Dynamic"] = "DYNAMIC";
})(UpsertSegmentRequestTypeEnum || (UpsertSegmentRequestTypeEnum = {}));
;
function isOptionalUpsertSegmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpsertSegmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpsertSegmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpsertSegmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpsertSegmentRequestPropertyNames('audienceType', 'name', 'type');
    const optionalStringProperties = createUpsertSegmentRequestOptionalProperties({ name: 'audienceType', nullable: false }, { name: 'description', nullable: false }, { name: 'name', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createUpsertSegmentRequestOptionalProperties();
    const optionalBooleanProperties = createUpsertSegmentRequestOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpsertSegmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpsertSegmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpsertSegmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var VehicleResponseOdometerUnitEnum;
(function (VehicleResponseOdometerUnitEnum) {
    VehicleResponseOdometerUnitEnum["Miles"] = "MILES";
    VehicleResponseOdometerUnitEnum["Kilometers"] = "KILOMETERS";
})(VehicleResponseOdometerUnitEnum || (VehicleResponseOdometerUnitEnum = {}));
;
function isOptionalVehicleResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVehicleResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createVehicleResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfVehicleResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVehicleResponsePropertyNames('accountId', 'createdAt', 'description', 'isActive', 'unitNumber', 'updatedAt', 'vehicleId', 'version', 'vin', 'vinNormalized');
    const optionalStringProperties = createVehicleResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'licensePlate', nullable: false }, { name: 'licensePlateJurisdiction', nullable: false }, { name: 'make', nullable: false }, { name: 'model', nullable: false }, { name: 'odometerUnit', nullable: false }, { name: 'trim', nullable: false }, { name: 'unitNumber', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'updatedBy', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'vin', nullable: false }, { name: 'vinNormalized', nullable: false });
    const optionalNumberProperties = createVehicleResponseOptionalProperties({ name: 'odometerValue', nullable: false }, { name: 'version', nullable: false }, { name: 'year', nullable: false });
    const optionalBooleanProperties = createVehicleResponseOptionalProperties({ name: 'isActive', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVehicleResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVehicleResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVehicleResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalVehicleSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVehicleSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createVehicleSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfVehicleSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVehicleSummaryPropertyNames('vehicleId');
    const optionalStringProperties = createVehicleSummaryOptionalProperties({ name: 'licensePlate', nullable: false }, { name: 'make', nullable: false }, { name: 'model', nullable: false }, { name: 'vehicleId', nullable: false }, { name: 'vin', nullable: false });
    const optionalNumberProperties = createVehicleSummaryOptionalProperties({ name: 'year', nullable: false });
    const optionalBooleanProperties = createVehicleSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVehicleSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVehicleSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVehicleSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AddSuppressionRequestChannelEnum, AddSuppressionRequestReasonEnum, AddSuppressionRequestSourceEnum, ApiModule, AssignPartyTagRequestSourceEnum, AssignedRoleRoleCodeEnum, BASE_PATH, BillingRuleRefInvoiceDeliveryMethodEnum, COLLECTION_FORMATS, CRMAccountsService, CRMCommunicationPreferencesService, CRMContactsService, CRMFollowUpsService, CRMInquiriesService, CRMInteractionsService, CRMMarketingConsentService, CRMPartyRelationshipsService, CRMPersonLinkReconciliationService, CRMPersonsService, CRMPublicInquiryService, CRMSegmentsService, CRMSnapshotsService, CRMSuppressionService, CRMTagsService, CRMVehiclesService, CommercialBulkIngestAPIService, ComparisonOperatorEnum, Configuration, ContactPointDtoContactTypeEnum, ContactWithRoleRolesEnum, ContactWithRolesInvoiceDeliveryMethodEnum, CreateFollowUpTaskRequestTypeEnum, CreatePartyRelationshipRequestRolesEnum, CreatePartyRelationshipResponseRolesEnum, CreatePersonRequestPreferredContactMethodEnum, CreatePersonResponsePreferredContactMethodEnum, CreateVehicleForPartyResponseStatusEnum, CustomerAPIService, CustomerBulkIngestAPIService, CustomerInteractionResponseChannelEnum, CustomerInteractionResponseDirectionEnum, CustomerInteractionResponseTypeEnum, CustomerRequirementsService, FollowUpTaskResponseStatusEnum, FollowUpTaskResponseTypeEnum, GetAccountTierResponseTierEnum, GetCommunicationPreferencesResponseEmailPreferenceEnum, GetCommunicationPreferencesResponseMarketingPreferenceEnum, GetCommunicationPreferencesResponsePhonePreferenceEnum, GetCommunicationPreferencesResponseSmsPreferenceEnum, GetCommunicationPreferencesResponseUpdateSourceEnum, GetPersonResponsePreferredContactMethodEnum, InquiryResponseAudienceTypeEnum, InquiryResponseChannelEnum, InquiryResponseStatusEnum, MarketingConsentDecisionChannelEnum, MarketingConsentDecisionReasonEnum, MarketingConsentSummaryResponseMarketingEmailConsentEnum, MarketingConsentSummaryResponseMarketingSmsConsentEnum, PartyMatchMatchTypeEnum, PartyTagAssignmentResponseSourceEnum, PhoneInputTypeEnum, PromotionRedemptionResponseStatusEnum, PromotionRedemptionsService, RecordInteractionRequestChannelEnum, RecordInteractionRequestDirectionEnum, RecordInteractionRequestTypeEnum, ResolveAccountTierResponseCurrentTierEnum, ResolveAccountTierResponseRecommendedTierEnum, SegmentAttributeResponseOperandKindEnum, SegmentResolutionResponseAudienceTypeEnum, SegmentResolutionResponseChannelEnum, SegmentResponseAudienceTypeEnum, SegmentResponseTypeEnum, SnapshotMetadataSourceEnum, SubmitInquiryRequestAudienceTypeEnum, SubmitInquiryRequestChannelEnum, SuppressionEntryResponseChannelEnum, UpdateMarketingConsentRequestMarketingEmailConsentEnum, UpdateMarketingConsentRequestMarketingSmsConsentEnum, UpdateMarketingConsentRequestOptOutReasonEnum, UpdateMarketingConsentRequestSourceEnum, UpsertBillingRulesRequestInvoiceDeliveryMethodEnum, UpsertSegmentRequestAudienceTypeEnum, UpsertSegmentRequestTypeEnum, VehicleResponseOdometerUnitEnum, instanceOfAccountSummary, instanceOfAddSuppressionRequest, instanceOfAnd, instanceOfApiError, instanceOfAssignPartyTagRequest, instanceOfAssignedRole, instanceOfBillingPreferences, instanceOfBillingRuleRef, instanceOfBillingTermsRef, instanceOfBulkIngestRequestCommercialBulkIngestRecord, instanceOfBulkIngestRequestCustomerBulkIngestRecord, instanceOfBulkIngestResponse, instanceOfBulkIngestResult, instanceOfCloseFollowUpTaskRequest, instanceOfCommercialBulkIngestRecord, instanceOfComparison, instanceOfContactPointDto, instanceOfContactPreferences, instanceOfContactSummary, instanceOfContactWithRole, instanceOfContactWithRoles, instanceOfCreateCommercialAccountRequest, instanceOfCreateCommercialAccountResponse, instanceOfCreateFollowUpTaskRequest, instanceOfCreatePartyRelationshipRequest, instanceOfCreatePartyRelationshipResponse, instanceOfCreatePersonRequest, instanceOfCreatePersonResponse, instanceOfCreateVehicleForPartyRequest, instanceOfCreateVehicleForPartyResponse, instanceOfCrmSnapshotDTO, instanceOfCustomerBulkIngestRecord, instanceOfCustomerDTO, instanceOfCustomerInteractionResponse, instanceOfDuplicateCandidate, instanceOfDuplicateCheckResponse, instanceOfEmailAddressDTO, instanceOfEmailInput, instanceOfFieldError, instanceOfFollowUpTaskResponse, instanceOfGetAccountTierResponse, instanceOfGetCommercialAccountContactsResponse, instanceOfGetCommunicationPreferencesResponse, instanceOfGetContactsWithRolesResponse, instanceOfGetPartyResponse, instanceOfGetPersonResponse, instanceOfIndividualDetails, instanceOfInquiryAcceptedResponse, instanceOfInquiryResponse, instanceOfMarketingConsentDecision, instanceOfMarketingConsentSummaryResponse, instanceOfMergePartiesRequest, instanceOfMergePartiesResponse, instanceOfNot, instanceOfOr, instanceOfPageCustomerDTO, instanceOfPageableObject, instanceOfPagedResponse, instanceOfPartyFactReplayResultDto, instanceOfPartyMatch, instanceOfPartyNameRef, instanceOfPartyNameResolveRequest, instanceOfPartySummary, instanceOfPartyTagAssignmentResponse, instanceOfPartyTagResponse, instanceOfPersonLinkReport, instanceOfPhoneInput, instanceOfPhoneNumberDTO, instanceOfPrimaryContact, instanceOfPromotionRedemptionResponse, instanceOfRecordInteractionRequest, instanceOfRecordRedemptionRequest, instanceOfResolveAccountTierRequest, instanceOfResolveAccountTierResponse, instanceOfRoleAssignment, instanceOfSearchPartiesRequest, instanceOfSearchPartiesResponse, instanceOfSegmentAttributeResponse, instanceOfSegmentMembersRequest, instanceOfSegmentPredicate, instanceOfSegmentResolutionResponse, instanceOfSegmentResponse, instanceOfSegmentSampleEntry, instanceOfSnapshotMetadata, instanceOfSortObject, instanceOfSubmitInquiryRequest, instanceOfSuppressionEntryResponse, instanceOfUpdateContactRolesRequest, instanceOfUpdateContactRolesResponse, instanceOfUpdateMarketingConsentRequest, instanceOfUpsertBillingRulesRequest, instanceOfUpsertCommunicationPreferencesRequest, instanceOfUpsertCommunicationPreferencesResponse, instanceOfUpsertPartyTagRequest, instanceOfUpsertSegmentRequest, instanceOfVehicleResponse, instanceOfVehicleSummary, provideApi };
//# sourceMappingURL=durion-sdk-customer.mjs.map
