export * from '../../models/tenderTotal';
