import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/v1/customer';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMAccountsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    checkPartyDuplicates(legalName, observe = 'body', reportProgress = false, options) {
        if (legalName === null || legalName === undefined) {
            throw new Error('Required parameter legalName was null or undefined when calling checkPartyDuplicates.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'legalName', legalName, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/duplicate-check`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createCommercialAccount(createCommercialAccountRequest, observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createCommercialAccountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createVehicleForParty(partyId, createVehicleForPartyRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling createVehicleForParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createVehicleForPartyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAccountTier(accountId, observe = 'body', reportProgress = false, options) {
        if (accountId === null || accountId === undefined) {
            throw new Error('Required parameter accountId was null or undefined when calling getAccountTier.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/${this.configuration.encodeParam({ name: "accountId", value: accountId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tier`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCommunicationPreferences1(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getCommunicationPreferences1.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getContactsWithRoles1(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getContactsWithRoles1.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getParty(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listBillingTerms(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/billing-terms`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    mergeParties(partyId, mergePartiesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling mergeParties.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/merge`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: mergePartiesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveAccountTier(resolveAccountTierRequest, observe = 'body', reportProgress = false, options) {
        if (resolveAccountTierRequest === null || resolveAccountTierRequest === undefined) {
            throw new Error('Required parameter resolveAccountTierRequest was null or undefined when calling resolveAccountTier.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/tierResolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: resolveAccountTierRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchParties(searchPartiesRequest, observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: searchPartiesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateContactRoles1(partyId, contactId, updateContactRolesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling updateContactRoles1.');
        }
        if (contactId === null || contactId === undefined) {
            throw new Error('Required parameter contactId was null or undefined when calling updateContactRoles1.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts/${this.configuration.encodeParam({ name: "contactId", value: contactId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateContactRolesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertBillingRules(partyId, upsertBillingRulesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertBillingRules.');
        }
        if (upsertBillingRulesRequest === null || upsertBillingRulesRequest === undefined) {
            throw new Error('Required parameter upsertBillingRulesRequest was null or undefined when calling upsertBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/billing-rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertBillingRulesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertCommunicationPreferences1(partyId, upsertCommunicationPreferencesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertCommunicationPreferences1.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/accounts/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertCommunicationPreferencesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMAccountsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMAccountsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMAccountsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMCommunicationPreferencesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getCommunicationPreferences(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getCommunicationPreferences.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertCommunicationPreferences(partyId, upsertCommunicationPreferencesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling upsertCommunicationPreferences.');
        }
        if (upsertCommunicationPreferencesRequest === null || upsertCommunicationPreferencesRequest === undefined) {
            throw new Error('Required parameter upsertCommunicationPreferencesRequest was null or undefined when calling upsertCommunicationPreferences.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/communicationPreferences`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: upsertCommunicationPreferencesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMCommunicationPreferencesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMCommunicationPreferencesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMCommunicationPreferencesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMContactsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getContactsWithRoles(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getContactsWithRoles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateContactRoles(partyId, contactId, updateContactRolesRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling updateContactRoles.');
        }
        if (contactId === null || contactId === undefined) {
            throw new Error('Required parameter contactId was null or undefined when calling updateContactRoles.');
        }
        if (updateContactRolesRequest === null || updateContactRolesRequest === undefined) {
            throw new Error('Required parameter updateContactRolesRequest was null or undefined when calling updateContactRoles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/parties/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts/${this.configuration.encodeParam({ name: "contactId", value: contactId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateContactRolesRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMContactsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMContactsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMContactsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMPartyRelationshipsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createRelationship(partyId, createPartyRelationshipRequest, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling createRelationship.');
        }
        if (createPartyRelationshipRequest === null || createPartyRelationshipRequest === undefined) {
            throw new Error('Required parameter createPartyRelationshipRequest was null or undefined when calling createRelationship.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/relationships`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createPartyRelationshipRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivateRelationship(partyId, relationshipId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling deactivateRelationship.');
        }
        if (relationshipId === null || relationshipId === undefined) {
            throw new Error('Required parameter relationshipId was null or undefined when calling deactivateRelationship.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/relationships/${this.configuration.encodeParam({ name: "relationshipId", value: relationshipId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    designatePrimaryBillingContact(partyId, relationshipId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling designatePrimaryBillingContact.');
        }
        if (relationshipId === null || relationshipId === undefined) {
            throw new Error('Required parameter relationshipId was null or undefined when calling designatePrimaryBillingContact.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/relationships/${this.configuration.encodeParam({ name: "relationshipId", value: relationshipId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/primary-billing`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getContacts(partyId, roles, status, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getContacts.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'roles', roles, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/commercial-accounts/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMPartyRelationshipsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMPartyRelationshipsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMPartyRelationshipsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMPersonsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPerson(createPersonRequest, observe = 'body', reportProgress = false, options) {
        if (createPersonRequest === null || createPersonRequest === undefined) {
            throw new Error('Required parameter createPersonRequest was null or undefined when calling createPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/persons`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createPersonRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPerson(personId, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/persons/${this.configuration.encodeParam({ name: "personId", value: personId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchPersons(name, email, phone, limit, offset, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'name', name, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'email', email, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'phone', phone, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'offset', offset, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/persons`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMPersonsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMPersonsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMPersonsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMSnapshotsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    fetchByParty(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling fetchByParty.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/snapshot/party/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    fetchByVehicle(vehicleId, observe = 'body', reportProgress = false, options) {
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling fetchByVehicle.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/snapshot/vehicle/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getBillingRules(partyId, observe = 'body', reportProgress = false, options) {
        if (partyId === null || partyId === undefined) {
            throw new Error('Required parameter partyId was null or undefined when calling getBillingRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/snapshot/party/${this.configuration.encodeParam({ name: "partyId", value: partyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/billing-rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMSnapshotsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMSnapshotsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMSnapshotsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CRMVehiclesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createVehicles(customerId, createVehicleForPartyRequest, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling createVehicles.');
        }
        if (createVehicleForPartyRequest === null || createVehicleForPartyRequest === undefined) {
            throw new Error('Required parameter createVehicleForPartyRequest was null or undefined when calling createVehicles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createVehicleForPartyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteVehicle(customerId, vehicleId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling deleteVehicle.');
        }
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling deleteVehicle.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getVehiclesForCustomer(customerId, vehicleId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling getVehiclesForCustomer.');
        }
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling getVehiclesForCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    transferVehicles(customerId, vehicleId, vehicleTransferRequest, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling transferVehicles.');
        }
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling transferVehicles.');
        }
        if (vehicleTransferRequest === null || vehicleTransferRequest === undefined) {
            throw new Error('Required parameter vehicleTransferRequest was null or undefined when calling transferVehicles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/transfer`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: vehicleTransferRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateVehicles(customerId, vehicleId, createVehicleForPartyRequest, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling updateVehicles.');
        }
        if (vehicleId === null || vehicleId === undefined) {
            throw new Error('Required parameter vehicleId was null or undefined when calling updateVehicles.');
        }
        if (createVehicleForPartyRequest === null || createVehicleForPartyRequest === undefined) {
            throw new Error('Required parameter createVehicleForPartyRequest was null or undefined when calling updateVehicles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/vehicles/${this.configuration.encodeParam({ name: "vehicleId", value: vehicleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createVehicleForPartyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMVehiclesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMVehiclesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CRMVehiclesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CustomerAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCustomer(customerDTO, observe = 'body', reportProgress = false, options) {
        if (customerDTO === null || customerDTO === undefined) {
            throw new Error('Required parameter customerDTO was null or undefined when calling createCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: customerDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteCustomer(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling deleteCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAllCustomers(pageable, customerType, observe = 'body', reportProgress = false, options) {
        if (pageable === null || pageable === undefined) {
            throw new Error('Required parameter pageable was null or undefined when calling getAllCustomers.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'customerType', customerType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageable', pageable, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCustomerById(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getCustomerById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCustomer(id, customerDTO, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateCustomer.');
        }
        if (customerDTO === null || customerDTO === undefined) {
            throw new Error('Required parameter customerDTO was null or undefined when calling updateCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/crm/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: customerDTO,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CustomerAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CustomerAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CustomerAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CustomerBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngest(bulkIngestRequestCustomerBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestCustomerBulkIngestRecord === null || bulkIngestRequestCustomerBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestCustomerBulkIngestRecord was null or undefined when calling bulkIngest.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/customer/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestCustomerBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CustomerBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CustomerBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: CustomerBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PromotionRedemptionsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getRedemptionsByCustomer(customerId, observe = 'body', reportProgress = false, options) {
        if (customerId === null || customerId === undefined) {
            throw new Error('Required parameter customerId was null or undefined when calling getRedemptionsByCustomer.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/promotions/redemptions/by-customer/${this.configuration.encodeParam({ name: "customerId", value: customerId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    recordRedemption(recordRedemptionRequest, observe = 'body', reportProgress = false, options) {
        if (recordRedemptionRequest === null || recordRedemptionRequest === undefined) {
            throw new Error('Required parameter recordRedemptionRequest was null or undefined when calling recordRedemption.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/promotions/redemptions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: recordRedemptionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PromotionRedemptionsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PromotionRedemptionsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: PromotionRedemptionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

const APIS = [CRMAccountsService, CRMCommunicationPreferencesService, CRMContactsService, CRMPartyRelationshipsService, CRMPersonsService, CRMSnapshotsService, CRMVehiclesService, CustomerAPIService, CustomerBulkIngestAPIService, PromotionRedemptionsService];

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfAccountSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('accountNumber' in _v && typeof _v['accountNumber'] !== 'string')
        return false;
    if ('accountName' in _v && typeof _v['accountName'] !== 'string')
        return false;
    if ('accountType' in _v && typeof _v['accountType'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfAssignedRole(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('roleCode' in _v && typeof _v['roleCode'] !== 'string')
        return false;
    if ('roleLabel' in _v && typeof _v['roleLabel'] !== 'string')
        return false;
    if ('isPrimary' in _v && typeof _v['isPrimary'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfBillingPreferences(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('marketingOptOut' in _v && typeof _v['marketingOptOut'] !== 'boolean')
        return false;
    if ('doNotContact' in _v && typeof _v['doNotContact'] !== 'boolean')
        return false;
    if ('invoiceDeliveryMethod' in _v && typeof _v['invoiceDeliveryMethod'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BillingRuleRefInvoiceDeliveryMethodEnum;
(function (BillingRuleRefInvoiceDeliveryMethodEnum) {
    BillingRuleRefInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    BillingRuleRefInvoiceDeliveryMethodEnum["Mail"] = "MAIL";
    BillingRuleRefInvoiceDeliveryMethodEnum["Portal"] = "PORTAL";
    BillingRuleRefInvoiceDeliveryMethodEnum["Edi"] = "EDI";
})(BillingRuleRefInvoiceDeliveryMethodEnum || (BillingRuleRefInvoiceDeliveryMethodEnum = {}));
;
function instanceOfBillingRuleRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('poRequired' in _v && typeof _v['poRequired'] !== 'boolean')
        return false;
    if ('taxExempt' in _v && typeof _v['taxExempt'] !== 'boolean')
        return false;
    if ('paymentTerms' in _v && typeof _v['paymentTerms'] !== 'string')
        return false;
    if ('creditLimit' in _v && typeof _v['creditLimit'] !== 'number')
        return false;
    if ('creditHold' in _v && typeof _v['creditHold'] !== 'boolean')
        return false;
    if ('invoiceDeliveryMethod' in _v && typeof _v['invoiceDeliveryMethod'] !== 'string')
        return false;
    if ('billingAddressId' in _v && typeof _v['billingAddressId'] !== 'string')
        return false;
    if ('autoPayEnabled' in _v && typeof _v['autoPayEnabled'] !== 'boolean')
        return false;
    if ('discountPolicyRef' in _v && typeof _v['discountPolicyRef'] !== 'string')
        return false;
    if ('currency' in _v && typeof _v['currency'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfBillingTermsRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('code' in _v && typeof _v['code'] !== 'string')
        return false;
    if ('label' in _v && typeof _v['label'] !== 'string')
        return false;
    if ('netDays' in _v && typeof _v['netDays'] !== 'number')
        return false;
    return true;
}

function instanceOfBulkIngestRequestCustomerBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('jobId' in _v) || _v['jobId'] === undefined)
        return false;
    if ('jobId' in _v && typeof _v['jobId'] !== 'string')
        return false;
    if (!('locationId' in _v) || _v['locationId'] === undefined)
        return false;
    if ('locationId' in _v && typeof _v['locationId'] !== 'string')
        return false;
    if (!('records' in _v) || _v['records'] === undefined)
        return false;
    if ('operatorId' in _v && typeof _v['operatorId'] !== 'string')
        return false;
    return true;
}

function instanceOfBulkIngestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('totalSubmitted' in _v && typeof _v['totalSubmitted'] !== 'number')
        return false;
    if ('successCount' in _v && typeof _v['successCount'] !== 'number')
        return false;
    if ('failureCount' in _v && typeof _v['failureCount'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfBulkIngestResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('rowIndex' in _v && typeof _v['rowIndex'] !== 'number')
        return false;
    if ('entityId' in _v && typeof _v['entityId'] !== 'string')
        return false;
    if ('success' in _v && typeof _v['success'] !== 'boolean')
        return false;
    if ('errorCode' in _v && typeof _v['errorCode'] !== 'string')
        return false;
    if ('errorMessage' in _v && typeof _v['errorMessage'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ContactPointDtoContactTypeEnum;
(function (ContactPointDtoContactTypeEnum) {
    ContactPointDtoContactTypeEnum["Email"] = "EMAIL";
    ContactPointDtoContactTypeEnum["PhoneMobile"] = "PHONE_MOBILE";
    ContactPointDtoContactTypeEnum["PhoneHome"] = "PHONE_HOME";
    ContactPointDtoContactTypeEnum["PhoneWork"] = "PHONE_WORK";
    ContactPointDtoContactTypeEnum["Fax"] = "FAX";
})(ContactPointDtoContactTypeEnum || (ContactPointDtoContactTypeEnum = {}));
;
function instanceOfContactPointDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('contactPointId' in _v && typeof _v['contactPointId'] !== 'string')
        return false;
    if ('contactType' in _v && typeof _v['contactType'] !== 'string')
        return false;
    if ('value' in _v && typeof _v['value'] !== 'string')
        return false;
    if ('primary' in _v && typeof _v['primary'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfContactPreferences(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('emailOptIn' in _v && typeof _v['emailOptIn'] !== 'boolean')
        return false;
    if ('smsOptIn' in _v && typeof _v['smsOptIn'] !== 'boolean')
        return false;
    if ('phoneOptIn' in _v && typeof _v['phoneOptIn'] !== 'boolean')
        return false;
    if ('doNotContact' in _v && typeof _v['doNotContact'] !== 'boolean')
        return false;
    if ('preferredContactMethod' in _v && typeof _v['preferredContactMethod'] !== 'string')
        return false;
    if ('preferredLanguage' in _v && typeof _v['preferredLanguage'] !== 'string')
        return false;
    return true;
}

function instanceOfContactSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('contactId' in _v && typeof _v['contactId'] !== 'string')
        return false;
    if ('name' in _v && typeof _v['name'] !== 'string')
        return false;
    if ('primary' in _v && typeof _v['primary'] !== 'boolean')
        return false;
    return true;
}

var ContactWithRoleRolesEnum;
(function (ContactWithRoleRolesEnum) {
    ContactWithRoleRolesEnum["Approver"] = "APPROVER";
    ContactWithRoleRolesEnum["Billing"] = "BILLING";
    ContactWithRoleRolesEnum["PrimaryContact"] = "PRIMARY_CONTACT";
    ContactWithRoleRolesEnum["Driver"] = "DRIVER";
    ContactWithRoleRolesEnum["Technical"] = "TECHNICAL";
})(ContactWithRoleRolesEnum || (ContactWithRoleRolesEnum = {}));
;
function instanceOfContactWithRole(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('relationshipId' in _v && typeof _v['relationshipId'] !== 'string')
        return false;
    if ('individualId' in _v && typeof _v['individualId'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('primaryBilling' in _v && typeof _v['primaryBilling'] !== 'boolean')
        return false;
    return true;
}

function instanceOfContactWithRoles(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('contactId' in _v && typeof _v['contactId'] !== 'string')
        return false;
    if ('contactName' in _v && typeof _v['contactName'] !== 'string')
        return false;
    if ('email' in _v && typeof _v['email'] !== 'string')
        return false;
    if ('phone' in _v && typeof _v['phone'] !== 'string')
        return false;
    if ('hasPrimaryEmail' in _v && typeof _v['hasPrimaryEmail'] !== 'boolean')
        return false;
    if ('invoiceDeliveryMethod' in _v && typeof _v['invoiceDeliveryMethod'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfCreateCommercialAccountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('legalName' in _v && typeof _v['legalName'] !== 'string')
        return false;
    if ('displayName' in _v && typeof _v['displayName'] !== 'string')
        return false;
    if ('taxId' in _v && typeof _v['taxId'] !== 'string')
        return false;
    if ('partyType' in _v && typeof _v['partyType'] !== 'string')
        return false;
    if ('billingTermsId' in _v && typeof _v['billingTermsId'] !== 'string')
        return false;
    if ('contactFirstName' in _v && typeof _v['contactFirstName'] !== 'string')
        return false;
    if ('contactLastName' in _v && typeof _v['contactLastName'] !== 'string')
        return false;
    if ('email' in _v && typeof _v['email'] !== 'string')
        return false;
    if ('phone' in _v && typeof _v['phone'] !== 'string')
        return false;
    return true;
}

function instanceOfCreateCommercialAccountResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('legalName' in _v && typeof _v['legalName'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreatePartyRelationshipRequestRolesEnum;
(function (CreatePartyRelationshipRequestRolesEnum) {
    CreatePartyRelationshipRequestRolesEnum["Approver"] = "APPROVER";
    CreatePartyRelationshipRequestRolesEnum["Billing"] = "BILLING";
    CreatePartyRelationshipRequestRolesEnum["PrimaryContact"] = "PRIMARY_CONTACT";
    CreatePartyRelationshipRequestRolesEnum["Driver"] = "DRIVER";
    CreatePartyRelationshipRequestRolesEnum["Technical"] = "TECHNICAL";
})(CreatePartyRelationshipRequestRolesEnum || (CreatePartyRelationshipRequestRolesEnum = {}));
;
function instanceOfCreatePartyRelationshipRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('personId' in _v) || _v['personId'] === undefined)
        return false;
    if ('personId' in _v && typeof _v['personId'] !== 'string')
        return false;
    if (!('roles' in _v) || _v['roles'] === undefined)
        return false;
    if (!('effectiveStartDate' in _v) || _v['effectiveStartDate'] === undefined)
        return false;
    if ('primaryBillingContact' in _v && typeof _v['primaryBillingContact'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreatePartyRelationshipResponseRolesEnum;
(function (CreatePartyRelationshipResponseRolesEnum) {
    CreatePartyRelationshipResponseRolesEnum["Approver"] = "APPROVER";
    CreatePartyRelationshipResponseRolesEnum["Billing"] = "BILLING";
    CreatePartyRelationshipResponseRolesEnum["PrimaryContact"] = "PRIMARY_CONTACT";
    CreatePartyRelationshipResponseRolesEnum["Driver"] = "DRIVER";
    CreatePartyRelationshipResponseRolesEnum["Technical"] = "TECHNICAL";
})(CreatePartyRelationshipResponseRolesEnum || (CreatePartyRelationshipResponseRolesEnum = {}));
;
function instanceOfCreatePartyRelationshipResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('relationshipId' in _v && typeof _v['relationshipId'] !== 'string')
        return false;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('personId' in _v && typeof _v['personId'] !== 'string')
        return false;
    if ('previousPrimaryDemoted' in _v && typeof _v['previousPrimaryDemoted'] !== 'boolean')
        return false;
    if ('primaryBillingContact' in _v && typeof _v['primaryBillingContact'] !== 'boolean')
        return false;
    return true;
}

var CreatePersonRequestPreferredContactMethodEnum;
(function (CreatePersonRequestPreferredContactMethodEnum) {
    CreatePersonRequestPreferredContactMethodEnum["Email"] = "EMAIL";
    CreatePersonRequestPreferredContactMethodEnum["PhoneCall"] = "PHONE_CALL";
    CreatePersonRequestPreferredContactMethodEnum["Sms"] = "SMS";
    CreatePersonRequestPreferredContactMethodEnum["None"] = "NONE";
})(CreatePersonRequestPreferredContactMethodEnum || (CreatePersonRequestPreferredContactMethodEnum = {}));
;
function instanceOfCreatePersonRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('firstName' in _v) || _v['firstName'] === undefined)
        return false;
    if ('firstName' in _v && typeof _v['firstName'] !== 'string')
        return false;
    if (!('lastName' in _v) || _v['lastName'] === undefined)
        return false;
    if ('lastName' in _v && typeof _v['lastName'] !== 'string')
        return false;
    if (!('preferredContactMethod' in _v) || _v['preferredContactMethod'] === undefined)
        return false;
    if ('preferredContactMethod' in _v && typeof _v['preferredContactMethod'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreatePersonResponsePreferredContactMethodEnum;
(function (CreatePersonResponsePreferredContactMethodEnum) {
    CreatePersonResponsePreferredContactMethodEnum["Email"] = "EMAIL";
    CreatePersonResponsePreferredContactMethodEnum["PhoneCall"] = "PHONE_CALL";
    CreatePersonResponsePreferredContactMethodEnum["Sms"] = "SMS";
    CreatePersonResponsePreferredContactMethodEnum["None"] = "NONE";
})(CreatePersonResponsePreferredContactMethodEnum || (CreatePersonResponsePreferredContactMethodEnum = {}));
;
function instanceOfCreatePersonResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('personId' in _v && typeof _v['personId'] !== 'string')
        return false;
    if ('firstName' in _v && typeof _v['firstName'] !== 'string')
        return false;
    if ('lastName' in _v && typeof _v['lastName'] !== 'string')
        return false;
    if ('preferredContactMethod' in _v && typeof _v['preferredContactMethod'] !== 'string')
        return false;
    if ('contactPointsCreated' in _v && typeof _v['contactPointsCreated'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfCreateVehicleForPartyRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('vinNumber' in _v && typeof _v['vinNumber'] !== 'string')
        return false;
    if ('unitNumber' in _v && typeof _v['unitNumber'] !== 'string')
        return false;
    if ('description' in _v && typeof _v['description'] !== 'string')
        return false;
    if ('licensePlate' in _v && typeof _v['licensePlate'] !== 'string')
        return false;
    if ('licensePlateRegion' in _v && typeof _v['licensePlateRegion'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfCreateVehicleForPartyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('vehicleId' in _v && typeof _v['vehicleId'] !== 'string')
        return false;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('vinNumber' in _v && typeof _v['vinNumber'] !== 'string')
        return false;
    if ('unitNumber' in _v && typeof _v['unitNumber'] !== 'string')
        return false;
    if ('description' in _v && typeof _v['description'] !== 'string')
        return false;
    if ('licensePlate' in _v && typeof _v['licensePlate'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('createdAt' in _v && typeof _v['createdAt'] !== 'string')
        return false;
    return true;
}

function instanceOfCrmSnapshotDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfCustomerBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('firstName' in _v) || _v['firstName'] === undefined)
        return false;
    if ('firstName' in _v && typeof _v['firstName'] !== 'string')
        return false;
    if (!('lastName' in _v) || _v['lastName'] === undefined)
        return false;
    if ('lastName' in _v && typeof _v['lastName'] !== 'string')
        return false;
    if ('email' in _v && typeof _v['email'] !== 'string')
        return false;
    if ('phoneNumber' in _v && typeof _v['phoneNumber'] !== 'string')
        return false;
    if ('primaryAddress' in _v && typeof _v['primaryAddress'] !== 'string')
        return false;
    if ('customerNumber' in _v && typeof _v['customerNumber'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfCustomerDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('id' in _v && typeof _v['id'] !== 'string')
        return false;
    if ('customerNumber' in _v && typeof _v['customerNumber'] !== 'string')
        return false;
    if (!('lastName' in _v) || _v['lastName'] === undefined)
        return false;
    if ('lastName' in _v && typeof _v['lastName'] !== 'string')
        return false;
    if (!('firstName' in _v) || _v['firstName'] === undefined)
        return false;
    if ('firstName' in _v && typeof _v['firstName'] !== 'string')
        return false;
    if ('phoneNumber' in _v && typeof _v['phoneNumber'] !== 'string')
        return false;
    if ('email' in _v && typeof _v['email'] !== 'string')
        return false;
    if ('primaryAddress' in _v && typeof _v['primaryAddress'] !== 'string')
        return false;
    if ('customerType' in _v && typeof _v['customerType'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfDuplicateCandidate(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('legalName' in _v && typeof _v['legalName'] !== 'string')
        return false;
    if ('matchReason' in _v && typeof _v['matchReason'] !== 'string')
        return false;
    return true;
}

function instanceOfDuplicateCheckResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('duplicatesFound' in _v && typeof _v['duplicatesFound'] !== 'boolean')
        return false;
    if ('exactMatchPartyId' in _v && typeof _v['exactMatchPartyId'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfEmailAddressDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('type' in _v && typeof _v['type'] !== 'string')
        return false;
    if ('address' in _v && typeof _v['address'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfEmailInput(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('value' in _v) || _v['value'] === undefined)
        return false;
    if ('value' in _v && typeof _v['value'] !== 'string')
        return false;
    if ('primary' in _v && typeof _v['primary'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var GetAccountTierResponseTierEnum;
(function (GetAccountTierResponseTierEnum) {
    GetAccountTierResponseTierEnum["Standard"] = "STANDARD";
    GetAccountTierResponseTierEnum["Bronze"] = "BRONZE";
    GetAccountTierResponseTierEnum["Silver"] = "SILVER";
    GetAccountTierResponseTierEnum["Gold"] = "GOLD";
    GetAccountTierResponseTierEnum["Platinum"] = "PLATINUM";
    GetAccountTierResponseTierEnum["Enterprise"] = "ENTERPRISE";
})(GetAccountTierResponseTierEnum || (GetAccountTierResponseTierEnum = {}));
;
function instanceOfGetAccountTierResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('accountId' in _v && typeof _v['accountId'] !== 'string')
        return false;
    if ('tier' in _v && typeof _v['tier'] !== 'string')
        return false;
    if ('tierDisplayName' in _v && typeof _v['tierDisplayName'] !== 'string')
        return false;
    if ('tierAssignedBy' in _v && typeof _v['tierAssignedBy'] !== 'string')
        return false;
    if ('notes' in _v && typeof _v['notes'] !== 'string')
        return false;
    if ('manualOverride' in _v && typeof _v['manualOverride'] !== 'boolean')
        return false;
    return true;
}

function instanceOfGetCommercialAccountContactsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('commercialAccountId' in _v && typeof _v['commercialAccountId'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfGetCommunicationPreferencesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('version' in _v && typeof _v['version'] !== 'string')
        return false;
    if ('emailPreference' in _v && typeof _v['emailPreference'] !== 'string')
        return false;
    if ('smsPreference' in _v && typeof _v['smsPreference'] !== 'string')
        return false;
    if ('phonePreference' in _v && typeof _v['phonePreference'] !== 'string')
        return false;
    if ('marketingPreference' in _v && typeof _v['marketingPreference'] !== 'string')
        return false;
    if ('preferencesNote' in _v && typeof _v['preferencesNote'] !== 'string')
        return false;
    if ('updatedAt' in _v && typeof _v['updatedAt'] !== 'string')
        return false;
    if ('updateSource' in _v && typeof _v['updateSource'] !== 'string')
        return false;
    return true;
}

function instanceOfGetContactsWithRolesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfGetPartyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('partyType' in _v && typeof _v['partyType'] !== 'string')
        return false;
    if ('legalName' in _v && typeof _v['legalName'] !== 'string')
        return false;
    if ('displayName' in _v && typeof _v['displayName'] !== 'string')
        return false;
    if ('taxId' in _v && typeof _v['taxId'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('billingTermsId' in _v && typeof _v['billingTermsId'] !== 'string')
        return false;
    if ('createdAt' in _v && typeof _v['createdAt'] !== 'string')
        return false;
    if ('modifiedAt' in _v && typeof _v['modifiedAt'] !== 'string')
        return false;
    return true;
}

var GetPersonResponsePreferredContactMethodEnum;
(function (GetPersonResponsePreferredContactMethodEnum) {
    GetPersonResponsePreferredContactMethodEnum["Email"] = "EMAIL";
    GetPersonResponsePreferredContactMethodEnum["PhoneCall"] = "PHONE_CALL";
    GetPersonResponsePreferredContactMethodEnum["Sms"] = "SMS";
    GetPersonResponsePreferredContactMethodEnum["None"] = "NONE";
})(GetPersonResponsePreferredContactMethodEnum || (GetPersonResponsePreferredContactMethodEnum = {}));
;
function instanceOfGetPersonResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('personId' in _v && typeof _v['personId'] !== 'string')
        return false;
    if ('firstName' in _v && typeof _v['firstName'] !== 'string')
        return false;
    if ('lastName' in _v && typeof _v['lastName'] !== 'string')
        return false;
    if ('displayName' in _v && typeof _v['displayName'] !== 'string')
        return false;
    if ('preferredContactMethod' in _v && typeof _v['preferredContactMethod'] !== 'string')
        return false;
    if ('individualCustomer' in _v && typeof _v['individualCustomer'] !== 'boolean')
        return false;
    if ('commercialContact' in _v && typeof _v['commercialContact'] !== 'boolean')
        return false;
    if ('commercialAccountCount' in _v && typeof _v['commercialAccountCount'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfIndividualDetails(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('displayName' in _v && typeof _v['displayName'] !== 'string')
        return false;
    if ('email' in _v && typeof _v['email'] !== 'string')
        return false;
    if ('phone' in _v && typeof _v['phone'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfMergePartiesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('survivorPartyId' in _v && typeof _v['survivorPartyId'] !== 'string')
        return false;
    if ('losingPartyId' in _v && typeof _v['losingPartyId'] !== 'string')
        return false;
    if ('justification' in _v && typeof _v['justification'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfMergePartiesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('mergeAuditId' in _v && typeof _v['mergeAuditId'] !== 'string')
        return false;
    if ('survivorPartyId' in _v && typeof _v['survivorPartyId'] !== 'string')
        return false;
    if ('losingPartyId' in _v && typeof _v['losingPartyId'] !== 'string')
        return false;
    if ('mergedPartyAlias' in _v && typeof _v['mergedPartyAlias'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('completedAt' in _v && typeof _v['completedAt'] !== 'string')
        return false;
    return true;
}

function instanceOfPageCustomerDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('totalPages' in _v && typeof _v['totalPages'] !== 'number')
        return false;
    if ('totalElements' in _v && typeof _v['totalElements'] !== 'number')
        return false;
    if ('size' in _v && typeof _v['size'] !== 'number')
        return false;
    if ('number' in _v && typeof _v['number'] !== 'number')
        return false;
    if ('first' in _v && typeof _v['first'] !== 'boolean')
        return false;
    if ('last' in _v && typeof _v['last'] !== 'boolean')
        return false;
    if ('numberOfElements' in _v && typeof _v['numberOfElements'] !== 'number')
        return false;
    if ('empty' in _v && typeof _v['empty'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfPageable(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('page' in _v && typeof _v['page'] !== 'number')
        return false;
    if ('size' in _v && typeof _v['size'] !== 'number')
        return false;
    return true;
}

function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('offset' in _v && typeof _v['offset'] !== 'number')
        return false;
    if ('paged' in _v && typeof _v['paged'] !== 'boolean')
        return false;
    if ('pageNumber' in _v && typeof _v['pageNumber'] !== 'number')
        return false;
    if ('pageSize' in _v && typeof _v['pageSize'] !== 'number')
        return false;
    if ('unpaged' in _v && typeof _v['unpaged'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PartyMatchMatchTypeEnum;
(function (PartyMatchMatchTypeEnum) {
    PartyMatchMatchTypeEnum["Exact"] = "EXACT";
    PartyMatchMatchTypeEnum["Fuzzy"] = "FUZZY";
})(PartyMatchMatchTypeEnum || (PartyMatchMatchTypeEnum = {}));
;
function instanceOfPartyMatch(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('legalName' in _v && typeof _v['legalName'] !== 'string')
        return false;
    if ('matchType' in _v && typeof _v['matchType'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfPartySummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('legalName' in _v && typeof _v['legalName'] !== 'string')
        return false;
    if ('displayName' in _v && typeof _v['displayName'] !== 'string')
        return false;
    if ('partyType' in _v && typeof _v['partyType'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('createdAt' in _v && typeof _v['createdAt'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PhoneInputTypeEnum;
(function (PhoneInputTypeEnum) {
    PhoneInputTypeEnum["Email"] = "EMAIL";
    PhoneInputTypeEnum["PhoneMobile"] = "PHONE_MOBILE";
    PhoneInputTypeEnum["PhoneHome"] = "PHONE_HOME";
    PhoneInputTypeEnum["PhoneWork"] = "PHONE_WORK";
    PhoneInputTypeEnum["Fax"] = "FAX";
})(PhoneInputTypeEnum || (PhoneInputTypeEnum = {}));
;
function instanceOfPhoneInput(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('value' in _v) || _v['value'] === undefined)
        return false;
    if ('value' in _v && typeof _v['value'] !== 'string')
        return false;
    if ('type' in _v && typeof _v['type'] !== 'string')
        return false;
    if ('primary' in _v && typeof _v['primary'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfPhoneNumberDTO(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('type' in _v && typeof _v['type'] !== 'string')
        return false;
    if ('number' in _v && typeof _v['number'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PromotionRedemptionResponseStatusEnum;
(function (PromotionRedemptionResponseStatusEnum) {
    PromotionRedemptionResponseStatusEnum["Recorded"] = "RECORDED";
    PromotionRedemptionResponseStatusEnum["RecordedOverLimit"] = "RECORDED_OVER_LIMIT";
})(PromotionRedemptionResponseStatusEnum || (PromotionRedemptionResponseStatusEnum = {}));
;
function instanceOfPromotionRedemptionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('promotionRedemptionId' in _v && typeof _v['promotionRedemptionId'] !== 'string')
        return false;
    if ('promotionId' in _v && typeof _v['promotionId'] !== 'string')
        return false;
    if ('customerId' in _v && typeof _v['customerId'] !== 'string')
        return false;
    if ('workorderId' in _v && typeof _v['workorderId'] !== 'string')
        return false;
    if ('invoiceId' in _v && typeof _v['invoiceId'] !== 'string')
        return false;
    if ('discountAmount' in _v && typeof _v['discountAmount'] !== 'number')
        return false;
    if ('discountType' in _v && typeof _v['discountType'] !== 'string')
        return false;
    if ('promotionCode' in _v && typeof _v['promotionCode'] !== 'string')
        return false;
    if ('recordedBy' in _v && typeof _v['recordedBy'] !== 'string')
        return false;
    if ('recordedOverLimit' in _v && typeof _v['recordedOverLimit'] !== 'boolean')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfRecordRedemptionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if (!('promotionId' in _v) || _v['promotionId'] === undefined)
        return false;
    if ('promotionId' in _v && typeof _v['promotionId'] !== 'string')
        return false;
    if (!('customerId' in _v) || _v['customerId'] === undefined)
        return false;
    if ('customerId' in _v && typeof _v['customerId'] !== 'string')
        return false;
    if (!('workorderId' in _v) || _v['workorderId'] === undefined)
        return false;
    if ('workorderId' in _v && typeof _v['workorderId'] !== 'string')
        return false;
    if ('invoiceId' in _v && typeof _v['invoiceId'] !== 'string')
        return false;
    if (!('discountAmount' in _v) || _v['discountAmount'] === undefined)
        return false;
    if ('discountAmount' in _v && typeof _v['discountAmount'] !== 'number')
        return false;
    if (!('discountType' in _v) || _v['discountType'] === undefined)
        return false;
    if ('discountType' in _v && typeof _v['discountType'] !== 'string')
        return false;
    if (!('promotionCode' in _v) || _v['promotionCode'] === undefined)
        return false;
    if ('promotionCode' in _v && typeof _v['promotionCode'] !== 'string')
        return false;
    if ('recordedOverLimit' in _v && typeof _v['recordedOverLimit'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfResolveAccountTierRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('accountId' in _v && typeof _v['accountId'] !== 'string')
        return false;
    if ('annualRevenue' in _v && typeof _v['annualRevenue'] !== 'number')
        return false;
    if ('activeContractCount' in _v && typeof _v['activeContractCount'] !== 'number')
        return false;
    if ('accountAgeMonths' in _v && typeof _v['accountAgeMonths'] !== 'number')
        return false;
    if ('applyTier' in _v && typeof _v['applyTier'] !== 'boolean')
        return false;
    if ('forceRecalculation' in _v && typeof _v['forceRecalculation'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ResolveAccountTierResponseCurrentTierEnum;
(function (ResolveAccountTierResponseCurrentTierEnum) {
    ResolveAccountTierResponseCurrentTierEnum["Standard"] = "STANDARD";
    ResolveAccountTierResponseCurrentTierEnum["Bronze"] = "BRONZE";
    ResolveAccountTierResponseCurrentTierEnum["Silver"] = "SILVER";
    ResolveAccountTierResponseCurrentTierEnum["Gold"] = "GOLD";
    ResolveAccountTierResponseCurrentTierEnum["Platinum"] = "PLATINUM";
    ResolveAccountTierResponseCurrentTierEnum["Enterprise"] = "ENTERPRISE";
})(ResolveAccountTierResponseCurrentTierEnum || (ResolveAccountTierResponseCurrentTierEnum = {}));
;
var ResolveAccountTierResponseRecommendedTierEnum;
(function (ResolveAccountTierResponseRecommendedTierEnum) {
    ResolveAccountTierResponseRecommendedTierEnum["Standard"] = "STANDARD";
    ResolveAccountTierResponseRecommendedTierEnum["Bronze"] = "BRONZE";
    ResolveAccountTierResponseRecommendedTierEnum["Silver"] = "SILVER";
    ResolveAccountTierResponseRecommendedTierEnum["Gold"] = "GOLD";
    ResolveAccountTierResponseRecommendedTierEnum["Platinum"] = "PLATINUM";
    ResolveAccountTierResponseRecommendedTierEnum["Enterprise"] = "ENTERPRISE";
})(ResolveAccountTierResponseRecommendedTierEnum || (ResolveAccountTierResponseRecommendedTierEnum = {}));
;
function instanceOfResolveAccountTierResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('accountId' in _v && typeof _v['accountId'] !== 'string')
        return false;
    if ('currentTier' in _v && typeof _v['currentTier'] !== 'string')
        return false;
    if ('recommendedTier' in _v && typeof _v['recommendedTier'] !== 'string')
        return false;
    if ('tierApplied' in _v && typeof _v['tierApplied'] !== 'boolean')
        return false;
    if ('manualOverrideActive' in _v && typeof _v['manualOverrideActive'] !== 'boolean')
        return false;
    if ('resolutionReason' in _v && typeof _v['resolutionReason'] !== 'string')
        return false;
    if ('tierScore' in _v && typeof _v['tierScore'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfRoleAssignment(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('roleCode' in _v && typeof _v['roleCode'] !== 'string')
        return false;
    if ('isPrimary' in _v && typeof _v['isPrimary'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfSearchPartiesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('name' in _v && typeof _v['name'] !== 'string')
        return false;
    if ('email' in _v && typeof _v['email'] !== 'string')
        return false;
    if ('phone' in _v && typeof _v['phone'] !== 'string')
        return false;
    if ('taxId' in _v && typeof _v['taxId'] !== 'string')
        return false;
    if ('partyType' in _v && typeof _v['partyType'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('includeMerged' in _v && typeof _v['includeMerged'] !== 'boolean')
        return false;
    if ('pageNumber' in _v && typeof _v['pageNumber'] !== 'number')
        return false;
    if ('pageSize' in _v && typeof _v['pageSize'] !== 'number')
        return false;
    if ('sortField' in _v && typeof _v['sortField'] !== 'string')
        return false;
    if ('sortOrder' in _v && typeof _v['sortOrder'] !== 'string')
        return false;
    return true;
}

function instanceOfSearchPartiesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('totalCount' in _v && typeof _v['totalCount'] !== 'number')
        return false;
    if ('pageNumber' in _v && typeof _v['pageNumber'] !== 'number')
        return false;
    if ('pageSize' in _v && typeof _v['pageSize'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfSnapshotMetadata(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('snapshotId' in _v && typeof _v['snapshotId'] !== 'string')
        return false;
    if ('version' in _v && typeof _v['version'] !== 'string')
        return false;
    if ('source' in _v && typeof _v['source'] !== 'string')
        return false;
    if ('stale' in _v && typeof _v['stale'] !== 'boolean')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('empty' in _v && typeof _v['empty'] !== 'boolean')
        return false;
    if ('sorted' in _v && typeof _v['sorted'] !== 'boolean')
        return false;
    if ('unsorted' in _v && typeof _v['unsorted'] !== 'boolean')
        return false;
    return true;
}

function instanceOfUpdateContactRolesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('version' in _v && typeof _v['version'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfUpdateContactRolesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('contactId' in _v && typeof _v['contactId'] !== 'string')
        return false;
    if ('version' in _v && typeof _v['version'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('updatedAt' in _v && typeof _v['updatedAt'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var UpsertBillingRulesRequestInvoiceDeliveryMethodEnum;
(function (UpsertBillingRulesRequestInvoiceDeliveryMethodEnum) {
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Email"] = "EMAIL";
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Mail"] = "MAIL";
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Portal"] = "PORTAL";
    UpsertBillingRulesRequestInvoiceDeliveryMethodEnum["Edi"] = "EDI";
})(UpsertBillingRulesRequestInvoiceDeliveryMethodEnum || (UpsertBillingRulesRequestInvoiceDeliveryMethodEnum = {}));
;
function instanceOfUpsertBillingRulesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('paymentTerms' in _v && typeof _v['paymentTerms'] !== 'string')
        return false;
    if ('creditLimit' in _v && typeof _v['creditLimit'] !== 'number')
        return false;
    if ('currency' in _v && typeof _v['currency'] !== 'string')
        return false;
    if ('taxExempt' in _v && typeof _v['taxExempt'] !== 'boolean')
        return false;
    if ('poRequired' in _v && typeof _v['poRequired'] !== 'boolean')
        return false;
    if ('creditHold' in _v && typeof _v['creditHold'] !== 'boolean')
        return false;
    if ('autoPayEnabled' in _v && typeof _v['autoPayEnabled'] !== 'boolean')
        return false;
    if ('invoiceDeliveryMethod' in _v && typeof _v['invoiceDeliveryMethod'] !== 'string')
        return false;
    if ('billingAddressId' in _v && typeof _v['billingAddressId'] !== 'string')
        return false;
    if ('discountPolicyRef' in _v && typeof _v['discountPolicyRef'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfUpsertCommunicationPreferencesRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('version' in _v && typeof _v['version'] !== 'string')
        return false;
    if ('emailPreference' in _v && typeof _v['emailPreference'] !== 'string')
        return false;
    if ('smsPreference' in _v && typeof _v['smsPreference'] !== 'string')
        return false;
    if ('phonePreference' in _v && typeof _v['phonePreference'] !== 'string')
        return false;
    if ('marketingPreference' in _v && typeof _v['marketingPreference'] !== 'string')
        return false;
    if ('preferencesNote' in _v && typeof _v['preferencesNote'] !== 'string')
        return false;
    if ('updateSource' in _v && typeof _v['updateSource'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfUpsertCommunicationPreferencesResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('partyId' in _v && typeof _v['partyId'] !== 'string')
        return false;
    if ('version' in _v && typeof _v['version'] !== 'string')
        return false;
    if ('operationType' in _v && typeof _v['operationType'] !== 'string')
        return false;
    if ('status' in _v && typeof _v['status'] !== 'string')
        return false;
    if ('updatedAt' in _v && typeof _v['updatedAt'] !== 'string')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfVehicleResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('vehicleId' in _v && typeof _v['vehicleId'] !== 'string')
        return false;
    if ('accountId' in _v && typeof _v['accountId'] !== 'string')
        return false;
    if ('vin' in _v && typeof _v['vin'] !== 'string')
        return false;
    if ('vinNormalized' in _v && typeof _v['vinNormalized'] !== 'string')
        return false;
    if ('unitNumber' in _v && typeof _v['unitNumber'] !== 'string')
        return false;
    if ('description' in _v && typeof _v['description'] !== 'string')
        return false;
    if ('licensePlate' in _v && typeof _v['licensePlate'] !== 'string')
        return false;
    if ('licensePlateJurisdiction' in _v && typeof _v['licensePlateJurisdiction'] !== 'string')
        return false;
    if ('year' in _v && typeof _v['year'] !== 'number')
        return false;
    if ('make' in _v && typeof _v['make'] !== 'string')
        return false;
    if ('model' in _v && typeof _v['model'] !== 'string')
        return false;
    if ('trim' in _v && typeof _v['trim'] !== 'string')
        return false;
    if ('isActive' in _v && typeof _v['isActive'] !== 'boolean')
        return false;
    if ('createdBy' in _v && typeof _v['createdBy'] !== 'string')
        return false;
    if ('updatedBy' in _v && typeof _v['updatedBy'] !== 'string')
        return false;
    if ('version' in _v && typeof _v['version'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfVehicleSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('vehicleId' in _v && typeof _v['vehicleId'] !== 'string')
        return false;
    if ('vin' in _v && typeof _v['vin'] !== 'string')
        return false;
    if ('licensePlate' in _v && typeof _v['licensePlate'] !== 'string')
        return false;
    if ('make' in _v && typeof _v['make'] !== 'string')
        return false;
    if ('model' in _v && typeof _v['model'] !== 'string')
        return false;
    if ('year' in _v && typeof _v['year'] !== 'number')
        return false;
    return true;
}

/**
 * Positivity Customer API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function instanceOfVehicleTransferRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    if ('targetCustomerId' in _v && typeof _v['targetCustomerId'] !== 'string')
        return false;
    if ('notes' in _v && typeof _v['notes'] !== 'string')
        return false;
    return true;
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { APIS, ApiModule, BASE_PATH, BillingRuleRefInvoiceDeliveryMethodEnum, COLLECTION_FORMATS, CRMAccountsService, CRMCommunicationPreferencesService, CRMContactsService, CRMPartyRelationshipsService, CRMPersonsService, CRMSnapshotsService, CRMVehiclesService, Configuration, ContactPointDtoContactTypeEnum, ContactWithRoleRolesEnum, CreatePartyRelationshipRequestRolesEnum, CreatePartyRelationshipResponseRolesEnum, CreatePersonRequestPreferredContactMethodEnum, CreatePersonResponsePreferredContactMethodEnum, CustomerAPIService, CustomerBulkIngestAPIService, GetAccountTierResponseTierEnum, GetPersonResponsePreferredContactMethodEnum, PartyMatchMatchTypeEnum, PhoneInputTypeEnum, PromotionRedemptionResponseStatusEnum, PromotionRedemptionsService, ResolveAccountTierResponseCurrentTierEnum, ResolveAccountTierResponseRecommendedTierEnum, UpsertBillingRulesRequestInvoiceDeliveryMethodEnum, instanceOfAccountSummary, instanceOfAssignedRole, instanceOfBillingPreferences, instanceOfBillingRuleRef, instanceOfBillingTermsRef, instanceOfBulkIngestRequestCustomerBulkIngestRecord, instanceOfBulkIngestResponse, instanceOfBulkIngestResult, instanceOfContactPointDto, instanceOfContactPreferences, instanceOfContactSummary, instanceOfContactWithRole, instanceOfContactWithRoles, instanceOfCreateCommercialAccountRequest, instanceOfCreateCommercialAccountResponse, instanceOfCreatePartyRelationshipRequest, instanceOfCreatePartyRelationshipResponse, instanceOfCreatePersonRequest, instanceOfCreatePersonResponse, instanceOfCreateVehicleForPartyRequest, instanceOfCreateVehicleForPartyResponse, instanceOfCrmSnapshotDTO, instanceOfCustomerBulkIngestRecord, instanceOfCustomerDTO, instanceOfDuplicateCandidate, instanceOfDuplicateCheckResponse, instanceOfEmailAddressDTO, instanceOfEmailInput, instanceOfGetAccountTierResponse, instanceOfGetCommercialAccountContactsResponse, instanceOfGetCommunicationPreferencesResponse, instanceOfGetContactsWithRolesResponse, instanceOfGetPartyResponse, instanceOfGetPersonResponse, instanceOfIndividualDetails, instanceOfMergePartiesRequest, instanceOfMergePartiesResponse, instanceOfPageCustomerDTO, instanceOfPageable, instanceOfPageableObject, instanceOfPartyMatch, instanceOfPartySummary, instanceOfPhoneInput, instanceOfPhoneNumberDTO, instanceOfPromotionRedemptionResponse, instanceOfRecordRedemptionRequest, instanceOfResolveAccountTierRequest, instanceOfResolveAccountTierResponse, instanceOfRoleAssignment, instanceOfSearchPartiesRequest, instanceOfSearchPartiesResponse, instanceOfSnapshotMetadata, instanceOfSortObject, instanceOfUpdateContactRolesRequest, instanceOfUpdateContactRolesResponse, instanceOfUpsertBillingRulesRequest, instanceOfUpsertCommunicationPreferencesRequest, instanceOfUpsertCommunicationPreferencesResponse, instanceOfVehicleResponse, instanceOfVehicleSummary, instanceOfVehicleTransferRequest, provideApi };
//# sourceMappingURL=durion-sdk-customer.mjs.map
