import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/catalog';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CatalogAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCatalog(catalogDto, observe = 'body', reportProgress = false, options) {
        if (catalogDto === null || catalogDto === undefined) {
            throw new Error('Required parameter catalogDto was null or undefined when calling createCatalog.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalogs`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: catalogDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteCatalog(catalogId, observe = 'body', reportProgress = false, options) {
        if (catalogId === null || catalogId === undefined) {
            throw new Error('Required parameter catalogId was null or undefined when calling deleteCatalog.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalogs/${this.configuration.encodeParam({ name: "catalogId", value: catalogId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCatalogById(catalogId, observe = 'body', reportProgress = false, options) {
        if (catalogId === null || catalogId === undefined) {
            throw new Error('Required parameter catalogId was null or undefined when calling getCatalogById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalogs/${this.configuration.encodeParam({ name: "catalogId", value: catalogId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCatalogsByName(name, observe = 'body', reportProgress = false, options) {
        if (name === null || name === undefined) {
            throw new Error('Required parameter name was null or undefined when calling listCatalogsByName.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalogs/name/${this.configuration.encodeParam({ name: "name", value: name, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCatalog(catalogId, catalogDto, observe = 'body', reportProgress = false, options) {
        if (catalogId === null || catalogId === undefined) {
            throw new Error('Required parameter catalogId was null or undefined when calling updateCatalog.');
        }
        if (catalogDto === null || catalogDto === undefined) {
            throw new Error('Required parameter catalogDto was null or undefined when calling updateCatalog.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalogs/${this.configuration.encodeParam({ name: "catalogId", value: catalogId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: catalogDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CatalogBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestCatalogProducts(bulkIngestRequestCatalogBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestCatalogBulkIngestRecord === null || bulkIngestRequestCatalogBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestCatalogBulkIngestRecord was null or undefined when calling bulkIngestCatalogProducts.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestCatalogBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CatalogItemsAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCatalogItem(type, catalogItemRequestDto, observe = 'body', reportProgress = false, options) {
        if (type === null || type === undefined) {
            throw new Error('Required parameter type was null or undefined when calling createCatalogItem.');
        }
        if (catalogItemRequestDto === null || catalogItemRequestDto === undefined) {
            throw new Error('Required parameter catalogItemRequestDto was null or undefined when calling createCatalogItem.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/${this.configuration.encodeParam({ name: "type", value: type, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: catalogItemRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteCatalogItem(type, catalogId, observe = 'body', reportProgress = false, options) {
        if (type === null || type === undefined) {
            throw new Error('Required parameter type was null or undefined when calling deleteCatalogItem.');
        }
        if (catalogId === null || catalogId === undefined) {
            throw new Error('Required parameter catalogId was null or undefined when calling deleteCatalogItem.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/${this.configuration.encodeParam({ name: "type", value: type, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/${this.configuration.encodeParam({ name: "catalogId", value: catalogId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    replayServiceFacts(afterServiceId, updatedSince, limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'afterServiceId', afterServiceId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'updatedSince', updatedSince, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/services/facts/replay`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCatalogItem(type, catalogId, catalogItemRequestDto, observe = 'body', reportProgress = false, options) {
        if (type === null || type === undefined) {
            throw new Error('Required parameter type was null or undefined when calling updateCatalogItem.');
        }
        if (catalogId === null || catalogId === undefined) {
            throw new Error('Required parameter catalogId was null or undefined when calling updateCatalogItem.');
        }
        if (catalogItemRequestDto === null || catalogItemRequestDto === undefined) {
            throw new Error('Required parameter catalogItemRequestDto was null or undefined when calling updateCatalogItem.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/${this.configuration.encodeParam({ name: "type", value: type, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/${this.configuration.encodeParam({ name: "catalogId", value: catalogId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: catalogItemRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogItemsAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogItemsAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogItemsAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CatalogServiceBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestCatalogServices(bulkIngestRequestCatalogServiceBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestCatalogServiceBulkIngestRecord === null || bulkIngestRequestCatalogServiceBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestCatalogServiceBulkIngestRecord was null or undefined when calling bulkIngestCatalogServices.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/services/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestCatalogServiceBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogServiceBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogServiceBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CatalogServiceBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ItemCostAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getItemCostAuditHistory(itemId, observe = 'body', reportProgress = false, options) {
        if (itemId === null || itemId === undefined) {
            throw new Error('Required parameter itemId was null or undefined when calling getItemCostAuditHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/items/${this.configuration.encodeParam({ name: "itemId", value: itemId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/costs/audit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getItemCosts(itemId, observe = 'body', reportProgress = false, options) {
        if (itemId === null || itemId === undefined) {
            throw new Error('Required parameter itemId was null or undefined when calling getItemCosts.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/items/${this.configuration.encodeParam({ name: "itemId", value: itemId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/costs`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateStandardItemCost(itemId, updateStandardCostRequestDto, observe = 'body', reportProgress = false, options) {
        if (itemId === null || itemId === undefined) {
            throw new Error('Required parameter itemId was null or undefined when calling updateStandardItemCost.');
        }
        if (updateStandardCostRequestDto === null || updateStandardCostRequestDto === undefined) {
            throw new Error('Required parameter updateStandardCostRequestDto was null or undefined when calling updateStandardItemCost.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/items/${this.configuration.encodeParam({ name: "itemId", value: itemId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/standard-cost`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateStandardCostRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ItemCostAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ItemCostAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ItemCostAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LaborGuideImportsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listIncompleteLaborGuideImports(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/labor-guide-imports/incomplete`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listUnmappedLaborGuideOperations(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/labor-guide-imports/unmapped`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    runLaborGuideImport(sourceCode, observe = 'body', reportProgress = false, options) {
        if (sourceCode === null || sourceCode === undefined) {
            throw new Error('Required parameter sourceCode was null or undefined when calling runLaborGuideImport.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceCode', sourceCode, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/labor-guide-imports`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborGuideImportsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborGuideImportsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborGuideImportsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LaborStandardBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestLaborStandards(bulkIngestRequestServiceLaborStandardImportRequestDto, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestServiceLaborStandardImportRequestDto === null || bulkIngestRequestServiceLaborStandardImportRequestDto === undefined) {
            throw new Error('Required parameter bulkIngestRequestServiceLaborStandardImportRequestDto was null or undefined when calling bulkIngestLaborStandards.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/labor-standards/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestServiceLaborStandardImportRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborStandardBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborStandardBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborStandardBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LaborStandardConflictsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listLaborStandardConflicts(thresholdHours, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'thresholdHours', thresholdHours, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/labor-standards/conflicts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborStandardConflictsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborStandardConflictsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborStandardConflictsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LaborTimeResolutionService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    resolveLaborTime(laborTimeQuoteRequest, observe = 'body', reportProgress = false, options) {
        if (laborTimeQuoteRequest === null || laborTimeQuoteRequest === undefined) {
            throw new Error('Required parameter laborTimeQuoteRequest was null or undefined when calling resolveLaborTime.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/labor-times/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: laborTimeQuoteRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborTimeResolutionService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborTimeResolutionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LaborTimeResolutionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PriceBookAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createPriceBook(priceBookCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (priceBookCreateRequestDto === null || priceBookCreateRequestDto === undefined) {
            throw new Error('Required parameter priceBookCreateRequestDto was null or undefined when calling createPriceBook.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: priceBookCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createPriceBookRule(priceBookId, priceBookRuleCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (priceBookId === null || priceBookId === undefined) {
            throw new Error('Required parameter priceBookId was null or undefined when calling createPriceBookRule.');
        }
        if (priceBookRuleCreateRequestDto === null || priceBookRuleCreateRequestDto === undefined) {
            throw new Error('Required parameter priceBookRuleCreateRequestDto was null or undefined when calling createPriceBookRule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/${this.configuration.encodeParam({ name: "priceBookId", value: priceBookId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: priceBookRuleCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivatePriceBookRule(priceBookId, ruleId, observe = 'body', reportProgress = false, options) {
        if (priceBookId === null || priceBookId === undefined) {
            throw new Error('Required parameter priceBookId was null or undefined when calling deactivatePriceBookRule.');
        }
        if (ruleId === null || ruleId === undefined) {
            throw new Error('Required parameter ruleId was null or undefined when calling deactivatePriceBookRule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/${this.configuration.encodeParam({ name: "priceBookId", value: priceBookId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/rules/${this.configuration.encodeParam({ name: "ruleId", value: ruleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPriceBook(priceBookId, observe = 'body', reportProgress = false, options) {
        if (priceBookId === null || priceBookId === undefined) {
            throw new Error('Required parameter priceBookId was null or undefined when calling getPriceBook.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/${this.configuration.encodeParam({ name: "priceBookId", value: priceBookId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPriceBookRules(priceBookId, observe = 'body', reportProgress = false, options) {
        if (priceBookId === null || priceBookId === undefined) {
            throw new Error('Required parameter priceBookId was null or undefined when calling listPriceBookRules.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/${this.configuration.encodeParam({ name: "priceBookId", value: priceBookId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/rules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveProductPrice(resolvePriceRequestDto, observe = 'body', reportProgress = false, options) {
        if (resolvePriceRequestDto === null || resolvePriceRequestDto === undefined) {
            throw new Error('Required parameter resolvePriceRequestDto was null or undefined when calling resolveProductPrice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/resolve-price`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: resolvePriceRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePriceBook(priceBookId, priceBookCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (priceBookId === null || priceBookId === undefined) {
            throw new Error('Required parameter priceBookId was null or undefined when calling updatePriceBook.');
        }
        if (priceBookCreateRequestDto === null || priceBookCreateRequestDto === undefined) {
            throw new Error('Required parameter priceBookCreateRequestDto was null or undefined when calling updatePriceBook.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/${this.configuration.encodeParam({ name: "priceBookId", value: priceBookId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: priceBookCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePriceBookRule(priceBookId, ruleId, priceBookRuleCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (priceBookId === null || priceBookId === undefined) {
            throw new Error('Required parameter priceBookId was null or undefined when calling updatePriceBookRule.');
        }
        if (ruleId === null || ruleId === undefined) {
            throw new Error('Required parameter ruleId was null or undefined when calling updatePriceBookRule.');
        }
        if (priceBookRuleCreateRequestDto === null || priceBookRuleCreateRequestDto === undefined) {
            throw new Error('Required parameter priceBookRuleCreateRequestDto was null or undefined when calling updatePriceBookRule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/price-books/${this.configuration.encodeParam({ name: "priceBookId", value: priceBookId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/rules/${this.configuration.encodeParam({ name: "ruleId", value: ruleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: priceBookRuleCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PriceBookAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PriceBookAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PriceBookAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ProductMSRPAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createProductMsrp(productId, createMsrpRequestDto, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling createProductMsrp.');
        }
        if (createMsrpRequestDto === null || createMsrpRequestDto === undefined) {
            throw new Error('Required parameter createMsrpRequestDto was null or undefined when calling createProductMsrp.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/msrp`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createMsrpRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getActiveProductMsrp(productId, asOf, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getActiveProductMsrp.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/msrp/active`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listProductMsrpHistory(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling listProductMsrpHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/msrp`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateProductMsrp(productId, msrpId, updateMsrpRequestDto, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling updateProductMsrp.');
        }
        if (msrpId === null || msrpId === undefined) {
            throw new Error('Required parameter msrpId was null or undefined when calling updateProductMsrp.');
        }
        if (updateMsrpRequestDto === null || updateMsrpRequestDto === undefined) {
            throw new Error('Required parameter updateMsrpRequestDto was null or undefined when calling updateProductMsrp.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/msrp/${this.configuration.encodeParam({ name: "msrpId", value: msrpId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateMsrpRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductMSRPAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductMSRPAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductMSRPAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ProductUoMAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addProductUom(productId, productUomCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling addProductUom.');
        }
        if (productUomCreateRequestDto === null || productUomCreateRequestDto === undefined) {
            throw new Error('Required parameter productUomCreateRequestDto was null or undefined when calling addProductUom.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/uoms`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productUomCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteProductUom(productId, uomId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling deleteProductUom.');
        }
        if (uomId === null || uomId === undefined) {
            throw new Error('Required parameter uomId was null or undefined when calling deleteProductUom.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/uoms/${this.configuration.encodeParam({ name: "uomId", value: uomId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listProductUoms(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling listProductUoms.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/uoms`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateProductUom(productId, uomId, productUomUpdateRequestDto, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling updateProductUom.');
        }
        if (uomId === null || uomId === undefined) {
            throw new Error('Required parameter uomId was null or undefined when calling updateProductUom.');
        }
        if (productUomUpdateRequestDto === null || productUomUpdateRequestDto === undefined) {
            throw new Error('Required parameter productUomUpdateRequestDto was null or undefined when calling updateProductUom.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/uoms/${this.configuration.encodeParam({ name: "uomId", value: uomId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productUomUpdateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductUoMAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductUoMAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductUoMAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ProductsAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addProductReplacement(productId, productReplacementRequest, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling addProductReplacement.');
        }
        if (productReplacementRequest === null || productReplacementRequest === undefined) {
            throw new Error('Required parameter productReplacementRequest was null or undefined when calling addProductReplacement.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/replacements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productReplacementRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    approveLocationPriceOverride(overrideId, locationPriceOverrideDecisionRequestDto, observe = 'body', reportProgress = false, options) {
        if (overrideId === null || overrideId === undefined) {
            throw new Error('Required parameter overrideId was null or undefined when calling approveLocationPriceOverride.');
        }
        if (locationPriceOverrideDecisionRequestDto === null || locationPriceOverrideDecisionRequestDto === undefined) {
            throw new Error('Required parameter locationPriceOverrideDecisionRequestDto was null or undefined when calling approveLocationPriceOverride.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/pricing/location-overrides/${this.configuration.encodeParam({ name: "overrideId", value: overrideId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: locationPriceOverrideDecisionRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createLocationPriceOverride(locationPriceOverrideCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (locationPriceOverrideCreateRequestDto === null || locationPriceOverrideCreateRequestDto === undefined) {
            throw new Error('Required parameter locationPriceOverrideCreateRequestDto was null or undefined when calling createLocationPriceOverride.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/pricing/location-overrides`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: locationPriceOverrideCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createProduct(productCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (productCreateRequestDto === null || productCreateRequestDto === undefined) {
            throw new Error('Required parameter productCreateRequestDto was null or undefined when calling createProduct.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    findProductByCode(codeType, code, observe = 'body', reportProgress = false, options) {
        if (codeType === null || codeType === undefined) {
            throw new Error('Required parameter codeType was null or undefined when calling findProductByCode.');
        }
        if (code === null || code === undefined) {
            throw new Error('Required parameter code was null or undefined when calling findProductByCode.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'codeType', codeType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'code', code, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/by-code`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getEffectiveLocationPrice(locationId, productId, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getEffectiveLocationPrice.');
        }
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getEffectiveLocationPrice.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/pricing/effective-price/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getNonInventoryProductById(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getNonInventoryProductById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/noninventory/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPartSubstitutes(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getPartSubstitutes.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/substitutes`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getProductById(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getProductById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getProductDetailView(productId, locationId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getProductDetailView.');
        }
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getProductDetailView.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'location_id', locationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/detail`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getProductLifecycle(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getProductLifecycle.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/lifecycle`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getServiceById(serviceId, observe = 'body', reportProgress = false, options) {
        if (serviceId === null || serviceId === undefined) {
            throw new Error('Required parameter serviceId was null or undefined when calling getServiceById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/services/${this.configuration.encodeParam({ name: "serviceId", value: serviceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listNonInventoryProductsByName(name, observe = 'body', reportProgress = false, options) {
        if (name === null || name === undefined) {
            throw new Error('Required parameter name was null or undefined when calling listNonInventoryProductsByName.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/noninventory/name/${this.configuration.encodeParam({ name: "name", value: name, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listProductReplacements(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling listProductReplacements.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/replacements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listProductsByName(name, observe = 'body', reportProgress = false, options) {
        if (name === null || name === undefined) {
            throw new Error('Required parameter name was null or undefined when calling listProductsByName.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/name/${this.configuration.encodeParam({ name: "name", value: name, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listServicesByName(name, observe = 'body', reportProgress = false, options) {
        if (name === null || name === undefined) {
            throw new Error('Required parameter name was null or undefined when calling listServicesByName.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/services/name/${this.configuration.encodeParam({ name: "name", value: name, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectLocationPriceOverride(overrideId, locationPriceOverrideDecisionRequestDto, observe = 'body', reportProgress = false, options) {
        if (overrideId === null || overrideId === undefined) {
            throw new Error('Required parameter overrideId was null or undefined when calling rejectLocationPriceOverride.');
        }
        if (locationPriceOverrideDecisionRequestDto === null || locationPriceOverrideDecisionRequestDto === undefined) {
            throw new Error('Required parameter locationPriceOverrideDecisionRequestDto was null or undefined when calling rejectLocationPriceOverride.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/pricing/location-overrides/${this.configuration.encodeParam({ name: "overrideId", value: overrideId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: locationPriceOverrideDecisionRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    replayProductFacts(afterProductId, updatedSince, limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'afterProductId', afterProductId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'updatedSince', updatedSince, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/facts/replay`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchCatalogProducts(q, brand, category, sku, cursor, limit, detailed, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'q', q, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'brand', brand, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'category', category, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'cursor', cursor, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'detailed', detailed, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchCatalogServices(q, limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'q', q, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/services/search`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateProduct(productId, productUpdateRequestDto, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling updateProduct.');
        }
        if (productUpdateRequestDto === null || productUpdateRequestDto === undefined) {
            throw new Error('Required parameter productUpdateRequestDto was null or undefined when calling updateProduct.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productUpdateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateProductLifecycle(productId, productLifecycleUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling updateProductLifecycle.');
        }
        if (productLifecycleUpdateRequest === null || productLifecycleUpdateRequest === undefined) {
            throw new Error('Required parameter productLifecycleUpdateRequest was null or undefined when calling updateProductLifecycle.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/lifecycle`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productLifecycleUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateProductTrackingLevel(productId, productTrackingLevelUpdateRequestDto, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling updateProductTrackingLevel.');
        }
        if (productTrackingLevelUpdateRequestDto === null || productTrackingLevelUpdateRequestDto === undefined) {
            throw new Error('Required parameter productTrackingLevelUpdateRequestDto was null or undefined when calling updateProductTrackingLevel.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tracking-level`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: productTrackingLevelUpdateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertLocationGuardrailPolicy(guardrailPolicyUpsertRequestDto, observe = 'body', reportProgress = false, options) {
        if (guardrailPolicyUpsertRequestDto === null || guardrailPolicyUpsertRequestDto === undefined) {
            throw new Error('Required parameter guardrailPolicyUpsertRequestDto was null or undefined when calling upsertLocationGuardrailPolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/pricing/guardrail-policies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: guardrailPolicyUpsertRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductsAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductsAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ProductsAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ServiceLaborStandardsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createServiceLaborStandard(serviceId, serviceLaborStandardRequestDto, observe = 'body', reportProgress = false, options) {
        if (serviceId === null || serviceId === undefined) {
            throw new Error('Required parameter serviceId was null or undefined when calling createServiceLaborStandard.');
        }
        if (serviceLaborStandardRequestDto === null || serviceLaborStandardRequestDto === undefined) {
            throw new Error('Required parameter serviceLaborStandardRequestDto was null or undefined when calling createServiceLaborStandard.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/service/${this.configuration.encodeParam({ name: "serviceId", value: serviceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/labor-standards`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: serviceLaborStandardRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listServiceLaborStandards(serviceId, includeSuperseded, observe = 'body', reportProgress = false, options) {
        if (serviceId === null || serviceId === undefined) {
            throw new Error('Required parameter serviceId was null or undefined when calling listServiceLaborStandards.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeSuperseded', includeSuperseded, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/service/${this.configuration.encodeParam({ name: "serviceId", value: serviceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/labor-standards`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    supersedeServiceLaborStandard(serviceId, standardId, serviceLaborStandardRequestDto, observe = 'body', reportProgress = false, options) {
        if (serviceId === null || serviceId === undefined) {
            throw new Error('Required parameter serviceId was null or undefined when calling supersedeServiceLaborStandard.');
        }
        if (standardId === null || standardId === undefined) {
            throw new Error('Required parameter standardId was null or undefined when calling supersedeServiceLaborStandard.');
        }
        if (serviceLaborStandardRequestDto === null || serviceLaborStandardRequestDto === undefined) {
            throw new Error('Required parameter serviceLaborStandardRequestDto was null or undefined when calling supersedeServiceLaborStandard.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog-items/service/${this.configuration.encodeParam({ name: "serviceId", value: serviceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/labor-standards/${this.configuration.encodeParam({ name: "standardId", value: standardId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/supersede`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: serviceLaborStandardRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServiceLaborStandardsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServiceLaborStandardsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServiceLaborStandardsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ServicePackageBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestServicePackages(bulkIngestRequestServicePackageBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestServicePackageBulkIngestRecord === null || bulkIngestRequestServicePackageBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestServicePackageBulkIngestRecord was null or undefined when calling bulkIngestServicePackages.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-packages/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestServicePackageBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackageBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackageBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackageBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ServicePackageMemberBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestServicePackageMembers(bulkIngestRequestServicePackageMemberBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestServicePackageMemberBulkIngestRecord === null || bulkIngestRequestServicePackageMemberBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestServicePackageMemberBulkIngestRecord was null or undefined when calling bulkIngestServicePackageMembers.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-package-members/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestServicePackageMemberBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackageMemberBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackageMemberBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackageMemberBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ServicePackagesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addServicePackageMember(packageId, servicePackageMemberRequestDto, observe = 'body', reportProgress = false, options) {
        if (packageId === null || packageId === undefined) {
            throw new Error('Required parameter packageId was null or undefined when calling addServicePackageMember.');
        }
        if (servicePackageMemberRequestDto === null || servicePackageMemberRequestDto === undefined) {
            throw new Error('Required parameter servicePackageMemberRequestDto was null or undefined when calling addServicePackageMember.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-packages/${this.configuration.encodeParam({ name: "packageId", value: packageId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/members`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: servicePackageMemberRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createServicePackage(servicePackageRequestDto, observe = 'body', reportProgress = false, options) {
        if (servicePackageRequestDto === null || servicePackageRequestDto === undefined) {
            throw new Error('Required parameter servicePackageRequestDto was null or undefined when calling createServicePackage.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-packages`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: servicePackageRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getServicePackage(packageId, observe = 'body', reportProgress = false, options) {
        if (packageId === null || packageId === undefined) {
            throw new Error('Required parameter packageId was null or undefined when calling getServicePackage.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-packages/${this.configuration.encodeParam({ name: "packageId", value: packageId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listServicePackages(locationId, fleetPartyId, includeFleetPackages, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'fleetPartyId', fleetPartyId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeFleetPackages', includeFleetPackages, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-packages`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeServicePackageMember(packageId, memberId, observe = 'body', reportProgress = false, options) {
        if (packageId === null || packageId === undefined) {
            throw new Error('Required parameter packageId was null or undefined when calling removeServicePackageMember.');
        }
        if (memberId === null || memberId === undefined) {
            throw new Error('Required parameter memberId was null or undefined when calling removeServicePackageMember.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/service-packages/${this.configuration.encodeParam({ name: "packageId", value: packageId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/members/${this.configuration.encodeParam({ name: "memberId", value: memberId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackagesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackagesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ServicePackagesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SubstitutionGroupAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addSubstitutionGroupMember(groupId, substitutionGroupMemberRequestDto, observe = 'body', reportProgress = false, options) {
        if (groupId === null || groupId === undefined) {
            throw new Error('Required parameter groupId was null or undefined when calling addSubstitutionGroupMember.');
        }
        if (substitutionGroupMemberRequestDto === null || substitutionGroupMemberRequestDto === undefined) {
            throw new Error('Required parameter substitutionGroupMemberRequestDto was null or undefined when calling addSubstitutionGroupMember.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/substitution-groups/${this.configuration.encodeParam({ name: "groupId", value: groupId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/members`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: substitutionGroupMemberRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createSubstitutionGroup(substitutionGroupCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (substitutionGroupCreateRequestDto === null || substitutionGroupCreateRequestDto === undefined) {
            throw new Error('Required parameter substitutionGroupCreateRequestDto was null or undefined when calling createSubstitutionGroup.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/substitution-groups`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: substitutionGroupCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteSubstitutionGroup(groupId, observe = 'body', reportProgress = false, options) {
        if (groupId === null || groupId === undefined) {
            throw new Error('Required parameter groupId was null or undefined when calling deleteSubstitutionGroup.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/substitution-groups/${this.configuration.encodeParam({ name: "groupId", value: groupId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getSubstitutionGroup(groupId, observe = 'body', reportProgress = false, options) {
        if (groupId === null || groupId === undefined) {
            throw new Error('Required parameter groupId was null or undefined when calling getSubstitutionGroup.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/substitution-groups/${this.configuration.encodeParam({ name: "groupId", value: groupId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSubstitutionGroups(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/substitution-groups`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeSubstitutionGroupMember(groupId, productId, observe = 'body', reportProgress = false, options) {
        if (groupId === null || groupId === undefined) {
            throw new Error('Required parameter groupId was null or undefined when calling removeSubstitutionGroupMember.');
        }
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling removeSubstitutionGroupMember.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/substitution-groups/${this.configuration.encodeParam({ name: "groupId", value: groupId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/members/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SubstitutionGroupAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SubstitutionGroupAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SubstitutionGroupAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierArticleCodesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    replaySupplierArticleCodeFacts(afterId, updatedSince, limit, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'afterId', afterId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'updatedSince', updatedSince, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'limit', limit, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/supplier-article-codes/replay`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierArticleCodesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierArticleCodesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierArticleCodesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierPricesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getLatestSupplierPrice(productId, countryCode, currency, vendorProfileId, asOf, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getLatestSupplierPrice.');
        }
        if (countryCode === null || countryCode === undefined) {
            throw new Error('Required parameter countryCode was null or undefined when calling getLatestSupplierPrice.');
        }
        if (currency === null || currency === undefined) {
            throw new Error('Required parameter currency was null or undefined when calling getLatestSupplierPrice.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productId', productId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'countryCode', countryCode, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'currency', currency, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vendorProfileId', vendorProfileId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/supplier-prices/latest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listIncompleteSupplierPriceImports(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/supplier-prices/imports/incomplete`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierPriceHistory(productId, vendorProfileId, page, size, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling listSupplierPriceHistory.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productId', productId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vendorProfileId', vendorProfileId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/supplier-prices/history`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierPricesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierPricesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierPricesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TreadDesignEnrichmentService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getTreadDesignForProduct(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getTreadDesignForProduct.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/tread-designs/for-product/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTreadDesignCandidates(treadDesignId, observe = 'body', reportProgress = false, options) {
        if (treadDesignId === null || treadDesignId === undefined) {
            throw new Error('Required parameter treadDesignId was null or undefined when calling listTreadDesignCandidates.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/tread-designs/${this.configuration.encodeParam({ name: "treadDesignId", value: treadDesignId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/candidates`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listUnmatchedTreadDesigns(matchState, vendorProfileId, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'matchState', matchState, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'vendorProfileId', vendorProfileId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/tread-designs/unmatched`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveTreadDesign(treadDesignId, treadDesignResolveRequest, observe = 'body', reportProgress = false, options) {
        if (treadDesignId === null || treadDesignId === undefined) {
            throw new Error('Required parameter treadDesignId was null or undefined when calling resolveTreadDesign.');
        }
        if (treadDesignResolveRequest === null || treadDesignResolveRequest === undefined) {
            throw new Error('Required parameter treadDesignResolveRequest was null or undefined when calling resolveTreadDesign.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/catalog/tread-designs/${this.configuration.encodeParam({ name: "treadDesignId", value: treadDesignId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: treadDesignResolveRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreadDesignEnrichmentService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreadDesignEnrichmentService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreadDesignEnrichmentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class UOMConversionAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createUomConversion(uomConversionCreateRequestDto, observe = 'body', reportProgress = false, options) {
        if (uomConversionCreateRequestDto === null || uomConversionCreateRequestDto === undefined) {
            throw new Error('Required parameter uomConversionCreateRequestDto was null or undefined when calling createUomConversion.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/uom-conversions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: uomConversionCreateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivateUomConversion(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling deactivateUomConversion.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/uom-conversions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUomConversionById(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getUomConversionById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/uom-conversions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listUomConversions(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/uom-conversions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateUomConversion(id, uomConversionUpdateRequestDto, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateUomConversion.');
        }
        if (uomConversionUpdateRequestDto === null || uomConversionUpdateRequestDto === undefined) {
            throw new Error('Required parameter uomConversionUpdateRequestDto was null or undefined when calling updateUomConversion.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/products/uom-conversions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: uomConversionUpdateRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UOMConversionAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UOMConversionAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UOMConversionAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var AvailabilityInfoConfidenceEnum;
(function (AvailabilityInfoConfidenceEnum) {
    AvailabilityInfoConfidenceEnum["Low"] = "LOW";
    AvailabilityInfoConfidenceEnum["Medium"] = "MEDIUM";
    AvailabilityInfoConfidenceEnum["High"] = "HIGH";
})(AvailabilityInfoConfidenceEnum || (AvailabilityInfoConfidenceEnum = {}));
;
var AvailabilityInfoStatusEnum;
(function (AvailabilityInfoStatusEnum) {
    AvailabilityInfoStatusEnum["Ok"] = "OK";
    AvailabilityInfoStatusEnum["Unavailable"] = "UNAVAILABLE";
    AvailabilityInfoStatusEnum["Stale"] = "STALE";
    AvailabilityInfoStatusEnum["Error"] = "ERROR";
})(AvailabilityInfoStatusEnum || (AvailabilityInfoStatusEnum = {}));
;
function isOptionalAvailabilityInfoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAvailabilityInfoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAvailabilityInfoOptionalProperties(...properties) {
    return properties;
}
function instanceOfAvailabilityInfo(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAvailabilityInfoPropertyNames('confidence', 'status');
    const optionalStringProperties = createAvailabilityInfoOptionalProperties({ name: 'asOf', nullable: false }, { name: 'confidence', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createAvailabilityInfoOptionalProperties({ name: 'availableToPromiseQuantity', nullable: false }, { name: 'onHandQuantity', nullable: false });
    const optionalBooleanProperties = createAvailabilityInfoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAvailabilityInfoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAvailabilityInfoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAvailabilityInfoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestCatalogBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestCatalogBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestCatalogBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestCatalogBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestCatalogBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestCatalogBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestCatalogBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestCatalogBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestCatalogBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestCatalogBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestCatalogBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestCatalogServiceBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestCatalogServiceBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestCatalogServiceBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestCatalogServiceBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestCatalogServiceBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestCatalogServiceBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestCatalogServiceBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestCatalogServiceBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestCatalogServiceBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestCatalogServiceBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestCatalogServiceBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestServiceLaborStandardImportRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestServiceLaborStandardImportRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestServiceLaborStandardImportRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestServiceLaborStandardImportRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestServiceLaborStandardImportRequestDtoPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestServiceLaborStandardImportRequestDtoOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestServiceLaborStandardImportRequestDtoOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestServiceLaborStandardImportRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestServiceLaborStandardImportRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestServiceLaborStandardImportRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestServiceLaborStandardImportRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestServicePackageBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestServicePackageBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestServicePackageBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestServicePackageBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestServicePackageBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestServicePackageBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestServicePackageBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestServicePackageBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestServicePackageBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestServicePackageBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestServicePackageBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestServicePackageMemberBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestServicePackageMemberBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestServicePackageMemberBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestServicePackageMemberBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestServicePackageMemberBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestServicePackageMemberBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestServicePackageMemberBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestServicePackageMemberBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestServicePackageMemberBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestServicePackageMemberBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestServicePackageMemberBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResponsePropertyNames('failureCount', 'results', 'successCount', 'totalSubmitted');
    const optionalStringProperties = createBulkIngestResponseOptionalProperties();
    const optionalNumberProperties = createBulkIngestResponseOptionalProperties({ name: 'failureCount', nullable: false }, { name: 'successCount', nullable: false }, { name: 'totalSubmitted', nullable: false });
    const optionalBooleanProperties = createBulkIngestResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBulkIngestResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResultPropertyNames('rowIndex', 'success');
    const optionalStringProperties = createBulkIngestResultOptionalProperties({ name: 'correlationId', nullable: false }, { name: 'entityId', nullable: false }, { name: 'errorCode', nullable: false }, { name: 'errorMessage', nullable: false });
    const optionalNumberProperties = createBulkIngestResultOptionalProperties({ name: 'rowIndex', nullable: false });
    const optionalBooleanProperties = createBulkIngestResultOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCatalogBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogBulkIngestRecordPropertyNames('name', 'sku');
    const optionalStringProperties = createCatalogBulkIngestRecordOptionalProperties({ name: 'categoryName', nullable: false }, { name: 'countryOfOrigin', nullable: false }, { name: 'description', nullable: false }, { name: 'manufacturerBrand', nullable: false }, { name: 'manufacturerName', nullable: false }, { name: 'mpn', nullable: false }, { name: 'name', nullable: false }, { name: 'sku', nullable: false }, { name: 'subcategoryName', nullable: false }, { name: 'type', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'upc', nullable: false });
    const optionalNumberProperties = createCatalogBulkIngestRecordOptionalProperties({ name: 'price', nullable: false });
    const optionalBooleanProperties = createCatalogBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCatalogDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogDtoPropertyNames('id', 'name');
    const optionalStringProperties = createCatalogDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'id', nullable: false }, { name: 'name', nullable: false });
    const optionalNumberProperties = createCatalogDtoOptionalProperties();
    const optionalBooleanProperties = createCatalogDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CatalogItemRequestDtoOperationCategoryEnum;
(function (CatalogItemRequestDtoOperationCategoryEnum) {
    CatalogItemRequestDtoOperationCategoryEnum["Repair"] = "REPAIR";
    CatalogItemRequestDtoOperationCategoryEnum["Diagnostic"] = "DIAGNOSTIC";
    CatalogItemRequestDtoOperationCategoryEnum["Maintenance"] = "MAINTENANCE";
    CatalogItemRequestDtoOperationCategoryEnum["TireService"] = "TIRE_SERVICE";
})(CatalogItemRequestDtoOperationCategoryEnum || (CatalogItemRequestDtoOperationCategoryEnum = {}));
;
function isOptionalCatalogItemRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogItemRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogItemRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogItemRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogItemRequestDtoPropertyNames();
    const optionalStringProperties = createCatalogItemRequestDtoOptionalProperties({ name: 'color', nullable: false }, { name: 'countryOfOrigin', nullable: false }, { name: 'longDescription', nullable: false }, { name: 'manufacturerBrand', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'manufacturerName', nullable: false }, { name: 'manufacturerPartNumber', nullable: false }, { name: 'manufacturerWarranty', nullable: false }, { name: 'material', nullable: false }, { name: 'name', nullable: false }, { name: 'operationCategory', nullable: false }, { name: 'operationCode', nullable: false }, { name: 'productCode', nullable: false }, { name: 'shortDescription', nullable: false }, { name: 'sku', nullable: false }, { name: 'specifications', nullable: false }, { name: 'type', nullable: false }, { name: 'warranty', nullable: false });
    const optionalNumberProperties = createCatalogItemRequestDtoOptionalProperties({ name: 'defaultLaborHours', nullable: false });
    const optionalBooleanProperties = createCatalogItemRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogItemRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogItemRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogItemRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CatalogItemResponseDtoOperationCategoryEnum;
(function (CatalogItemResponseDtoOperationCategoryEnum) {
    CatalogItemResponseDtoOperationCategoryEnum["Repair"] = "REPAIR";
    CatalogItemResponseDtoOperationCategoryEnum["Diagnostic"] = "DIAGNOSTIC";
    CatalogItemResponseDtoOperationCategoryEnum["Maintenance"] = "MAINTENANCE";
    CatalogItemResponseDtoOperationCategoryEnum["TireService"] = "TIRE_SERVICE";
})(CatalogItemResponseDtoOperationCategoryEnum || (CatalogItemResponseDtoOperationCategoryEnum = {}));
;
function isOptionalCatalogItemResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogItemResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogItemResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogItemResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogItemResponseDtoPropertyNames('id', 'itemType');
    const optionalStringProperties = createCatalogItemResponseDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'itemType', nullable: false }, { name: 'longDescription', nullable: false }, { name: 'name', nullable: false }, { name: 'operationCategory', nullable: false }, { name: 'operationCode', nullable: false }, { name: 'shortDescription', nullable: false });
    const optionalNumberProperties = createCatalogItemResponseDtoOptionalProperties({ name: 'defaultLaborHours', nullable: false });
    const optionalBooleanProperties = createCatalogItemResponseDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogItemResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogItemResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogItemResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalCatalogSearchResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogSearchResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogSearchResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogSearchResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogSearchResultDtoPropertyNames('data', 'limit');
    const optionalStringProperties = createCatalogSearchResultDtoOptionalProperties({ name: 'nextCursor', nullable: false });
    const optionalNumberProperties = createCatalogSearchResultDtoOptionalProperties({ name: 'limit', nullable: false });
    const optionalBooleanProperties = createCatalogSearchResultDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogSearchResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogSearchResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogSearchResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CatalogServiceBulkIngestRecordOperationCategoryEnum;
(function (CatalogServiceBulkIngestRecordOperationCategoryEnum) {
    CatalogServiceBulkIngestRecordOperationCategoryEnum["Repair"] = "REPAIR";
    CatalogServiceBulkIngestRecordOperationCategoryEnum["Diagnostic"] = "DIAGNOSTIC";
    CatalogServiceBulkIngestRecordOperationCategoryEnum["Maintenance"] = "MAINTENANCE";
    CatalogServiceBulkIngestRecordOperationCategoryEnum["TireService"] = "TIRE_SERVICE";
})(CatalogServiceBulkIngestRecordOperationCategoryEnum || (CatalogServiceBulkIngestRecordOperationCategoryEnum = {}));
;
function isOptionalCatalogServiceBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogServiceBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogServiceBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogServiceBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogServiceBulkIngestRecordPropertyNames('name', 'operationCode');
    const optionalStringProperties = createCatalogServiceBulkIngestRecordOptionalProperties({ name: 'defaultLaborHours', nullable: false }, { name: 'longDescription', nullable: false }, { name: 'name', nullable: false }, { name: 'operationCategory', nullable: false }, { name: 'operationCode', nullable: false }, { name: 'shortDescription', nullable: false });
    const optionalNumberProperties = createCatalogServiceBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createCatalogServiceBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogServiceBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogServiceBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogServiceBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCategoryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCategoryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCategoryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCategoryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCategoryDtoPropertyNames('id', 'name');
    const optionalStringProperties = createCategoryDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'name', nullable: false });
    const optionalNumberProperties = createCategoryDtoOptionalProperties();
    const optionalBooleanProperties = createCategoryDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCategoryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCategoryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCategoryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateMsrpRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateMsrpRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateMsrpRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateMsrpRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateMsrpRequestDtoPropertyNames('amount', 'createdByUserId', 'currency', 'effectiveStartDate');
    const optionalStringProperties = createCreateMsrpRequestDtoOptionalProperties({ name: 'createdByUserId', nullable: false }, { name: 'currency', nullable: false }, { name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false });
    const optionalNumberProperties = createCreateMsrpRequestDtoOptionalProperties({ name: 'amount', nullable: false });
    const optionalBooleanProperties = createCreateMsrpRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateMsrpRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateMsrpRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateMsrpRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var DimensionDtoDimensionTypeEnum;
(function (DimensionDtoDimensionTypeEnum) {
    DimensionDtoDimensionTypeEnum["Length"] = "LENGTH";
    DimensionDtoDimensionTypeEnum["Width"] = "WIDTH";
    DimensionDtoDimensionTypeEnum["Height"] = "HEIGHT";
    DimensionDtoDimensionTypeEnum["Weight"] = "WEIGHT";
    DimensionDtoDimensionTypeEnum["Volume"] = "VOLUME";
    DimensionDtoDimensionTypeEnum["Area"] = "AREA";
    DimensionDtoDimensionTypeEnum["Diameter"] = "DIAMETER";
    DimensionDtoDimensionTypeEnum["Circumference"] = "CIRCUMFERENCE";
    DimensionDtoDimensionTypeEnum["Radius"] = "RADIUS";
    DimensionDtoDimensionTypeEnum["Temperature"] = "TEMPERATURE";
    DimensionDtoDimensionTypeEnum["Time"] = "TIME";
    DimensionDtoDimensionTypeEnum["Speed"] = "SPEED";
    DimensionDtoDimensionTypeEnum["Pressure"] = "PRESSURE";
    DimensionDtoDimensionTypeEnum["Force"] = "FORCE";
    DimensionDtoDimensionTypeEnum["Energy"] = "ENERGY";
    DimensionDtoDimensionTypeEnum["Power"] = "POWER";
    DimensionDtoDimensionTypeEnum["Frequency"] = "FREQUENCY";
    DimensionDtoDimensionTypeEnum["Angle"] = "ANGLE";
    DimensionDtoDimensionTypeEnum["DataSize"] = "DATA_SIZE";
    DimensionDtoDimensionTypeEnum["Current"] = "CURRENT";
    DimensionDtoDimensionTypeEnum["Voltage"] = "VOLTAGE";
    DimensionDtoDimensionTypeEnum["Resistance"] = "RESISTANCE";
})(DimensionDtoDimensionTypeEnum || (DimensionDtoDimensionTypeEnum = {}));
;
function isOptionalDimensionDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDimensionDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDimensionDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfDimensionDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDimensionDtoPropertyNames('dimensionType', 'dimensionValue', 'id');
    const optionalStringProperties = createDimensionDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'dimensionType', nullable: false }, { name: 'id', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createDimensionDtoOptionalProperties();
    const optionalBooleanProperties = createDimensionDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDimensionDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDimensionDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDimensionDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var EffectiveLocationPriceResponseDtoOverrideStatusEnum;
(function (EffectiveLocationPriceResponseDtoOverrideStatusEnum) {
    EffectiveLocationPriceResponseDtoOverrideStatusEnum["Active"] = "ACTIVE";
    EffectiveLocationPriceResponseDtoOverrideStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    EffectiveLocationPriceResponseDtoOverrideStatusEnum["Rejected"] = "REJECTED";
    EffectiveLocationPriceResponseDtoOverrideStatusEnum["Inactive"] = "INACTIVE";
})(EffectiveLocationPriceResponseDtoOverrideStatusEnum || (EffectiveLocationPriceResponseDtoOverrideStatusEnum = {}));
;
function isOptionalEffectiveLocationPriceResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createEffectiveLocationPriceResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createEffectiveLocationPriceResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfEffectiveLocationPriceResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createEffectiveLocationPriceResponseDtoPropertyNames('basePrice', 'effectivePrice', 'locationId', 'productId');
    const optionalStringProperties = createEffectiveLocationPriceResponseDtoOptionalProperties({ name: 'locationId', nullable: false }, { name: 'overrideStatus', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createEffectiveLocationPriceResponseDtoOptionalProperties({ name: 'basePrice', nullable: false }, { name: 'effectivePrice', nullable: false });
    const optionalBooleanProperties = createEffectiveLocationPriceResponseDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalEffectiveLocationPriceResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalEffectiveLocationPriceResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalEffectiveLocationPriceResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGuardrailPolicyUpsertRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGuardrailPolicyUpsertRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGuardrailPolicyUpsertRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfGuardrailPolicyUpsertRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGuardrailPolicyUpsertRequestDtoPropertyNames('autoApprovalThresholdPercent', 'maxDiscountPercent', 'minMarginPercent', 'scopeId');
    const optionalStringProperties = createGuardrailPolicyUpsertRequestDtoOptionalProperties({ name: 'scopeId', nullable: false });
    const optionalNumberProperties = createGuardrailPolicyUpsertRequestDtoOptionalProperties({ name: 'autoApprovalThresholdPercent', nullable: false }, { name: 'maxDiscountPercent', nullable: false }, { name: 'minMarginPercent', nullable: false });
    const optionalBooleanProperties = createGuardrailPolicyUpsertRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGuardrailPolicyUpsertRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGuardrailPolicyUpsertRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGuardrailPolicyUpsertRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ItemCostAuditDtoChangeSourceTypeEnum;
(function (ItemCostAuditDtoChangeSourceTypeEnum) {
    ItemCostAuditDtoChangeSourceTypeEnum["Manual"] = "MANUAL";
    ItemCostAuditDtoChangeSourceTypeEnum["PurchaseOrder"] = "PURCHASE_ORDER";
})(ItemCostAuditDtoChangeSourceTypeEnum || (ItemCostAuditDtoChangeSourceTypeEnum = {}));
;
var ItemCostAuditDtoCostTypeChangedEnum;
(function (ItemCostAuditDtoCostTypeChangedEnum) {
    ItemCostAuditDtoCostTypeChangedEnum["Standard"] = "STANDARD";
    ItemCostAuditDtoCostTypeChangedEnum["Last"] = "LAST";
    ItemCostAuditDtoCostTypeChangedEnum["Average"] = "AVERAGE";
})(ItemCostAuditDtoCostTypeChangedEnum || (ItemCostAuditDtoCostTypeChangedEnum = {}));
;
function isOptionalItemCostAuditDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createItemCostAuditDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createItemCostAuditDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfItemCostAuditDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createItemCostAuditDtoPropertyNames('auditId', 'changeSourceType', 'costTypeChanged', 'itemId', 'timestamp');
    const optionalStringProperties = createItemCostAuditDtoOptionalProperties({ name: 'actor', nullable: false }, { name: 'auditId', nullable: false }, { name: 'changeSourceId', nullable: false }, { name: 'changeSourceType', nullable: false }, { name: 'costTypeChanged', nullable: false }, { name: 'itemId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createItemCostAuditDtoOptionalProperties({ name: 'newValue', nullable: false }, { name: 'oldValue', nullable: false });
    const optionalBooleanProperties = createItemCostAuditDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalItemCostAuditDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalItemCostAuditDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalItemCostAuditDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalItemCostsDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createItemCostsDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createItemCostsDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfItemCostsDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createItemCostsDtoPropertyNames('itemId');
    const optionalStringProperties = createItemCostsDtoOptionalProperties({ name: 'itemId', nullable: false });
    const optionalNumberProperties = createItemCostsDtoOptionalProperties({ name: 'averageCost', nullable: false }, { name: 'lastCost', nullable: false }, { name: 'standardCost', nullable: false });
    const optionalBooleanProperties = createItemCostsDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalItemCostsDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalItemCostsDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalItemCostsDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLaborGuideImportSummaryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborGuideImportSummaryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborGuideImportSummaryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborGuideImportSummaryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborGuideImportSummaryDtoPropertyNames('alreadyImported', 'chunksApplied', 'expectedChunkCount', 'expectedLineCount', 'importManifestId', 'linesApplied', 'linesUnchanged', 'linesUnmapped', 'sourceCode', 'sourceRevision', 'standardsWritten', 'status');
    const optionalStringProperties = createLaborGuideImportSummaryDtoOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'importManifestId', nullable: false }, { name: 'sourceCode', nullable: false }, { name: 'sourceRevision', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createLaborGuideImportSummaryDtoOptionalProperties({ name: 'chunksApplied', nullable: false }, { name: 'expectedChunkCount', nullable: false }, { name: 'expectedLineCount', nullable: false }, { name: 'linesApplied', nullable: false }, { name: 'linesUnchanged', nullable: false }, { name: 'linesUnmapped', nullable: false }, { name: 'standardsWritten', nullable: false });
    const optionalBooleanProperties = createLaborGuideImportSummaryDtoOptionalProperties({ name: 'alreadyImported', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborGuideImportSummaryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborGuideImportSummaryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborGuideImportSummaryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLaborGuideUnmappedOperationDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborGuideUnmappedOperationDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborGuideUnmappedOperationDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborGuideUnmappedOperationDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborGuideUnmappedOperationDtoPropertyNames('firstSeenAt', 'lastSeenAt', 'occurrenceCount', 'providerOpCode', 'sourceCode');
    const optionalStringProperties = createLaborGuideUnmappedOperationDtoOptionalProperties({ name: 'firstSeenAt', nullable: false }, { name: 'lastManifestId', nullable: false }, { name: 'lastSeenAt', nullable: false }, { name: 'providerOpCode', nullable: false }, { name: 'sourceCode', nullable: false });
    const optionalNumberProperties = createLaborGuideUnmappedOperationDtoOptionalProperties({ name: 'occurrenceCount', nullable: false });
    const optionalBooleanProperties = createLaborGuideUnmappedOperationDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborGuideUnmappedOperationDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborGuideUnmappedOperationDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborGuideUnmappedOperationDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLaborStandardConflictDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborStandardConflictDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborStandardConflictDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborStandardConflictDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborStandardConflictDtoPropertyNames();
    const optionalStringProperties = createLaborStandardConflictDtoOptionalProperties({ name: 'operationCode', nullable: false }, { name: 'otherSourceCode', nullable: false }, { name: 'otherStandardId', nullable: false }, { name: 'serviceId', nullable: false }, { name: 'sourceCode', nullable: false }, { name: 'standardId', nullable: false }, { name: 'timeType', nullable: false }, { name: 'vehicleKey', nullable: false });
    const optionalNumberProperties = createLaborStandardConflictDtoOptionalProperties({ name: 'differenceHours', nullable: false }, { name: 'laborHours', nullable: false }, { name: 'otherLaborHours', nullable: false });
    const optionalBooleanProperties = createLaborStandardConflictDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborStandardConflictDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborStandardConflictDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborStandardConflictDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LaborTimeQuoteRequestPreferredTimeTypeEnum;
(function (LaborTimeQuoteRequestPreferredTimeTypeEnum) {
    LaborTimeQuoteRequestPreferredTimeTypeEnum["RetailFlatRate"] = "RETAIL_FLAT_RATE";
    LaborTimeQuoteRequestPreferredTimeTypeEnum["OemWarranty"] = "OEM_WARRANTY";
    LaborTimeQuoteRequestPreferredTimeTypeEnum["ManufacturerInstall"] = "MANUFACTURER_INSTALL";
    LaborTimeQuoteRequestPreferredTimeTypeEnum["DurionStandard"] = "DURION_STANDARD";
})(LaborTimeQuoteRequestPreferredTimeTypeEnum || (LaborTimeQuoteRequestPreferredTimeTypeEnum = {}));
;
function isOptionalLaborTimeQuoteRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborTimeQuoteRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborTimeQuoteRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborTimeQuoteRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborTimeQuoteRequestPropertyNames('serviceId');
    const optionalStringProperties = createLaborTimeQuoteRequestOptionalProperties({ name: 'engineCode', nullable: false }, { name: 'locationId', nullable: false }, { name: 'make', nullable: false }, { name: 'model', nullable: false }, { name: 'preferredTimeType', nullable: false }, { name: 'serviceId', nullable: false }, { name: 'submodel', nullable: false }, { name: 'vehicleYear', nullable: false });
    const optionalNumberProperties = createLaborTimeQuoteRequestOptionalProperties();
    const optionalBooleanProperties = createLaborTimeQuoteRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborTimeQuoteRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborTimeQuoteRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborTimeQuoteRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LaborTimeQuoteResponseMatchGradeEnum;
(function (LaborTimeQuoteResponseMatchGradeEnum) {
    LaborTimeQuoteResponseMatchGradeEnum["Exact"] = "EXACT";
    LaborTimeQuoteResponseMatchGradeEnum["EngineWildcard"] = "ENGINE_WILDCARD";
    LaborTimeQuoteResponseMatchGradeEnum["ModelLevel"] = "MODEL_LEVEL";
    LaborTimeQuoteResponseMatchGradeEnum["DefaultHours"] = "DEFAULT_HOURS";
})(LaborTimeQuoteResponseMatchGradeEnum || (LaborTimeQuoteResponseMatchGradeEnum = {}));
;
var LaborTimeQuoteResponseStatusEnum;
(function (LaborTimeQuoteResponseStatusEnum) {
    LaborTimeQuoteResponseStatusEnum["Resolved"] = "RESOLVED";
    LaborTimeQuoteResponseStatusEnum["NoTimeAvailable"] = "NO_TIME_AVAILABLE";
    LaborTimeQuoteResponseStatusEnum["SourceUnavailable"] = "SOURCE_UNAVAILABLE";
})(LaborTimeQuoteResponseStatusEnum || (LaborTimeQuoteResponseStatusEnum = {}));
;
function isOptionalLaborTimeQuoteResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLaborTimeQuoteResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLaborTimeQuoteResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLaborTimeQuoteResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLaborTimeQuoteResponsePropertyNames();
    const optionalStringProperties = createLaborTimeQuoteResponseOptionalProperties({ name: 'matchGrade', nullable: false }, { name: 'overlapGroup', nullable: false }, { name: 'ownerScope', nullable: false }, { name: 'sourceCode', nullable: false }, { name: 'sourceRevision', nullable: false }, { name: 'status', nullable: false }, { name: 'timeType', nullable: false });
    const optionalNumberProperties = createLaborTimeQuoteResponseOptionalProperties({ name: 'laborHours', nullable: false });
    const optionalBooleanProperties = createLaborTimeQuoteResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLaborTimeQuoteResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLaborTimeQuoteResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLaborTimeQuoteResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LeadTimeInfoConfidenceEnum;
(function (LeadTimeInfoConfidenceEnum) {
    LeadTimeInfoConfidenceEnum["Low"] = "LOW";
    LeadTimeInfoConfidenceEnum["Medium"] = "MEDIUM";
    LeadTimeInfoConfidenceEnum["High"] = "HIGH";
})(LeadTimeInfoConfidenceEnum || (LeadTimeInfoConfidenceEnum = {}));
;
var LeadTimeInfoSourceEnum;
(function (LeadTimeInfoSourceEnum) {
    LeadTimeInfoSourceEnum["Catalog"] = "CATALOG";
    LeadTimeInfoSourceEnum["Inventory"] = "INVENTORY";
    LeadTimeInfoSourceEnum["SupplyChain"] = "SUPPLY_CHAIN";
})(LeadTimeInfoSourceEnum || (LeadTimeInfoSourceEnum = {}));
;
function isOptionalLeadTimeInfoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLeadTimeInfoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLeadTimeInfoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLeadTimeInfo(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLeadTimeInfoPropertyNames('confidence', 'source');
    const optionalStringProperties = createLeadTimeInfoOptionalProperties({ name: 'asOf', nullable: false }, { name: 'confidence', nullable: false }, { name: 'displayText', nullable: false }, { name: 'source', nullable: false });
    const optionalNumberProperties = createLeadTimeInfoOptionalProperties({ name: 'maxDays', nullable: false }, { name: 'minDays', nullable: false });
    const optionalBooleanProperties = createLeadTimeInfoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLeadTimeInfoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLeadTimeInfoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLeadTimeInfoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLocationPriceOverrideCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationPriceOverrideCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationPriceOverrideCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationPriceOverrideCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationPriceOverrideCreateRequestDtoPropertyNames('basePrice', 'createdByUserId', 'locationId', 'overridePrice', 'productId');
    const optionalStringProperties = createLocationPriceOverrideCreateRequestDtoOptionalProperties({ name: 'createdByUserId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createLocationPriceOverrideCreateRequestDtoOptionalProperties({ name: 'basePrice', nullable: false }, { name: 'cost', nullable: false }, { name: 'overridePrice', nullable: false });
    const optionalBooleanProperties = createLocationPriceOverrideCreateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationPriceOverrideCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationPriceOverrideCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationPriceOverrideCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLocationPriceOverrideDecisionRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationPriceOverrideDecisionRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationPriceOverrideDecisionRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationPriceOverrideDecisionRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationPriceOverrideDecisionRequestDtoPropertyNames('actorUserId', 'version');
    const optionalStringProperties = createLocationPriceOverrideDecisionRequestDtoOptionalProperties({ name: 'actorUserId', nullable: false }, { name: 'rejectionNotes', nullable: false }, { name: 'rejectionReasonCode', nullable: false });
    const optionalNumberProperties = createLocationPriceOverrideDecisionRequestDtoOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createLocationPriceOverrideDecisionRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationPriceOverrideDecisionRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationPriceOverrideDecisionRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationPriceOverrideDecisionRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LocationPriceOverrideResponseDtoStatusEnum;
(function (LocationPriceOverrideResponseDtoStatusEnum) {
    LocationPriceOverrideResponseDtoStatusEnum["Active"] = "ACTIVE";
    LocationPriceOverrideResponseDtoStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    LocationPriceOverrideResponseDtoStatusEnum["Rejected"] = "REJECTED";
    LocationPriceOverrideResponseDtoStatusEnum["Inactive"] = "INACTIVE";
})(LocationPriceOverrideResponseDtoStatusEnum || (LocationPriceOverrideResponseDtoStatusEnum = {}));
;
function isOptionalLocationPriceOverrideResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationPriceOverrideResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationPriceOverrideResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationPriceOverrideResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationPriceOverrideResponseDtoPropertyNames('basePrice', 'createdAt', 'createdByUserId', 'locationId', 'overrideId', 'overridePrice', 'productId', 'status', 'version');
    const optionalStringProperties = createLocationPriceOverrideResponseDtoOptionalProperties({ name: 'approvedAt', nullable: false }, { name: 'approvedByUserId', nullable: false }, { name: 'assignedApproverId', nullable: false }, { name: 'assignmentStrategy', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdByUserId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'overrideId', nullable: false }, { name: 'productId', nullable: false }, { name: 'rejectedAt', nullable: false }, { name: 'rejectedBy', nullable: false }, { name: 'rejectionNotes', nullable: false }, { name: 'rejectionReasonCode', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createLocationPriceOverrideResponseDtoOptionalProperties({ name: 'basePrice', nullable: false }, { name: 'cost', nullable: false }, { name: 'discountPercent', nullable: false }, { name: 'marginPercent', nullable: false }, { name: 'overridePrice', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createLocationPriceOverrideResponseDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationPriceOverrideResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationPriceOverrideResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationPriceOverrideResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalNonInventoryProductDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createNonInventoryProductDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createNonInventoryProductDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfNonInventoryProductDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createNonInventoryProductDtoPropertyNames('id', 'name');
    const optionalStringProperties = createNonInventoryProductDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'longDescription', nullable: false }, { name: 'name', nullable: false }, { name: 'shortDescription', nullable: false });
    const optionalNumberProperties = createNonInventoryProductDtoOptionalProperties();
    const optionalBooleanProperties = createNonInventoryProductDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalNonInventoryProductDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalNonInventoryProductDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalNonInventoryProductDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPagePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageOptionalProperties(...properties) {
    return properties;
}
function instanceOfPage(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagePropertyNames();
    const optionalStringProperties = createPageOptionalProperties();
    const optionalNumberProperties = createPageOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageableObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageableObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageableObjectPropertyNames();
    const optionalStringProperties = createPageableObjectOptionalProperties();
    const optionalNumberProperties = createPageableObjectOptionalProperties({ name: 'offset', nullable: false }, { name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createPageableObjectOptionalProperties({ name: 'paged', nullable: false }, { name: 'unpaged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PriceBookCreateRequestDtoScopeEnum;
(function (PriceBookCreateRequestDtoScopeEnum) {
    PriceBookCreateRequestDtoScopeEnum["CompanyDefault"] = "COMPANY_DEFAULT";
    PriceBookCreateRequestDtoScopeEnum["Location"] = "LOCATION";
    PriceBookCreateRequestDtoScopeEnum["CustomerTier"] = "CUSTOMER_TIER";
})(PriceBookCreateRequestDtoScopeEnum || (PriceBookCreateRequestDtoScopeEnum = {}));
;
var PriceBookCreateRequestDtoStatusEnum;
(function (PriceBookCreateRequestDtoStatusEnum) {
    PriceBookCreateRequestDtoStatusEnum["Active"] = "ACTIVE";
    PriceBookCreateRequestDtoStatusEnum["Inactive"] = "INACTIVE";
})(PriceBookCreateRequestDtoStatusEnum || (PriceBookCreateRequestDtoStatusEnum = {}));
;
function isOptionalPriceBookCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceBookCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceBookCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceBookCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceBookCreateRequestDtoPropertyNames('name', 'scope');
    const optionalStringProperties = createPriceBookCreateRequestDtoOptionalProperties({ name: 'name', nullable: false }, { name: 'scope', nullable: false }, { name: 'scopeId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createPriceBookCreateRequestDtoOptionalProperties();
    const optionalBooleanProperties = createPriceBookCreateRequestDtoOptionalProperties({ name: 'isDefault', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceBookCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceBookCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceBookCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PriceBookDtoScopeEnum;
(function (PriceBookDtoScopeEnum) {
    PriceBookDtoScopeEnum["CompanyDefault"] = "COMPANY_DEFAULT";
    PriceBookDtoScopeEnum["Location"] = "LOCATION";
    PriceBookDtoScopeEnum["CustomerTier"] = "CUSTOMER_TIER";
})(PriceBookDtoScopeEnum || (PriceBookDtoScopeEnum = {}));
;
var PriceBookDtoStatusEnum;
(function (PriceBookDtoStatusEnum) {
    PriceBookDtoStatusEnum["Active"] = "ACTIVE";
    PriceBookDtoStatusEnum["Inactive"] = "INACTIVE";
})(PriceBookDtoStatusEnum || (PriceBookDtoStatusEnum = {}));
;
function isOptionalPriceBookDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceBookDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceBookDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceBookDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceBookDtoPropertyNames('createdAt', 'name', 'priceBookId', 'scope', 'status', 'version');
    const optionalStringProperties = createPriceBookDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'name', nullable: false }, { name: 'priceBookId', nullable: false }, { name: 'scope', nullable: false }, { name: 'scopeId', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createPriceBookDtoOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createPriceBookDtoOptionalProperties({ name: '_default', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceBookDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceBookDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceBookDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PriceBookRuleCreateRequestDtoConditionTypeEnum;
(function (PriceBookRuleCreateRequestDtoConditionTypeEnum) {
    PriceBookRuleCreateRequestDtoConditionTypeEnum["CustomerTier"] = "CUSTOMER_TIER";
    PriceBookRuleCreateRequestDtoConditionTypeEnum["Location"] = "LOCATION";
    PriceBookRuleCreateRequestDtoConditionTypeEnum["None"] = "NONE";
})(PriceBookRuleCreateRequestDtoConditionTypeEnum || (PriceBookRuleCreateRequestDtoConditionTypeEnum = {}));
;
var PriceBookRuleCreateRequestDtoTargetTypeEnum;
(function (PriceBookRuleCreateRequestDtoTargetTypeEnum) {
    PriceBookRuleCreateRequestDtoTargetTypeEnum["Sku"] = "SKU";
    PriceBookRuleCreateRequestDtoTargetTypeEnum["Category"] = "CATEGORY";
    PriceBookRuleCreateRequestDtoTargetTypeEnum["Global"] = "GLOBAL";
})(PriceBookRuleCreateRequestDtoTargetTypeEnum || (PriceBookRuleCreateRequestDtoTargetTypeEnum = {}));
;
function isOptionalPriceBookRuleCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceBookRuleCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceBookRuleCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceBookRuleCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceBookRuleCreateRequestDtoPropertyNames('createdByUserId', 'effectiveStartAt', 'pricingLogic', 'targetType');
    const optionalStringProperties = createPriceBookRuleCreateRequestDtoOptionalProperties({ name: 'conditionType', nullable: false }, { name: 'conditionValue', nullable: false }, { name: 'createdByUserId', nullable: false }, { name: 'effectiveEndAt', nullable: false }, { name: 'effectiveStartAt', nullable: false }, { name: 'pricingLogic', nullable: false }, { name: 'targetId', nullable: false }, { name: 'targetType', nullable: false });
    const optionalNumberProperties = createPriceBookRuleCreateRequestDtoOptionalProperties({ name: 'priority', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createPriceBookRuleCreateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceBookRuleCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceBookRuleCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceBookRuleCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PriceBookRuleDtoConditionTypeEnum;
(function (PriceBookRuleDtoConditionTypeEnum) {
    PriceBookRuleDtoConditionTypeEnum["CustomerTier"] = "CUSTOMER_TIER";
    PriceBookRuleDtoConditionTypeEnum["Location"] = "LOCATION";
    PriceBookRuleDtoConditionTypeEnum["None"] = "NONE";
})(PriceBookRuleDtoConditionTypeEnum || (PriceBookRuleDtoConditionTypeEnum = {}));
;
var PriceBookRuleDtoStatusEnum;
(function (PriceBookRuleDtoStatusEnum) {
    PriceBookRuleDtoStatusEnum["Active"] = "ACTIVE";
    PriceBookRuleDtoStatusEnum["Inactive"] = "INACTIVE";
})(PriceBookRuleDtoStatusEnum || (PriceBookRuleDtoStatusEnum = {}));
;
var PriceBookRuleDtoTargetTypeEnum;
(function (PriceBookRuleDtoTargetTypeEnum) {
    PriceBookRuleDtoTargetTypeEnum["Sku"] = "SKU";
    PriceBookRuleDtoTargetTypeEnum["Category"] = "CATEGORY";
    PriceBookRuleDtoTargetTypeEnum["Global"] = "GLOBAL";
})(PriceBookRuleDtoTargetTypeEnum || (PriceBookRuleDtoTargetTypeEnum = {}));
;
function isOptionalPriceBookRuleDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPriceBookRuleDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPriceBookRuleDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPriceBookRuleDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPriceBookRuleDtoPropertyNames('createdAt', 'createdByUserId', 'effectiveStartAt', 'priceBookId', 'pricingLogic', 'ruleId', 'status', 'targetType', 'version');
    const optionalStringProperties = createPriceBookRuleDtoOptionalProperties({ name: 'conditionType', nullable: false }, { name: 'conditionValue', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdByUserId', nullable: false }, { name: 'effectiveEndAt', nullable: false }, { name: 'effectiveStartAt', nullable: false }, { name: 'priceBookId', nullable: false }, { name: 'pricingLogic', nullable: false }, { name: 'ruleId', nullable: false }, { name: 'status', nullable: false }, { name: 'targetId', nullable: false }, { name: 'targetType', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createPriceBookRuleDtoOptionalProperties({ name: 'priority', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createPriceBookRuleDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPriceBookRuleDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPriceBookRuleDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPriceBookRuleDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PricingInfoConfidenceEnum;
(function (PricingInfoConfidenceEnum) {
    PricingInfoConfidenceEnum["Low"] = "LOW";
    PricingInfoConfidenceEnum["Medium"] = "MEDIUM";
    PricingInfoConfidenceEnum["High"] = "HIGH";
})(PricingInfoConfidenceEnum || (PricingInfoConfidenceEnum = {}));
;
var PricingInfoStatusEnum;
(function (PricingInfoStatusEnum) {
    PricingInfoStatusEnum["Ok"] = "OK";
    PricingInfoStatusEnum["Unavailable"] = "UNAVAILABLE";
    PricingInfoStatusEnum["Stale"] = "STALE";
    PricingInfoStatusEnum["Error"] = "ERROR";
})(PricingInfoStatusEnum || (PricingInfoStatusEnum = {}));
;
function isOptionalPricingInfoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPricingInfoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPricingInfoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPricingInfo(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPricingInfoPropertyNames('confidence', 'status');
    const optionalStringProperties = createPricingInfoOptionalProperties({ name: 'asOf', nullable: false }, { name: 'confidence', nullable: false }, { name: 'currency', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createPricingInfoOptionalProperties();
    const optionalBooleanProperties = createPricingInfoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPricingInfoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPricingInfoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPricingInfoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductCodeMatchCodeTypeEnum;
(function (ProductCodeMatchCodeTypeEnum) {
    ProductCodeMatchCodeTypeEnum["Upc"] = "UPC";
    ProductCodeMatchCodeTypeEnum["Ean"] = "EAN";
})(ProductCodeMatchCodeTypeEnum || (ProductCodeMatchCodeTypeEnum = {}));
;
function isOptionalProductCodeMatchPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductCodeMatchPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductCodeMatchOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductCodeMatch(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductCodeMatchPropertyNames();
    const optionalStringProperties = createProductCodeMatchOptionalProperties({ name: 'code', nullable: false }, { name: 'codeType', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'manufacturerPartNumber', nullable: false }, { name: 'name', nullable: false }, { name: 'productId', nullable: false }, { name: 'sku', nullable: false });
    const optionalNumberProperties = createProductCodeMatchOptionalProperties();
    const optionalBooleanProperties = createProductCodeMatchOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductCodeMatchPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductCodeMatchPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductCodeMatchPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProductCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductCreateRequestDtoPropertyNames('description', 'mpn', 'name', 'sku', 'unitOfMeasure');
    const optionalStringProperties = createProductCreateRequestDtoOptionalProperties({ name: 'attributes', nullable: false }, { name: 'categoryId', nullable: false }, { name: 'countryOfOrigin', nullable: false }, { name: 'description', nullable: false }, { name: 'manufacturerBrand', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'manufacturerName', nullable: false }, { name: 'mpn', nullable: false }, { name: 'name', nullable: false }, { name: 'sku', nullable: false }, { name: 'subcategoryId', nullable: false }, { name: 'type', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'upc', nullable: false });
    const optionalNumberProperties = createProductCreateRequestDtoOptionalProperties();
    const optionalBooleanProperties = createProductCreateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ProductDetailViewConfidenceEnum;
(function (ProductDetailViewConfidenceEnum) {
    ProductDetailViewConfidenceEnum["Low"] = "LOW";
    ProductDetailViewConfidenceEnum["Medium"] = "MEDIUM";
    ProductDetailViewConfidenceEnum["High"] = "HIGH";
})(ProductDetailViewConfidenceEnum || (ProductDetailViewConfidenceEnum = {}));
;
function isOptionalProductDetailViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductDetailViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductDetailViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductDetailView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductDetailViewPropertyNames('confidence', 'generatedAt', 'productId');
    const optionalStringProperties = createProductDetailViewOptionalProperties({ name: 'confidence', nullable: false }, { name: 'description', nullable: false }, { name: 'generatedAt', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createProductDetailViewOptionalProperties();
    const optionalBooleanProperties = createProductDetailViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductDetailViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductDetailViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductDetailViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ProductDtoLifecycleStateEnum;
(function (ProductDtoLifecycleStateEnum) {
    ProductDtoLifecycleStateEnum["Active"] = "ACTIVE";
    ProductDtoLifecycleStateEnum["Inactive"] = "INACTIVE";
    ProductDtoLifecycleStateEnum["Discontinued"] = "DISCONTINUED";
})(ProductDtoLifecycleStateEnum || (ProductDtoLifecycleStateEnum = {}));
;
var ProductDtoProductCodeTypeEnum;
(function (ProductDtoProductCodeTypeEnum) {
    ProductDtoProductCodeTypeEnum["Upc"] = "UPC";
    ProductDtoProductCodeTypeEnum["Ean"] = "EAN";
})(ProductDtoProductCodeTypeEnum || (ProductDtoProductCodeTypeEnum = {}));
;
var ProductDtoStatusEnum;
(function (ProductDtoStatusEnum) {
    ProductDtoStatusEnum["Active"] = "ACTIVE";
    ProductDtoStatusEnum["Inactive"] = "INACTIVE";
})(ProductDtoStatusEnum || (ProductDtoStatusEnum = {}));
;
var ProductDtoTrackingLevelEnum;
(function (ProductDtoTrackingLevelEnum) {
    ProductDtoTrackingLevelEnum["None"] = "NONE";
    ProductDtoTrackingLevelEnum["Lot"] = "LOT";
    ProductDtoTrackingLevelEnum["Serial"] = "SERIAL";
})(ProductDtoTrackingLevelEnum || (ProductDtoTrackingLevelEnum = {}));
;
function isOptionalProductDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductDtoPropertyNames('id', 'name');
    const optionalStringProperties = createProductDtoOptionalProperties({ name: 'attributes', nullable: false }, { name: 'color', nullable: false }, { name: 'countryOfOrigin', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'description', nullable: false }, { name: 'id', nullable: false }, { name: 'lastStateChangedAt', nullable: false }, { name: 'lastStateChangedBy', nullable: false }, { name: 'lifecycleOverrideReason', nullable: false }, { name: 'lifecycleState', nullable: false }, { name: 'lifecycleStateEffectiveAt', nullable: false }, { name: 'longDescription', nullable: false }, { name: 'manufacturerBrand', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'manufacturerName', nullable: false }, { name: 'manufacturerPartNumber', nullable: false }, { name: 'manufacturerWarranty', nullable: false }, { name: 'material', nullable: false }, { name: 'mpn', nullable: false }, { name: 'name', nullable: false }, { name: 'productCode', nullable: false }, { name: 'productCodeType', nullable: false }, { name: 'shortDescription', nullable: false }, { name: 'sku', nullable: false }, { name: 'specifications', nullable: false }, { name: 'status', nullable: false }, { name: 'trackingLevel', nullable: false }, { name: 'type', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'upc', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'warranty', nullable: false });
    const optionalNumberProperties = createProductDtoOptionalProperties();
    const optionalBooleanProperties = createProductDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProductFactReplayResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductFactReplayResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductFactReplayResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductFactReplayResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductFactReplayResultDtoPropertyNames();
    const optionalStringProperties = createProductFactReplayResultDtoOptionalProperties({ name: 'nextAfterId', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'updatedSince', nullable: false });
    const optionalNumberProperties = createProductFactReplayResultDtoOptionalProperties({ name: 'emitted', nullable: false });
    const optionalBooleanProperties = createProductFactReplayResultDtoOptionalProperties({ name: 'complete', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductFactReplayResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductFactReplayResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductFactReplayResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var ProductLifecycleResponseLifecycleStateEnum;
(function (ProductLifecycleResponseLifecycleStateEnum) {
    ProductLifecycleResponseLifecycleStateEnum["Active"] = "ACTIVE";
    ProductLifecycleResponseLifecycleStateEnum["Inactive"] = "INACTIVE";
    ProductLifecycleResponseLifecycleStateEnum["Discontinued"] = "DISCONTINUED";
})(ProductLifecycleResponseLifecycleStateEnum || (ProductLifecycleResponseLifecycleStateEnum = {}));
;
function isOptionalProductLifecycleResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductLifecycleResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductLifecycleResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductLifecycleResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductLifecycleResponsePropertyNames('lifecycleState', 'productId');
    const optionalStringProperties = createProductLifecycleResponseOptionalProperties({ name: 'lastStateChangedAt', nullable: false }, { name: 'lastStateChangedBy', nullable: false }, { name: 'lifecycleOverrideReason', nullable: false }, { name: 'lifecycleState', nullable: false }, { name: 'lifecycleStateEffectiveAt', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createProductLifecycleResponseOptionalProperties();
    const optionalBooleanProperties = createProductLifecycleResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductLifecycleResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductLifecycleResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductLifecycleResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductLifecycleUpdateRequestLifecycleStateEnum;
(function (ProductLifecycleUpdateRequestLifecycleStateEnum) {
    ProductLifecycleUpdateRequestLifecycleStateEnum["Active"] = "ACTIVE";
    ProductLifecycleUpdateRequestLifecycleStateEnum["Inactive"] = "INACTIVE";
    ProductLifecycleUpdateRequestLifecycleStateEnum["Discontinued"] = "DISCONTINUED";
})(ProductLifecycleUpdateRequestLifecycleStateEnum || (ProductLifecycleUpdateRequestLifecycleStateEnum = {}));
;
function isOptionalProductLifecycleUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductLifecycleUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductLifecycleUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductLifecycleUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductLifecycleUpdateRequestPropertyNames('lifecycleState');
    const optionalStringProperties = createProductLifecycleUpdateRequestOptionalProperties({ name: 'changedBy', nullable: false }, { name: 'effectiveAt', nullable: false }, { name: 'effectiveDate', nullable: false }, { name: 'lifecycleState', nullable: false }, { name: 'overrideReason', nullable: false });
    const optionalNumberProperties = createProductLifecycleUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createProductLifecycleUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductLifecycleUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductLifecycleUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductLifecycleUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProductMsrpDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductMsrpDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductMsrpDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductMsrpDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductMsrpDtoPropertyNames('amount', 'createdAt', 'currency', 'effectiveStartDate', 'msrpId', 'productId', 'version');
    const optionalStringProperties = createProductMsrpDtoOptionalProperties({ name: 'amount', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'currency', nullable: false }, { name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'msrpId', nullable: false }, { name: 'productId', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'updatedBy', nullable: false });
    const optionalNumberProperties = createProductMsrpDtoOptionalProperties({ name: 'version', nullable: false });
    const optionalBooleanProperties = createProductMsrpDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductMsrpDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductMsrpDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductMsrpDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProductReplacementRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductReplacementRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductReplacementRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductReplacementRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductReplacementRequestPropertyNames('replacementProductId');
    const optionalStringProperties = createProductReplacementRequestOptionalProperties({ name: 'effectiveAt', nullable: false }, { name: 'notes', nullable: false }, { name: 'replacementProductId', nullable: false });
    const optionalNumberProperties = createProductReplacementRequestOptionalProperties({ name: 'priorityOrder', nullable: false });
    const optionalBooleanProperties = createProductReplacementRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductReplacementRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductReplacementRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductReplacementRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProductSpecificationPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductSpecificationPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductSpecificationOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductSpecification(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductSpecificationPropertyNames('name', 'value');
    const optionalStringProperties = createProductSpecificationOptionalProperties({ name: 'name', nullable: false }, { name: 'value', nullable: false });
    const optionalNumberProperties = createProductSpecificationOptionalProperties();
    const optionalBooleanProperties = createProductSpecificationOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductSpecificationPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductSpecificationPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductSpecificationPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductSummaryLifecycleStateEnum;
(function (ProductSummaryLifecycleStateEnum) {
    ProductSummaryLifecycleStateEnum["Active"] = "ACTIVE";
    ProductSummaryLifecycleStateEnum["Inactive"] = "INACTIVE";
    ProductSummaryLifecycleStateEnum["Discontinued"] = "DISCONTINUED";
})(ProductSummaryLifecycleStateEnum || (ProductSummaryLifecycleStateEnum = {}));
;
function isOptionalProductSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductSummaryPropertyNames();
    const optionalStringProperties = createProductSummaryOptionalProperties({ name: 'category', nullable: false }, { name: 'lifecycleState', nullable: true }, { name: 'lifecycleStateEffectiveAt', nullable: true }, { name: 'manufacturerBrand', nullable: false }, { name: 'msrpAmount', nullable: true }, { name: 'msrpCurrency', nullable: true }, { name: 'msrpEffectiveEndDate', nullable: true }, { name: 'msrpEffectiveStartDate', nullable: true }, { name: 'name', nullable: false }, { name: 'productId', nullable: false }, { name: 'sku', nullable: false }, { name: 'thumbnailUrl', nullable: false });
    const optionalNumberProperties = createProductSummaryOptionalProperties();
    const optionalBooleanProperties = createProductSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum;
(function (ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum) {
    ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum["None"] = "NONE";
    ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum["Lot"] = "LOT";
    ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum["Serial"] = "SERIAL";
})(ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum || (ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum = {}));
;
function isOptionalProductTrackingLevelUpdateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductTrackingLevelUpdateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductTrackingLevelUpdateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductTrackingLevelUpdateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductTrackingLevelUpdateRequestDtoPropertyNames('trackingLevel');
    const optionalStringProperties = createProductTrackingLevelUpdateRequestDtoOptionalProperties({ name: 'trackingLevel', nullable: false });
    const optionalNumberProperties = createProductTrackingLevelUpdateRequestDtoOptionalProperties();
    const optionalBooleanProperties = createProductTrackingLevelUpdateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductTrackingLevelUpdateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductTrackingLevelUpdateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductTrackingLevelUpdateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductUomCreateRequestDtoUomTypeEnum;
(function (ProductUomCreateRequestDtoUomTypeEnum) {
    ProductUomCreateRequestDtoUomTypeEnum["Base"] = "BASE";
    ProductUomCreateRequestDtoUomTypeEnum["Purchase"] = "PURCHASE";
    ProductUomCreateRequestDtoUomTypeEnum["Pack"] = "PACK";
    ProductUomCreateRequestDtoUomTypeEnum["Other"] = "OTHER";
})(ProductUomCreateRequestDtoUomTypeEnum || (ProductUomCreateRequestDtoUomTypeEnum = {}));
;
function isOptionalProductUomCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductUomCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductUomCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductUomCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductUomCreateRequestDtoPropertyNames('factorToBase', 'precisionScale', 'uomCode', 'uomType');
    const optionalStringProperties = createProductUomCreateRequestDtoOptionalProperties({ name: 'uomCode', nullable: false }, { name: 'uomType', nullable: false });
    const optionalNumberProperties = createProductUomCreateRequestDtoOptionalProperties({ name: 'factorToBase', nullable: false }, { name: 'precisionScale', nullable: false });
    const optionalBooleanProperties = createProductUomCreateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductUomCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductUomCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductUomCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductUomDtoUomTypeEnum;
(function (ProductUomDtoUomTypeEnum) {
    ProductUomDtoUomTypeEnum["Base"] = "BASE";
    ProductUomDtoUomTypeEnum["Purchase"] = "PURCHASE";
    ProductUomDtoUomTypeEnum["Pack"] = "PACK";
    ProductUomDtoUomTypeEnum["Other"] = "OTHER";
})(ProductUomDtoUomTypeEnum || (ProductUomDtoUomTypeEnum = {}));
;
function isOptionalProductUomDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductUomDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductUomDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductUomDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductUomDtoPropertyNames('factorToBase', 'id', 'precisionScale', 'productId', 'uomCode', 'uomType');
    const optionalStringProperties = createProductUomDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'id', nullable: false }, { name: 'productId', nullable: false }, { name: 'uomCode', nullable: false }, { name: 'uomType', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createProductUomDtoOptionalProperties({ name: 'factorToBase', nullable: false }, { name: 'precisionScale', nullable: false });
    const optionalBooleanProperties = createProductUomDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductUomDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductUomDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductUomDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ProductUomUpdateRequestDtoUomTypeEnum;
(function (ProductUomUpdateRequestDtoUomTypeEnum) {
    ProductUomUpdateRequestDtoUomTypeEnum["Base"] = "BASE";
    ProductUomUpdateRequestDtoUomTypeEnum["Purchase"] = "PURCHASE";
    ProductUomUpdateRequestDtoUomTypeEnum["Pack"] = "PACK";
    ProductUomUpdateRequestDtoUomTypeEnum["Other"] = "OTHER";
})(ProductUomUpdateRequestDtoUomTypeEnum || (ProductUomUpdateRequestDtoUomTypeEnum = {}));
;
function isOptionalProductUomUpdateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductUomUpdateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductUomUpdateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductUomUpdateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductUomUpdateRequestDtoPropertyNames('factorToBase', 'precisionScale');
    const optionalStringProperties = createProductUomUpdateRequestDtoOptionalProperties({ name: 'uomType', nullable: false });
    const optionalNumberProperties = createProductUomUpdateRequestDtoOptionalProperties({ name: 'factorToBase', nullable: false }, { name: 'precisionScale', nullable: false });
    const optionalBooleanProperties = createProductUomUpdateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductUomUpdateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductUomUpdateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductUomUpdateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalProductUpdateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createProductUpdateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createProductUpdateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfProductUpdateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createProductUpdateRequestDtoPropertyNames();
    const optionalStringProperties = createProductUpdateRequestDtoOptionalProperties({ name: 'attributes', nullable: false }, { name: 'categoryId', nullable: false }, { name: 'description', nullable: false }, { name: 'manufacturerId', nullable: false }, { name: 'mpn', nullable: false }, { name: 'name', nullable: false }, { name: 'sku', nullable: false }, { name: 'subcategoryId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'upc', nullable: false });
    const optionalNumberProperties = createProductUpdateRequestDtoOptionalProperties();
    const optionalBooleanProperties = createProductUpdateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalProductUpdateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalProductUpdateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalProductUpdateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReplacementOptionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReplacementOptionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReplacementOptionOptionalProperties(...properties) {
    return properties;
}
function instanceOfReplacementOption(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReplacementOptionPropertyNames('replacementId', 'replacementProductId');
    const optionalStringProperties = createReplacementOptionOptionalProperties({ name: 'effectiveAt', nullable: false }, { name: 'notes', nullable: false }, { name: 'replacementId', nullable: false }, { name: 'replacementProductId', nullable: false });
    const optionalNumberProperties = createReplacementOptionOptionalProperties({ name: 'priorityOrder', nullable: false });
    const optionalBooleanProperties = createReplacementOptionOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReplacementOptionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReplacementOptionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReplacementOptionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalResolvePriceRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolvePriceRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolvePriceRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolvePriceRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolvePriceRequestDtoPropertyNames('productId');
    const optionalStringProperties = createResolvePriceRequestDtoOptionalProperties({ name: 'asOf', nullable: false }, { name: 'currency', nullable: false }, { name: 'customerTier', nullable: false }, { name: 'customerTierId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'priceBookId', nullable: false }, { name: 'productId', nullable: false });
    const optionalNumberProperties = createResolvePriceRequestDtoOptionalProperties();
    const optionalBooleanProperties = createResolvePriceRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolvePriceRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolvePriceRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolvePriceRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ResolvePriceResponseDtoSourceEnum;
(function (ResolvePriceResponseDtoSourceEnum) {
    ResolvePriceResponseDtoSourceEnum["PriceBookRule"] = "PRICE_BOOK_RULE";
    ResolvePriceResponseDtoSourceEnum["Msrp"] = "MSRP";
    ResolvePriceResponseDtoSourceEnum["Unavailable"] = "UNAVAILABLE";
})(ResolvePriceResponseDtoSourceEnum || (ResolvePriceResponseDtoSourceEnum = {}));
;
function isOptionalResolvePriceResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolvePriceResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolvePriceResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolvePriceResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolvePriceResponseDtoPropertyNames('source');
    const optionalStringProperties = createResolvePriceResponseDtoOptionalProperties({ name: 'currency', nullable: false }, { name: 'fallbackReason', nullable: false }, { name: 'resolvedAmount', nullable: false }, { name: 'source', nullable: false }, { name: 'sourceRuleId', nullable: false });
    const optionalNumberProperties = createResolvePriceResponseDtoOptionalProperties();
    const optionalBooleanProperties = createResolvePriceResponseDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolvePriceResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolvePriceResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolvePriceResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ServiceDtoOperationCategoryEnum;
(function (ServiceDtoOperationCategoryEnum) {
    ServiceDtoOperationCategoryEnum["Repair"] = "REPAIR";
    ServiceDtoOperationCategoryEnum["Diagnostic"] = "DIAGNOSTIC";
    ServiceDtoOperationCategoryEnum["Maintenance"] = "MAINTENANCE";
    ServiceDtoOperationCategoryEnum["TireService"] = "TIRE_SERVICE";
})(ServiceDtoOperationCategoryEnum || (ServiceDtoOperationCategoryEnum = {}));
;
function isOptionalServiceDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServiceDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServiceDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServiceDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServiceDtoPropertyNames();
    const optionalStringProperties = createServiceDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'longDescription', nullable: false }, { name: 'name', nullable: false }, { name: 'operationCategory', nullable: false }, { name: 'operationCode', nullable: false }, { name: 'shortDescription', nullable: false });
    const optionalNumberProperties = createServiceDtoOptionalProperties({ name: 'defaultLaborHours', nullable: false });
    const optionalBooleanProperties = createServiceDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServiceDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServiceDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServiceDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalServiceFactReplayResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServiceFactReplayResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServiceFactReplayResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServiceFactReplayResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServiceFactReplayResultDtoPropertyNames();
    const optionalStringProperties = createServiceFactReplayResultDtoOptionalProperties({ name: 'nextAfterId', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'updatedSince', nullable: false });
    const optionalNumberProperties = createServiceFactReplayResultDtoOptionalProperties({ name: 'emitted', nullable: false });
    const optionalBooleanProperties = createServiceFactReplayResultDtoOptionalProperties({ name: 'complete', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServiceFactReplayResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServiceFactReplayResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServiceFactReplayResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ServiceLaborStandardImportRequestDtoOwnerScopeEnum;
(function (ServiceLaborStandardImportRequestDtoOwnerScopeEnum) {
    ServiceLaborStandardImportRequestDtoOwnerScopeEnum["Platform"] = "PLATFORM";
    ServiceLaborStandardImportRequestDtoOwnerScopeEnum["Shop"] = "SHOP";
})(ServiceLaborStandardImportRequestDtoOwnerScopeEnum || (ServiceLaborStandardImportRequestDtoOwnerScopeEnum = {}));
;
function isOptionalServiceLaborStandardImportRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServiceLaborStandardImportRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServiceLaborStandardImportRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServiceLaborStandardImportRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServiceLaborStandardImportRequestDtoPropertyNames('laborHours', 'operationCode', 'sourceCode', 'sourceRevision');
    const optionalStringProperties = createServiceLaborStandardImportRequestDtoOptionalProperties({ name: 'engineCode', nullable: false }, { name: 'includedOpCodes', nullable: false }, { name: 'laborHours', nullable: false }, { name: 'make', nullable: false }, { name: 'model', nullable: false }, { name: 'operationCode', nullable: false }, { name: 'overlapGroup', nullable: false }, { name: 'ownerLocationId', nullable: false }, { name: 'ownerScope', nullable: false }, { name: 'publishedAt', nullable: false }, { name: 'sourceCode', nullable: false }, { name: 'sourceRevision', nullable: false }, { name: 'submodel', nullable: false }, { name: 'timeType', nullable: false }, { name: 'vehicleYear', nullable: false });
    const optionalNumberProperties = createServiceLaborStandardImportRequestDtoOptionalProperties();
    const optionalBooleanProperties = createServiceLaborStandardImportRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServiceLaborStandardImportRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServiceLaborStandardImportRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServiceLaborStandardImportRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ServiceLaborStandardRequestDtoOwnerScopeEnum;
(function (ServiceLaborStandardRequestDtoOwnerScopeEnum) {
    ServiceLaborStandardRequestDtoOwnerScopeEnum["Platform"] = "PLATFORM";
    ServiceLaborStandardRequestDtoOwnerScopeEnum["Shop"] = "SHOP";
})(ServiceLaborStandardRequestDtoOwnerScopeEnum || (ServiceLaborStandardRequestDtoOwnerScopeEnum = {}));
;
var ServiceLaborStandardRequestDtoTimeTypeEnum;
(function (ServiceLaborStandardRequestDtoTimeTypeEnum) {
    ServiceLaborStandardRequestDtoTimeTypeEnum["RetailFlatRate"] = "RETAIL_FLAT_RATE";
    ServiceLaborStandardRequestDtoTimeTypeEnum["OemWarranty"] = "OEM_WARRANTY";
    ServiceLaborStandardRequestDtoTimeTypeEnum["ManufacturerInstall"] = "MANUFACTURER_INSTALL";
    ServiceLaborStandardRequestDtoTimeTypeEnum["DurionStandard"] = "DURION_STANDARD";
})(ServiceLaborStandardRequestDtoTimeTypeEnum || (ServiceLaborStandardRequestDtoTimeTypeEnum = {}));
;
function isOptionalServiceLaborStandardRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServiceLaborStandardRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServiceLaborStandardRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServiceLaborStandardRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServiceLaborStandardRequestDtoPropertyNames('laborHours');
    const optionalStringProperties = createServiceLaborStandardRequestDtoOptionalProperties({ name: 'engineCode', nullable: false }, { name: 'make', nullable: false }, { name: 'model', nullable: false }, { name: 'overlapGroup', nullable: false }, { name: 'ownerLocationId', nullable: false }, { name: 'ownerScope', nullable: false }, { name: 'publishedAt', nullable: false }, { name: 'submodel', nullable: false }, { name: 'timeType', nullable: false }, { name: 'vehicleYear', nullable: false });
    const optionalNumberProperties = createServiceLaborStandardRequestDtoOptionalProperties({ name: 'laborHours', nullable: false });
    const optionalBooleanProperties = createServiceLaborStandardRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServiceLaborStandardRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServiceLaborStandardRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServiceLaborStandardRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalServiceLaborStandardResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServiceLaborStandardResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServiceLaborStandardResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServiceLaborStandardResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServiceLaborStandardResponseDtoPropertyNames('createdAt', 'id', 'laborHours', 'ownerScope', 'serviceId', 'sourceCode', 'sourceRevision', 'timeType');
    const optionalStringProperties = createServiceLaborStandardResponseDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'engineCode', nullable: true }, { name: 'id', nullable: false }, { name: 'make', nullable: true }, { name: 'model', nullable: true }, { name: 'overlapGroup', nullable: false }, { name: 'ownerLocationId', nullable: true }, { name: 'ownerScope', nullable: false }, { name: 'publishedAt', nullable: false }, { name: 'serviceId', nullable: false }, { name: 'sourceCode', nullable: false }, { name: 'sourceRevision', nullable: false }, { name: 'submodel', nullable: true }, { name: 'supersededAt', nullable: true }, { name: 'timeType', nullable: false }, { name: 'vehicleYear', nullable: true });
    const optionalNumberProperties = createServiceLaborStandardResponseDtoOptionalProperties({ name: 'laborHours', nullable: false });
    const optionalBooleanProperties = createServiceLaborStandardResponseDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServiceLaborStandardResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServiceLaborStandardResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServiceLaborStandardResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ServicePackageBulkIngestRecordOwnerScopeEnum;
(function (ServicePackageBulkIngestRecordOwnerScopeEnum) {
    ServicePackageBulkIngestRecordOwnerScopeEnum["Platform"] = "PLATFORM";
    ServicePackageBulkIngestRecordOwnerScopeEnum["Shop"] = "SHOP";
})(ServicePackageBulkIngestRecordOwnerScopeEnum || (ServicePackageBulkIngestRecordOwnerScopeEnum = {}));
;
function isOptionalServicePackageBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServicePackageBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServicePackageBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfServicePackageBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServicePackageBulkIngestRecordPropertyNames('name', 'packageCode', 'packageLaborHours');
    const optionalStringProperties = createServicePackageBulkIngestRecordOptionalProperties({ name: 'active', nullable: false }, { name: 'description', nullable: false }, { name: 'effectiveFrom', nullable: false }, { name: 'effectiveTo', nullable: false }, { name: 'fleetPartyId', nullable: false }, { name: 'name', nullable: false }, { name: 'ownerLocationId', nullable: false }, { name: 'ownerScope', nullable: false }, { name: 'packageCode', nullable: false }, { name: 'packageLaborHours', nullable: false });
    const optionalNumberProperties = createServicePackageBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createServicePackageBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServicePackageBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServicePackageBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServicePackageBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalServicePackageMemberBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServicePackageMemberBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServicePackageMemberBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfServicePackageMemberBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServicePackageMemberBulkIngestRecordPropertyNames('operationCode', 'packageCode');
    const optionalStringProperties = createServicePackageMemberBulkIngestRecordOptionalProperties({ name: 'operationCode', nullable: false }, { name: 'packageCode', nullable: false }, { name: 'quantity', nullable: false }, { name: 'required', nullable: false }, { name: 'sequence', nullable: false });
    const optionalNumberProperties = createServicePackageMemberBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createServicePackageMemberBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServicePackageMemberBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServicePackageMemberBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServicePackageMemberBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalServicePackageMemberRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServicePackageMemberRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServicePackageMemberRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServicePackageMemberRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServicePackageMemberRequestDtoPropertyNames('serviceId');
    const optionalStringProperties = createServicePackageMemberRequestDtoOptionalProperties({ name: 'serviceId', nullable: false });
    const optionalNumberProperties = createServicePackageMemberRequestDtoOptionalProperties({ name: 'quantity', nullable: false }, { name: 'sequence', nullable: false });
    const optionalBooleanProperties = createServicePackageMemberRequestDtoOptionalProperties({ name: 'required', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServicePackageMemberRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServicePackageMemberRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServicePackageMemberRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalServicePackageMemberResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServicePackageMemberResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServicePackageMemberResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServicePackageMemberResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServicePackageMemberResponseDtoPropertyNames();
    const optionalStringProperties = createServicePackageMemberResponseDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'operationCode', nullable: false }, { name: 'serviceId', nullable: false }, { name: 'serviceName', nullable: false });
    const optionalNumberProperties = createServicePackageMemberResponseDtoOptionalProperties({ name: 'quantity', nullable: false }, { name: 'sequence', nullable: false });
    const optionalBooleanProperties = createServicePackageMemberResponseDtoOptionalProperties({ name: 'required', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServicePackageMemberResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServicePackageMemberResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServicePackageMemberResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ServicePackageRequestDtoOwnerScopeEnum;
(function (ServicePackageRequestDtoOwnerScopeEnum) {
    ServicePackageRequestDtoOwnerScopeEnum["Platform"] = "PLATFORM";
    ServicePackageRequestDtoOwnerScopeEnum["Shop"] = "SHOP";
})(ServicePackageRequestDtoOwnerScopeEnum || (ServicePackageRequestDtoOwnerScopeEnum = {}));
;
function isOptionalServicePackageRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServicePackageRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServicePackageRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServicePackageRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServicePackageRequestDtoPropertyNames('name', 'packageCode');
    const optionalStringProperties = createServicePackageRequestDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'effectiveFrom', nullable: false }, { name: 'effectiveTo', nullable: false }, { name: 'fleetPartyId', nullable: false }, { name: 'name', nullable: false }, { name: 'ownerLocationId', nullable: false }, { name: 'ownerScope', nullable: false }, { name: 'packageCode', nullable: false });
    const optionalNumberProperties = createServicePackageRequestDtoOptionalProperties({ name: 'packageLaborHours', nullable: false });
    const optionalBooleanProperties = createServicePackageRequestDtoOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServicePackageRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServicePackageRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServicePackageRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalServicePackageResponseDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createServicePackageResponseDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createServicePackageResponseDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfServicePackageResponseDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createServicePackageResponseDtoPropertyNames();
    const optionalStringProperties = createServicePackageResponseDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'description', nullable: false }, { name: 'effectiveFrom', nullable: false }, { name: 'effectiveTo', nullable: false }, { name: 'fleetPartyId', nullable: true }, { name: 'id', nullable: false }, { name: 'name', nullable: false }, { name: 'ownerLocationId', nullable: true }, { name: 'ownerScope', nullable: false }, { name: 'packageCode', nullable: false });
    const optionalNumberProperties = createServicePackageResponseDtoOptionalProperties({ name: 'packageLaborHours', nullable: false });
    const optionalBooleanProperties = createServicePackageResponseDtoOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalServicePackageResponseDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalServicePackageResponseDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalServicePackageResponseDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSortObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSortObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSortObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSortObjectPropertyNames();
    const optionalStringProperties = createSortObjectOptionalProperties();
    const optionalNumberProperties = createSortObjectOptionalProperties();
    const optionalBooleanProperties = createSortObjectOptionalProperties({ name: 'empty', nullable: false }, { name: 'sorted', nullable: false }, { name: 'unsorted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSubcategoryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubcategoryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubcategoryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubcategoryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubcategoryDtoPropertyNames();
    const optionalStringProperties = createSubcategoryDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'name', nullable: false });
    const optionalNumberProperties = createSubcategoryDtoOptionalProperties();
    const optionalBooleanProperties = createSubcategoryDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubcategoryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubcategoryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubcategoryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSubstitutionGroupCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubstitutionGroupCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubstitutionGroupCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubstitutionGroupCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubstitutionGroupCreateRequestDtoPropertyNames('name');
    const optionalStringProperties = createSubstitutionGroupCreateRequestDtoOptionalProperties({ name: 'name', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createSubstitutionGroupCreateRequestDtoOptionalProperties();
    const optionalBooleanProperties = createSubstitutionGroupCreateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubstitutionGroupCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubstitutionGroupCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubstitutionGroupCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSubstitutionGroupDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubstitutionGroupDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubstitutionGroupDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubstitutionGroupDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubstitutionGroupDtoPropertyNames('id', 'name', 'productIds');
    const optionalStringProperties = createSubstitutionGroupDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'id', nullable: false }, { name: 'name', nullable: false }, { name: 'notes', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createSubstitutionGroupDtoOptionalProperties();
    const optionalBooleanProperties = createSubstitutionGroupDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubstitutionGroupDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubstitutionGroupDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubstitutionGroupDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSubstitutionGroupMemberRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubstitutionGroupMemberRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubstitutionGroupMemberRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubstitutionGroupMemberRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubstitutionGroupMemberRequestDtoPropertyNames('productId');
    const optionalStringProperties = createSubstitutionGroupMemberRequestDtoOptionalProperties({ name: 'productId', nullable: false });
    const optionalNumberProperties = createSubstitutionGroupMemberRequestDtoOptionalProperties();
    const optionalBooleanProperties = createSubstitutionGroupMemberRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubstitutionGroupMemberRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubstitutionGroupMemberRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubstitutionGroupMemberRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSubstitutionHintPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubstitutionHintPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubstitutionHintOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubstitutionHint(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubstitutionHintPropertyNames('productId');
    const optionalStringProperties = createSubstitutionHintOptionalProperties({ name: 'productId', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createSubstitutionHintOptionalProperties();
    const optionalBooleanProperties = createSubstitutionHintOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubstitutionHintPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubstitutionHintPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubstitutionHintPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSupplierArticleCodeReplayResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierArticleCodeReplayResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierArticleCodeReplayResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierArticleCodeReplayResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierArticleCodeReplayResultDtoPropertyNames();
    const optionalStringProperties = createSupplierArticleCodeReplayResultDtoOptionalProperties({ name: 'nextAfterId', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'updatedSince', nullable: false });
    const optionalNumberProperties = createSupplierArticleCodeReplayResultDtoOptionalProperties({ name: 'emitted', nullable: false });
    const optionalBooleanProperties = createSupplierArticleCodeReplayResultDtoOptionalProperties({ name: 'complete', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierArticleCodeReplayResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierArticleCodeReplayResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierArticleCodeReplayResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SupplierAvailabilityInfoConfidenceEnum;
(function (SupplierAvailabilityInfoConfidenceEnum) {
    SupplierAvailabilityInfoConfidenceEnum["Low"] = "LOW";
    SupplierAvailabilityInfoConfidenceEnum["Medium"] = "MEDIUM";
    SupplierAvailabilityInfoConfidenceEnum["High"] = "HIGH";
})(SupplierAvailabilityInfoConfidenceEnum || (SupplierAvailabilityInfoConfidenceEnum = {}));
;
var SupplierAvailabilityInfoStatusEnum;
(function (SupplierAvailabilityInfoStatusEnum) {
    SupplierAvailabilityInfoStatusEnum["Ok"] = "OK";
    SupplierAvailabilityInfoStatusEnum["Unavailable"] = "UNAVAILABLE";
    SupplierAvailabilityInfoStatusEnum["Stale"] = "STALE";
    SupplierAvailabilityInfoStatusEnum["Error"] = "ERROR";
})(SupplierAvailabilityInfoStatusEnum || (SupplierAvailabilityInfoStatusEnum = {}));
;
var SupplierAvailabilityInfoVendorStatusEnum;
(function (SupplierAvailabilityInfoVendorStatusEnum) {
    SupplierAvailabilityInfoVendorStatusEnum["Available"] = "AVAILABLE";
    SupplierAvailabilityInfoVendorStatusEnum["Unavailable"] = "UNAVAILABLE";
    SupplierAvailabilityInfoVendorStatusEnum["NotListed"] = "NOT_LISTED";
    SupplierAvailabilityInfoVendorStatusEnum["NotAnswered"] = "NOT_ANSWERED";
})(SupplierAvailabilityInfoVendorStatusEnum || (SupplierAvailabilityInfoVendorStatusEnum = {}));
;
function isOptionalSupplierAvailabilityInfoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierAvailabilityInfoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierAvailabilityInfoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierAvailabilityInfo(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierAvailabilityInfoPropertyNames('confidence', 'status');
    const optionalStringProperties = createSupplierAvailabilityInfoOptionalProperties({ name: 'asOf', nullable: false }, { name: 'confidence', nullable: false }, { name: 'earliestDeliveryDate', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorStatus', nullable: false });
    const optionalNumberProperties = createSupplierAvailabilityInfoOptionalProperties({ name: 'availableQuantity', nullable: false });
    const optionalBooleanProperties = createSupplierAvailabilityInfoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierAvailabilityInfoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierAvailabilityInfoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierAvailabilityInfoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SupplierPriceEntryDtoMatchMethodEnum;
(function (SupplierPriceEntryDtoMatchMethodEnum) {
    SupplierPriceEntryDtoMatchMethodEnum["Ean"] = "EAN";
    SupplierPriceEntryDtoMatchMethodEnum["UpcXreference"] = "UPC_XREFERENCE";
})(SupplierPriceEntryDtoMatchMethodEnum || (SupplierPriceEntryDtoMatchMethodEnum = {}));
;
function isOptionalSupplierPriceEntryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierPriceEntryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierPriceEntryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierPriceEntryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierPriceEntryDtoPropertyNames();
    const optionalStringProperties = createSupplierPriceEntryDtoOptionalProperties({ name: 'articleEan', nullable: false }, { name: 'buyerAccountNumber', nullable: false }, { name: 'countryCode', nullable: false }, { name: 'currency', nullable: false }, { name: 'effectiveFrom', nullable: false }, { name: 'fetchedAt', nullable: false }, { name: 'id', nullable: false }, { name: 'importManifestId', nullable: false }, { name: 'matchMethod', nullable: false }, { name: 'productId', nullable: false }, { name: 'sourceDocumentDate', nullable: false }, { name: 'sourceDocumentId', nullable: false }, { name: 'supplierArticleCode', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createSupplierPriceEntryDtoOptionalProperties({ name: 'grossPrice', nullable: false }, { name: 'netPrice', nullable: false }, { name: 'recyclingFee', nullable: false }, { name: 'suggestedRetailPrice', nullable: false }, { name: 'taxRate', nullable: false });
    const optionalBooleanProperties = createSupplierPriceEntryDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierPriceEntryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierPriceEntryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierPriceEntryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SupplierPriceImportStatusDtoStatusEnum;
(function (SupplierPriceImportStatusDtoStatusEnum) {
    SupplierPriceImportStatusDtoStatusEnum["Applying"] = "APPLYING";
    SupplierPriceImportStatusDtoStatusEnum["Complete"] = "COMPLETE";
    SupplierPriceImportStatusDtoStatusEnum["Incomplete"] = "INCOMPLETE";
})(SupplierPriceImportStatusDtoStatusEnum || (SupplierPriceImportStatusDtoStatusEnum = {}));
;
function isOptionalSupplierPriceImportStatusDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierPriceImportStatusDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierPriceImportStatusDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierPriceImportStatusDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierPriceImportStatusDtoPropertyNames();
    const optionalStringProperties = createSupplierPriceImportStatusDtoOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'importManifestId', nullable: false }, { name: 'status', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createSupplierPriceImportStatusDtoOptionalProperties({ name: 'chunksApplied', nullable: false }, { name: 'expectedChunkCount', nullable: false }, { name: 'expectedLineCount', nullable: false }, { name: 'linesApplied', nullable: false });
    const optionalBooleanProperties = createSupplierPriceImportStatusDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierPriceImportStatusDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierPriceImportStatusDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierPriceImportStatusDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TreadDesignCandidateDtoTierEnum;
(function (TreadDesignCandidateDtoTierEnum) {
    TreadDesignCandidateDtoTierEnum["Auto"] = "AUTO";
    TreadDesignCandidateDtoTierEnum["Review"] = "REVIEW";
    TreadDesignCandidateDtoTierEnum["None"] = "NONE";
})(TreadDesignCandidateDtoTierEnum || (TreadDesignCandidateDtoTierEnum = {}));
;
function isOptionalTreadDesignCandidateDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTreadDesignCandidateDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTreadDesignCandidateDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTreadDesignCandidateDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTreadDesignCandidateDtoPropertyNames();
    const optionalStringProperties = createTreadDesignCandidateDtoOptionalProperties({ name: 'productId', nullable: false }, { name: 'tier', nullable: false });
    const optionalNumberProperties = createTreadDesignCandidateDtoOptionalProperties({ name: 'score', nullable: false });
    const optionalBooleanProperties = createTreadDesignCandidateDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTreadDesignCandidateDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTreadDesignCandidateDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTreadDesignCandidateDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var TreadDesignDtoMatchStateEnum;
(function (TreadDesignDtoMatchStateEnum) {
    TreadDesignDtoMatchStateEnum["Unmatched"] = "UNMATCHED";
    TreadDesignDtoMatchStateEnum["Review"] = "REVIEW";
    TreadDesignDtoMatchStateEnum["Matched"] = "MATCHED";
    TreadDesignDtoMatchStateEnum["Rejected"] = "REJECTED";
    TreadDesignDtoMatchStateEnum["Deferred"] = "DEFERRED";
})(TreadDesignDtoMatchStateEnum || (TreadDesignDtoMatchStateEnum = {}));
;
function isOptionalTreadDesignDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTreadDesignDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTreadDesignDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTreadDesignDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTreadDesignDtoPropertyNames();
    const optionalStringProperties = createTreadDesignDtoOptionalProperties({ name: 'brand', nullable: false }, { name: 'deferUntil', nullable: false }, { name: 'id', nullable: false }, { name: 'matchState', nullable: false }, { name: 'matchStateAt', nullable: false }, { name: 'productName', nullable: false }, { name: 'resolutionNote', nullable: false }, { name: 'resolvedBy', nullable: false }, { name: 'seasonality', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'treadDesign', nullable: false }, { name: 'treadDesign2', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'vehicleType', nullable: false }, { name: 'vendorProfileId', nullable: false }, { name: 'vendorVariantId', nullable: false });
    const optionalNumberProperties = createTreadDesignDtoOptionalProperties();
    const optionalBooleanProperties = createTreadDesignDtoOptionalProperties({ name: 'hasUnresolvedImages', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTreadDesignDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTreadDesignDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTreadDesignDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTreadDesignImageDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTreadDesignImageDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTreadDesignImageDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTreadDesignImageDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTreadDesignImageDtoPropertyNames();
    const optionalStringProperties = createTreadDesignImageDtoOptionalProperties({ name: 'imageType', nullable: false });
    const optionalNumberProperties = createTreadDesignImageDtoOptionalProperties({ name: 'imageId', nullable: false });
    const optionalBooleanProperties = createTreadDesignImageDtoOptionalProperties({ name: 'unresolved', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTreadDesignImageDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTreadDesignImageDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTreadDesignImageDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TreadDesignResolveRequestActionEnum;
(function (TreadDesignResolveRequestActionEnum) {
    TreadDesignResolveRequestActionEnum["Attach"] = "ATTACH";
    TreadDesignResolveRequestActionEnum["Reject"] = "REJECT";
    TreadDesignResolveRequestActionEnum["Defer"] = "DEFER";
})(TreadDesignResolveRequestActionEnum || (TreadDesignResolveRequestActionEnum = {}));
;
function isOptionalTreadDesignResolveRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTreadDesignResolveRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTreadDesignResolveRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTreadDesignResolveRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTreadDesignResolveRequestPropertyNames('action');
    const optionalStringProperties = createTreadDesignResolveRequestOptionalProperties({ name: 'action', nullable: false }, { name: 'deferUntil', nullable: false }, { name: 'note', nullable: false });
    const optionalNumberProperties = createTreadDesignResolveRequestOptionalProperties();
    const optionalBooleanProperties = createTreadDesignResolveRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTreadDesignResolveRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTreadDesignResolveRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTreadDesignResolveRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTreadDesignTextDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTreadDesignTextDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTreadDesignTextDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfTreadDesignTextDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTreadDesignTextDtoPropertyNames();
    const optionalStringProperties = createTreadDesignTextDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'footNotes', nullable: false }, { name: 'languageCode', nullable: false }, { name: 'name', nullable: false });
    const optionalNumberProperties = createTreadDesignTextDtoOptionalProperties();
    const optionalBooleanProperties = createTreadDesignTextDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTreadDesignTextDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTreadDesignTextDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTreadDesignTextDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUomConversionCreateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUomConversionCreateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUomConversionCreateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUomConversionCreateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUomConversionCreateRequestDtoPropertyNames('conversionFactor', 'fromUomCode', 'toUomCode');
    const optionalStringProperties = createUomConversionCreateRequestDtoOptionalProperties({ name: 'createdBy', nullable: false }, { name: 'fromUomCode', nullable: false }, { name: 'toUomCode', nullable: false });
    const optionalNumberProperties = createUomConversionCreateRequestDtoOptionalProperties({ name: 'conversionFactor', nullable: false });
    const optionalBooleanProperties = createUomConversionCreateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUomConversionCreateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUomConversionCreateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUomConversionCreateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUomConversionDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUomConversionDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUomConversionDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUomConversionDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUomConversionDtoPropertyNames('active', 'conversionFactor', 'createdAt', 'fromUomCode', 'id', 'toUomCode');
    const optionalStringProperties = createUomConversionDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'fromUomCode', nullable: false }, { name: 'id', nullable: false }, { name: 'toUomCode', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createUomConversionDtoOptionalProperties({ name: 'conversionFactor', nullable: false });
    const optionalBooleanProperties = createUomConversionDtoOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUomConversionDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUomConversionDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUomConversionDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUomConversionUpdateRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUomConversionUpdateRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUomConversionUpdateRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUomConversionUpdateRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUomConversionUpdateRequestDtoPropertyNames('conversionFactor');
    const optionalStringProperties = createUomConversionUpdateRequestDtoOptionalProperties();
    const optionalNumberProperties = createUomConversionUpdateRequestDtoOptionalProperties({ name: 'conversionFactor', nullable: false });
    const optionalBooleanProperties = createUomConversionUpdateRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUomConversionUpdateRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUomConversionUpdateRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUomConversionUpdateRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpdateMsrpRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateMsrpRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateMsrpRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateMsrpRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateMsrpRequestDtoPropertyNames('amount', 'createdByUserId', 'currency', 'effectiveStartDate');
    const optionalStringProperties = createUpdateMsrpRequestDtoOptionalProperties({ name: 'createdByUserId', nullable: false }, { name: 'currency', nullable: false }, { name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false });
    const optionalNumberProperties = createUpdateMsrpRequestDtoOptionalProperties({ name: 'amount', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createUpdateMsrpRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateMsrpRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateMsrpRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateMsrpRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Product API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpdateStandardCostRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateStandardCostRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateStandardCostRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateStandardCostRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateStandardCostRequestDtoPropertyNames('newCost', 'reasonCode');
    const optionalStringProperties = createUpdateStandardCostRequestDtoOptionalProperties({ name: 'reasonCode', nullable: false });
    const optionalNumberProperties = createUpdateStandardCostRequestDtoOptionalProperties({ name: 'newCost', nullable: false });
    const optionalBooleanProperties = createUpdateStandardCostRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateStandardCostRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateStandardCostRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateStandardCostRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { ApiModule, AvailabilityInfoConfidenceEnum, AvailabilityInfoStatusEnum, BASE_PATH, COLLECTION_FORMATS, CatalogAPIService, CatalogBulkIngestAPIService, CatalogItemRequestDtoOperationCategoryEnum, CatalogItemResponseDtoOperationCategoryEnum, CatalogItemsAPIService, CatalogServiceBulkIngestAPIService, CatalogServiceBulkIngestRecordOperationCategoryEnum, Configuration, DimensionDtoDimensionTypeEnum, EffectiveLocationPriceResponseDtoOverrideStatusEnum, ItemCostAPIService, ItemCostAuditDtoChangeSourceTypeEnum, ItemCostAuditDtoCostTypeChangedEnum, LaborGuideImportsService, LaborStandardBulkIngestAPIService, LaborStandardConflictsService, LaborTimeQuoteRequestPreferredTimeTypeEnum, LaborTimeQuoteResponseMatchGradeEnum, LaborTimeQuoteResponseStatusEnum, LaborTimeResolutionService, LeadTimeInfoConfidenceEnum, LeadTimeInfoSourceEnum, LocationPriceOverrideResponseDtoStatusEnum, PriceBookAPIService, PriceBookCreateRequestDtoScopeEnum, PriceBookCreateRequestDtoStatusEnum, PriceBookDtoScopeEnum, PriceBookDtoStatusEnum, PriceBookRuleCreateRequestDtoConditionTypeEnum, PriceBookRuleCreateRequestDtoTargetTypeEnum, PriceBookRuleDtoConditionTypeEnum, PriceBookRuleDtoStatusEnum, PriceBookRuleDtoTargetTypeEnum, PricingInfoConfidenceEnum, PricingInfoStatusEnum, ProductCodeMatchCodeTypeEnum, ProductDetailViewConfidenceEnum, ProductDtoLifecycleStateEnum, ProductDtoProductCodeTypeEnum, ProductDtoStatusEnum, ProductDtoTrackingLevelEnum, ProductLifecycleResponseLifecycleStateEnum, ProductLifecycleUpdateRequestLifecycleStateEnum, ProductMSRPAPIService, ProductSummaryLifecycleStateEnum, ProductTrackingLevelUpdateRequestDtoTrackingLevelEnum, ProductUoMAPIService, ProductUomCreateRequestDtoUomTypeEnum, ProductUomDtoUomTypeEnum, ProductUomUpdateRequestDtoUomTypeEnum, ProductsAPIService, ResolvePriceResponseDtoSourceEnum, ServiceDtoOperationCategoryEnum, ServiceLaborStandardImportRequestDtoOwnerScopeEnum, ServiceLaborStandardRequestDtoOwnerScopeEnum, ServiceLaborStandardRequestDtoTimeTypeEnum, ServiceLaborStandardsService, ServicePackageBulkIngestAPIService, ServicePackageBulkIngestRecordOwnerScopeEnum, ServicePackageMemberBulkIngestAPIService, ServicePackageRequestDtoOwnerScopeEnum, ServicePackagesService, SubstitutionGroupAPIService, SupplierArticleCodesService, SupplierAvailabilityInfoConfidenceEnum, SupplierAvailabilityInfoStatusEnum, SupplierAvailabilityInfoVendorStatusEnum, SupplierPriceEntryDtoMatchMethodEnum, SupplierPriceImportStatusDtoStatusEnum, SupplierPricesService, TreadDesignCandidateDtoTierEnum, TreadDesignDtoMatchStateEnum, TreadDesignEnrichmentService, TreadDesignResolveRequestActionEnum, UOMConversionAPIService, instanceOfApiError, instanceOfAvailabilityInfo, instanceOfBulkIngestRequestCatalogBulkIngestRecord, instanceOfBulkIngestRequestCatalogServiceBulkIngestRecord, instanceOfBulkIngestRequestServiceLaborStandardImportRequestDto, instanceOfBulkIngestRequestServicePackageBulkIngestRecord, instanceOfBulkIngestRequestServicePackageMemberBulkIngestRecord, instanceOfBulkIngestResponse, instanceOfBulkIngestResult, instanceOfCatalogBulkIngestRecord, instanceOfCatalogDto, instanceOfCatalogItemRequestDto, instanceOfCatalogItemResponseDto, instanceOfCatalogSearchResultDto, instanceOfCatalogServiceBulkIngestRecord, instanceOfCategoryDto, instanceOfCreateMsrpRequestDto, instanceOfDimensionDto, instanceOfEffectiveLocationPriceResponseDto, instanceOfFieldError, instanceOfGuardrailPolicyUpsertRequestDto, instanceOfItemCostAuditDto, instanceOfItemCostsDto, instanceOfLaborGuideImportSummaryDto, instanceOfLaborGuideUnmappedOperationDto, instanceOfLaborStandardConflictDto, instanceOfLaborTimeQuoteRequest, instanceOfLaborTimeQuoteResponse, instanceOfLeadTimeInfo, instanceOfLocationPriceOverrideCreateRequestDto, instanceOfLocationPriceOverrideDecisionRequestDto, instanceOfLocationPriceOverrideResponseDto, instanceOfNonInventoryProductDto, instanceOfPage, instanceOfPageableObject, instanceOfPriceBookCreateRequestDto, instanceOfPriceBookDto, instanceOfPriceBookRuleCreateRequestDto, instanceOfPriceBookRuleDto, instanceOfPricingInfo, instanceOfProductCodeMatch, instanceOfProductCreateRequestDto, instanceOfProductDetailView, instanceOfProductDto, instanceOfProductFactReplayResultDto, instanceOfProductLifecycleResponse, instanceOfProductLifecycleUpdateRequest, instanceOfProductMsrpDto, instanceOfProductReplacementRequest, instanceOfProductSpecification, instanceOfProductSummary, instanceOfProductTrackingLevelUpdateRequestDto, instanceOfProductUomCreateRequestDto, instanceOfProductUomDto, instanceOfProductUomUpdateRequestDto, instanceOfProductUpdateRequestDto, instanceOfReplacementOption, instanceOfResolvePriceRequestDto, instanceOfResolvePriceResponseDto, instanceOfServiceDto, instanceOfServiceFactReplayResultDto, instanceOfServiceLaborStandardImportRequestDto, instanceOfServiceLaborStandardRequestDto, instanceOfServiceLaborStandardResponseDto, instanceOfServicePackageBulkIngestRecord, instanceOfServicePackageMemberBulkIngestRecord, instanceOfServicePackageMemberRequestDto, instanceOfServicePackageMemberResponseDto, instanceOfServicePackageRequestDto, instanceOfServicePackageResponseDto, instanceOfSortObject, instanceOfSubcategoryDto, instanceOfSubstitutionGroupCreateRequestDto, instanceOfSubstitutionGroupDto, instanceOfSubstitutionGroupMemberRequestDto, instanceOfSubstitutionHint, instanceOfSupplierArticleCodeReplayResultDto, instanceOfSupplierAvailabilityInfo, instanceOfSupplierPriceEntryDto, instanceOfSupplierPriceImportStatusDto, instanceOfTreadDesignCandidateDto, instanceOfTreadDesignDto, instanceOfTreadDesignImageDto, instanceOfTreadDesignResolveRequest, instanceOfTreadDesignTextDto, instanceOfUomConversionCreateRequestDto, instanceOfUomConversionDto, instanceOfUomConversionUpdateRequestDto, instanceOfUpdateMsrpRequestDto, instanceOfUpdateStandardCostRequestDto, provideApi };
//# sourceMappingURL=durion-sdk-catalog.mjs.map
