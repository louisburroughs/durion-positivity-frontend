export * from '../../models/channelFunnel';
