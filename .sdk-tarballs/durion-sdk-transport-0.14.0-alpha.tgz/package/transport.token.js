import { InjectionToken } from '@angular/core';
export const DURION_SDK_CONFIG = new InjectionToken('DURION_SDK_CONFIG');
