import { InjectionToken } from '@angular/core';
import { DurionSdkConfig } from './config';
export declare const DURION_SDK_CONFIG: InjectionToken<DurionSdkConfig>;
