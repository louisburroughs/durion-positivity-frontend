var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable, InjectionToken, inject, makeEnvironmentProviders, } from '@angular/core';
import { HTTP_INTERCEPTORS, } from '@angular/common/http';
import { from, switchMap } from 'rxjs';
export const DURION_SDK_CONFIG = new InjectionToken('DURION_SDK_CONFIG');
const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
/**
 * HTTP interceptor that applies Durion cross-cutting concerns:
 * - Authorization Bearer token (resolved per request)
 * - X-API-Version header
 * - X-Correlation-Id header
 * - Idempotency-Key header for mutating methods
 */
let DurionTransportInterceptor = class DurionTransportInterceptor {
    config = inject(DURION_SDK_CONFIG);
    intercept(req, next) {
        return from(this.resolveHeaders(req)).pipe(switchMap((headers) => next.handle(req.clone({ setHeaders: headers }))));
    }
    async resolveHeaders(req) {
        const headers = {};
        if (this.config.token) {
            const token = await this.config.token();
            headers['Authorization'] = `Bearer ${token}`;
        }
        headers['X-API-Version'] = this.config.apiVersion ?? '1';
        headers['X-Correlation-Id'] =
            this.config.correlationIdProvider?.() ?? cryptoRandomUUID();
        const method = req.method.toUpperCase();
        if (MUTATING_METHODS.has(method)) {
            const explicit = req.headers.get('Idempotency-Key') ?? undefined;
            const generated = explicit ?? this.config.idempotencyKeyGenerator?.(method, req.urlWithParams);
            if (generated) {
                headers['Idempotency-Key'] = generated;
            }
        }
        return headers;
    }
};
DurionTransportInterceptor = __decorate([
    Injectable()
], DurionTransportInterceptor);
export { DurionTransportInterceptor };
function cryptoRandomUUID() {
    const c = typeof globalThis !== 'undefined' ? globalThis.crypto : undefined;
    if (c && typeof c.randomUUID === 'function') {
        return c.randomUUID();
    }
    // Fallback (RFC4122 v4-ish, non-crypto): only used in environments without crypto.
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (ch) => {
        const r = Math.floor(Math.random() * 16);
        const v = ch === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}
/**
 * Register the Durion transport interceptor and config in an Angular application.
 * Use alongside `provideHttpClient()` and each SDK package's `provideApi(baseUrl)`.
 */
export function provideDurionTransport(config) {
    return makeEnvironmentProviders([
        { provide: DURION_SDK_CONFIG, useValue: config },
        { provide: HTTP_INTERCEPTORS, useClass: DurionTransportInterceptor, multi: true },
    ]);
}
