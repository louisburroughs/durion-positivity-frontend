var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
import { Inject, Injectable, Optional, inject } from '@angular/core';
import { from, switchMap, of } from 'rxjs';
import { DURION_SDK_CONFIG } from './transport.token';
const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
let DurionTransportInterceptor = class DurionTransportInterceptor {
    config;
    constructor(ctorConfig) {
        // Support both classical constructor injection and `inject()`-based resolution
        // (used by tests that build the interceptor with `Injector.create` and `deps: []`).
        if (ctorConfig) {
            this.config = ctorConfig;
        }
        else {
            let resolved;
            try {
                resolved = inject(DURION_SDK_CONFIG, { optional: true });
            }
            catch {
                resolved = undefined;
            }
            this.config = resolved ?? undefined;
        }
    }
    intercept(req, next) {
        const config = this.config;
        const tokenSource$ = config?.token
            ? from(Promise.resolve(config.token()))
            : of(undefined);
        return tokenSource$.pipe(switchMap((token) => {
            const setHeaders = {};
            if (token) {
                setHeaders['Authorization'] = `Bearer ${token}`;
            }
            setHeaders['X-API-Version'] = config?.apiVersion ?? '1';
            setHeaders['X-Correlation-Id'] = config?.correlationIdProvider?.() ?? cryptoRandomUUID();
            const method = req.method.toUpperCase();
            if (MUTATING_METHODS.has(method)) {
                const callerKey = req.headers.get('Idempotency-Key');
                if (callerKey) {
                    // Caller-provided header wins; nothing to set (already on the request).
                }
                else if (config?.idempotencyKeyGenerator) {
                    setHeaders['Idempotency-Key'] = config.idempotencyKeyGenerator(method, req.url);
                }
            }
            const updated = req.clone({ setHeaders });
            return next.handle(updated);
        }));
    }
};
DurionTransportInterceptor = __decorate([
    Injectable(),
    __param(0, Optional()),
    __param(0, Inject(DURION_SDK_CONFIG)),
    __metadata("design:paramtypes", [Object])
], DurionTransportInterceptor);
export { DurionTransportInterceptor };
function cryptoRandomUUID() {
    const c = typeof crypto === 'undefined' ? undefined : crypto;
    if (c?.randomUUID) {
        return c.randomUUID();
    }
    // Fallback: RFC4122-ish v4 string for environments without crypto.randomUUID.
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replaceAll(/[xy]/g, (ch) => {
        const r = Math.trunc(Math.random() * 16);
        const v = ch === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}
