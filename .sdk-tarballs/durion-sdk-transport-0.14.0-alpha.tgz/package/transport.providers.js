import { makeEnvironmentProviders } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { DURION_SDK_CONFIG } from './transport.token';
import { DurionTransportInterceptor } from './transport.interceptor';
export function provideDurionTransport(config) {
    return makeEnvironmentProviders([
        { provide: DURION_SDK_CONFIG, useValue: config },
        DurionTransportInterceptor,
        {
            provide: HTTP_INTERCEPTORS,
            useExisting: DurionTransportInterceptor,
            multi: true,
        },
    ]);
}
