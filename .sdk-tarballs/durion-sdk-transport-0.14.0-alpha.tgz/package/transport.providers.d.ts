import { EnvironmentProviders } from '@angular/core';
import { DurionSdkConfig } from './config';
export declare function provideDurionTransport(config: DurionSdkConfig): EnvironmentProviders;
