import { EnvironmentProviders, InjectionToken } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DurionSdkConfig } from './config';
export declare const DURION_SDK_CONFIG: InjectionToken<DurionSdkConfig>;
/**
 * HTTP interceptor that applies Durion cross-cutting concerns:
 * - Authorization Bearer token (resolved per request)
 * - X-API-Version header
 * - X-Correlation-Id header
 * - Idempotency-Key header for mutating methods
 */
export declare class DurionTransportInterceptor implements HttpInterceptor {
    private readonly config;
    intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
    private resolveHeaders;
}
/**
 * Register the Durion transport interceptor and config in an Angular application.
 * Use alongside `provideHttpClient()` and each SDK package's `provideApi(baseUrl)`.
 */
export declare function provideDurionTransport(config: DurionSdkConfig): EnvironmentProviders;
