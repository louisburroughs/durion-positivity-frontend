import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DurionSdkConfig } from './config';
export declare class DurionTransportInterceptor implements HttpInterceptor {
    private readonly config;
    constructor(ctorConfig?: DurionSdkConfig | null);
    intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
}
