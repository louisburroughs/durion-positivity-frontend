export * from '../../models/staffingAssignmentBulkIngestRecord';
