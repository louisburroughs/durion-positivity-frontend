export * from '../../models/primaryLocationResponse';
