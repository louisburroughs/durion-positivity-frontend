export * from '../../models/conflictDetails';
