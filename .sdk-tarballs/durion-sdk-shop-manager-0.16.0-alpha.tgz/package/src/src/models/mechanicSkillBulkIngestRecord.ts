export * from '../../models/mechanicSkillBulkIngestRecord';
