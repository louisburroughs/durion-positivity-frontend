import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/tenant';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PlatformAccountAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    addAccountContact(id, accountContactRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling addAccountContact.');
        }
        if (accountContactRequest === null || accountContactRequest === undefined) {
            throw new Error('Required parameter accountContactRequest was null or undefined when calling addAccountContact.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: accountContactRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createAccount(accountCreateRequest, observe = 'body', reportProgress = false, options) {
        if (accountCreateRequest === null || accountCreateRequest === undefined) {
            throw new Error('Required parameter accountCreateRequest was null or undefined when calling createAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: accountCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAccount(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listAccounts(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    putAccountBillingProfile(id, billingProfileRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling putAccountBillingProfile.');
        }
        if (billingProfileRequest === null || billingProfileRequest === undefined) {
            throw new Error('Required parameter billingProfileRequest was null or undefined when calling putAccountBillingProfile.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/billing-profile`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: billingProfileRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    removeAccountContact(id, contactId, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling removeAccountContact.');
        }
        if (contactId === null || contactId === undefined) {
            throw new Error('Required parameter contactId was null or undefined when calling removeAccountContact.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts/${this.configuration.encodeParam({ name: "contactId", value: contactId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateAccount(id, accountUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateAccount.');
        }
        if (accountUpdateRequest === null || accountUpdateRequest === undefined) {
            throw new Error('Required parameter accountUpdateRequest was null or undefined when calling updateAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('patch', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: accountUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateAccountContact(id, contactId, accountContactRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateAccountContact.');
        }
        if (contactId === null || contactId === undefined) {
            throw new Error('Required parameter contactId was null or undefined when calling updateAccountContact.');
        }
        if (accountContactRequest === null || accountContactRequest === undefined) {
            throw new Error('Required parameter accountContactRequest was null or undefined when calling updateAccountContact.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/accounts/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/contacts/${this.configuration.encodeParam({ name: "contactId", value: contactId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: accountContactRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformAccountAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformAccountAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformAccountAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PlatformTenantAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createTenant(tenantCreateRequest, observe = 'body', reportProgress = false, options) {
        if (tenantCreateRequest === null || tenantCreateRequest === undefined) {
            throw new Error('Required parameter tenantCreateRequest was null or undefined when calling createTenant.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: tenantCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    decommissionTenant(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling decommissionTenant.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/decommission`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTenant(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getTenant.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTenants(status, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    reactivateTenant(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling reactivateTenant.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reactivate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    suspendTenant(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling suspendTenant.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/suspend`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateTenant(id, tenantUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateTenant.');
        }
        if (tenantUpdateRequest === null || tenantUpdateRequest === undefined) {
            throw new Error('Required parameter tenantUpdateRequest was null or undefined when calling updateTenant.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('patch', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: tenantUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformTenantAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformTenantAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformTenantAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AccountContactRequestRoleEnum;
(function (AccountContactRequestRoleEnum) {
    AccountContactRequestRoleEnum["Owner"] = "OWNER";
    AccountContactRequestRoleEnum["Billing"] = "BILLING";
    AccountContactRequestRoleEnum["Technical"] = "TECHNICAL";
})(AccountContactRequestRoleEnum || (AccountContactRequestRoleEnum = {}));
;
function isOptionalAccountContactRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountContactRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountContactRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountContactRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountContactRequestPropertyNames('email', 'name', 'role');
    const optionalStringProperties = createAccountContactRequestOptionalProperties({ name: 'email', nullable: false }, { name: 'name', nullable: false }, { name: 'phone', nullable: false }, { name: 'role', nullable: false });
    const optionalNumberProperties = createAccountContactRequestOptionalProperties();
    const optionalBooleanProperties = createAccountContactRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountContactRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountContactRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountContactRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AccountContactResponseRoleEnum;
(function (AccountContactResponseRoleEnum) {
    AccountContactResponseRoleEnum["Owner"] = "OWNER";
    AccountContactResponseRoleEnum["Billing"] = "BILLING";
    AccountContactResponseRoleEnum["Technical"] = "TECHNICAL";
})(AccountContactResponseRoleEnum || (AccountContactResponseRoleEnum = {}));
;
function isOptionalAccountContactResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountContactResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountContactResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountContactResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountContactResponsePropertyNames('accountId', 'createdAt', 'email', 'id', 'name', 'role', 'updatedAt');
    const optionalStringProperties = createAccountContactResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'email', nullable: false }, { name: 'id', nullable: false }, { name: 'name', nullable: false }, { name: 'phone', nullable: false }, { name: 'role', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createAccountContactResponseOptionalProperties();
    const optionalBooleanProperties = createAccountContactResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountContactResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountContactResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountContactResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAccountCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountCreateRequestPropertyNames('homeCountry', 'homeCurrency', 'legalName');
    const optionalStringProperties = createAccountCreateRequestOptionalProperties({ name: 'homeCountry', nullable: false }, { name: 'homeCurrency', nullable: false }, { name: 'legalName', nullable: false }, { name: 'taxId', nullable: false }, { name: 'tradingName', nullable: false });
    const optionalNumberProperties = createAccountCreateRequestOptionalProperties();
    const optionalBooleanProperties = createAccountCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var AccountResponseStatusEnum;
(function (AccountResponseStatusEnum) {
    AccountResponseStatusEnum["Active"] = "ACTIVE";
    AccountResponseStatusEnum["Suspended"] = "SUSPENDED";
    AccountResponseStatusEnum["Closed"] = "CLOSED";
})(AccountResponseStatusEnum || (AccountResponseStatusEnum = {}));
;
function isOptionalAccountResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountResponsePropertyNames('contacts', 'createdAt', 'homeCountry', 'homeCurrency', 'id', 'legalName', 'status', 'tenantIds', 'updatedAt');
    const optionalStringProperties = createAccountResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'homeCountry', nullable: false }, { name: 'homeCurrency', nullable: false }, { name: 'id', nullable: false }, { name: 'legalName', nullable: false }, { name: 'status', nullable: false }, { name: 'taxId', nullable: false }, { name: 'tradingName', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createAccountResponseOptionalProperties();
    const optionalBooleanProperties = createAccountResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AccountUpdateRequestStatusEnum;
(function (AccountUpdateRequestStatusEnum) {
    AccountUpdateRequestStatusEnum["Active"] = "ACTIVE";
    AccountUpdateRequestStatusEnum["Suspended"] = "SUSPENDED";
    AccountUpdateRequestStatusEnum["Closed"] = "CLOSED";
})(AccountUpdateRequestStatusEnum || (AccountUpdateRequestStatusEnum = {}));
;
function isOptionalAccountUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountUpdateRequestPropertyNames();
    const optionalStringProperties = createAccountUpdateRequestOptionalProperties({ name: 'homeCountry', nullable: false }, { name: 'homeCurrency', nullable: false }, { name: 'legalName', nullable: false }, { name: 'status', nullable: false }, { name: 'taxId', nullable: false }, { name: 'tradingName', nullable: false });
    const optionalNumberProperties = createAccountUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createAccountUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBillingProfileRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingProfileRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingProfileRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingProfileRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingProfileRequestPropertyNames('addressLine1', 'city', 'country', 'invoicingEmail', 'paymentTerms');
    const optionalStringProperties = createBillingProfileRequestOptionalProperties({ name: 'addressLine1', nullable: false }, { name: 'addressLine2', nullable: false }, { name: 'city', nullable: false }, { name: 'country', nullable: false }, { name: 'invoicingEmail', nullable: false }, { name: 'paymentProcessorCustomerToken', nullable: false }, { name: 'paymentTerms', nullable: false }, { name: 'postalCode', nullable: false }, { name: 'region', nullable: false });
    const optionalNumberProperties = createBillingProfileRequestOptionalProperties();
    const optionalBooleanProperties = createBillingProfileRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingProfileRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingProfileRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingProfileRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBillingProfileResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBillingProfileResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBillingProfileResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBillingProfileResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBillingProfileResponsePropertyNames('accountId', 'addressLine1', 'city', 'country', 'createdAt', 'id', 'invoicingEmail', 'paymentProcessorCustomerTokenPresent', 'paymentTerms', 'updatedAt');
    const optionalStringProperties = createBillingProfileResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'addressLine1', nullable: false }, { name: 'addressLine2', nullable: false }, { name: 'city', nullable: false }, { name: 'country', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'id', nullable: false }, { name: 'invoicingEmail', nullable: false }, { name: 'paymentTerms', nullable: false }, { name: 'postalCode', nullable: false }, { name: 'region', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createBillingProfileResponseOptionalProperties();
    const optionalBooleanProperties = createBillingProfileResponseOptionalProperties({ name: 'paymentProcessorCustomerTokenPresent', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBillingProfileResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBillingProfileResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBillingProfileResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalConflictPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConflictPropertyNames(...propertyNames) {
    return propertyNames;
}
function createConflictOptionalProperties(...properties) {
    return properties;
}
function instanceOfConflict(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConflictPropertyNames('code', 'message', 'overridable', 'severity');
    const optionalStringProperties = createConflictOptionalProperties({ name: 'affectedResource', nullable: false }, { name: 'code', nullable: false }, { name: 'message', nullable: false }, { name: 'severity', nullable: false });
    const optionalNumberProperties = createConflictOptionalProperties();
    const optionalBooleanProperties = createConflictOptionalProperties({ name: 'overridable', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConflictPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConflictPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConflictPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSuggestedAlternativePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSuggestedAlternativePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSuggestedAlternativeOptionalProperties(...properties) {
    return properties;
}
function instanceOfSuggestedAlternative(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSuggestedAlternativePropertyNames('endDateTime', 'startDateTime');
    const optionalStringProperties = createSuggestedAlternativeOptionalProperties({ name: 'endDateTime', nullable: false }, { name: 'reason', nullable: false }, { name: 'startDateTime', nullable: false });
    const optionalNumberProperties = createSuggestedAlternativeOptionalProperties();
    const optionalBooleanProperties = createSuggestedAlternativeOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSuggestedAlternativePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSuggestedAlternativePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSuggestedAlternativePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTenantCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTenantCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTenantCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTenantCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTenantCreateRequestPropertyNames('accountId', 'initialAdminEmail', 'slug');
    const optionalStringProperties = createTenantCreateRequestOptionalProperties({ name: 'accountId', nullable: false }, { name: 'cell', nullable: false }, { name: 'displayName', nullable: false }, { name: 'initialAdminEmail', nullable: false }, { name: 'slug', nullable: false });
    const optionalNumberProperties = createTenantCreateRequestOptionalProperties();
    const optionalBooleanProperties = createTenantCreateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTenantCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTenantCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTenantCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TenantResponseStatusEnum;
(function (TenantResponseStatusEnum) {
    TenantResponseStatusEnum["Pending"] = "PENDING";
    TenantResponseStatusEnum["Active"] = "ACTIVE";
    TenantResponseStatusEnum["Suspended"] = "SUSPENDED";
    TenantResponseStatusEnum["Decommissioned"] = "DECOMMISSIONED";
})(TenantResponseStatusEnum || (TenantResponseStatusEnum = {}));
;
function isOptionalTenantResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTenantResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTenantResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTenantResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTenantResponsePropertyNames('accountId', 'createdAt', 'displayName', 'id', 'initialAdminEmail', 'slug', 'status', 'updatedAt');
    const optionalStringProperties = createTenantResponseOptionalProperties({ name: 'accountId', nullable: false }, { name: 'activatedAt', nullable: false }, { name: 'cell', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'decommissionedAt', nullable: false }, { name: 'displayName', nullable: false }, { name: 'id', nullable: false }, { name: 'initialAdminEmail', nullable: false }, { name: 'slug', nullable: false }, { name: 'status', nullable: false }, { name: 'suspendedAt', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createTenantResponseOptionalProperties();
    const optionalBooleanProperties = createTenantResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTenantResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTenantResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTenantResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Tenant API
 *
 * Contact: platform@durionpos.org
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTenantUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTenantUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTenantUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTenantUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTenantUpdateRequestPropertyNames();
    const optionalStringProperties = createTenantUpdateRequestOptionalProperties({ name: 'cell', nullable: false }, { name: 'displayName', nullable: false });
    const optionalNumberProperties = createTenantUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createTenantUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTenantUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTenantUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTenantUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AccountContactRequestRoleEnum, AccountContactResponseRoleEnum, AccountResponseStatusEnum, AccountUpdateRequestStatusEnum, ApiModule, BASE_PATH, COLLECTION_FORMATS, Configuration, PlatformAccountAPIService, PlatformTenantAPIService, TenantResponseStatusEnum, instanceOfAccountContactRequest, instanceOfAccountContactResponse, instanceOfAccountCreateRequest, instanceOfAccountResponse, instanceOfAccountUpdateRequest, instanceOfApiError, instanceOfBillingProfileRequest, instanceOfBillingProfileResponse, instanceOfConflict, instanceOfFieldError, instanceOfSuggestedAlternative, instanceOfTenantCreateRequest, instanceOfTenantResponse, instanceOfTenantUpdateRequest, provideApi };
//# sourceMappingURL=durion-sdk-tenant.mjs.map
