export * from '../../models/customerBulkIngestRecord';
