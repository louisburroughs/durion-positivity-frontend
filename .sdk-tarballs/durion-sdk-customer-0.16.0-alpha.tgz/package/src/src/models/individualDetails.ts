export * from '../../models/individualDetails';
