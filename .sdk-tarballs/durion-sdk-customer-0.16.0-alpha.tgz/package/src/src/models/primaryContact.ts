export * from '../../models/primaryContact';
