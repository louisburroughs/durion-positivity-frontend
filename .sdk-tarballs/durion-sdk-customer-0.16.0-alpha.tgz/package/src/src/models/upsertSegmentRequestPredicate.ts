export * from '../../models/upsertSegmentRequestPredicate';
