export * from '../../models/segmentResponse';
