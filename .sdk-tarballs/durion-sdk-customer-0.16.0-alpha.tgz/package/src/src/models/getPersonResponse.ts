export * from '../../models/getPersonResponse';
