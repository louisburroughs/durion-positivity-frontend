export * from '../../models/segmentResolutionResponse';
