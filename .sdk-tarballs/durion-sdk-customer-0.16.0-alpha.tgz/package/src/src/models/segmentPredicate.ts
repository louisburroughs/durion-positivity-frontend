export * from '../../models/segmentPredicate';
