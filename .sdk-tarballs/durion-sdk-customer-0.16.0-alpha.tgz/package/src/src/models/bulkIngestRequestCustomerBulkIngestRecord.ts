export * from '../../models/bulkIngestRequestCustomerBulkIngestRecord';
