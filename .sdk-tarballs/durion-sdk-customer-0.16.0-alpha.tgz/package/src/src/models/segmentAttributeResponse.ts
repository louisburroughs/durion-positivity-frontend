export * from '../../models/segmentAttributeResponse';
