export * from '../../models/commercialBulkIngestRecord';
