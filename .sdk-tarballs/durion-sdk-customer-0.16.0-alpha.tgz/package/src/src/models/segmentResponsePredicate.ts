export * from '../../models/segmentResponsePredicate';
