export * from '../../models/assignedRole';
