export * from '../../models/inquiryResponse';
