export * from '../../models/marketingConsentDecision';
