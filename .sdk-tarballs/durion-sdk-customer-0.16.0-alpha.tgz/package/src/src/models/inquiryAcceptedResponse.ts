export * from '../../models/inquiryAcceptedResponse';
