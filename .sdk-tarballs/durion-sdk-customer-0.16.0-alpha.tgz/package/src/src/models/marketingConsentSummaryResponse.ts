export * from '../../models/marketingConsentSummaryResponse';
