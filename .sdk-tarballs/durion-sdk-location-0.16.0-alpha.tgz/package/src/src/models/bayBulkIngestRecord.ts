export * from '../../models/bayBulkIngestRecord';
