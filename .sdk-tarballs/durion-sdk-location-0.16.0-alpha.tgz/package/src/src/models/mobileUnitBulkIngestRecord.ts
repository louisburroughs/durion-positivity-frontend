export * from '../../models/mobileUnitBulkIngestRecord';
