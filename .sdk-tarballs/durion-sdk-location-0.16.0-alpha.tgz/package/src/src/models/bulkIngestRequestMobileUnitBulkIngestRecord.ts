export * from '../../models/bulkIngestRequestMobileUnitBulkIngestRecord';
