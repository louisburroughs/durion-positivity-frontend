export * from '../../models/postalCodeEntry';
