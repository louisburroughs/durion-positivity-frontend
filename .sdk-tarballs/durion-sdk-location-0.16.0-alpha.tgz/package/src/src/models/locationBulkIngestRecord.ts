export * from '../../models/locationBulkIngestRecord';
