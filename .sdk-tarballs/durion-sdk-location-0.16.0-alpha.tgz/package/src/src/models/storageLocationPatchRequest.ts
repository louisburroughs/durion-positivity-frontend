export * from '../../models/storageLocationPatchRequest';
