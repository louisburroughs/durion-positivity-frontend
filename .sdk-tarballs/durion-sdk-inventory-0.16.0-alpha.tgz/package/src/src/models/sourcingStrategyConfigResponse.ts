export * from '../../models/sourcingStrategyConfigResponse';
