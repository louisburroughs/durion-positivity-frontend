export * from '../../models/revaluationResponse';
