export * from '../../models/scrapResponse';
