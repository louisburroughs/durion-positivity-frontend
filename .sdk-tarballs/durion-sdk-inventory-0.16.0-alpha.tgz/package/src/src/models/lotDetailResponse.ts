export * from '../../models/lotDetailResponse';
