export * from '../../models/putawayRuleBulkIngestRecord';
