export * from '../../models/promoteAllocationRequest';
