export * from '../../models/deactivateLocationResponse';
