export * from '../../models/consumptionResponse';
