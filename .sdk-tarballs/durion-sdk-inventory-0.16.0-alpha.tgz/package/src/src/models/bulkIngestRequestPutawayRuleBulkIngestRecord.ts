export * from '../../models/bulkIngestRequestPutawayRuleBulkIngestRecord';
