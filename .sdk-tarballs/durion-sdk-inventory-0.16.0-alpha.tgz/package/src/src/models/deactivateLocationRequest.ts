export * from '../../models/deactivateLocationRequest';
