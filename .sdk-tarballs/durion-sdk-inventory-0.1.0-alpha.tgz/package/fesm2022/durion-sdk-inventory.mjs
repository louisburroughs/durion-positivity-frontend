import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/inventory';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ASNService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createAsn(createAsnRequest, observe = 'body', reportProgress = false, options) {
        if (createAsnRequest === null || createAsnRequest === undefined) {
            throw new Error('Required parameter createAsnRequest was null or undefined when calling createAsn.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/asns`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createAsnRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createGoodsReceipt(createGoodsReceiptRequest, observe = 'body', reportProgress = false, options) {
        if (createGoodsReceiptRequest === null || createGoodsReceiptRequest === undefined) {
            throw new Error('Required parameter createGoodsReceiptRequest was null or undefined when calling createGoodsReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/goods-receipts`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createGoodsReceiptRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAsn(asnId, observe = 'body', reportProgress = false, options) {
        if (asnId === null || asnId === undefined) {
            throw new Error('Required parameter asnId was null or undefined when calling getAsn.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/asns/${this.configuration.encodeParam({ name: "asnId", value: asnId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getGoodsReceipt(receiptId, observe = 'body', reportProgress = false, options) {
        if (receiptId === null || receiptId === undefined) {
            throw new Error('Required parameter receiptId was null or undefined when calling getGoodsReceipt.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/goods-receipts/${this.configuration.encodeParam({ name: "receiptId", value: receiptId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ASNService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ASNService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ASNService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class BackordersService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getBackorder(backorderId, observe = 'body', reportProgress = false, options) {
        if (backorderId === null || backorderId === undefined) {
            throw new Error('Required parameter backorderId was null or undefined when calling getBackorder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/backorders/${this.configuration.encodeParam({ name: "backorderId", value: backorderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listBackorders(status, sku, locationId, workorderLineId, salesOrderLineId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderLineId', workorderLineId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'salesOrderLineId', salesOrderLineId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/backorders`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BackordersService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BackordersService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BackordersService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ConsumptionService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    consumePickedItems(consumeItemsRequest, observe = 'body', reportProgress = false, options) {
        if (consumeItemsRequest === null || consumeItemsRequest === undefined) {
            throw new Error('Required parameter consumeItemsRequest was null or undefined when calling consumePickedItems.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/consumption`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: consumeItemsRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ConsumptionService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ConsumptionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ConsumptionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getCycleCountTask(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling getCycleCountTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/task/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountAuditorTasks(auditorId, observe = 'body', reportProgress = false, options) {
        if (auditorId === null || auditorId === undefined) {
            throw new Error('Required parameter auditorId was null or undefined when calling listCycleCountAuditorTasks.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/auditor/${this.configuration.encodeParam({ name: "auditorId", value: auditorId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/tasks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountHistory(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling listCycleCountHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/task/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/history`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountInterferingMovements(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling listCycleCountInterferingMovements.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/task/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/interfering-movements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitCycleCount(submitCountRequest, observe = 'body', reportProgress = false, options) {
        if (submitCountRequest === null || submitCountRequest === undefined) {
            throw new Error('Required parameter submitCountRequest was null or undefined when calling submitCycleCount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/submit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitCountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitCycleCountRecount(submitRecountRequest, observe = 'body', reportProgress = false, options) {
        if (submitRecountRequest === null || submitRecountRequest === undefined) {
            throw new Error('Required parameter submitRecountRequest was null or undefined when calling submitCycleCountRecount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/recount`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitRecountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountAdjustmentsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveCycleCountAdjustment(adjustmentId, approveAdjustmentRequest, xCorrelationId, observe = 'body', reportProgress = false, options) {
        if (adjustmentId === null || adjustmentId === undefined) {
            throw new Error('Required parameter adjustmentId was null or undefined when calling approveCycleCountAdjustment.');
        }
        if (approveAdjustmentRequest === null || approveAdjustmentRequest === undefined) {
            throw new Error('Required parameter approveAdjustmentRequest was null or undefined when calling approveCycleCountAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments/${this.configuration.encodeParam({ name: "adjustmentId", value: adjustmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approveAdjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    countPendingCycleCountAdjustments(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments/pending/count`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createCycleCountAdjustment(createAdjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (createAdjustmentRequest === null || createAdjustmentRequest === undefined) {
            throw new Error('Required parameter createAdjustmentRequest was null or undefined when calling createCycleCountAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createAdjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCycleCountAdjustment(adjustmentId, observe = 'body', reportProgress = false, options) {
        if (adjustmentId === null || adjustmentId === undefined) {
            throw new Error('Required parameter adjustmentId was null or undefined when calling getCycleCountAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments/${this.configuration.encodeParam({ name: "adjustmentId", value: adjustmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountAdjustments(status, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPendingCycleCountAdjustments(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments/pending`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectCycleCountAdjustment(adjustmentId, rejectAdjustmentRequest, observe = 'body', reportProgress = false, options) {
        if (adjustmentId === null || adjustmentId === undefined) {
            throw new Error('Required parameter adjustmentId was null or undefined when calling rejectCycleCountAdjustment.');
        }
        if (rejectAdjustmentRequest === null || rejectAdjustmentRequest === undefined) {
            throw new Error('Required parameter rejectAdjustmentRequest was null or undefined when calling rejectCycleCountAdjustment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountAdjustments/${this.configuration.encodeParam({ name: "adjustmentId", value: adjustmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rejectAdjustmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountAdjustmentsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountAdjustmentsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountAdjustmentsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountOperationsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    submitCycleCount(submitCountRequest, observe = 'body', reportProgress = false, options) {
        if (submitCountRequest === null || submitCountRequest === undefined) {
            throw new Error('Required parameter submitCountRequest was null or undefined when calling submitCycleCount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/submit`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitCountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitCycleCountRecount(submitRecountRequest, observe = 'body', reportProgress = false, options) {
        if (submitRecountRequest === null || submitRecountRequest === undefined) {
            throw new Error('Required parameter submitRecountRequest was null or undefined when calling submitCycleCountRecount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/recount`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: submitRecountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountOperationsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountOperationsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountOperationsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountPlansService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCycleCountPlan(createCycleCountPlanRequest, observe = 'body', reportProgress = false, options) {
        if (createCycleCountPlanRequest === null || createCycleCountPlanRequest === undefined) {
            throw new Error('Required parameter createCycleCountPlanRequest was null or undefined when calling createCycleCountPlan.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountPlans`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createCycleCountPlanRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCycleCountPlan(planId, observe = 'body', reportProgress = false, options) {
        if (planId === null || planId === undefined) {
            throw new Error('Required parameter planId was null or undefined when calling getCycleCountPlan.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountPlans/${this.configuration.encodeParam({ name: "planId", value: planId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountPlans(locationId, status, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountPlans`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCycleCountPlanStatus(planId, updateCycleCountPlanStatusRequest, observe = 'body', reportProgress = false, options) {
        if (planId === null || planId === undefined) {
            throw new Error('Required parameter planId was null or undefined when calling updateCycleCountPlanStatus.');
        }
        if (updateCycleCountPlanStatusRequest === null || updateCycleCountPlanStatusRequest === undefined) {
            throw new Error('Required parameter updateCycleCountPlanStatusRequest was null or undefined when calling updateCycleCountPlanStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountPlans/${this.configuration.encodeParam({ name: "planId", value: planId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/status`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateCycleCountPlanStatusRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountPlansService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountPlansService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountPlansService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountQueryService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getCycleCountTask(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling getCycleCountTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/task/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountAuditorTasks(auditorId, observe = 'body', reportProgress = false, options) {
        if (auditorId === null || auditorId === undefined) {
            throw new Error('Required parameter auditorId was null or undefined when calling listCycleCountAuditorTasks.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/auditor/${this.configuration.encodeParam({ name: "auditorId", value: auditorId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/tasks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountHistory(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling listCycleCountHistory.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/task/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/history`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountInterferingMovements(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling listCycleCountInterferingMovements.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCount/task/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/interfering-movements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountQueryService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountQueryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountQueryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountSchedulesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCycleCountSchedule(createCycleCountScheduleRequest, observe = 'body', reportProgress = false, options) {
        if (createCycleCountScheduleRequest === null || createCycleCountScheduleRequest === undefined) {
            throw new Error('Required parameter createCycleCountScheduleRequest was null or undefined when calling createCycleCountSchedule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountSchedules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createCycleCountScheduleRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deactivateCycleCountSchedule(scheduleId, observe = 'body', reportProgress = false, options) {
        if (scheduleId === null || scheduleId === undefined) {
            throw new Error('Required parameter scheduleId was null or undefined when calling deactivateCycleCountSchedule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountSchedules/${this.configuration.encodeParam({ name: "scheduleId", value: scheduleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCycleCountSchedule(scheduleId, observe = 'body', reportProgress = false, options) {
        if (scheduleId === null || scheduleId === undefined) {
            throw new Error('Required parameter scheduleId was null or undefined when calling getCycleCountSchedule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountSchedules/${this.configuration.encodeParam({ name: "scheduleId", value: scheduleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountSchedules(locationId, active, due, page, size, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'active', active, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'due', due, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountSchedules`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCycleCountSchedule(scheduleId, updateCycleCountScheduleRequest, observe = 'body', reportProgress = false, options) {
        if (scheduleId === null || scheduleId === undefined) {
            throw new Error('Required parameter scheduleId was null or undefined when calling updateCycleCountSchedule.');
        }
        if (updateCycleCountScheduleRequest === null || updateCycleCountScheduleRequest === undefined) {
            throw new Error('Required parameter updateCycleCountScheduleRequest was null or undefined when calling updateCycleCountSchedule.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountSchedules/${this.configuration.encodeParam({ name: "scheduleId", value: scheduleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateCycleCountScheduleRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountSchedulesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountSchedulesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountSchedulesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class CycleCountTolerancesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createCycleCountTolerance(createCycleCountToleranceRequest, observe = 'body', reportProgress = false, options) {
        if (createCycleCountToleranceRequest === null || createCycleCountToleranceRequest === undefined) {
            throw new Error('Required parameter createCycleCountToleranceRequest was null or undefined when calling createCycleCountTolerance.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountTolerances`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createCycleCountToleranceRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteCycleCountTolerance(toleranceId, observe = 'body', reportProgress = false, options) {
        if (toleranceId === null || toleranceId === undefined) {
            throw new Error('Required parameter toleranceId was null or undefined when calling deleteCycleCountTolerance.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountTolerances/${this.configuration.encodeParam({ name: "toleranceId", value: toleranceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getCycleCountTolerance(toleranceId, observe = 'body', reportProgress = false, options) {
        if (toleranceId === null || toleranceId === undefined) {
            throw new Error('Required parameter toleranceId was null or undefined when calling getCycleCountTolerance.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountTolerances/${this.configuration.encodeParam({ name: "toleranceId", value: toleranceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listCycleCountTolerances(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountTolerances`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateCycleCountTolerance(toleranceId, updateCycleCountToleranceRequest, observe = 'body', reportProgress = false, options) {
        if (toleranceId === null || toleranceId === undefined) {
            throw new Error('Required parameter toleranceId was null or undefined when calling updateCycleCountTolerance.');
        }
        if (updateCycleCountToleranceRequest === null || updateCycleCountToleranceRequest === undefined) {
            throw new Error('Required parameter updateCycleCountToleranceRequest was null or undefined when calling updateCycleCountTolerance.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/cycleCountTolerances/${this.configuration.encodeParam({ name: "toleranceId", value: toleranceId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateCycleCountToleranceRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountTolerancesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountTolerancesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CycleCountTolerancesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryAvailabilityService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getAvailabilityByProduct(productId, horizon, asOf, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getAvailabilityByProduct.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'horizon', horizon, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/availability/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAvailabilityBySku(productSku, locationId, storageLocationId, sourceType, horizon, observe = 'body', reportProgress = false, options) {
        if (productSku === null || productSku === undefined) {
            throw new Error('Required parameter productSku was null or undefined when calling getAvailabilityBySku.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productSku', productSku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'storageLocationId', storageLocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceType', sourceType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'horizon', horizon, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/availability/by-sku`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getInventoryLeadTime(productId, locationId, storageLocationId, sourceType, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling getInventoryLeadTime.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productId', productId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'storageLocationId', storageLocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceType', sourceType, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/availability/lead-time`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listAvailabilityBySku(sku, locationId, storageLocationId, sourceType, horizon, observe = 'body', reportProgress = false, options) {
        if (sku === null || sku === undefined) {
            throw new Error('Required parameter sku was null or undefined when calling listAvailabilityBySku.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'storageLocationId', storageLocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceType', sourceType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'horizon', horizon, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/availability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateInventoryAvailability(productId, body, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling updateInventoryAvailability.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/availability/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryAvailabilityService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryAvailabilityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryAvailabilityService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestInventoryAdjustments(bulkIngestRequestInventoryBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestInventoryBulkIngestRecord === null || bulkIngestRequestInventoryBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestInventoryBulkIngestRecord was null or undefined when calling bulkIngestInventoryAdjustments.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestInventoryBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryLedgerService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getInventoryLedgerEntry(entryId, observe = 'body', reportProgress = false, options) {
        if (entryId === null || entryId === undefined) {
            throw new Error('Required parameter entryId was null or undefined when calling getInventoryLedgerEntry.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/ledger/${this.configuration.encodeParam({ name: "entryId", value: entryId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listInventoryLedger(productSku, locationId, storageLocationId, dateFrom, dateTo, sourceTransactionId, workorderId, workorderLineId, movementTypes, pageToken, pageSize, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productSku', productSku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'storageLocationId', storageLocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateFrom', dateFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'dateTo', dateTo, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceTransactionId', sourceTransactionId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderId', workorderId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderLineId', workorderLineId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'movementTypes', movementTypes, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageToken', pageToken, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageSize', pageSize, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/ledger`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryLedgerService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryLedgerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryLedgerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryLocationsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getLocationInventory(locationId, sku, asOf, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getLocationInventory.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/locations/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/inventory-inquiry`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listLocationInventoryItems(locationId, asOf, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling listLocationInventoryItems.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/locations/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/inventory-items`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryLocationsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryLocationsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryLocationsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryManagementService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    deactivateInventoryLocation(locationId, deactivateLocationRequest, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling deactivateInventoryLocation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/locations/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/deactivate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: deactivateLocationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryManagementService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryManagementService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryManagementService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryReferenceDataService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listInventoryLocationZones(locationId, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/location-zones`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listInventoryLocations(siteId, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'siteId', siteId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/locations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listInventoryStorageLocations(locationId, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/storage-locations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listStorageTypes(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/meta/storage-types`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryReferenceDataService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryReferenceDataService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryReferenceDataService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryReservationsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    cancelReservation(workorderLineId, observe = 'body', reportProgress = false, options) {
        if (workorderLineId === null || workorderLineId === undefined) {
            throw new Error('Required parameter workorderLineId was null or undefined when calling cancelReservation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/reservations/${this.configuration.encodeParam({ name: "workorderLineId", value: workorderLineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    cancelReservationForSalesOrderLine(salesOrderLineId, observe = 'body', reportProgress = false, options) {
        if (salesOrderLineId === null || salesOrderLineId === undefined) {
            throw new Error('Required parameter salesOrderLineId was null or undefined when calling cancelReservationForSalesOrderLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/reservations/sales-order-line/${this.configuration.encodeParam({ name: "salesOrderLineId", value: salesOrderLineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createOrUpdateReservation(createReservationRequest, observe = 'body', reportProgress = false, options) {
        if (createReservationRequest === null || createReservationRequest === undefined) {
            throw new Error('Required parameter createReservationRequest was null or undefined when calling createOrUpdateReservation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/reservations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createReservationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    promoteReservationAllocation(allocationId, promoteAllocationRequest, observe = 'body', reportProgress = false, options) {
        if (allocationId === null || allocationId === undefined) {
            throw new Error('Required parameter allocationId was null or undefined when calling promoteReservationAllocation.');
        }
        if (promoteAllocationRequest === null || promoteAllocationRequest === undefined) {
            throw new Error('Required parameter promoteAllocationRequest was null or undefined when calling promoteReservationAllocation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/reservations/${this.configuration.encodeParam({ name: "allocationId", value: allocationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/promote`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: promoteAllocationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryReservationsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryReservationsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryReservationsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryRevaluationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveRevaluation(revaluationId, observe = 'body', reportProgress = false, options) {
        if (revaluationId === null || revaluationId === undefined) {
            throw new Error('Required parameter revaluationId was null or undefined when calling approveRevaluation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/revaluations/${this.configuration.encodeParam({ name: "revaluationId", value: revaluationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createRevaluation(createRevaluationRequest, observe = 'body', reportProgress = false, options) {
        if (createRevaluationRequest === null || createRevaluationRequest === undefined) {
            throw new Error('Required parameter createRevaluationRequest was null or undefined when calling createRevaluation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/revaluations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createRevaluationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRevaluation(revaluationId, observe = 'body', reportProgress = false, options) {
        if (revaluationId === null || revaluationId === undefined) {
            throw new Error('Required parameter revaluationId was null or undefined when calling getRevaluation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/revaluations/${this.configuration.encodeParam({ name: "revaluationId", value: revaluationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listRevaluations(stockItemId, status, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'stockItemId', stockItemId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/revaluations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectRevaluation(revaluationId, rejectRevaluationRequest, observe = 'body', reportProgress = false, options) {
        if (revaluationId === null || revaluationId === undefined) {
            throw new Error('Required parameter revaluationId was null or undefined when calling rejectRevaluation.');
        }
        if (rejectRevaluationRequest === null || rejectRevaluationRequest === undefined) {
            throw new Error('Required parameter rejectRevaluationRequest was null or undefined when calling rejectRevaluation.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/revaluations/${this.configuration.encodeParam({ name: "revaluationId", value: revaluationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rejectRevaluationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryRevaluationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryRevaluationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryRevaluationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryRollupService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getLocationInventoryRollup(locationId, parentType, sku, expand, depth, includeEmpty, observe = 'body', reportProgress = false, options) {
        if (locationId === null || locationId === undefined) {
            throw new Error('Required parameter locationId was null or undefined when calling getLocationInventoryRollup.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'parentType', parentType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'expand', expand, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'depth', depth, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeEmpty', includeEmpty, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/locations/${this.configuration.encodeParam({ name: "locationId", value: locationId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/inventory-rollup`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getSiteInventoryRollup(siteId, sku, depth, includeEmpty, observe = 'body', reportProgress = false, options) {
        if (siteId === null || siteId === undefined) {
            throw new Error('Required parameter siteId was null or undefined when calling getSiteInventoryRollup.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'depth', depth, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeEmpty', includeEmpty, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sites/${this.configuration.encodeParam({ name: "siteId", value: siteId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/inventory-rollup`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryRollupService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryRollupService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryRollupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventorySitesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSiteDefaultLocations(siteId, observe = 'body', reportProgress = false, options) {
        if (siteId === null || siteId === undefined) {
            throw new Error('Required parameter siteId was null or undefined when calling getSiteDefaultLocations.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sites/${this.configuration.encodeParam({ name: "siteId", value: siteId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/defaultLocations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateSiteDefaultLocations(siteId, requestBody, observe = 'body', reportProgress = false, options) {
        if (siteId === null || siteId === undefined) {
            throw new Error('Required parameter siteId was null or undefined when calling updateSiteDefaultLocations.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sites/${this.configuration.encodeParam({ name: "siteId", value: siteId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/defaultLocations`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: requestBody,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventorySitesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventorySitesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventorySitesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class InventoryValuationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getInventoryValuation(locationId, sku, asOf, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'asOf', asOf, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryValuationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryValuationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InventoryValuationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LocationSyncService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSyncLog(syncLogId, observe = 'body', reportProgress = false, options) {
        if (syncLogId === null || syncLogId === undefined) {
            throw new Error('Required parameter syncLogId was null or undefined when calling getSyncLog.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sync-logs/${this.configuration.encodeParam({ name: "syncLogId", value: syncLogId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSyncLogs(outcome, page, size, pageIndex, pageSize, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'outcome', outcome, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageIndex', pageIndex, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageSize', pageSize, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sync-logs`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    triggerLocationSync(idempotencyKey, xCorrelationId, observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        if (idempotencyKey !== undefined && idempotencyKey !== null) {
            localVarHeaders = localVarHeaders.set('Idempotency-Key', String(idempotencyKey));
        }
        if (xCorrelationId !== undefined && xCorrelationId !== null) {
            localVarHeaders = localVarHeaders.set('X-Correlation-Id', String(xCorrelationId));
        }
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/locations/sync`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LocationSyncService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LocationSyncService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LocationSyncService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class LotsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getInventoryLot(lotId, observe = 'body', reportProgress = false, options) {
        if (lotId === null || lotId === undefined) {
            throw new Error('Required parameter lotId was null or undefined when calling getInventoryLot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/lots/${this.configuration.encodeParam({ name: "lotId", value: lotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listInventoryLots(stockItemId, status, lotNumber, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'stockItemId', stockItemId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'lotNumber', lotNumber, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/lots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateInventoryLotExpiration(lotId, lotExpirationUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (lotId === null || lotId === undefined) {
            throw new Error('Required parameter lotId was null or undefined when calling updateInventoryLotExpiration.');
        }
        if (lotExpirationUpdateRequest === null || lotExpirationUpdateRequest === undefined) {
            throw new Error('Required parameter lotExpirationUpdateRequest was null or undefined when calling updateInventoryLotExpiration.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/lots/${this.configuration.encodeParam({ name: "lotId", value: lotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/expiration`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: lotExpirationUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateInventoryLotStatus(lotId, lotStatusUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (lotId === null || lotId === undefined) {
            throw new Error('Required parameter lotId was null or undefined when calling updateInventoryLotStatus.');
        }
        if (lotStatusUpdateRequest === null || lotStatusUpdateRequest === undefined) {
            throw new Error('Required parameter lotStatusUpdateRequest was null or undefined when calling updateInventoryLotStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/lots/${this.configuration.encodeParam({ name: "lotId", value: lotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/status`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: lotStatusUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LotsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LotsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: LotsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PickListsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    cancelPickList(pickListId, observe = 'body', reportProgress = false, options) {
        if (pickListId === null || pickListId === undefined) {
            throw new Error('Required parameter pickListId was null or undefined when calling cancelPickList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists/${this.configuration.encodeParam({ name: "pickListId", value: pickListId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    confirmPickTask(pickListId, taskId, confirmPickTaskRequest, observe = 'body', reportProgress = false, options) {
        if (pickListId === null || pickListId === undefined) {
            throw new Error('Required parameter pickListId was null or undefined when calling confirmPickTask.');
        }
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling confirmPickTask.');
        }
        if (confirmPickTaskRequest === null || confirmPickTaskRequest === undefined) {
            throw new Error('Required parameter confirmPickTaskRequest was null or undefined when calling confirmPickTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists/${this.configuration.encodeParam({ name: "pickListId", value: pickListId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tasks/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/confirm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: confirmPickTaskRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createPickList(createPickListRequest, observe = 'body', reportProgress = false, options) {
        if (createPickListRequest === null || createPickListRequest === undefined) {
            throw new Error('Required parameter createPickListRequest was null or undefined when calling createPickList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createPickListRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPickList(pickListId, observe = 'body', reportProgress = false, options) {
        if (pickListId === null || pickListId === undefined) {
            throw new Error('Required parameter pickListId was null or undefined when calling getPickList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists/${this.configuration.encodeParam({ name: "pickListId", value: pickListId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPickListsForWorkorder(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling listPickListsForWorkorder.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderId', workorderId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPickTasksForPickList(pickListId, observe = 'body', reportProgress = false, options) {
        if (pickListId === null || pickListId === undefined) {
            throw new Error('Required parameter pickListId was null or undefined when calling listPickTasksForPickList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists/${this.configuration.encodeParam({ name: "pickListId", value: pickListId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/tasks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    releasePickList(pickListId, observe = 'body', reportProgress = false, options) {
        if (pickListId === null || pickListId === undefined) {
            throw new Error('Required parameter pickListId was null or undefined when calling releasePickList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists/${this.configuration.encodeParam({ name: "pickListId", value: pickListId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/release`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updatePickListStatus(pickListId, updatePickListStatusRequest, observe = 'body', reportProgress = false, options) {
        if (pickListId === null || pickListId === undefined) {
            throw new Error('Required parameter pickListId was null or undefined when calling updatePickListStatus.');
        }
        if (updatePickListStatusRequest === null || updatePickListStatusRequest === undefined) {
            throw new Error('Required parameter updatePickListStatusRequest was null or undefined when calling updatePickListStatus.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pick-lists/${this.configuration.encodeParam({ name: "pickListId", value: pickListId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/status`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('patch', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updatePickListStatusRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PickListsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PickListsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PickListsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PickingListsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    confirmPickingList(id, body, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling confirmPickingList.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/pickingLists/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/confirm`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PickingListsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PickingListsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PickingListsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PurchaseSuggestionsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    acceptPurchaseSuggestion(suggestionId, observe = 'body', reportProgress = false, options) {
        if (suggestionId === null || suggestionId === undefined) {
            throw new Error('Required parameter suggestionId was null or undefined when calling acceptPurchaseSuggestion.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/purchase-suggestions/${this.configuration.encodeParam({ name: "suggestionId", value: suggestionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/accept`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    convertPurchaseSuggestions(convertPurchaseSuggestionsRequest, observe = 'body', reportProgress = false, options) {
        if (convertPurchaseSuggestionsRequest === null || convertPurchaseSuggestionsRequest === undefined) {
            throw new Error('Required parameter convertPurchaseSuggestionsRequest was null or undefined when calling convertPurchaseSuggestions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/purchase-suggestions/convert`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: convertPurchaseSuggestionsRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    dismissPurchaseSuggestion(suggestionId, dismissPurchaseSuggestionRequest, observe = 'body', reportProgress = false, options) {
        if (suggestionId === null || suggestionId === undefined) {
            throw new Error('Required parameter suggestionId was null or undefined when calling dismissPurchaseSuggestion.');
        }
        if (dismissPurchaseSuggestionRequest === null || dismissPurchaseSuggestionRequest === undefined) {
            throw new Error('Required parameter dismissPurchaseSuggestionRequest was null or undefined when calling dismissPurchaseSuggestion.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/purchase-suggestions/${this.configuration.encodeParam({ name: "suggestionId", value: suggestionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/dismiss`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: dismissPurchaseSuggestionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPurchaseSuggestion(suggestionId, observe = 'body', reportProgress = false, options) {
        if (suggestionId === null || suggestionId === undefined) {
            throw new Error('Required parameter suggestionId was null or undefined when calling getPurchaseSuggestion.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/purchase-suggestions/${this.configuration.encodeParam({ name: "suggestionId", value: suggestionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPurchaseSuggestions(status, sku, locationId, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/purchase-suggestions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PurchaseSuggestionsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PurchaseSuggestionsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PurchaseSuggestionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PutawayService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    claimPutawayTask(taskId, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling claimPutawayTask.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/putaway/tasks/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/claim`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    generatePutawayTasks(generatePutawayTasksRequest, observe = 'body', reportProgress = false, options) {
        if (generatePutawayTasksRequest === null || generatePutawayTasksRequest === undefined) {
            throw new Error('Required parameter generatePutawayTasksRequest was null or undefined when calling generatePutawayTasks.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/putaway/tasks/generate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: generatePutawayTasksRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPutawayTasks(locationId, storageLocationId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'storageLocationId', storageLocationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/putaway/tasks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PutawayService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PutawayService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PutawayService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PutawayExecutionService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    executePutaway(taskId, putawayExecutionRequest, observe = 'body', reportProgress = false, options) {
        if (taskId === null || taskId === undefined) {
            throw new Error('Required parameter taskId was null or undefined when calling executePutaway.');
        }
        if (putawayExecutionRequest === null || putawayExecutionRequest === undefined) {
            throw new Error('Required parameter putawayExecutionRequest was null or undefined when calling executePutaway.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/putaway/tasks/${this.configuration.encodeParam({ name: "taskId", value: taskId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/execute`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: putawayExecutionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PutawayExecutionService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PutawayExecutionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PutawayExecutionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ReallocationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    reallocateAllocations(reallocateRequest, observe = 'body', reportProgress = false, options) {
        if (reallocateRequest === null || reallocateRequest === undefined) {
            throw new Error('Required parameter reallocateRequest was null or undefined when calling reallocateAllocations.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/allocations/reallocate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: reallocateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReallocationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReallocationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReallocationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ReceivingService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createReceivingSession(createReceivingSessionRequest, observe = 'body', reportProgress = false, options) {
        if (createReceivingSessionRequest === null || createReceivingSessionRequest === undefined) {
            throw new Error('Required parameter createReceivingSessionRequest was null or undefined when calling createReceivingSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/receiving/sessions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createReceivingSessionRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    crossDockReceivingLine(sessionId, lineId, crossDockRequest, observe = 'body', reportProgress = false, options) {
        if (sessionId === null || sessionId === undefined) {
            throw new Error('Required parameter sessionId was null or undefined when calling crossDockReceivingLine.');
        }
        if (lineId === null || lineId === undefined) {
            throw new Error('Required parameter lineId was null or undefined when calling crossDockReceivingLine.');
        }
        if (crossDockRequest === null || crossDockRequest === undefined) {
            throw new Error('Required parameter crossDockRequest was null or undefined when calling crossDockReceivingLine.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/receiving/sessions/${this.configuration.encodeParam({ name: "sessionId", value: sessionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/lines/${this.configuration.encodeParam({ name: "lineId", value: lineId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/cross-dock`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: crossDockRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getReceivingSession(sessionId, observe = 'body', reportProgress = false, options) {
        if (sessionId === null || sessionId === undefined) {
            throw new Error('Required parameter sessionId was null or undefined when calling getReceivingSession.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/receiving/sessions/${this.configuration.encodeParam({ name: "sessionId", value: sessionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    receiveItemsIntoStaging(sessionId, receiveItemsRequest, observe = 'body', reportProgress = false, options) {
        if (sessionId === null || sessionId === undefined) {
            throw new Error('Required parameter sessionId was null or undefined when calling receiveItemsIntoStaging.');
        }
        if (receiveItemsRequest === null || receiveItemsRequest === undefined) {
            throw new Error('Required parameter receiveItemsRequest was null or undefined when calling receiveItemsIntoStaging.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/receiving/sessions/${this.configuration.encodeParam({ name: "sessionId", value: sessionId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receive`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: receiveItemsRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReceivingService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReceivingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReceivingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ReplenishmentService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createReplenishmentPolicy(createReplenishmentPolicyRequest, observe = 'body', reportProgress = false, options) {
        if (createReplenishmentPolicyRequest === null || createReplenishmentPolicyRequest === undefined) {
            throw new Error('Required parameter createReplenishmentPolicyRequest was null or undefined when calling createReplenishmentPolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/policies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createReplenishmentPolicyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReplenishmentNeeds(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/needs`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReplenishmentPolicies(locationId, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/policies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReplenishmentTasks(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/tasks`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    runReplenishmentScan(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/scan`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    snoozeReplenishmentPolicy(policyId, snoozeReplenishmentPolicyRequest, observe = 'body', reportProgress = false, options) {
        if (policyId === null || policyId === undefined) {
            throw new Error('Required parameter policyId was null or undefined when calling snoozeReplenishmentPolicy.');
        }
        if (snoozeReplenishmentPolicyRequest === null || snoozeReplenishmentPolicyRequest === undefined) {
            throw new Error('Required parameter snoozeReplenishmentPolicyRequest was null or undefined when calling snoozeReplenishmentPolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/policies/${this.configuration.encodeParam({ name: "policyId", value: policyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/snooze`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: snoozeReplenishmentPolicyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateReplenishmentPolicy(policyId, updateReplenishmentPolicyRequest, observe = 'body', reportProgress = false, options) {
        if (policyId === null || policyId === undefined) {
            throw new Error('Required parameter policyId was null or undefined when calling updateReplenishmentPolicy.');
        }
        if (updateReplenishmentPolicyRequest === null || updateReplenishmentPolicyRequest === undefined) {
            throw new Error('Required parameter updateReplenishmentPolicyRequest was null or undefined when calling updateReplenishmentPolicy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/replenishment/policies/${this.configuration.encodeParam({ name: "policyId", value: policyId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: updateReplenishmentPolicyRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReplenishmentService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReplenishmentService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReplenishmentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ReturnsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listReturnReasonCodes(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/returns/reason-codes`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listReturnableItems(workorderId, observe = 'body', reportProgress = false, options) {
        if (workorderId === null || workorderId === undefined) {
            throw new Error('Required parameter workorderId was null or undefined when calling listReturnableItems.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderId', workorderId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/returns/returnable-items`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    submitReturnToStock(returnSubmitRequest, observe = 'body', reportProgress = false, options) {
        if (returnSubmitRequest === null || returnSubmitRequest === undefined) {
            throw new Error('Required parameter returnSubmitRequest was null or undefined when calling submitReturnToStock.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/returns/submit-to-stock`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: returnSubmitRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReturnsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReturnsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReturnsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ScrapsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveScrap(scrapId, approveScrapRequest, observe = 'body', reportProgress = false, options) {
        if (scrapId === null || scrapId === undefined) {
            throw new Error('Required parameter scrapId was null or undefined when calling approveScrap.');
        }
        if (approveScrapRequest === null || approveScrapRequest === undefined) {
            throw new Error('Required parameter approveScrapRequest was null or undefined when calling approveScrap.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/scraps/${this.configuration.encodeParam({ name: "scrapId", value: scrapId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: approveScrapRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createScrap(createScrapRequest, observe = 'body', reportProgress = false, options) {
        if (createScrapRequest === null || createScrapRequest === undefined) {
            throw new Error('Required parameter createScrapRequest was null or undefined when calling createScrap.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/scraps`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createScrapRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getScrap(scrapId, observe = 'body', reportProgress = false, options) {
        if (scrapId === null || scrapId === undefined) {
            throw new Error('Required parameter scrapId was null or undefined when calling getScrap.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/scraps/${this.configuration.encodeParam({ name: "scrapId", value: scrapId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listScraps(reasonCode, status, locationId, createdFrom, createdTo, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'reasonCode', reasonCode, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'createdFrom', createdFrom, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'createdTo', createdTo, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/scraps`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectScrap(scrapId, rejectScrapRequest, observe = 'body', reportProgress = false, options) {
        if (scrapId === null || scrapId === undefined) {
            throw new Error('Required parameter scrapId was null or undefined when calling rejectScrap.');
        }
        if (rejectScrapRequest === null || rejectScrapRequest === undefined) {
            throw new Error('Required parameter rejectScrapRequest was null or undefined when calling rejectScrap.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/scraps/${this.configuration.encodeParam({ name: "scrapId", value: scrapId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/reject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rejectScrapRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ScrapsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ScrapsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ScrapsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SerialUnitsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSerialUnit(serialUnitId, observe = 'body', reportProgress = false, options) {
        if (serialUnitId === null || serialUnitId === undefined) {
            throw new Error('Required parameter serialUnitId was null or undefined when calling getSerialUnit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/serial-units/${this.configuration.encodeParam({ name: "serialUnitId", value: serialUnitId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSerialUnits(stockItemId, status, serialNumber, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'stockItemId', stockItemId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'serialNumber', serialNumber, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/serial-units`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SerialUnitsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SerialUnitsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SerialUnitsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ShortageResolutionService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listShortageOptions(allocationId, sku, shortQuantity, workorderLineId, locationId, observe = 'body', reportProgress = false, options) {
        if (allocationId === null || allocationId === undefined) {
            throw new Error('Required parameter allocationId was null or undefined when calling listShortageOptions.');
        }
        if (sku === null || sku === undefined) {
            throw new Error('Required parameter sku was null or undefined when calling listShortageOptions.');
        }
        if (shortQuantity === null || shortQuantity === undefined) {
            throw new Error('Required parameter shortQuantity was null or undefined when calling listShortageOptions.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'allocationId', allocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'shortQuantity', shortQuantity, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderLineId', workorderLineId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationId', locationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/shortage/options`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveShortage(shortageResolveRequest, observe = 'body', reportProgress = false, options) {
        if (shortageResolveRequest === null || shortageResolveRequest === undefined) {
            throw new Error('Required parameter shortageResolveRequest was null or undefined when calling resolveShortage.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/shortage/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: shortageResolveRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ShortageResolutionService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ShortageResolutionService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ShortageResolutionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SourcingStrategiesService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    deactivateSourcingStrategyConfig(configId, observe = 'body', reportProgress = false, options) {
        if (configId === null || configId === undefined) {
            throw new Error('Required parameter configId was null or undefined when calling deactivateSourcingStrategyConfig.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sourcing-strategies/${this.configuration.encodeParam({ name: "configId", value: configId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSourcingStrategyConfigs(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sourcing-strategies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertSourcingStrategyConfig(sourcingStrategyConfigRequest, observe = 'body', reportProgress = false, options) {
        if (sourcingStrategyConfigRequest === null || sourcingStrategyConfigRequest === undefined) {
            throw new Error('Required parameter sourcingStrategyConfigRequest was null or undefined when calling upsertSourcingStrategyConfig.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/sourcing-strategies`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: sourcingStrategyConfigRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SourcingStrategiesService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SourcingStrategiesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SourcingStrategiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class StockMovementsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveAdjustmentRequest(adjustmentRequestId, observe = 'body', reportProgress = false, options) {
        if (adjustmentRequestId === null || adjustmentRequestId === undefined) {
            throw new Error('Required parameter adjustmentRequestId was null or undefined when calling approveAdjustmentRequest.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/adjustments/${this.configuration.encodeParam({ name: "adjustmentRequestId", value: adjustmentRequestId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createAdjustmentRequest(createAdjustmentRequestDto, observe = 'body', reportProgress = false, options) {
        if (createAdjustmentRequestDto === null || createAdjustmentRequestDto === undefined) {
            throw new Error('Required parameter createAdjustmentRequestDto was null or undefined when calling createAdjustmentRequest.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/adjustments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createAdjustmentRequestDto,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createStockMovement(recordMovementRequest, observe = 'body', reportProgress = false, options) {
        if (recordMovementRequest === null || recordMovementRequest === undefined) {
            throw new Error('Required parameter recordMovementRequest was null or undefined when calling createStockMovement.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/stock-movements`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: recordMovementRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StockMovementsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StockMovementsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StockMovementsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SupplierStockHintsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listSupplierStockHintsByCode(identityKind, value, observe = 'body', reportProgress = false, options) {
        if (identityKind === null || identityKind === undefined) {
            throw new Error('Required parameter identityKind was null or undefined when calling listSupplierStockHintsByCode.');
        }
        if (value === null || value === undefined) {
            throw new Error('Required parameter value was null or undefined when calling listSupplierStockHintsByCode.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'identityKind', identityKind, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'value', value, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/supplierStockHints/byCode`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSupplierStockHintsByProduct(productId, observe = 'body', reportProgress = false, options) {
        if (productId === null || productId === undefined) {
            throw new Error('Required parameter productId was null or undefined when calling listSupplierStockHintsByProduct.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/supplierStockHints/byProduct/${this.configuration.encodeParam({ name: "productId", value: productId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockHintsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockHintsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SupplierStockHintsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TraceabilityService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    traceInventoryLot(lotId, observe = 'body', reportProgress = false, options) {
        if (lotId === null || lotId === undefined) {
            throw new Error('Required parameter lotId was null or undefined when calling traceInventoryLot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/lots/${this.configuration.encodeParam({ name: "lotId", value: lotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/traceability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    traceSerialUnit(serialUnitId, observe = 'body', reportProgress = false, options) {
        if (serialUnitId === null || serialUnitId === undefined) {
            throw new Error('Required parameter serialUnitId was null or undefined when calling traceSerialUnit.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/serial-units/${this.configuration.encodeParam({ name: "serialUnitId", value: serialUnitId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/traceability`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TraceabilityService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TraceabilityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TraceabilityService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TransferOrdersService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    approveTransferOrder(transferOrderId, observe = 'body', reportProgress = false, options) {
        if (transferOrderId === null || transferOrderId === undefined) {
            throw new Error('Required parameter transferOrderId was null or undefined when calling approveTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders/${this.configuration.encodeParam({ name: "transferOrderId", value: transferOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/approve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    cancelTransferOrder(transferOrderId, observe = 'body', reportProgress = false, options) {
        if (transferOrderId === null || transferOrderId === undefined) {
            throw new Error('Required parameter transferOrderId was null or undefined when calling cancelTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders/${this.configuration.encodeParam({ name: "transferOrderId", value: transferOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/cancel`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createTransferOrder(createTransferOrderRequest, observe = 'body', reportProgress = false, options) {
        if (createTransferOrderRequest === null || createTransferOrderRequest === undefined) {
            throw new Error('Required parameter createTransferOrderRequest was null or undefined when calling createTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createTransferOrderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    dispatchTransferOrder(transferOrderId, dispatchTransferOrderRequest, observe = 'body', reportProgress = false, options) {
        if (transferOrderId === null || transferOrderId === undefined) {
            throw new Error('Required parameter transferOrderId was null or undefined when calling dispatchTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders/${this.configuration.encodeParam({ name: "transferOrderId", value: transferOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/dispatch`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: dispatchTransferOrderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTransferOrder(transferOrderId, observe = 'body', reportProgress = false, options) {
        if (transferOrderId === null || transferOrderId === undefined) {
            throw new Error('Required parameter transferOrderId was null or undefined when calling getTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders/${this.configuration.encodeParam({ name: "transferOrderId", value: transferOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listTransferOrders(status, sourceLocationId, destinationLocationId, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sourceLocationId', sourceLocationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'destinationLocationId', destinationLocationId, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    receiveTransferOrder(transferOrderId, receiveTransferOrderRequest, observe = 'body', reportProgress = false, options) {
        if (transferOrderId === null || transferOrderId === undefined) {
            throw new Error('Required parameter transferOrderId was null or undefined when calling receiveTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders/${this.configuration.encodeParam({ name: "transferOrderId", value: transferOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/receive`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: receiveTransferOrderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    shortCloseTransferOrder(transferOrderId, shortCloseTransferOrderRequest, observe = 'body', reportProgress = false, options) {
        if (transferOrderId === null || transferOrderId === undefined) {
            throw new Error('Required parameter transferOrderId was null or undefined when calling shortCloseTransferOrder.');
        }
        if (shortCloseTransferOrderRequest === null || shortCloseTransferOrderRequest === undefined) {
            throw new Error('Required parameter shortCloseTransferOrderRequest was null or undefined when calling shortCloseTransferOrder.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/transfer-orders/${this.configuration.encodeParam({ name: "transferOrderId", value: transferOrderId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/short-close`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: shortCloseTransferOrderRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TransferOrdersService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TransferOrdersService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TransferOrdersService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class ValuationMethodsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    listCostingMethodConfigs(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/methods`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    upsertCostingMethodConfig(costingMethodConfigRequest, observe = 'body', reportProgress = false, options) {
        if (costingMethodConfigRequest === null || costingMethodConfigRequest === undefined) {
            throw new Error('Required parameter costingMethodConfigRequest was null or undefined when calling upsertCostingMethodConfig.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/inventory/valuation/methods`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: costingMethodConfigRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ValuationMethodsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ValuationMethodsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ValuationMethodsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAdjustmentRequestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAdjustmentRequestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAdjustmentRequestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAdjustmentRequestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAdjustmentRequestResponsePropertyNames('adjustmentRequestId', 'locationId', 'productSku', 'quantity', 'reasonCode', 'status');
    const optionalStringProperties = createAdjustmentRequestResponseOptionalProperties({ name: 'adjustmentRequestId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'productSku', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createAdjustmentRequestResponseOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createAdjustmentRequestResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAdjustmentRequestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAdjustmentRequestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAdjustmentRequestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AdjustmentResponseRequiredApprovalTierEnum;
(function (AdjustmentResponseRequiredApprovalTierEnum) {
    AdjustmentResponseRequiredApprovalTierEnum["Tier1Manager"] = "TIER_1_MANAGER";
    AdjustmentResponseRequiredApprovalTierEnum["Tier2Director"] = "TIER_2_DIRECTOR";
})(AdjustmentResponseRequiredApprovalTierEnum || (AdjustmentResponseRequiredApprovalTierEnum = {}));
;
var AdjustmentResponseStatusEnum;
(function (AdjustmentResponseStatusEnum) {
    AdjustmentResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    AdjustmentResponseStatusEnum["AutoApproved"] = "AUTO_APPROVED";
    AdjustmentResponseStatusEnum["Approved"] = "APPROVED";
    AdjustmentResponseStatusEnum["Posted"] = "POSTED";
    AdjustmentResponseStatusEnum["Rejected"] = "REJECTED";
    AdjustmentResponseStatusEnum["Failed"] = "FAILED";
})(AdjustmentResponseStatusEnum || (AdjustmentResponseStatusEnum = {}));
;
function isOptionalAdjustmentResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAdjustmentResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAdjustmentResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAdjustmentResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAdjustmentResponsePropertyNames('adjustmentId', 'costAtTimeOfAdjustment', 'countedQuantity', 'createdAt', 'createdByUserId', 'quantityChange', 'quantityOnHandBefore', 'reasonCode', 'status', 'stockItemId', 'updatedAt');
    const optionalStringProperties = createAdjustmentResponseOptionalProperties({ name: 'adjustmentId', nullable: false }, { name: 'approvedAt', nullable: false }, { name: 'approvedByUserId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdByUserId', nullable: false }, { name: 'errorMessage', nullable: false }, { name: 'ledgerEntryId', nullable: false }, { name: 'postedAt', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'rejectedAt', nullable: false }, { name: 'rejectedByUserId', nullable: false }, { name: 'rejectionReason', nullable: false }, { name: 'requiredApprovalTier', nullable: false }, { name: 'status', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'taskId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createAdjustmentResponseOptionalProperties({ name: 'costAtTimeOfAdjustment', nullable: false }, { name: 'countedQuantity', nullable: false }, { name: 'quantityChange', nullable: false }, { name: 'quantityOnHandBefore', nullable: false }, { name: 'variancePercentage', nullable: false }, { name: 'varianceValue', nullable: false });
    const optionalBooleanProperties = createAdjustmentResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAdjustmentResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAdjustmentResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAdjustmentResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalApproveAdjustmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApproveAdjustmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApproveAdjustmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfApproveAdjustmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApproveAdjustmentRequestPropertyNames();
    const optionalStringProperties = createApproveAdjustmentRequestOptionalProperties({ name: 'approverUserId', nullable: false }, { name: 'notes', nullable: false });
    const optionalNumberProperties = createApproveAdjustmentRequestOptionalProperties();
    const optionalBooleanProperties = createApproveAdjustmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApproveAdjustmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApproveAdjustmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApproveAdjustmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalApproveScrapRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApproveScrapRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApproveScrapRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfApproveScrapRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApproveScrapRequestPropertyNames();
    const optionalStringProperties = createApproveScrapRequestOptionalProperties();
    const optionalNumberProperties = createApproveScrapRequestOptionalProperties();
    const optionalBooleanProperties = createApproveScrapRequestOptionalProperties({ name: 'negativeStockOverride', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApproveScrapRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApproveScrapRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApproveScrapRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAsnLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAsnLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAsnLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAsnLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAsnLineResponsePropertyNames('asnLineId', 'poId', 'quantityShipped', 'sku');
    const optionalStringProperties = createAsnLineResponseOptionalProperties({ name: 'asnLineId', nullable: false }, { name: 'documentUom', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'poId', nullable: false }, { name: 'sku', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createAsnLineResponseOptionalProperties({ name: 'conversionFactor', nullable: false }, { name: 'documentQuantity', nullable: false }, { name: 'quantityReceived', nullable: false }, { name: 'quantityShipped', nullable: false });
    const optionalBooleanProperties = createAsnLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAsnLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAsnLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAsnLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var AsnResponseStatusEnum;
(function (AsnResponseStatusEnum) {
    AsnResponseStatusEnum["Loaded"] = "LOADED";
    AsnResponseStatusEnum["ReadyForReceipt"] = "READY_FOR_RECEIPT";
    AsnResponseStatusEnum["PartiallyReceived"] = "PARTIALLY_RECEIVED";
    AsnResponseStatusEnum["FullyReceived"] = "FULLY_RECEIVED";
    AsnResponseStatusEnum["Cancelled"] = "CANCELLED";
})(AsnResponseStatusEnum || (AsnResponseStatusEnum = {}));
;
function isOptionalAsnResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAsnResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAsnResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAsnResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAsnResponsePropertyNames('asnId', 'asnReferenceNumber', 'createdAt', 'status', 'vendorId');
    const optionalStringProperties = createAsnResponseOptionalProperties({ name: 'asnId', nullable: false }, { name: 'asnReferenceNumber', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'expectedArrivalDate', nullable: false }, { name: 'shipDate', nullable: false }, { name: 'status', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createAsnResponseOptionalProperties();
    const optionalBooleanProperties = createAsnResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAsnResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAsnResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAsnResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAvailabilityViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAvailabilityViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAvailabilityViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfAvailabilityView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAvailabilityViewPropertyNames('allocatedQuantity', 'availableToPromiseQuantity', 'locationId', 'onHandQuantity', 'productSku', 'unitOfMeasure');
    const optionalStringProperties = createAvailabilityViewOptionalProperties({ name: 'locationId', nullable: false }, { name: 'productSku', nullable: false }, { name: 'storageLocationId', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createAvailabilityViewOptionalProperties({ name: 'allocatedQuantity', nullable: false }, { name: 'availableToPromiseQuantity', nullable: false }, { name: 'incomingQty', nullable: false }, { name: 'onHandQuantity', nullable: false }, { name: 'outgoingQty', nullable: false }, { name: 'projectedAvailable', nullable: false });
    const optionalBooleanProperties = createAvailabilityViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAvailabilityViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAvailabilityViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAvailabilityViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var BackorderResponseResolutionSourceEnum;
(function (BackorderResponseResolutionSourceEnum) {
    BackorderResponseResolutionSourceEnum["Availability"] = "AVAILABILITY";
    BackorderResponseResolutionSourceEnum["ReplenishmentReceipt"] = "REPLENISHMENT_RECEIPT";
    BackorderResponseResolutionSourceEnum["Manual"] = "MANUAL";
})(BackorderResponseResolutionSourceEnum || (BackorderResponseResolutionSourceEnum = {}));
;
var BackorderResponseStatusEnum;
(function (BackorderResponseStatusEnum) {
    BackorderResponseStatusEnum["Open"] = "OPEN";
    BackorderResponseStatusEnum["Resolved"] = "RESOLVED";
    BackorderResponseStatusEnum["Cancelled"] = "CANCELLED";
})(BackorderResponseStatusEnum || (BackorderResponseStatusEnum = {}));
;
function isOptionalBackorderResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBackorderResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBackorderResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBackorderResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBackorderResponsePropertyNames();
    const optionalStringProperties = createBackorderResponseOptionalProperties({ name: 'backorderId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'locationId', nullable: false }, { name: 'resolutionSource', nullable: false }, { name: 'resolvedAt', nullable: false }, { name: 'salesOrderLineId', nullable: false }, { name: 'sku', nullable: false }, { name: 'status', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createBackorderResponseOptionalProperties({ name: 'quantityShort', nullable: false });
    const optionalBooleanProperties = createBackorderResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBackorderResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBackorderResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBackorderResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestInventoryBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestInventoryBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestInventoryBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestInventoryBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestInventoryBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestInventoryBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestInventoryBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestInventoryBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestInventoryBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestInventoryBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestInventoryBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResponsePropertyNames('failureCount', 'results', 'successCount', 'totalSubmitted');
    const optionalStringProperties = createBulkIngestResponseOptionalProperties();
    const optionalNumberProperties = createBulkIngestResponseOptionalProperties({ name: 'failureCount', nullable: false }, { name: 'successCount', nullable: false }, { name: 'totalSubmitted', nullable: false });
    const optionalBooleanProperties = createBulkIngestResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBulkIngestResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResultPropertyNames('rowIndex', 'success');
    const optionalStringProperties = createBulkIngestResultOptionalProperties({ name: 'entityId', nullable: false }, { name: 'errorCode', nullable: false }, { name: 'errorMessage', nullable: false });
    const optionalNumberProperties = createBulkIngestResultOptionalProperties({ name: 'rowIndex', nullable: false });
    const optionalBooleanProperties = createBulkIngestResultOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalConfirmPickTaskRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConfirmPickTaskRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createConfirmPickTaskRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfConfirmPickTaskRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConfirmPickTaskRequestPropertyNames('quantityPicked', 'scannedLocationId', 'scannedSkuId');
    const optionalStringProperties = createConfirmPickTaskRequestOptionalProperties({ name: 'lotNumber', nullable: false }, { name: 'scannedLocationId', nullable: false }, { name: 'scannedSkuId', nullable: false });
    const optionalNumberProperties = createConfirmPickTaskRequestOptionalProperties({ name: 'quantityPicked', nullable: false });
    const optionalBooleanProperties = createConfirmPickTaskRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConfirmPickTaskRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConfirmPickTaskRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConfirmPickTaskRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalConsumeItemLinePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConsumeItemLinePropertyNames(...propertyNames) {
    return propertyNames;
}
function createConsumeItemLineOptionalProperties(...properties) {
    return properties;
}
function instanceOfConsumeItemLine(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConsumeItemLinePropertyNames('pickTaskId', 'quantity', 'skuId');
    const optionalStringProperties = createConsumeItemLineOptionalProperties({ name: 'lotNumber', nullable: false }, { name: 'pickTaskId', nullable: false }, { name: 'skuId', nullable: false });
    const optionalNumberProperties = createConsumeItemLineOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createConsumeItemLineOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConsumeItemLinePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConsumeItemLinePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConsumeItemLinePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalConsumeItemsRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConsumeItemsRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createConsumeItemsRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfConsumeItemsRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConsumeItemsRequestPropertyNames('workorderId');
    const optionalStringProperties = createConsumeItemsRequestOptionalProperties({ name: 'pickListId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createConsumeItemsRequestOptionalProperties();
    const optionalBooleanProperties = createConsumeItemsRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConsumeItemsRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConsumeItemsRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConsumeItemsRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalConsumptionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConsumptionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createConsumptionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfConsumptionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConsumptionResponsePropertyNames('consumptionId', 'createdAt', 'totalItemsConsumed', 'workorderId');
    const optionalStringProperties = createConsumptionResponseOptionalProperties({ name: 'consumptionId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'pickListId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createConsumptionResponseOptionalProperties({ name: 'totalItemsConsumed', nullable: false });
    const optionalBooleanProperties = createConsumptionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConsumptionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConsumptionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConsumptionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalConvertPurchaseSuggestionsRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConvertPurchaseSuggestionsRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createConvertPurchaseSuggestionsRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfConvertPurchaseSuggestionsRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConvertPurchaseSuggestionsRequestPropertyNames('suggestionIds');
    const optionalStringProperties = createConvertPurchaseSuggestionsRequestOptionalProperties();
    const optionalNumberProperties = createConvertPurchaseSuggestionsRequestOptionalProperties();
    const optionalBooleanProperties = createConvertPurchaseSuggestionsRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConvertPurchaseSuggestionsRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConvertPurchaseSuggestionsRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConvertPurchaseSuggestionsRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalConvertPurchaseSuggestionsResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createConvertPurchaseSuggestionsResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createConvertPurchaseSuggestionsResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfConvertPurchaseSuggestionsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createConvertPurchaseSuggestionsResponsePropertyNames('convertedSuggestionIds', 'poNumber', 'purchaseOrderId', 'purchaseOrderStatus');
    const optionalStringProperties = createConvertPurchaseSuggestionsResponseOptionalProperties({ name: 'poNumber', nullable: false }, { name: 'purchaseOrderId', nullable: false }, { name: 'purchaseOrderStatus', nullable: false });
    const optionalNumberProperties = createConvertPurchaseSuggestionsResponseOptionalProperties();
    const optionalBooleanProperties = createConvertPurchaseSuggestionsResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalConvertPurchaseSuggestionsResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalConvertPurchaseSuggestionsResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalConvertPurchaseSuggestionsResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CostingMethodConfigRequestMethodEnum;
(function (CostingMethodConfigRequestMethodEnum) {
    CostingMethodConfigRequestMethodEnum["Standard"] = "STANDARD";
    CostingMethodConfigRequestMethodEnum["Average"] = "AVERAGE";
})(CostingMethodConfigRequestMethodEnum || (CostingMethodConfigRequestMethodEnum = {}));
;
var CostingMethodConfigRequestScopeTypeEnum;
(function (CostingMethodConfigRequestScopeTypeEnum) {
    CostingMethodConfigRequestScopeTypeEnum["Sku"] = "SKU";
    CostingMethodConfigRequestScopeTypeEnum["SkuCategory"] = "SKU_CATEGORY";
    CostingMethodConfigRequestScopeTypeEnum["Default"] = "DEFAULT";
})(CostingMethodConfigRequestScopeTypeEnum || (CostingMethodConfigRequestScopeTypeEnum = {}));
;
function isOptionalCostingMethodConfigRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCostingMethodConfigRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCostingMethodConfigRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCostingMethodConfigRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCostingMethodConfigRequestPropertyNames('method', 'scopeType');
    const optionalStringProperties = createCostingMethodConfigRequestOptionalProperties({ name: 'method', nullable: false }, { name: 'scopeType', nullable: false }, { name: 'scopeValue', nullable: false });
    const optionalNumberProperties = createCostingMethodConfigRequestOptionalProperties();
    const optionalBooleanProperties = createCostingMethodConfigRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCostingMethodConfigRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCostingMethodConfigRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCostingMethodConfigRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CostingMethodConfigResponseMethodEnum;
(function (CostingMethodConfigResponseMethodEnum) {
    CostingMethodConfigResponseMethodEnum["Standard"] = "STANDARD";
    CostingMethodConfigResponseMethodEnum["Average"] = "AVERAGE";
})(CostingMethodConfigResponseMethodEnum || (CostingMethodConfigResponseMethodEnum = {}));
;
var CostingMethodConfigResponseScopeTypeEnum;
(function (CostingMethodConfigResponseScopeTypeEnum) {
    CostingMethodConfigResponseScopeTypeEnum["Sku"] = "SKU";
    CostingMethodConfigResponseScopeTypeEnum["SkuCategory"] = "SKU_CATEGORY";
    CostingMethodConfigResponseScopeTypeEnum["Default"] = "DEFAULT";
})(CostingMethodConfigResponseScopeTypeEnum || (CostingMethodConfigResponseScopeTypeEnum = {}));
;
function isOptionalCostingMethodConfigResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCostingMethodConfigResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCostingMethodConfigResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCostingMethodConfigResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCostingMethodConfigResponsePropertyNames('active', 'configId', 'createdAt', 'method', 'scopeType', 'updatedAt');
    const optionalStringProperties = createCostingMethodConfigResponseOptionalProperties({ name: 'configId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'method', nullable: false }, { name: 'scopeType', nullable: false }, { name: 'scopeValue', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createCostingMethodConfigResponseOptionalProperties();
    const optionalBooleanProperties = createCostingMethodConfigResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCostingMethodConfigResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCostingMethodConfigResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCostingMethodConfigResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CountEntryResponseMeasurementMethodEnum;
(function (CountEntryResponseMeasurementMethodEnum) {
    CountEntryResponseMeasurementMethodEnum["ManualCount"] = "MANUAL_COUNT";
    CountEntryResponseMeasurementMethodEnum["Dip"] = "DIP";
    CountEntryResponseMeasurementMethodEnum["Gauge"] = "GAUGE";
    CountEntryResponseMeasurementMethodEnum["Scale"] = "SCALE";
    CountEntryResponseMeasurementMethodEnum["Meter"] = "METER";
    CountEntryResponseMeasurementMethodEnum["Sensor"] = "SENSOR";
})(CountEntryResponseMeasurementMethodEnum || (CountEntryResponseMeasurementMethodEnum = {}));
;
function isOptionalCountEntryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCountEntryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCountEntryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCountEntryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCountEntryResponsePropertyNames('actualQuantity', 'auditorId', 'countEntryId', 'countedAt', 'cycleCountTaskId', 'expectedQuantity', 'measuredQuantity', 'measurementMethod', 'recount', 'recountSequenceNumber', 'variance', 'variancePercentage', 'withinTolerance');
    const optionalStringProperties = createCountEntryResponseOptionalProperties({ name: 'auditorId', nullable: false }, { name: 'countEntryId', nullable: false }, { name: 'countedAt', nullable: false }, { name: 'cycleCountTaskId', nullable: false }, { name: 'measurementMethod', nullable: false }, { name: 'recountOfCountEntryId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'varianceReason', nullable: false });
    const optionalNumberProperties = createCountEntryResponseOptionalProperties({ name: 'actualQuantity', nullable: false }, { name: 'allowedToleranceAbsolute', nullable: false }, { name: 'allowedTolerancePercentage', nullable: false }, { name: 'expectedQuantity', nullable: false }, { name: 'measuredQuantity', nullable: false }, { name: 'recountSequenceNumber', nullable: false }, { name: 'variance', nullable: false }, { name: 'variancePercentage', nullable: false });
    const optionalBooleanProperties = createCountEntryResponseOptionalProperties({ name: 'recount', nullable: false }, { name: 'withinTolerance', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCountEntryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCountEntryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCountEntryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CountResponseTaskStatusEnum;
(function (CountResponseTaskStatusEnum) {
    CountResponseTaskStatusEnum["Assigned"] = "ASSIGNED";
    CountResponseTaskStatusEnum["CountedPendingReview"] = "COUNTED_PENDING_REVIEW";
    CountResponseTaskStatusEnum["Conflict"] = "CONFLICT";
    CountResponseTaskStatusEnum["RequiresInvestigation"] = "REQUIRES_INVESTIGATION";
    CountResponseTaskStatusEnum["AcceptedWithinTolerance"] = "ACCEPTED_WITHIN_TOLERANCE";
    CountResponseTaskStatusEnum["Approved"] = "APPROVED";
    CountResponseTaskStatusEnum["Rejected"] = "REJECTED";
})(CountResponseTaskStatusEnum || (CountResponseTaskStatusEnum = {}));
;
function isOptionalCountResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCountResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCountResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCountResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCountResponsePropertyNames('actualQuantity', 'countEntryId', 'countedAt', 'expectedQuantity', 'limitExceeded', 'recountSequenceNumber', 'taskId', 'taskStatus', 'variance', 'withinTolerance');
    const optionalStringProperties = createCountResponseOptionalProperties({ name: 'countEntryId', nullable: false }, { name: 'countedAt', nullable: false }, { name: 'message', nullable: false }, { name: 'taskId', nullable: false }, { name: 'taskStatus', nullable: false });
    const optionalNumberProperties = createCountResponseOptionalProperties({ name: 'actualQuantity', nullable: false }, { name: 'expectedQuantity', nullable: false }, { name: 'recountSequenceNumber', nullable: false }, { name: 'variance', nullable: false });
    const optionalBooleanProperties = createCountResponseOptionalProperties({ name: 'limitExceeded', nullable: false }, { name: 'withinTolerance', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCountResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCountResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCountResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateAdjustmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateAdjustmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateAdjustmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateAdjustmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateAdjustmentRequestPropertyNames('costAtTimeOfAdjustment', 'countedQuantity', 'createdByUserId', 'quantityOnHandBefore', 'reasonCode', 'stockItemId');
    const optionalStringProperties = createCreateAdjustmentRequestOptionalProperties({ name: 'createdByUserId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'taskId', nullable: false });
    const optionalNumberProperties = createCreateAdjustmentRequestOptionalProperties({ name: 'costAtTimeOfAdjustment', nullable: false }, { name: 'countedQuantity', nullable: false }, { name: 'quantityOnHandBefore', nullable: false });
    const optionalBooleanProperties = createCreateAdjustmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateAdjustmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateAdjustmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateAdjustmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateAdjustmentRequestDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateAdjustmentRequestDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateAdjustmentRequestDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateAdjustmentRequestDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateAdjustmentRequestDtoPropertyNames('locationId', 'productSku', 'quantity', 'reasonCode');
    const optionalStringProperties = createCreateAdjustmentRequestDtoOptionalProperties({ name: 'locationId', nullable: false }, { name: 'productSku', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createCreateAdjustmentRequestDtoOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createCreateAdjustmentRequestDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateAdjustmentRequestDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateAdjustmentRequestDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateAdjustmentRequestDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateAsnLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateAsnLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateAsnLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateAsnLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateAsnLineRequestPropertyNames('poId', 'sku');
    const optionalStringProperties = createCreateAsnLineRequestOptionalProperties({ name: 'documentUom', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'poId', nullable: false }, { name: 'poLineId', nullable: false }, { name: 'sku', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createCreateAsnLineRequestOptionalProperties({ name: 'documentQuantity', nullable: false }, { name: 'quantityShipped', nullable: false }, { name: 'unitCostMinor', nullable: false });
    const optionalBooleanProperties = createCreateAsnLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateAsnLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateAsnLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateAsnLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalCreateAsnRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateAsnRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateAsnRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateAsnRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateAsnRequestPropertyNames('asnReferenceNumber', 'lineItems', 'relatedPoIds', 'vendorId');
    const optionalStringProperties = createCreateAsnRequestOptionalProperties({ name: 'asnReferenceNumber', nullable: false }, { name: 'expectedArrivalDate', nullable: false }, { name: 'shipDate', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createCreateAsnRequestOptionalProperties();
    const optionalBooleanProperties = createCreateAsnRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateAsnRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateAsnRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateAsnRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateCycleCountPlanRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateCycleCountPlanRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateCycleCountPlanRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateCycleCountPlanRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateCycleCountPlanRequestPropertyNames('locationId', 'planName', 'scheduledDate');
    const optionalStringProperties = createCreateCycleCountPlanRequestOptionalProperties({ name: 'locationId', nullable: false }, { name: 'planName', nullable: false }, { name: 'scheduledDate', nullable: false });
    const optionalNumberProperties = createCreateCycleCountPlanRequestOptionalProperties();
    const optionalBooleanProperties = createCreateCycleCountPlanRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateCycleCountPlanRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateCycleCountPlanRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateCycleCountPlanRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateCycleCountScheduleRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateCycleCountScheduleRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateCycleCountScheduleRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateCycleCountScheduleRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateCycleCountScheduleRequestPropertyNames('frequencyDays', 'locationId', 'nextDueDate');
    const optionalStringProperties = createCreateCycleCountScheduleRequestOptionalProperties({ name: 'locationId', nullable: false }, { name: 'nextDueDate', nullable: false }, { name: 'skuCategory', nullable: false }, { name: 'zoneId', nullable: false });
    const optionalNumberProperties = createCreateCycleCountScheduleRequestOptionalProperties({ name: 'frequencyDays', nullable: false });
    const optionalBooleanProperties = createCreateCycleCountScheduleRequestOptionalProperties({ name: 'autoCreatePlan', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateCycleCountScheduleRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateCycleCountScheduleRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateCycleCountScheduleRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateCycleCountToleranceRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateCycleCountToleranceRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateCycleCountToleranceRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateCycleCountToleranceRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateCycleCountToleranceRequestPropertyNames('createdBy');
    const optionalStringProperties = createCreateCycleCountToleranceRequestOptionalProperties({ name: 'createdBy', nullable: false }, { name: 'productId', nullable: false }, { name: 'storageLocation', nullable: false });
    const optionalNumberProperties = createCreateCycleCountToleranceRequestOptionalProperties({ name: 'absoluteTolerance', nullable: false }, { name: 'percentageTolerance', nullable: false });
    const optionalBooleanProperties = createCreateCycleCountToleranceRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateCycleCountToleranceRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateCycleCountToleranceRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateCycleCountToleranceRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateGoodsReceiptLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateGoodsReceiptLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateGoodsReceiptLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateGoodsReceiptLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateGoodsReceiptLineRequestPropertyNames('sku', 'unitCostMinor');
    const optionalStringProperties = createCreateGoodsReceiptLineRequestOptionalProperties({ name: 'documentUom', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'poLineId', nullable: false }, { name: 'sku', nullable: false });
    const optionalNumberProperties = createCreateGoodsReceiptLineRequestOptionalProperties({ name: 'documentQuantity', nullable: false }, { name: 'quantityReceived', nullable: false }, { name: 'unitCostMinor', nullable: false });
    const optionalBooleanProperties = createCreateGoodsReceiptLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateGoodsReceiptLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateGoodsReceiptLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateGoodsReceiptLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalCreateGoodsReceiptRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateGoodsReceiptRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateGoodsReceiptRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateGoodsReceiptRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateGoodsReceiptRequestPropertyNames('lines', 'locationId', 'poId');
    const optionalStringProperties = createCreateGoodsReceiptRequestOptionalProperties({ name: 'asnId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'poId', nullable: false });
    const optionalNumberProperties = createCreateGoodsReceiptRequestOptionalProperties();
    const optionalBooleanProperties = createCreateGoodsReceiptRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateGoodsReceiptRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateGoodsReceiptRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateGoodsReceiptRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreatePickListRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreatePickListRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreatePickListRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreatePickListRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreatePickListRequestPropertyNames('workorderId');
    const optionalStringProperties = createCreatePickListRequestOptionalProperties({ name: 'dueAt', nullable: false }, { name: 'reservationId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createCreatePickListRequestOptionalProperties({ name: 'priority', nullable: false });
    const optionalBooleanProperties = createCreatePickListRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreatePickListRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreatePickListRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreatePickListRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateReceivingSessionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateReceivingSessionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateReceivingSessionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateReceivingSessionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateReceivingSessionRequestPropertyNames('sourceDocumentId');
    const optionalStringProperties = createCreateReceivingSessionRequestOptionalProperties({ name: 'entryMethod', nullable: false }, { name: 'sourceDocumentId', nullable: false });
    const optionalNumberProperties = createCreateReceivingSessionRequestOptionalProperties();
    const optionalBooleanProperties = createCreateReceivingSessionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateReceivingSessionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateReceivingSessionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateReceivingSessionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreateReplenishmentPolicyRequestPreferredSourceTypeEnum;
(function (CreateReplenishmentPolicyRequestPreferredSourceTypeEnum) {
    CreateReplenishmentPolicyRequestPreferredSourceTypeEnum["InternalTransfer"] = "INTERNAL_TRANSFER";
    CreateReplenishmentPolicyRequestPreferredSourceTypeEnum["Purchase"] = "PURCHASE";
    CreateReplenishmentPolicyRequestPreferredSourceTypeEnum["Either"] = "EITHER";
})(CreateReplenishmentPolicyRequestPreferredSourceTypeEnum || (CreateReplenishmentPolicyRequestPreferredSourceTypeEnum = {}));
;
function isOptionalCreateReplenishmentPolicyRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateReplenishmentPolicyRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateReplenishmentPolicyRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateReplenishmentPolicyRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateReplenishmentPolicyRequestPropertyNames('itemSKU', 'locationId', 'maximumQuantity', 'minimumQuantity');
    const optionalStringProperties = createCreateReplenishmentPolicyRequestOptionalProperties({ name: 'itemSKU', nullable: false }, { name: 'locationId', nullable: false }, { name: 'preferredSourceType', nullable: false });
    const optionalNumberProperties = createCreateReplenishmentPolicyRequestOptionalProperties({ name: 'leadTimeDaysOverride', nullable: false }, { name: 'maximumQuantity', nullable: false }, { name: 'minimumQuantity', nullable: false }, { name: 'orderMultiple', nullable: false });
    const optionalBooleanProperties = createCreateReplenishmentPolicyRequestOptionalProperties({ name: 'active', nullable: false }, { name: 'minimumLessThanMaximum', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateReservationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateReservationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateReservationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateReservationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateReservationRequestPropertyNames('requiredQuantity', 'stockItemId');
    const optionalStringProperties = createCreateReservationRequestOptionalProperties({ name: 'salesOrderLineId', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createCreateReservationRequestOptionalProperties({ name: 'requiredQuantity', nullable: false });
    const optionalBooleanProperties = createCreateReservationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateReservationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateReservationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateReservationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateRevaluationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateRevaluationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateRevaluationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateRevaluationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateRevaluationRequestPropertyNames('reason', 'stockItemId');
    const optionalStringProperties = createCreateRevaluationRequestOptionalProperties({ name: 'reason', nullable: false }, { name: 'stockItemId', nullable: false });
    const optionalNumberProperties = createCreateRevaluationRequestOptionalProperties({ name: 'costDelta', nullable: false }, { name: 'newUnitCost', nullable: false });
    const optionalBooleanProperties = createCreateRevaluationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateRevaluationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateRevaluationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateRevaluationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CreateScrapRequestReasonCodeEnum;
(function (CreateScrapRequestReasonCodeEnum) {
    CreateScrapRequestReasonCodeEnum["Damaged"] = "DAMAGED";
    CreateScrapRequestReasonCodeEnum["Expired"] = "EXPIRED";
    CreateScrapRequestReasonCodeEnum["Lost"] = "LOST";
    CreateScrapRequestReasonCodeEnum["Recalled"] = "RECALLED";
    CreateScrapRequestReasonCodeEnum["Contaminated"] = "CONTAMINATED";
    CreateScrapRequestReasonCodeEnum["WarrantyDestroyed"] = "WARRANTY_DESTROYED";
    CreateScrapRequestReasonCodeEnum["Other"] = "OTHER";
})(CreateScrapRequestReasonCodeEnum || (CreateScrapRequestReasonCodeEnum = {}));
;
function isOptionalCreateScrapRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateScrapRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateScrapRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateScrapRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateScrapRequestPropertyNames('locationId', 'quantity', 'reasonCode', 'stockItemId');
    const optionalStringProperties = createCreateScrapRequestOptionalProperties({ name: 'attachmentReference', nullable: false }, { name: 'locationId', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'notes', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'storageLocationId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createCreateScrapRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createCreateScrapRequestOptionalProperties({ name: 'negativeStockOverride', nullable: false }, { name: 'shouldReplenish', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateScrapRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateScrapRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateScrapRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalCreateTransferOrderRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateTransferOrderRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateTransferOrderRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateTransferOrderRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateTransferOrderRequestPropertyNames('destinationLocationId', 'lines', 'sourceLocationId');
    const optionalStringProperties = createCreateTransferOrderRequestOptionalProperties({ name: 'destinationLocationId', nullable: false }, { name: 'destinationStorageLocationId', nullable: false }, { name: 'notes', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'sourceStorageLocationId', nullable: false });
    const optionalNumberProperties = createCreateTransferOrderRequestOptionalProperties();
    const optionalBooleanProperties = createCreateTransferOrderRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateTransferOrderRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateTransferOrderRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateTransferOrderRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCrossDockRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCrossDockRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCrossDockRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCrossDockRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCrossDockRequestPropertyNames('quantity', 'workorderId', 'workorderLineId');
    const optionalStringProperties = createCrossDockRequestOptionalProperties({ name: 'lotNumber', nullable: false }, { name: 'notes', nullable: false }, { name: 'workorderId', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createCrossDockRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createCrossDockRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCrossDockRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCrossDockRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCrossDockRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCrossDockResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCrossDockResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCrossDockResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCrossDockResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCrossDockResponsePropertyNames('crossDockedQuantity', 'lineId', 'lineStatus', 'sessionStatus', 'workorderId', 'workorderLineId');
    const optionalStringProperties = createCrossDockResponseOptionalProperties({ name: 'lineId', nullable: false }, { name: 'lineStatus', nullable: false }, { name: 'sessionStatus', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'workorderId', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createCrossDockResponseOptionalProperties({ name: 'crossDockedQuantity', nullable: false });
    const optionalBooleanProperties = createCrossDockResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCrossDockResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCrossDockResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCrossDockResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCycleCountPlanResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCycleCountPlanResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCycleCountPlanResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCycleCountPlanResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCycleCountPlanResponsePropertyNames('createdAt', 'createdBy', 'locationId', 'planId', 'planName', 'scheduledDate', 'status', 'updatedAt');
    const optionalStringProperties = createCycleCountPlanResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'dueDate', nullable: false }, { name: 'locationId', nullable: false }, { name: 'planId', nullable: false }, { name: 'planName', nullable: false }, { name: 'scheduleId', nullable: false }, { name: 'scheduledDate', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createCycleCountPlanResponseOptionalProperties();
    const optionalBooleanProperties = createCycleCountPlanResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCycleCountPlanResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCycleCountPlanResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCycleCountPlanResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCycleCountScheduleResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCycleCountScheduleResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCycleCountScheduleResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCycleCountScheduleResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCycleCountScheduleResponsePropertyNames('active', 'autoCreatePlan', 'createdAt', 'createdBy', 'frequencyDays', 'locationId', 'nextDueDate', 'scheduleId', 'updatedAt');
    const optionalStringProperties = createCycleCountScheduleResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'locationId', nullable: false }, { name: 'nextDueDate', nullable: false }, { name: 'scheduleId', nullable: false }, { name: 'skuCategory', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'zoneId', nullable: false });
    const optionalNumberProperties = createCycleCountScheduleResponseOptionalProperties({ name: 'frequencyDays', nullable: false });
    const optionalBooleanProperties = createCycleCountScheduleResponseOptionalProperties({ name: 'active', nullable: false }, { name: 'autoCreatePlan', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCycleCountScheduleResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCycleCountScheduleResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCycleCountScheduleResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var CycleCountTaskResponseStatusEnum;
(function (CycleCountTaskResponseStatusEnum) {
    CycleCountTaskResponseStatusEnum["Assigned"] = "ASSIGNED";
    CycleCountTaskResponseStatusEnum["CountedPendingReview"] = "COUNTED_PENDING_REVIEW";
    CycleCountTaskResponseStatusEnum["Conflict"] = "CONFLICT";
    CycleCountTaskResponseStatusEnum["RequiresInvestigation"] = "REQUIRES_INVESTIGATION";
    CycleCountTaskResponseStatusEnum["AcceptedWithinTolerance"] = "ACCEPTED_WITHIN_TOLERANCE";
    CycleCountTaskResponseStatusEnum["Approved"] = "APPROVED";
    CycleCountTaskResponseStatusEnum["Rejected"] = "REJECTED";
})(CycleCountTaskResponseStatusEnum || (CycleCountTaskResponseStatusEnum = {}));
;
function isOptionalCycleCountTaskResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCycleCountTaskResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCycleCountTaskResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCycleCountTaskResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCycleCountTaskResponsePropertyNames('binLocation', 'countEntriesCount', 'createdAt', 'expectedQuantity', 'itemSku', 'status', 'taskId', 'updatedAt');
    const optionalStringProperties = createCycleCountTaskResponseOptionalProperties({ name: 'auditorId', nullable: false }, { name: 'binLocation', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'itemDescription', nullable: false }, { name: 'itemSku', nullable: false }, { name: 'latestCountEntryId', nullable: false }, { name: 'status', nullable: false }, { name: 'taskId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createCycleCountTaskResponseOptionalProperties({ name: 'countEntriesCount', nullable: false }, { name: 'expectedQuantity', nullable: false });
    const optionalBooleanProperties = createCycleCountTaskResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCycleCountTaskResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCycleCountTaskResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCycleCountTaskResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCycleCountToleranceResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCycleCountToleranceResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCycleCountToleranceResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCycleCountToleranceResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCycleCountToleranceResponsePropertyNames('active', 'createdAt', 'createdBy', 'toleranceId', 'updatedAt');
    const optionalStringProperties = createCycleCountToleranceResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'productId', nullable: false }, { name: 'storageLocation', nullable: false }, { name: 'toleranceId', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createCycleCountToleranceResponseOptionalProperties({ name: 'absoluteTolerance', nullable: false }, { name: 'percentageTolerance', nullable: false });
    const optionalBooleanProperties = createCycleCountToleranceResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCycleCountToleranceResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCycleCountToleranceResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCycleCountToleranceResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalDeactivateLocationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDeactivateLocationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDeactivateLocationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfDeactivateLocationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDeactivateLocationRequestPropertyNames();
    const optionalStringProperties = createDeactivateLocationRequestOptionalProperties({ name: 'destinationLocationId', nullable: false });
    const optionalNumberProperties = createDeactivateLocationRequestOptionalProperties();
    const optionalBooleanProperties = createDeactivateLocationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDeactivateLocationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDeactivateLocationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDeactivateLocationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalDeactivateLocationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDeactivateLocationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createDeactivateLocationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfDeactivateLocationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDeactivateLocationResponsePropertyNames('sourceLocationId', 'status');
    const optionalStringProperties = createDeactivateLocationResponseOptionalProperties({ name: 'destinationLocationId', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createDeactivateLocationResponseOptionalProperties();
    const optionalBooleanProperties = createDeactivateLocationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDeactivateLocationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDeactivateLocationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDeactivateLocationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalDismissPurchaseSuggestionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDismissPurchaseSuggestionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDismissPurchaseSuggestionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfDismissPurchaseSuggestionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDismissPurchaseSuggestionRequestPropertyNames('reason');
    const optionalStringProperties = createDismissPurchaseSuggestionRequestOptionalProperties({ name: 'reason', nullable: false });
    const optionalNumberProperties = createDismissPurchaseSuggestionRequestOptionalProperties();
    const optionalBooleanProperties = createDismissPurchaseSuggestionRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDismissPurchaseSuggestionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDismissPurchaseSuggestionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDismissPurchaseSuggestionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalDispatchTransferOrderRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createDispatchTransferOrderRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createDispatchTransferOrderRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfDispatchTransferOrderRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createDispatchTransferOrderRequestPropertyNames();
    const optionalStringProperties = createDispatchTransferOrderRequestOptionalProperties();
    const optionalNumberProperties = createDispatchTransferOrderRequestOptionalProperties();
    const optionalBooleanProperties = createDispatchTransferOrderRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalDispatchTransferOrderRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalDispatchTransferOrderRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalDispatchTransferOrderRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGeneratePutawayTasksRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGeneratePutawayTasksRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGeneratePutawayTasksRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfGeneratePutawayTasksRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGeneratePutawayTasksRequestPropertyNames('sourceReceiptId');
    const optionalStringProperties = createGeneratePutawayTasksRequestOptionalProperties({ name: 'productId', nullable: false }, { name: 'sourceReceiptId', nullable: false });
    const optionalNumberProperties = createGeneratePutawayTasksRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createGeneratePutawayTasksRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGeneratePutawayTasksRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGeneratePutawayTasksRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGeneratePutawayTasksRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGoodsReceiptLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGoodsReceiptLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGoodsReceiptLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGoodsReceiptLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGoodsReceiptLineResponsePropertyNames('quantityReceived', 'receiptLineId', 'sku');
    const optionalStringProperties = createGoodsReceiptLineResponseOptionalProperties({ name: 'documentUom', nullable: false }, { name: 'poLineId', nullable: false }, { name: 'receiptLineId', nullable: false }, { name: 'sku', nullable: false });
    const optionalNumberProperties = createGoodsReceiptLineResponseOptionalProperties({ name: 'conversionFactor', nullable: false }, { name: 'documentQuantity', nullable: false }, { name: 'lineAccruedAmountMinor', nullable: false }, { name: 'quantityReceived', nullable: false }, { name: 'unitCostMinor', nullable: false });
    const optionalBooleanProperties = createGoodsReceiptLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGoodsReceiptLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGoodsReceiptLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGoodsReceiptLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalGoodsReceiptResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGoodsReceiptResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createGoodsReceiptResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfGoodsReceiptResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGoodsReceiptResponsePropertyNames('createdAt', 'locationId', 'poId', 'receiptId', 'receiptNumber');
    const optionalStringProperties = createGoodsReceiptResponseOptionalProperties({ name: 'asnId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'locationId', nullable: false }, { name: 'poId', nullable: false }, { name: 'receiptId', nullable: false }, { name: 'receiptNumber', nullable: false });
    const optionalNumberProperties = createGoodsReceiptResponseOptionalProperties({ name: 'totalAccruedAmountMinor', nullable: false });
    const optionalBooleanProperties = createGoodsReceiptResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGoodsReceiptResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGoodsReceiptResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGoodsReceiptResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InterferingMovementResponseEventTypeEnum;
(function (InterferingMovementResponseEventTypeEnum) {
    InterferingMovementResponseEventTypeEnum["GoodsReceipt"] = "GOODS_RECEIPT";
    InterferingMovementResponseEventTypeEnum["TransferIn"] = "TRANSFER_IN";
    InterferingMovementResponseEventTypeEnum["Putaway"] = "PUTAWAY";
    InterferingMovementResponseEventTypeEnum["ReturnToStock"] = "RETURN_TO_STOCK";
    InterferingMovementResponseEventTypeEnum["AdjustmentIn"] = "ADJUSTMENT_IN";
    InterferingMovementResponseEventTypeEnum["CountVarianceIn"] = "COUNT_VARIANCE_IN";
    InterferingMovementResponseEventTypeEnum["GoodsIssue"] = "GOODS_ISSUE";
    InterferingMovementResponseEventTypeEnum["WorkorderConsumption"] = "WORKORDER_CONSUMPTION";
    InterferingMovementResponseEventTypeEnum["TransferOut"] = "TRANSFER_OUT";
    InterferingMovementResponseEventTypeEnum["ScrapOut"] = "SCRAP_OUT";
    InterferingMovementResponseEventTypeEnum["AdjustmentOut"] = "ADJUSTMENT_OUT";
    InterferingMovementResponseEventTypeEnum["CountVarianceOut"] = "COUNT_VARIANCE_OUT";
    InterferingMovementResponseEventTypeEnum["AdjustCycleCount"] = "ADJUST_CYCLE_COUNT";
    InterferingMovementResponseEventTypeEnum["ReservationCreated"] = "RESERVATION_CREATED";
    InterferingMovementResponseEventTypeEnum["ReservationReleased"] = "RESERVATION_RELEASED";
    InterferingMovementResponseEventTypeEnum["AllocationCreated"] = "ALLOCATION_CREATED";
    InterferingMovementResponseEventTypeEnum["AllocationReleased"] = "ALLOCATION_RELEASED";
    InterferingMovementResponseEventTypeEnum["BackorderCreated"] = "BACKORDER_CREATED";
    InterferingMovementResponseEventTypeEnum["BackorderResolved"] = "BACKORDER_RESOLVED";
    InterferingMovementResponseEventTypeEnum["PickTaskCreated"] = "PICK_TASK_CREATED";
    InterferingMovementResponseEventTypeEnum["PickTaskCompleted"] = "PICK_TASK_COMPLETED";
})(InterferingMovementResponseEventTypeEnum || (InterferingMovementResponseEventTypeEnum = {}));
;
function isOptionalInterferingMovementResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInterferingMovementResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInterferingMovementResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInterferingMovementResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInterferingMovementResponsePropertyNames('changeInQuantity', 'eventType', 'ledgerEntryId', 'timestamp');
    const optionalStringProperties = createInterferingMovementResponseOptionalProperties({ name: 'eventType', nullable: false }, { name: 'ledgerEntryId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'notes', nullable: false }, { name: 'timestamp', nullable: false }, { name: 'transactionUserId', nullable: false });
    const optionalNumberProperties = createInterferingMovementResponseOptionalProperties({ name: 'changeInQuantity', nullable: false }, { name: 'quantityAfter', nullable: false });
    const optionalBooleanProperties = createInterferingMovementResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInterferingMovementResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInterferingMovementResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInterferingMovementResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInventoryAvailabilityResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInventoryAvailabilityResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createInventoryAvailabilityResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfInventoryAvailabilityResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInventoryAvailabilityResponsePropertyNames('allocatedQty', 'asOfTimestamp', 'atpQty', 'locationId', 'onHandQty', 'productId', 'uom');
    const optionalStringProperties = createInventoryAvailabilityResponseOptionalProperties({ name: 'asOfTimestamp', nullable: false }, { name: 'locationId', nullable: false }, { name: 'productId', nullable: false }, { name: 'uom', nullable: false });
    const optionalNumberProperties = createInventoryAvailabilityResponseOptionalProperties({ name: 'allocatedQty', nullable: false }, { name: 'atpQty', nullable: false }, { name: 'expectedReceiptsQty', nullable: true }, { name: 'onHandQty', nullable: false });
    const optionalBooleanProperties = createInventoryAvailabilityResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInventoryAvailabilityResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInventoryAvailabilityResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInventoryAvailabilityResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInventoryBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInventoryBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInventoryBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfInventoryBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInventoryBulkIngestRecordPropertyNames('quantity', 'sku');
    const optionalStringProperties = createInventoryBulkIngestRecordOptionalProperties({ name: 'locationId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'sku', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createInventoryBulkIngestRecordOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createInventoryBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInventoryBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInventoryBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInventoryBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var InventoryLedgerEntryDtoEventTypeEnum;
(function (InventoryLedgerEntryDtoEventTypeEnum) {
    InventoryLedgerEntryDtoEventTypeEnum["GoodsReceipt"] = "GOODS_RECEIPT";
    InventoryLedgerEntryDtoEventTypeEnum["TransferIn"] = "TRANSFER_IN";
    InventoryLedgerEntryDtoEventTypeEnum["Putaway"] = "PUTAWAY";
    InventoryLedgerEntryDtoEventTypeEnum["ReturnToStock"] = "RETURN_TO_STOCK";
    InventoryLedgerEntryDtoEventTypeEnum["AdjustmentIn"] = "ADJUSTMENT_IN";
    InventoryLedgerEntryDtoEventTypeEnum["CountVarianceIn"] = "COUNT_VARIANCE_IN";
    InventoryLedgerEntryDtoEventTypeEnum["GoodsIssue"] = "GOODS_ISSUE";
    InventoryLedgerEntryDtoEventTypeEnum["WorkorderConsumption"] = "WORKORDER_CONSUMPTION";
    InventoryLedgerEntryDtoEventTypeEnum["TransferOut"] = "TRANSFER_OUT";
    InventoryLedgerEntryDtoEventTypeEnum["ScrapOut"] = "SCRAP_OUT";
    InventoryLedgerEntryDtoEventTypeEnum["AdjustmentOut"] = "ADJUSTMENT_OUT";
    InventoryLedgerEntryDtoEventTypeEnum["CountVarianceOut"] = "COUNT_VARIANCE_OUT";
    InventoryLedgerEntryDtoEventTypeEnum["AdjustCycleCount"] = "ADJUST_CYCLE_COUNT";
    InventoryLedgerEntryDtoEventTypeEnum["ReservationCreated"] = "RESERVATION_CREATED";
    InventoryLedgerEntryDtoEventTypeEnum["ReservationReleased"] = "RESERVATION_RELEASED";
    InventoryLedgerEntryDtoEventTypeEnum["AllocationCreated"] = "ALLOCATION_CREATED";
    InventoryLedgerEntryDtoEventTypeEnum["AllocationReleased"] = "ALLOCATION_RELEASED";
    InventoryLedgerEntryDtoEventTypeEnum["BackorderCreated"] = "BACKORDER_CREATED";
    InventoryLedgerEntryDtoEventTypeEnum["BackorderResolved"] = "BACKORDER_RESOLVED";
    InventoryLedgerEntryDtoEventTypeEnum["PickTaskCreated"] = "PICK_TASK_CREATED";
    InventoryLedgerEntryDtoEventTypeEnum["PickTaskCompleted"] = "PICK_TASK_COMPLETED";
})(InventoryLedgerEntryDtoEventTypeEnum || (InventoryLedgerEntryDtoEventTypeEnum = {}));
;
function isOptionalInventoryLedgerEntryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInventoryLedgerEntryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInventoryLedgerEntryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfInventoryLedgerEntryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInventoryLedgerEntryDtoPropertyNames('changeInQuantity', 'eventType', 'ledgerEntryId', 'quantityAfter', 'stockItemId', 'timestamp');
    const optionalStringProperties = createInventoryLedgerEntryDtoOptionalProperties({ name: 'adjustmentId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'eventType', nullable: false }, { name: 'fromLocationId', nullable: false }, { name: 'ledgerEntryId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'notes', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'sourceTransactionId', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'timestamp', nullable: false }, { name: 'toLocationId', nullable: false }, { name: 'transactionUserId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createInventoryLedgerEntryDtoOptionalProperties({ name: 'changeInQuantity', nullable: false }, { name: 'quantityAfter', nullable: false }, { name: 'unitCost', nullable: false });
    const optionalBooleanProperties = createInventoryLedgerEntryDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInventoryLedgerEntryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInventoryLedgerEntryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInventoryLedgerEntryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLeadTimeViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLeadTimeViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLeadTimeViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfLeadTimeView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLeadTimeViewPropertyNames('locationId', 'productId');
    const optionalStringProperties = createLeadTimeViewOptionalProperties({ name: 'asOf', nullable: false }, { name: 'confidence', nullable: false }, { name: 'displayText', nullable: false }, { name: 'locationId', nullable: false }, { name: 'productId', nullable: false }, { name: 'source', nullable: false });
    const optionalNumberProperties = createLeadTimeViewOptionalProperties({ name: 'maxDays', nullable: false }, { name: 'minDays', nullable: false });
    const optionalBooleanProperties = createLeadTimeViewOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLeadTimeViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLeadTimeViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLeadTimeViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLedgerPagePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLedgerPagePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLedgerPageOptionalProperties(...properties) {
    return properties;
}
function instanceOfLedgerPage(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLedgerPagePropertyNames('entries');
    const optionalStringProperties = createLedgerPageOptionalProperties({ name: 'nextPageToken', nullable: false });
    const optionalNumberProperties = createLedgerPageOptionalProperties();
    const optionalBooleanProperties = createLedgerPageOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLedgerPagePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLedgerPagePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLedgerPagePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLocationAvailabilityDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationAvailabilityDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationAvailabilityDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationAvailabilityDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationAvailabilityDtoPropertyNames('locationId', 'locationName', 'onHandQuantity');
    const optionalStringProperties = createLocationAvailabilityDtoOptionalProperties({ name: 'locationId', nullable: false }, { name: 'locationName', nullable: false });
    const optionalNumberProperties = createLocationAvailabilityDtoOptionalProperties({ name: 'availableToPromiseQuantity', nullable: false }, { name: 'incomingQty', nullable: false }, { name: 'onHandQuantity', nullable: false }, { name: 'outgoingQty', nullable: false }, { name: 'projectedAvailable', nullable: false });
    const optionalBooleanProperties = createLocationAvailabilityDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationAvailabilityDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationAvailabilityDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationAvailabilityDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLocationInventoryInquiryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationInventoryInquiryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationInventoryInquiryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationInventoryInquiryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationInventoryInquiryResponsePropertyNames('locationId', 'onHandQuantity');
    const optionalStringProperties = createLocationInventoryInquiryResponseOptionalProperties({ name: 'locationId', nullable: false });
    const optionalNumberProperties = createLocationInventoryInquiryResponseOptionalProperties({ name: 'availableToPromiseQuantity', nullable: false }, { name: 'onHandQuantity', nullable: false });
    const optionalBooleanProperties = createLocationInventoryInquiryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationInventoryInquiryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationInventoryInquiryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationInventoryInquiryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLocationInventoryItemPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationInventoryItemPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationInventoryItemOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationInventoryItem(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationInventoryItemPropertyNames('onHandQuantity', 'stockItemId');
    const optionalStringProperties = createLocationInventoryItemOptionalProperties({ name: 'stockItemId', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createLocationInventoryItemOptionalProperties({ name: 'onHandQuantity', nullable: false });
    const optionalBooleanProperties = createLocationInventoryItemOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationInventoryItemPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationInventoryItemPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationInventoryItemPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalLocationInventoryItemsResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationInventoryItemsResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationInventoryItemsResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationInventoryItemsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationInventoryItemsResponsePropertyNames('items', 'locationId');
    const optionalStringProperties = createLocationInventoryItemsResponseOptionalProperties({ name: 'locationId', nullable: false });
    const optionalNumberProperties = createLocationInventoryItemsResponseOptionalProperties();
    const optionalBooleanProperties = createLocationInventoryItemsResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationInventoryItemsResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationInventoryItemsResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationInventoryItemsResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalLocationInventoryRollupResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationInventoryRollupResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationInventoryRollupResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationInventoryRollupResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationInventoryRollupResponsePropertyNames('locationId', 'parentType', 'sites', 'totals');
    const optionalStringProperties = createLocationInventoryRollupResponseOptionalProperties({ name: 'locationId', nullable: false }, { name: 'parentType', nullable: false });
    const optionalNumberProperties = createLocationInventoryRollupResponseOptionalProperties();
    const optionalBooleanProperties = createLocationInventoryRollupResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationInventoryRollupResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationInventoryRollupResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationInventoryRollupResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLocationSyncRunResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLocationSyncRunResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLocationSyncRunResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLocationSyncRunResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLocationSyncRunResponsePropertyNames('locationsCreated', 'locationsFailed', 'locationsProcessed', 'locationsUnchanged', 'locationsUpdated', 'outcome', 'syncRunId');
    const optionalStringProperties = createLocationSyncRunResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'outcome', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'syncRunId', nullable: false });
    const optionalNumberProperties = createLocationSyncRunResponseOptionalProperties({ name: 'locationsCreated', nullable: false }, { name: 'locationsFailed', nullable: false }, { name: 'locationsProcessed', nullable: false }, { name: 'locationsUnchanged', nullable: false }, { name: 'locationsUpdated', nullable: false });
    const optionalBooleanProperties = createLocationSyncRunResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLocationSyncRunResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLocationSyncRunResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLocationSyncRunResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalLotDetailResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLotDetailResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLotDetailResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLotDetailResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLotDetailResponsePropertyNames('lot');
    const optionalStringProperties = createLotDetailResponseOptionalProperties();
    const optionalNumberProperties = createLotDetailResponseOptionalProperties();
    const optionalBooleanProperties = createLotDetailResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLotDetailResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLotDetailResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLotDetailResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLotExpirationUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLotExpirationUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLotExpirationUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfLotExpirationUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLotExpirationUpdateRequestPropertyNames();
    const optionalStringProperties = createLotExpirationUpdateRequestOptionalProperties({ name: 'alertDate', nullable: false }, { name: 'expirationDate', nullable: false });
    const optionalNumberProperties = createLotExpirationUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createLotExpirationUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLotExpirationUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLotExpirationUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLotExpirationUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLotLocationOnHandPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLotLocationOnHandPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLotLocationOnHandOptionalProperties(...properties) {
    return properties;
}
function instanceOfLotLocationOnHand(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLotLocationOnHandPropertyNames('inTransitQty', 'onHand');
    const optionalStringProperties = createLotLocationOnHandOptionalProperties({ name: 'locationId', nullable: false });
    const optionalNumberProperties = createLotLocationOnHandOptionalProperties({ name: 'inTransitQty', nullable: false }, { name: 'onHand', nullable: false });
    const optionalBooleanProperties = createLotLocationOnHandOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLotLocationOnHandPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLotLocationOnHandPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLotLocationOnHandPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LotResponseStatusEnum;
(function (LotResponseStatusEnum) {
    LotResponseStatusEnum["Active"] = "ACTIVE";
    LotResponseStatusEnum["Quarantined"] = "QUARANTINED";
    LotResponseStatusEnum["Recalled"] = "RECALLED";
    LotResponseStatusEnum["Consumed"] = "CONSUMED";
})(LotResponseStatusEnum || (LotResponseStatusEnum = {}));
;
function isOptionalLotResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLotResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLotResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLotResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLotResponsePropertyNames('lotId', 'lotNumber', 'receivedAt', 'status', 'stockItemId');
    const optionalStringProperties = createLotResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'expirationDate', nullable: false }, { name: 'lotId', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'receivedAt', nullable: false }, { name: 'status', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createLotResponseOptionalProperties();
    const optionalBooleanProperties = createLotResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLotResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLotResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLotResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var LotStatusUpdateRequestStatusEnum;
(function (LotStatusUpdateRequestStatusEnum) {
    LotStatusUpdateRequestStatusEnum["Active"] = "ACTIVE";
    LotStatusUpdateRequestStatusEnum["Quarantined"] = "QUARANTINED";
    LotStatusUpdateRequestStatusEnum["Recalled"] = "RECALLED";
    LotStatusUpdateRequestStatusEnum["Consumed"] = "CONSUMED";
})(LotStatusUpdateRequestStatusEnum || (LotStatusUpdateRequestStatusEnum = {}));
;
function isOptionalLotStatusUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLotStatusUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLotStatusUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfLotStatusUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLotStatusUpdateRequestPropertyNames('reason', 'status');
    const optionalStringProperties = createLotStatusUpdateRequestOptionalProperties({ name: 'reason', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createLotStatusUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createLotStatusUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLotStatusUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLotStatusUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLotStatusUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var LotTraceabilityResponseLotStatusEnum;
(function (LotTraceabilityResponseLotStatusEnum) {
    LotTraceabilityResponseLotStatusEnum["Active"] = "ACTIVE";
    LotTraceabilityResponseLotStatusEnum["Quarantined"] = "QUARANTINED";
    LotTraceabilityResponseLotStatusEnum["Recalled"] = "RECALLED";
    LotTraceabilityResponseLotStatusEnum["Consumed"] = "CONSUMED";
})(LotTraceabilityResponseLotStatusEnum || (LotTraceabilityResponseLotStatusEnum = {}));
;
function isOptionalLotTraceabilityResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLotTraceabilityResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createLotTraceabilityResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfLotTraceabilityResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLotTraceabilityResponsePropertyNames('downstream', 'lotId', 'lotNumber', 'stockItemId', 'upstream');
    const optionalStringProperties = createLotTraceabilityResponseOptionalProperties({ name: 'lotId', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'lotStatus', nullable: false }, { name: 'stockItemId', nullable: false });
    const optionalNumberProperties = createLotTraceabilityResponseOptionalProperties();
    const optionalBooleanProperties = createLotTraceabilityResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLotTraceabilityResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLotTraceabilityResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLotTraceabilityResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalMovedItemPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createMovedItemPropertyNames(...propertyNames) {
    return propertyNames;
}
function createMovedItemOptionalProperties(...properties) {
    return properties;
}
function instanceOfMovedItem(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createMovedItemPropertyNames('itemId', 'quantity');
    const optionalStringProperties = createMovedItemOptionalProperties({ name: 'itemId', nullable: false });
    const optionalNumberProperties = createMovedItemOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createMovedItemOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalMovedItemPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalMovedItemPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalMovedItemPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PickListResponseStatusEnum;
(function (PickListResponseStatusEnum) {
    PickListResponseStatusEnum["Draft"] = "DRAFT";
    PickListResponseStatusEnum["ReadyToPick"] = "READY_TO_PICK";
    PickListResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    PickListResponseStatusEnum["Completed"] = "COMPLETED";
    PickListResponseStatusEnum["Cancelled"] = "CANCELLED";
})(PickListResponseStatusEnum || (PickListResponseStatusEnum = {}));
;
function isOptionalPickListResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPickListResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPickListResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPickListResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPickListResponsePropertyNames('createdAt', 'pickListId', 'priority', 'status', 'updatedAt', 'workorderId');
    const optionalStringProperties = createPickListResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'dueAt', nullable: false }, { name: 'pickListId', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createPickListResponseOptionalProperties({ name: 'priority', nullable: false });
    const optionalBooleanProperties = createPickListResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPickListResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPickListResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPickListResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PickTaskResponseStatusEnum;
(function (PickTaskResponseStatusEnum) {
    PickTaskResponseStatusEnum["Pending"] = "PENDING";
    PickTaskResponseStatusEnum["NeedsReview"] = "NEEDS_REVIEW";
    PickTaskResponseStatusEnum["Picked"] = "PICKED";
    PickTaskResponseStatusEnum["Cancelled"] = "CANCELLED";
})(PickTaskResponseStatusEnum || (PickTaskResponseStatusEnum = {}));
;
function isOptionalPickTaskResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPickTaskResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPickTaskResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPickTaskResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPickTaskResponsePropertyNames('locationId', 'pickListId', 'pickTaskId', 'quantityPicked', 'quantityRequired', 'skuId', 'sortOrder', 'status');
    const optionalStringProperties = createPickTaskResponseOptionalProperties({ name: 'locationId', nullable: false }, { name: 'pickListId', nullable: false }, { name: 'pickTaskId', nullable: false }, { name: 'pickedLotId', nullable: false }, { name: 'skuId', nullable: false }, { name: 'status', nullable: false }, { name: 'suggestedLotNumber', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createPickTaskResponseOptionalProperties({ name: 'quantityPicked', nullable: false }, { name: 'quantityRequired', nullable: false }, { name: 'sortOrder', nullable: false });
    const optionalBooleanProperties = createPickTaskResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPickTaskResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPickTaskResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPickTaskResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPromoteAllocationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPromoteAllocationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPromoteAllocationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPromoteAllocationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPromoteAllocationRequestPropertyNames('storageLocationId');
    const optionalStringProperties = createPromoteAllocationRequestOptionalProperties({ name: 'hardenedReason', nullable: false }, { name: 'storageLocationId', nullable: false });
    const optionalNumberProperties = createPromoteAllocationRequestOptionalProperties();
    const optionalBooleanProperties = createPromoteAllocationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPromoteAllocationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPromoteAllocationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPromoteAllocationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PurchaseSuggestionResponseStatusEnum;
(function (PurchaseSuggestionResponseStatusEnum) {
    PurchaseSuggestionResponseStatusEnum["Suggested"] = "SUGGESTED";
    PurchaseSuggestionResponseStatusEnum["Accepted"] = "ACCEPTED";
    PurchaseSuggestionResponseStatusEnum["Converted"] = "CONVERTED";
    PurchaseSuggestionResponseStatusEnum["Dismissed"] = "DISMISSED";
})(PurchaseSuggestionResponseStatusEnum || (PurchaseSuggestionResponseStatusEnum = {}));
;
var PurchaseSuggestionResponseSuggestedVendorTypeEnum;
(function (PurchaseSuggestionResponseSuggestedVendorTypeEnum) {
    PurchaseSuggestionResponseSuggestedVendorTypeEnum["Manufacturer"] = "MANUFACTURER";
    PurchaseSuggestionResponseSuggestedVendorTypeEnum["Distributor"] = "DISTRIBUTOR";
})(PurchaseSuggestionResponseSuggestedVendorTypeEnum || (PurchaseSuggestionResponseSuggestedVendorTypeEnum = {}));
;
function isOptionalPurchaseSuggestionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPurchaseSuggestionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPurchaseSuggestionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPurchaseSuggestionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPurchaseSuggestionResponsePropertyNames('createdAt', 'itemSKU', 'locationId', 'policyId', 'selectionReason', 'status', 'suggestedQuantity', 'suggestionId', 'updatedAt');
    const optionalStringProperties = createPurchaseSuggestionResponseOptionalProperties({ name: 'convertedPurchaseOrderId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'dismissalReason', nullable: false }, { name: 'earliestExpectedDate', nullable: false }, { name: 'itemSKU', nullable: false }, { name: 'locationId', nullable: false }, { name: 'policyId', nullable: false }, { name: 'selectionReason', nullable: false }, { name: 'status', nullable: false }, { name: 'suggestedVendorType', nullable: false }, { name: 'suggestionId', nullable: false }, { name: 'unitCostCurrency', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'vendorRefId', nullable: false });
    const optionalNumberProperties = createPurchaseSuggestionResponseOptionalProperties({ name: 'leadTimeDays', nullable: false }, { name: 'suggestedQuantity', nullable: false }, { name: 'unitCostMinor', nullable: false }, { name: 'vendorPackSize', nullable: false });
    const optionalBooleanProperties = createPurchaseSuggestionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPurchaseSuggestionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPurchaseSuggestionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPurchaseSuggestionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var PutawayExecutionRequestOverrideReasonCodeEnum;
(function (PutawayExecutionRequestOverrideReasonCodeEnum) {
    PutawayExecutionRequestOverrideReasonCodeEnum["CapacityOverride"] = "CAPACITY_OVERRIDE";
    PutawayExecutionRequestOverrideReasonCodeEnum["LocationCompatibilityOverride"] = "LOCATION_COMPATIBILITY_OVERRIDE";
    PutawayExecutionRequestOverrideReasonCodeEnum["UrgentFulfillment"] = "URGENT_FULFILLMENT";
    PutawayExecutionRequestOverrideReasonCodeEnum["AlternateLocation"] = "ALTERNATE_LOCATION";
    PutawayExecutionRequestOverrideReasonCodeEnum["Other"] = "OTHER";
})(PutawayExecutionRequestOverrideReasonCodeEnum || (PutawayExecutionRequestOverrideReasonCodeEnum = {}));
;
function isOptionalPutawayExecutionRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPutawayExecutionRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPutawayExecutionRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPutawayExecutionRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPutawayExecutionRequestPropertyNames('destinationLocationId', 'quantity', 'skuId', 'sourceLocationId');
    const optionalStringProperties = createPutawayExecutionRequestOptionalProperties({ name: 'approvedBy', nullable: false }, { name: 'destinationLocationId', nullable: false }, { name: 'overrideJustification', nullable: false }, { name: 'overrideReasonCode', nullable: false }, { name: 'skuId', nullable: false }, { name: 'sourceLocationId', nullable: false });
    const optionalNumberProperties = createPutawayExecutionRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createPutawayExecutionRequestOptionalProperties({ name: 'overrideCapacity', nullable: false }, { name: 'overrideLocationCompatibility', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPutawayExecutionRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPutawayExecutionRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPutawayExecutionRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPutawayExecutionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPutawayExecutionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPutawayExecutionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPutawayExecutionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPutawayExecutionResponsePropertyNames('destinationLocationId', 'executedAt', 'ledgerEntryId', 'quantityMoved', 'skuId', 'status', 'taskId', 'transactionType');
    const optionalStringProperties = createPutawayExecutionResponseOptionalProperties({ name: 'actorId', nullable: false }, { name: 'destinationLocationId', nullable: false }, { name: 'executedAt', nullable: false }, { name: 'ledgerEntryId', nullable: false }, { name: 'skuId', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'status', nullable: false }, { name: 'taskId', nullable: false }, { name: 'transactionType', nullable: false });
    const optionalNumberProperties = createPutawayExecutionResponseOptionalProperties({ name: 'quantityMoved', nullable: false });
    const optionalBooleanProperties = createPutawayExecutionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPutawayExecutionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPutawayExecutionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPutawayExecutionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPutawayLineItemRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPutawayLineItemRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPutawayLineItemRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPutawayLineItemRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPutawayLineItemRequestPropertyNames('productId', 'quantity');
    const optionalStringProperties = createPutawayLineItemRequestOptionalProperties({ name: 'productId', nullable: false });
    const optionalNumberProperties = createPutawayLineItemRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createPutawayLineItemRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPutawayLineItemRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPutawayLineItemRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPutawayLineItemRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPutawayTaskResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPutawayTaskResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPutawayTaskResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPutawayTaskResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPutawayTaskResponsePropertyNames('createdAt', 'productId', 'quantity', 'sourceReceiptId', 'status', 'taskId', 'updatedAt');
    const optionalStringProperties = createPutawayTaskResponseOptionalProperties({ name: 'actualDestinationLocationId', nullable: false }, { name: 'assigneeId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'fallbackReason', nullable: false }, { name: 'finalSuggestedLocationId', nullable: false }, { name: 'originalSuggestedLocationId', nullable: false }, { name: 'productId', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'sourceReceiptId', nullable: false }, { name: 'status', nullable: false }, { name: 'suggestedDestinationLocationId', nullable: false }, { name: 'taskId', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createPutawayTaskResponseOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createPutawayTaskResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPutawayTaskResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPutawayTaskResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPutawayTaskResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReallocateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReallocateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReallocateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReallocateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReallocateRequestPropertyNames('stockItemId');
    const optionalStringProperties = createReallocateRequestOptionalProperties({ name: 'stockItemId', nullable: false }, { name: 'triggerReferenceId', nullable: false }, { name: 'triggerType', nullable: false });
    const optionalNumberProperties = createReallocateRequestOptionalProperties();
    const optionalBooleanProperties = createReallocateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReallocateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReallocateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReallocateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReallocateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReallocateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReallocateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReallocateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReallocateResponsePropertyNames('atpAfterReallocation', 'auditRecordsCreated', 'stockItemId', 'totalReallocated');
    const optionalStringProperties = createReallocateResponseOptionalProperties({ name: 'stockItemId', nullable: false });
    const optionalNumberProperties = createReallocateResponseOptionalProperties({ name: 'atpAfterReallocation', nullable: false }, { name: 'auditRecordsCreated', nullable: false }, { name: 'totalReallocated', nullable: false });
    const optionalBooleanProperties = createReallocateResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReallocateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReallocateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReallocateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReasonCodeDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReasonCodeDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReasonCodeDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfReasonCodeDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReasonCodeDtoPropertyNames('code', 'description');
    const optionalStringProperties = createReasonCodeDtoOptionalProperties({ name: 'category', nullable: false }, { name: 'code', nullable: false }, { name: 'description', nullable: false });
    const optionalNumberProperties = createReasonCodeDtoOptionalProperties();
    const optionalBooleanProperties = createReasonCodeDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReasonCodeDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReasonCodeDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReasonCodeDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReceiveItemsRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceiveItemsRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceiveItemsRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceiveItemsRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceiveItemsRequestPropertyNames('lines');
    const optionalStringProperties = createReceiveItemsRequestOptionalProperties();
    const optionalNumberProperties = createReceiveItemsRequestOptionalProperties();
    const optionalBooleanProperties = createReceiveItemsRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceiveItemsRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceiveItemsRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceiveItemsRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReceiveItemsResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceiveItemsResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceiveItemsResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceiveItemsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceiveItemsResponsePropertyNames('linesProcessed', 'sessionId', 'sessionStatus');
    const optionalStringProperties = createReceiveItemsResponseOptionalProperties({ name: 'sessionId', nullable: false }, { name: 'sessionStatus', nullable: false });
    const optionalNumberProperties = createReceiveItemsResponseOptionalProperties({ name: 'linesProcessed', nullable: false });
    const optionalBooleanProperties = createReceiveItemsResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceiveItemsResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceiveItemsResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceiveItemsResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReceiveLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceiveLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceiveLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceiveLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceiveLineRequestPropertyNames('lineId');
    const optionalStringProperties = createReceiveLineRequestOptionalProperties({ name: 'documentUom', nullable: false }, { name: 'expirationDate', nullable: false }, { name: 'lineId', nullable: false }, { name: 'lotNumber', nullable: false });
    const optionalNumberProperties = createReceiveLineRequestOptionalProperties({ name: 'documentQuantity', nullable: false }, { name: 'receivedQuantity', nullable: false });
    const optionalBooleanProperties = createReceiveLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceiveLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceiveLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceiveLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReceiveTransferOrderRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceiveTransferOrderRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceiveTransferOrderRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceiveTransferOrderRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceiveTransferOrderRequestPropertyNames();
    const optionalStringProperties = createReceiveTransferOrderRequestOptionalProperties();
    const optionalNumberProperties = createReceiveTransferOrderRequestOptionalProperties();
    const optionalBooleanProperties = createReceiveTransferOrderRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceiveTransferOrderRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceiveTransferOrderRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceiveTransferOrderRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReceivingLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceivingLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceivingLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceivingLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceivingLineResponsePropertyNames('lineId', 'productId', 'status');
    const optionalStringProperties = createReceivingLineResponseOptionalProperties({ name: 'documentUom', nullable: false }, { name: 'lineId', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'productId', nullable: false }, { name: 'status', nullable: false }, { name: 'workorderId', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createReceivingLineResponseOptionalProperties({ name: 'conversionFactor', nullable: false }, { name: 'documentQuantity', nullable: false }, { name: 'expectedQuantity', nullable: false }, { name: 'receivedQuantity', nullable: false });
    const optionalBooleanProperties = createReceivingLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceivingLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceivingLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceivingLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReceivingSessionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReceivingSessionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReceivingSessionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReceivingSessionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReceivingSessionResponsePropertyNames('createdAt', 'sessionId', 'sourceDocumentId', 'status');
    const optionalStringProperties = createReceivingSessionResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdByUserId', nullable: false }, { name: 'entryMethod', nullable: false }, { name: 'sessionId', nullable: false }, { name: 'shipmentReference', nullable: false }, { name: 'sourceDocumentId', nullable: false }, { name: 'sourceDocumentType', nullable: false }, { name: 'status', nullable: false }, { name: 'supplierId', nullable: false });
    const optionalNumberProperties = createReceivingSessionResponseOptionalProperties();
    const optionalBooleanProperties = createReceivingSessionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReceivingSessionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReceivingSessionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReceivingSessionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RecordMovementRequestMovementTypeEnum;
(function (RecordMovementRequestMovementTypeEnum) {
    RecordMovementRequestMovementTypeEnum["Receive"] = "RECEIVE";
    RecordMovementRequestMovementTypeEnum["PutAway"] = "PUT_AWAY";
    RecordMovementRequestMovementTypeEnum["Pick"] = "PICK";
    RecordMovementRequestMovementTypeEnum["Issue"] = "ISSUE";
    RecordMovementRequestMovementTypeEnum["Return"] = "RETURN";
    RecordMovementRequestMovementTypeEnum["Transfer"] = "TRANSFER";
})(RecordMovementRequestMovementTypeEnum || (RecordMovementRequestMovementTypeEnum = {}));
;
function isOptionalRecordMovementRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRecordMovementRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRecordMovementRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRecordMovementRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRecordMovementRequestPropertyNames('fromLocationId', 'movementType', 'productSku', 'quantity');
    const optionalStringProperties = createRecordMovementRequestOptionalProperties({ name: 'fromLocationId', nullable: false }, { name: 'movementType', nullable: false }, { name: 'productSku', nullable: false }, { name: 'sourceTransactionId', nullable: false }, { name: 'toLocationId', nullable: false }, { name: 'unitOfMeasure', nullable: false });
    const optionalNumberProperties = createRecordMovementRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createRecordMovementRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRecordMovementRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRecordMovementRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRecordMovementRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRejectAdjustmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRejectAdjustmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRejectAdjustmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRejectAdjustmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRejectAdjustmentRequestPropertyNames('rejectionReason', 'rejectorUserId');
    const optionalStringProperties = createRejectAdjustmentRequestOptionalProperties({ name: 'rejectionReason', nullable: false }, { name: 'rejectorUserId', nullable: false });
    const optionalNumberProperties = createRejectAdjustmentRequestOptionalProperties();
    const optionalBooleanProperties = createRejectAdjustmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRejectAdjustmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRejectAdjustmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRejectAdjustmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRejectRevaluationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRejectRevaluationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRejectRevaluationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRejectRevaluationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRejectRevaluationRequestPropertyNames('rejectionReason');
    const optionalStringProperties = createRejectRevaluationRequestOptionalProperties({ name: 'rejectionReason', nullable: false });
    const optionalNumberProperties = createRejectRevaluationRequestOptionalProperties();
    const optionalBooleanProperties = createRejectRevaluationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRejectRevaluationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRejectRevaluationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRejectRevaluationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRejectScrapRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRejectScrapRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRejectScrapRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRejectScrapRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRejectScrapRequestPropertyNames('rejectionReason');
    const optionalStringProperties = createRejectScrapRequestOptionalProperties({ name: 'rejectionReason', nullable: false });
    const optionalNumberProperties = createRejectScrapRequestOptionalProperties();
    const optionalBooleanProperties = createRejectScrapRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRejectScrapRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRejectScrapRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRejectScrapRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ReplenishmentNeedResponseLeadTimeSourceEnum;
(function (ReplenishmentNeedResponseLeadTimeSourceEnum) {
    ReplenishmentNeedResponseLeadTimeSourceEnum["PolicyOverride"] = "POLICY_OVERRIDE";
    ReplenishmentNeedResponseLeadTimeSourceEnum["Feed"] = "FEED";
    ReplenishmentNeedResponseLeadTimeSourceEnum["Default"] = "DEFAULT";
})(ReplenishmentNeedResponseLeadTimeSourceEnum || (ReplenishmentNeedResponseLeadTimeSourceEnum = {}));
;
function isOptionalReplenishmentNeedResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReplenishmentNeedResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReplenishmentNeedResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReplenishmentNeedResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReplenishmentNeedResponsePropertyNames('itemSKU', 'leadHorizonDate', 'leadTimeSource', 'locationId', 'maximumQuantity', 'minimumQuantity', 'onHand', 'policyId', 'preferredSourceType', 'projectedAvailable', 'suggestedQuantity', 'wouldTrigger');
    const optionalStringProperties = createReplenishmentNeedResponseOptionalProperties({ name: 'deadlineDate', nullable: false }, { name: 'itemSKU', nullable: false }, { name: 'leadHorizonDate', nullable: false }, { name: 'leadTimeSource', nullable: false }, { name: 'locationId', nullable: false }, { name: 'policyId', nullable: false }, { name: 'preferredSourceType', nullable: false });
    const optionalNumberProperties = createReplenishmentNeedResponseOptionalProperties({ name: 'maximumQuantity', nullable: false }, { name: 'minimumQuantity', nullable: false }, { name: 'onHand', nullable: false }, { name: 'projectedAvailable', nullable: false }, { name: 'suggestedQuantity', nullable: false });
    const optionalBooleanProperties = createReplenishmentNeedResponseOptionalProperties({ name: 'wouldTrigger', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReplenishmentNeedResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReplenishmentNeedResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReplenishmentNeedResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReplenishmentPolicyResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReplenishmentPolicyResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReplenishmentPolicyResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReplenishmentPolicyResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReplenishmentPolicyResponsePropertyNames('active', 'createdAt', 'itemSKU', 'locationId', 'maximumQuantity', 'minimumQuantity', 'policyId', 'preferredSourceType');
    const optionalStringProperties = createReplenishmentPolicyResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'itemSKU', nullable: false }, { name: 'locationId', nullable: false }, { name: 'policyId', nullable: false }, { name: 'preferredSourceType', nullable: false }, { name: 'snoozedUntil', nullable: false });
    const optionalNumberProperties = createReplenishmentPolicyResponseOptionalProperties({ name: 'leadTimeDaysOverride', nullable: false }, { name: 'maximumQuantity', nullable: false }, { name: 'minimumQuantity', nullable: false }, { name: 'orderMultiple', nullable: false });
    const optionalBooleanProperties = createReplenishmentPolicyResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReplenishmentPolicyResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReplenishmentPolicyResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReplenishmentPolicyResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReplenishmentScanResultResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReplenishmentScanResultResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReplenishmentScanResultResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReplenishmentScanResultResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReplenishmentScanResultResponsePropertyNames('policiesBelowMinimum', 'policiesEvaluated', 'policiesSkipped', 'scanAt', 'suggestionsCreated', 'suggestionsRefreshed', 'tasksCreated', 'tasksRefreshed');
    const optionalStringProperties = createReplenishmentScanResultResponseOptionalProperties({ name: 'scanAt', nullable: false });
    const optionalNumberProperties = createReplenishmentScanResultResponseOptionalProperties({ name: 'policiesBelowMinimum', nullable: false }, { name: 'policiesEvaluated', nullable: false }, { name: 'policiesSkipped', nullable: false }, { name: 'suggestionsCreated', nullable: false }, { name: 'suggestionsRefreshed', nullable: false }, { name: 'tasksCreated', nullable: false }, { name: 'tasksRefreshed', nullable: false });
    const optionalBooleanProperties = createReplenishmentScanResultResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReplenishmentScanResultResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReplenishmentScanResultResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReplenishmentScanResultResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReplenishmentTaskResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReplenishmentTaskResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReplenishmentTaskResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReplenishmentTaskResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReplenishmentTaskResponsePropertyNames('createdAt', 'destinationLocationId', 'itemSKU', 'quantity', 'status', 'taskId');
    const optionalStringProperties = createReplenishmentTaskResponseOptionalProperties({ name: 'assignedTo', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'deadlineDate', nullable: false }, { name: 'decisionReason', nullable: false }, { name: 'destinationLocationId', nullable: false }, { name: 'itemSKU', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'sourcingReason', nullable: false }, { name: 'status', nullable: false }, { name: 'taskId', nullable: false }, { name: 'triggerType', nullable: false });
    const optionalNumberProperties = createReplenishmentTaskResponseOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createReplenishmentTaskResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReplenishmentTaskResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReplenishmentTaskResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReplenishmentTaskResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReservationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReservationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createReservationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfReservationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReservationResponsePropertyNames('allocatedQuantity', 'requiredQuantity', 'reservationId', 'status', 'stockItemId');
    const optionalStringProperties = createReservationResponseOptionalProperties({ name: 'reservationId', nullable: false }, { name: 'salesOrderLineId', nullable: false }, { name: 'status', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createReservationResponseOptionalProperties({ name: 'allocatedQuantity', nullable: false }, { name: 'requiredQuantity', nullable: false });
    const optionalBooleanProperties = createReservationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReservationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReservationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReservationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReturnLineDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReturnLineDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReturnLineDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfReturnLineDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReturnLineDtoPropertyNames('itemId', 'locationId', 'quantity', 'reasonCode');
    const optionalStringProperties = createReturnLineDtoOptionalProperties({ name: 'itemId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'storageLocationId', nullable: false });
    const optionalNumberProperties = createReturnLineDtoOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createReturnLineDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReturnLineDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReturnLineDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReturnLineDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReturnSubmissionResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReturnSubmissionResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReturnSubmissionResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfReturnSubmissionResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReturnSubmissionResultDtoPropertyNames('processedAt', 'processedLines', 'returnId', 'status', 'workorderId');
    const optionalStringProperties = createReturnSubmissionResultDtoOptionalProperties({ name: 'processedAt', nullable: false }, { name: 'returnId', nullable: false }, { name: 'status', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createReturnSubmissionResultDtoOptionalProperties({ name: 'processedLines', nullable: false });
    const optionalBooleanProperties = createReturnSubmissionResultDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReturnSubmissionResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReturnSubmissionResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReturnSubmissionResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalReturnSubmitRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReturnSubmitRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReturnSubmitRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfReturnSubmitRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReturnSubmitRequestPropertyNames('lines', 'workorderId');
    const optionalStringProperties = createReturnSubmitRequestOptionalProperties({ name: 'workorderId', nullable: false });
    const optionalNumberProperties = createReturnSubmitRequestOptionalProperties();
    const optionalBooleanProperties = createReturnSubmitRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReturnSubmitRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReturnSubmitRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReturnSubmitRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalReturnableItemDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createReturnableItemDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createReturnableItemDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfReturnableItemDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createReturnableItemDtoPropertyNames('itemId', 'quantityReturnable', 'sku', 'workorderId');
    const optionalStringProperties = createReturnableItemDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'itemId', nullable: false }, { name: 'sku', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createReturnableItemDtoOptionalProperties({ name: 'quantityReturnable', nullable: false });
    const optionalBooleanProperties = createReturnableItemDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalReturnableItemDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalReturnableItemDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalReturnableItemDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var RevaluationResponseCostingMethodEnum;
(function (RevaluationResponseCostingMethodEnum) {
    RevaluationResponseCostingMethodEnum["Standard"] = "STANDARD";
    RevaluationResponseCostingMethodEnum["Average"] = "AVERAGE";
})(RevaluationResponseCostingMethodEnum || (RevaluationResponseCostingMethodEnum = {}));
;
var RevaluationResponseRequiredApprovalTierEnum;
(function (RevaluationResponseRequiredApprovalTierEnum) {
    RevaluationResponseRequiredApprovalTierEnum["Tier1Manager"] = "TIER_1_MANAGER";
    RevaluationResponseRequiredApprovalTierEnum["Tier2Director"] = "TIER_2_DIRECTOR";
})(RevaluationResponseRequiredApprovalTierEnum || (RevaluationResponseRequiredApprovalTierEnum = {}));
;
var RevaluationResponseStatusEnum;
(function (RevaluationResponseStatusEnum) {
    RevaluationResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    RevaluationResponseStatusEnum["AutoApplied"] = "AUTO_APPLIED";
    RevaluationResponseStatusEnum["Applied"] = "APPLIED";
    RevaluationResponseStatusEnum["Rejected"] = "REJECTED";
})(RevaluationResponseStatusEnum || (RevaluationResponseStatusEnum = {}));
;
function isOptionalRevaluationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRevaluationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createRevaluationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfRevaluationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRevaluationResponsePropertyNames();
    const optionalStringProperties = createRevaluationResponseOptionalProperties({ name: 'appliedAt', nullable: false }, { name: 'approvedBy', nullable: false }, { name: 'costingMethod', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'reason', nullable: false }, { name: 'rejectedAt', nullable: false }, { name: 'rejectedBy', nullable: false }, { name: 'rejectionReason', nullable: false }, { name: 'requiredApprovalTier', nullable: false }, { name: 'revaluationId', nullable: false }, { name: 'status', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createRevaluationResponseOptionalProperties({ name: 'newUnitCost', nullable: false }, { name: 'onHandQuantity', nullable: false }, { name: 'previousUnitCost', nullable: false }, { name: 'valueDelta', nullable: false });
    const optionalBooleanProperties = createRevaluationResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRevaluationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRevaluationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRevaluationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRollupQuantitiesPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRollupQuantitiesPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRollupQuantitiesOptionalProperties(...properties) {
    return properties;
}
function instanceOfRollupQuantities(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRollupQuantitiesPropertyNames('allocated', 'available', 'onHand');
    const optionalStringProperties = createRollupQuantitiesOptionalProperties();
    const optionalNumberProperties = createRollupQuantitiesOptionalProperties({ name: 'allocated', nullable: false }, { name: 'available', nullable: false }, { name: 'onHand', nullable: false });
    const optionalBooleanProperties = createRollupQuantitiesOptionalProperties({ name: 'empty', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRollupQuantitiesPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRollupQuantitiesPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRollupQuantitiesPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ScrapResponseCostSourceEnum;
(function (ScrapResponseCostSourceEnum) {
    ScrapResponseCostSourceEnum["LatestReceipt"] = "LATEST_RECEIPT";
    ScrapResponseCostSourceEnum["None"] = "NONE";
})(ScrapResponseCostSourceEnum || (ScrapResponseCostSourceEnum = {}));
;
var ScrapResponseReasonCodeEnum;
(function (ScrapResponseReasonCodeEnum) {
    ScrapResponseReasonCodeEnum["Damaged"] = "DAMAGED";
    ScrapResponseReasonCodeEnum["Expired"] = "EXPIRED";
    ScrapResponseReasonCodeEnum["Lost"] = "LOST";
    ScrapResponseReasonCodeEnum["Recalled"] = "RECALLED";
    ScrapResponseReasonCodeEnum["Contaminated"] = "CONTAMINATED";
    ScrapResponseReasonCodeEnum["WarrantyDestroyed"] = "WARRANTY_DESTROYED";
    ScrapResponseReasonCodeEnum["Other"] = "OTHER";
})(ScrapResponseReasonCodeEnum || (ScrapResponseReasonCodeEnum = {}));
;
var ScrapResponseRequiredApprovalTierEnum;
(function (ScrapResponseRequiredApprovalTierEnum) {
    ScrapResponseRequiredApprovalTierEnum["Tier1Manager"] = "TIER_1_MANAGER";
    ScrapResponseRequiredApprovalTierEnum["Tier2Director"] = "TIER_2_DIRECTOR";
})(ScrapResponseRequiredApprovalTierEnum || (ScrapResponseRequiredApprovalTierEnum = {}));
;
var ScrapResponseStatusEnum;
(function (ScrapResponseStatusEnum) {
    ScrapResponseStatusEnum["PendingApproval"] = "PENDING_APPROVAL";
    ScrapResponseStatusEnum["AutoApproved"] = "AUTO_APPROVED";
    ScrapResponseStatusEnum["Approved"] = "APPROVED";
    ScrapResponseStatusEnum["Posted"] = "POSTED";
    ScrapResponseStatusEnum["Rejected"] = "REJECTED";
    ScrapResponseStatusEnum["Failed"] = "FAILED";
})(ScrapResponseStatusEnum || (ScrapResponseStatusEnum = {}));
;
function isOptionalScrapResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createScrapResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createScrapResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfScrapResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createScrapResponsePropertyNames();
    const optionalStringProperties = createScrapResponseOptionalProperties({ name: 'approvedAt', nullable: false }, { name: 'approvedBy', nullable: false }, { name: 'attachmentReference', nullable: false }, { name: 'costSource', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'errorMessage', nullable: false }, { name: 'ledgerEntryId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'lotId', nullable: false }, { name: 'notes', nullable: false }, { name: 'postedAt', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'rejectedAt', nullable: false }, { name: 'rejectedBy', nullable: false }, { name: 'rejectionReason', nullable: false }, { name: 'requiredApprovalTier', nullable: false }, { name: 'scrapId', nullable: false }, { name: 'status', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'storageLocationId', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createScrapResponseOptionalProperties({ name: 'quantity', nullable: false }, { name: 'scrapValue', nullable: false }, { name: 'unitCostSnapshot', nullable: false });
    const optionalBooleanProperties = createScrapResponseOptionalProperties({ name: 'shouldReplenish', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalScrapResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalScrapResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalScrapResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var SerialTraceabilityResponseSerialStatusEnum;
(function (SerialTraceabilityResponseSerialStatusEnum) {
    SerialTraceabilityResponseSerialStatusEnum["InStock"] = "IN_STOCK";
    SerialTraceabilityResponseSerialStatusEnum["Issued"] = "ISSUED";
    SerialTraceabilityResponseSerialStatusEnum["Returned"] = "RETURNED";
    SerialTraceabilityResponseSerialStatusEnum["Scrapped"] = "SCRAPPED";
})(SerialTraceabilityResponseSerialStatusEnum || (SerialTraceabilityResponseSerialStatusEnum = {}));
;
function isOptionalSerialTraceabilityResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSerialTraceabilityResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSerialTraceabilityResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSerialTraceabilityResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSerialTraceabilityResponsePropertyNames('downstream', 'serialNumber', 'serialUnitId', 'stockItemId', 'upstream', 'warrantyHolds');
    const optionalStringProperties = createSerialTraceabilityResponseOptionalProperties({ name: 'lotId', nullable: false }, { name: 'serialNumber', nullable: false }, { name: 'serialStatus', nullable: false }, { name: 'serialUnitId', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createSerialTraceabilityResponseOptionalProperties();
    const optionalBooleanProperties = createSerialTraceabilityResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSerialTraceabilityResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSerialTraceabilityResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSerialTraceabilityResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SerialUnitResponseStatusEnum;
(function (SerialUnitResponseStatusEnum) {
    SerialUnitResponseStatusEnum["InStock"] = "IN_STOCK";
    SerialUnitResponseStatusEnum["Issued"] = "ISSUED";
    SerialUnitResponseStatusEnum["Returned"] = "RETURNED";
    SerialUnitResponseStatusEnum["Scrapped"] = "SCRAPPED";
})(SerialUnitResponseStatusEnum || (SerialUnitResponseStatusEnum = {}));
;
function isOptionalSerialUnitResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSerialUnitResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSerialUnitResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSerialUnitResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSerialUnitResponsePropertyNames('serialNumber', 'serialUnitId', 'status', 'stockItemId');
    const optionalStringProperties = createSerialUnitResponseOptionalProperties({ name: 'consumedAt', nullable: false }, { name: 'consumptionLedgerEntryId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'locationId', nullable: false }, { name: 'lotId', nullable: false }, { name: 'receiptLedgerEntryId', nullable: false }, { name: 'receivedAt', nullable: false }, { name: 'serialNumber', nullable: false }, { name: 'serialUnitId', nullable: false }, { name: 'status', nullable: false }, { name: 'stockItemId', nullable: false }, { name: 'updatedAt', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createSerialUnitResponseOptionalProperties();
    const optionalBooleanProperties = createSerialUnitResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSerialUnitResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSerialUnitResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSerialUnitResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ShortCloseTransferOrderRequestDispositionEnum;
(function (ShortCloseTransferOrderRequestDispositionEnum) {
    ShortCloseTransferOrderRequestDispositionEnum["LostInTransit"] = "LOST_IN_TRANSIT";
    ShortCloseTransferOrderRequestDispositionEnum["ReturnedToSource"] = "RETURNED_TO_SOURCE";
})(ShortCloseTransferOrderRequestDispositionEnum || (ShortCloseTransferOrderRequestDispositionEnum = {}));
;
function isOptionalShortCloseTransferOrderRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createShortCloseTransferOrderRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createShortCloseTransferOrderRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfShortCloseTransferOrderRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createShortCloseTransferOrderRequestPropertyNames('disposition', 'notes', 'reason');
    const optionalStringProperties = createShortCloseTransferOrderRequestOptionalProperties({ name: 'disposition', nullable: false }, { name: 'notes', nullable: false }, { name: 'reason', nullable: false });
    const optionalNumberProperties = createShortCloseTransferOrderRequestOptionalProperties();
    const optionalBooleanProperties = createShortCloseTransferOrderRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalShortCloseTransferOrderRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalShortCloseTransferOrderRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalShortCloseTransferOrderRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ShortageOptionDtoOptionTypeEnum;
(function (ShortageOptionDtoOptionTypeEnum) {
    ShortageOptionDtoOptionTypeEnum["Backorder"] = "BACKORDER";
    ShortageOptionDtoOptionTypeEnum["Substitute"] = "SUBSTITUTE";
    ShortageOptionDtoOptionTypeEnum["TransferIn"] = "TRANSFER_IN";
    ShortageOptionDtoOptionTypeEnum["EmergencyPurchase"] = "EMERGENCY_PURCHASE";
    ShortageOptionDtoOptionTypeEnum["CancelLine"] = "CANCEL_LINE";
})(ShortageOptionDtoOptionTypeEnum || (ShortageOptionDtoOptionTypeEnum = {}));
;
function isOptionalShortageOptionDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createShortageOptionDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createShortageOptionDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfShortageOptionDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createShortageOptionDtoPropertyNames('allocationId', 'description', 'optionType');
    const optionalStringProperties = createShortageOptionDtoOptionalProperties({ name: 'allocationId', nullable: false }, { name: 'description', nullable: false }, { name: 'expectedResolutionDate', nullable: false }, { name: 'optionType', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'substituteSku', nullable: false });
    const optionalNumberProperties = createShortageOptionDtoOptionalProperties({ name: 'availableQuantity', nullable: false }, { name: 'costDelta', nullable: false });
    const optionalBooleanProperties = createShortageOptionDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalShortageOptionDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalShortageOptionDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalShortageOptionDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ShortageResolutionResultDtoOptionTypeEnum;
(function (ShortageResolutionResultDtoOptionTypeEnum) {
    ShortageResolutionResultDtoOptionTypeEnum["Backorder"] = "BACKORDER";
    ShortageResolutionResultDtoOptionTypeEnum["Substitute"] = "SUBSTITUTE";
    ShortageResolutionResultDtoOptionTypeEnum["TransferIn"] = "TRANSFER_IN";
    ShortageResolutionResultDtoOptionTypeEnum["EmergencyPurchase"] = "EMERGENCY_PURCHASE";
    ShortageResolutionResultDtoOptionTypeEnum["CancelLine"] = "CANCEL_LINE";
})(ShortageResolutionResultDtoOptionTypeEnum || (ShortageResolutionResultDtoOptionTypeEnum = {}));
;
function isOptionalShortageResolutionResultDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createShortageResolutionResultDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createShortageResolutionResultDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfShortageResolutionResultDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createShortageResolutionResultDtoPropertyNames('allocationId', 'artifactType', 'idempotencyKey', 'optionType', 'resolvedAt', 'status');
    const optionalStringProperties = createShortageResolutionResultDtoOptionalProperties({ name: 'allocationId', nullable: false }, { name: 'artifactId', nullable: false }, { name: 'artifactType', nullable: false }, { name: 'idempotencyKey', nullable: false }, { name: 'optionType', nullable: false }, { name: 'resolvedAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createShortageResolutionResultDtoOptionalProperties();
    const optionalBooleanProperties = createShortageResolutionResultDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalShortageResolutionResultDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalShortageResolutionResultDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalShortageResolutionResultDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var ShortageResolveRequestOptionTypeEnum;
(function (ShortageResolveRequestOptionTypeEnum) {
    ShortageResolveRequestOptionTypeEnum["Backorder"] = "BACKORDER";
    ShortageResolveRequestOptionTypeEnum["Substitute"] = "SUBSTITUTE";
    ShortageResolveRequestOptionTypeEnum["TransferIn"] = "TRANSFER_IN";
    ShortageResolveRequestOptionTypeEnum["EmergencyPurchase"] = "EMERGENCY_PURCHASE";
    ShortageResolveRequestOptionTypeEnum["CancelLine"] = "CANCEL_LINE";
})(ShortageResolveRequestOptionTypeEnum || (ShortageResolveRequestOptionTypeEnum = {}));
;
function isOptionalShortageResolveRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createShortageResolveRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createShortageResolveRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfShortageResolveRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createShortageResolveRequestPropertyNames('allocationId', 'idempotencyKey', 'optionType', 'shortQuantity', 'sku');
    const optionalStringProperties = createShortageResolveRequestOptionalProperties({ name: 'allocationId', nullable: false }, { name: 'idempotencyKey', nullable: false }, { name: 'locationId', nullable: false }, { name: 'notes', nullable: false }, { name: 'optionType', nullable: false }, { name: 'sku', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'substituteSku', nullable: false }, { name: 'workorderLineId', nullable: false });
    const optionalNumberProperties = createShortageResolveRequestOptionalProperties({ name: 'shortQuantity', nullable: false });
    const optionalBooleanProperties = createShortageResolveRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalShortageResolveRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalShortageResolveRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalShortageResolveRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalSiteInventoryRollupResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSiteInventoryRollupResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSiteInventoryRollupResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSiteInventoryRollupResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSiteInventoryRollupResponsePropertyNames('nodes', 'siteId', 'totals');
    const optionalStringProperties = createSiteInventoryRollupResponseOptionalProperties({ name: 'siteId', nullable: false });
    const optionalNumberProperties = createSiteInventoryRollupResponseOptionalProperties();
    const optionalBooleanProperties = createSiteInventoryRollupResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSiteInventoryRollupResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSiteInventoryRollupResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSiteInventoryRollupResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalSiteRollupSummaryPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSiteRollupSummaryPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSiteRollupSummaryOptionalProperties(...properties) {
    return properties;
}
function instanceOfSiteRollupSummary(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSiteRollupSummaryPropertyNames('siteId', 'totals');
    const optionalStringProperties = createSiteRollupSummaryOptionalProperties({ name: 'siteId', nullable: false }, { name: 'siteName', nullable: false });
    const optionalNumberProperties = createSiteRollupSummaryOptionalProperties();
    const optionalBooleanProperties = createSiteRollupSummaryOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSiteRollupSummaryPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSiteRollupSummaryPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSiteRollupSummaryPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSnoozeReplenishmentPolicyRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSnoozeReplenishmentPolicyRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSnoozeReplenishmentPolicyRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSnoozeReplenishmentPolicyRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSnoozeReplenishmentPolicyRequestPropertyNames();
    const optionalStringProperties = createSnoozeReplenishmentPolicyRequestOptionalProperties({ name: 'snoozedUntil', nullable: false });
    const optionalNumberProperties = createSnoozeReplenishmentPolicyRequestOptionalProperties();
    const optionalBooleanProperties = createSnoozeReplenishmentPolicyRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSnoozeReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSnoozeReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSnoozeReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SourcingStrategyConfigRequestScopeTypeEnum;
(function (SourcingStrategyConfigRequestScopeTypeEnum) {
    SourcingStrategyConfigRequestScopeTypeEnum["SkuCategory"] = "SKU_CATEGORY";
    SourcingStrategyConfigRequestScopeTypeEnum["Site"] = "SITE";
    SourcingStrategyConfigRequestScopeTypeEnum["Default"] = "DEFAULT";
})(SourcingStrategyConfigRequestScopeTypeEnum || (SourcingStrategyConfigRequestScopeTypeEnum = {}));
;
var SourcingStrategyConfigRequestStrategyEnum;
(function (SourcingStrategyConfigRequestStrategyEnum) {
    SourcingStrategyConfigRequestStrategyEnum["Fifo"] = "FIFO";
    SourcingStrategyConfigRequestStrategyEnum["Fefo"] = "FEFO";
    SourcingStrategyConfigRequestStrategyEnum["Proximity"] = "PROXIMITY";
    SourcingStrategyConfigRequestStrategyEnum["HighestStock"] = "HIGHEST_STOCK";
})(SourcingStrategyConfigRequestStrategyEnum || (SourcingStrategyConfigRequestStrategyEnum = {}));
;
function isOptionalSourcingStrategyConfigRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSourcingStrategyConfigRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSourcingStrategyConfigRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSourcingStrategyConfigRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSourcingStrategyConfigRequestPropertyNames('scopeType', 'strategy');
    const optionalStringProperties = createSourcingStrategyConfigRequestOptionalProperties({ name: 'scopeType', nullable: false }, { name: 'scopeValue', nullable: false }, { name: 'strategy', nullable: false });
    const optionalNumberProperties = createSourcingStrategyConfigRequestOptionalProperties();
    const optionalBooleanProperties = createSourcingStrategyConfigRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSourcingStrategyConfigRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSourcingStrategyConfigRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSourcingStrategyConfigRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SourcingStrategyConfigResponseScopeTypeEnum;
(function (SourcingStrategyConfigResponseScopeTypeEnum) {
    SourcingStrategyConfigResponseScopeTypeEnum["SkuCategory"] = "SKU_CATEGORY";
    SourcingStrategyConfigResponseScopeTypeEnum["Site"] = "SITE";
    SourcingStrategyConfigResponseScopeTypeEnum["Default"] = "DEFAULT";
})(SourcingStrategyConfigResponseScopeTypeEnum || (SourcingStrategyConfigResponseScopeTypeEnum = {}));
;
var SourcingStrategyConfigResponseStrategyEnum;
(function (SourcingStrategyConfigResponseStrategyEnum) {
    SourcingStrategyConfigResponseStrategyEnum["Fifo"] = "FIFO";
    SourcingStrategyConfigResponseStrategyEnum["Fefo"] = "FEFO";
    SourcingStrategyConfigResponseStrategyEnum["Proximity"] = "PROXIMITY";
    SourcingStrategyConfigResponseStrategyEnum["HighestStock"] = "HIGHEST_STOCK";
})(SourcingStrategyConfigResponseStrategyEnum || (SourcingStrategyConfigResponseStrategyEnum = {}));
;
function isOptionalSourcingStrategyConfigResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSourcingStrategyConfigResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSourcingStrategyConfigResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSourcingStrategyConfigResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSourcingStrategyConfigResponsePropertyNames('active', 'configId', 'createdAt', 'scopeType', 'strategy', 'updatedAt');
    const optionalStringProperties = createSourcingStrategyConfigResponseOptionalProperties({ name: 'configId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'scopeType', nullable: false }, { name: 'scopeValue', nullable: false }, { name: 'strategy', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createSourcingStrategyConfigResponseOptionalProperties();
    const optionalBooleanProperties = createSourcingStrategyConfigResponseOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSourcingStrategyConfigResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSourcingStrategyConfigResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSourcingStrategyConfigResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalStorageLocationRollupNodePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createStorageLocationRollupNodePropertyNames(...propertyNames) {
    return propertyNames;
}
function createStorageLocationRollupNodeOptionalProperties(...properties) {
    return properties;
}
function instanceOfStorageLocationRollupNode(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createStorageLocationRollupNodePropertyNames('own', 'rolledUp', 'storageLocationId');
    const optionalStringProperties = createStorageLocationRollupNodeOptionalProperties({ name: 'name', nullable: false }, { name: 'status', nullable: false }, { name: 'storageLocationId', nullable: false }, { name: 'type', nullable: false });
    const optionalNumberProperties = createStorageLocationRollupNodeOptionalProperties();
    const optionalBooleanProperties = createStorageLocationRollupNodeOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalStorageLocationRollupNodePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalStorageLocationRollupNodePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalStorageLocationRollupNodePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SubmitCountRequestMeasurementMethodEnum;
(function (SubmitCountRequestMeasurementMethodEnum) {
    SubmitCountRequestMeasurementMethodEnum["ManualCount"] = "MANUAL_COUNT";
    SubmitCountRequestMeasurementMethodEnum["Dip"] = "DIP";
    SubmitCountRequestMeasurementMethodEnum["Gauge"] = "GAUGE";
    SubmitCountRequestMeasurementMethodEnum["Scale"] = "SCALE";
    SubmitCountRequestMeasurementMethodEnum["Meter"] = "METER";
    SubmitCountRequestMeasurementMethodEnum["Sensor"] = "SENSOR";
})(SubmitCountRequestMeasurementMethodEnum || (SubmitCountRequestMeasurementMethodEnum = {}));
;
function isOptionalSubmitCountRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubmitCountRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubmitCountRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubmitCountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubmitCountRequestPropertyNames('actualQuantity', 'auditorId', 'taskId');
    const optionalStringProperties = createSubmitCountRequestOptionalProperties({ name: 'auditorId', nullable: false }, { name: 'measurementMethod', nullable: false }, { name: 'taskId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'varianceReason', nullable: false });
    const optionalNumberProperties = createSubmitCountRequestOptionalProperties({ name: 'actualQuantity', nullable: false });
    const optionalBooleanProperties = createSubmitCountRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubmitCountRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubmitCountRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubmitCountRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SubmitRecountRequestMeasurementMethodEnum;
(function (SubmitRecountRequestMeasurementMethodEnum) {
    SubmitRecountRequestMeasurementMethodEnum["ManualCount"] = "MANUAL_COUNT";
    SubmitRecountRequestMeasurementMethodEnum["Dip"] = "DIP";
    SubmitRecountRequestMeasurementMethodEnum["Gauge"] = "GAUGE";
    SubmitRecountRequestMeasurementMethodEnum["Scale"] = "SCALE";
    SubmitRecountRequestMeasurementMethodEnum["Meter"] = "METER";
    SubmitRecountRequestMeasurementMethodEnum["Sensor"] = "SENSOR";
})(SubmitRecountRequestMeasurementMethodEnum || (SubmitRecountRequestMeasurementMethodEnum = {}));
;
function isOptionalSubmitRecountRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSubmitRecountRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSubmitRecountRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSubmitRecountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSubmitRecountRequestPropertyNames('actualQuantity', 'auditorId', 'permission', 'taskId');
    const optionalStringProperties = createSubmitRecountRequestOptionalProperties({ name: 'auditorId', nullable: false }, { name: 'measurementMethod', nullable: false }, { name: 'permission', nullable: false }, { name: 'taskId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'varianceReason', nullable: false });
    const optionalNumberProperties = createSubmitRecountRequestOptionalProperties({ name: 'actualQuantity', nullable: false });
    const optionalBooleanProperties = createSubmitRecountRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSubmitRecountRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSubmitRecountRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSubmitRecountRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SupplierStockHintViewAsOfSourceEnum;
(function (SupplierStockHintViewAsOfSourceEnum) {
    SupplierStockHintViewAsOfSourceEnum["Vendor"] = "VENDOR";
    SupplierStockHintViewAsOfSourceEnum["Fetch"] = "FETCH";
})(SupplierStockHintViewAsOfSourceEnum || (SupplierStockHintViewAsOfSourceEnum = {}));
;
var SupplierStockHintViewAvailabilityEnum;
(function (SupplierStockHintViewAvailabilityEnum) {
    SupplierStockHintViewAvailabilityEnum["Reported"] = "REPORTED";
    SupplierStockHintViewAvailabilityEnum["QuantityNotStated"] = "QUANTITY_NOT_STATED";
    SupplierStockHintViewAvailabilityEnum["StaleUnknown"] = "STALE_UNKNOWN";
})(SupplierStockHintViewAvailabilityEnum || (SupplierStockHintViewAvailabilityEnum = {}));
;
var SupplierStockHintViewIdentityKindEnum;
(function (SupplierStockHintViewIdentityKindEnum) {
    SupplierStockHintViewIdentityKindEnum["Ean"] = "EAN";
    SupplierStockHintViewIdentityKindEnum["BuyerArticle"] = "BUYER_ARTICLE";
    SupplierStockHintViewIdentityKindEnum["SupplierArticle"] = "SUPPLIER_ARTICLE";
})(SupplierStockHintViewIdentityKindEnum || (SupplierStockHintViewIdentityKindEnum = {}));
;
function isOptionalSupplierStockHintViewPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSupplierStockHintViewPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSupplierStockHintViewOptionalProperties(...properties) {
    return properties;
}
function instanceOfSupplierStockHintView(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSupplierStockHintViewPropertyNames('asOfSource', 'availability', 'chunkCount', 'chunksApplied', 'fetchedAt', 'identityKind', 'identityValue', 'snapshotComplete', 'vendorProfileId');
    const optionalStringProperties = createSupplierStockHintViewOptionalProperties({ name: 'articleEan', nullable: false }, { name: 'asOfSource', nullable: false }, { name: 'availability', nullable: false }, { name: 'buyersArticleId', nullable: false }, { name: 'description', nullable: false }, { name: 'fetchedAt', nullable: false }, { name: 'identityKind', nullable: false }, { name: 'identityValue', nullable: false }, { name: 'resolvedProductId', nullable: false }, { name: 'snapshotAsOf', nullable: false }, { name: 'supplierArticleCode', nullable: false }, { name: 'supplierRef', nullable: false }, { name: 'vendorProfileId', nullable: false });
    const optionalNumberProperties = createSupplierStockHintViewOptionalProperties({ name: 'chunkCount', nullable: false }, { name: 'chunksApplied', nullable: false }, { name: 'quantity', nullable: false });
    const optionalBooleanProperties = createSupplierStockHintViewOptionalProperties({ name: 'snapshotComplete', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSupplierStockHintViewPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSupplierStockHintViewPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSupplierStockHintViewPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSyncLogResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSyncLogResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSyncLogResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSyncLogResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSyncLogResponsePropertyNames('createdAt', 'outcome', 'scope', 'syncLogId', 'syncRunId');
    const optionalStringProperties = createSyncLogResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'errorMessage', nullable: false }, { name: 'hrLocationId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'outcome', nullable: false }, { name: 'payload', nullable: false }, { name: 'scope', nullable: false }, { name: 'startedAt', nullable: false }, { name: 'syncLogId', nullable: false }, { name: 'syncRunId', nullable: false }, { name: 'triggeredBy', nullable: false });
    const optionalNumberProperties = createSyncLogResponseOptionalProperties({ name: 'locationsCreated', nullable: false }, { name: 'locationsFailed', nullable: false }, { name: 'locationsProcessed', nullable: false }, { name: 'locationsUnchanged', nullable: false }, { name: 'locationsUpdated', nullable: false });
    const optionalBooleanProperties = createSyncLogResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSyncLogResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSyncLogResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSyncLogResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TraceabilityDocumentRefDocumentTypeEnum;
(function (TraceabilityDocumentRefDocumentTypeEnum) {
    TraceabilityDocumentRefDocumentTypeEnum["PurchaseOrder"] = "PURCHASE_ORDER";
    TraceabilityDocumentRefDocumentTypeEnum["Asn"] = "ASN";
    TraceabilityDocumentRefDocumentTypeEnum["GoodsReceipt"] = "GOODS_RECEIPT";
})(TraceabilityDocumentRefDocumentTypeEnum || (TraceabilityDocumentRefDocumentTypeEnum = {}));
;
function isOptionalTraceabilityDocumentRefPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTraceabilityDocumentRefPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTraceabilityDocumentRefOptionalProperties(...properties) {
    return properties;
}
function instanceOfTraceabilityDocumentRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTraceabilityDocumentRefPropertyNames('documentId', 'documentType');
    const optionalStringProperties = createTraceabilityDocumentRefOptionalProperties({ name: 'documentId', nullable: false }, { name: 'documentType', nullable: false }, { name: 'reference', nullable: false });
    const optionalNumberProperties = createTraceabilityDocumentRefOptionalProperties();
    const optionalBooleanProperties = createTraceabilityDocumentRefOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTraceabilityDocumentRefPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTraceabilityDocumentRefPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTraceabilityDocumentRefPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var TraceabilityMovementEventTypeEnum;
(function (TraceabilityMovementEventTypeEnum) {
    TraceabilityMovementEventTypeEnum["GoodsReceipt"] = "GOODS_RECEIPT";
    TraceabilityMovementEventTypeEnum["TransferIn"] = "TRANSFER_IN";
    TraceabilityMovementEventTypeEnum["Putaway"] = "PUTAWAY";
    TraceabilityMovementEventTypeEnum["ReturnToStock"] = "RETURN_TO_STOCK";
    TraceabilityMovementEventTypeEnum["AdjustmentIn"] = "ADJUSTMENT_IN";
    TraceabilityMovementEventTypeEnum["CountVarianceIn"] = "COUNT_VARIANCE_IN";
    TraceabilityMovementEventTypeEnum["GoodsIssue"] = "GOODS_ISSUE";
    TraceabilityMovementEventTypeEnum["WorkorderConsumption"] = "WORKORDER_CONSUMPTION";
    TraceabilityMovementEventTypeEnum["TransferOut"] = "TRANSFER_OUT";
    TraceabilityMovementEventTypeEnum["ScrapOut"] = "SCRAP_OUT";
    TraceabilityMovementEventTypeEnum["AdjustmentOut"] = "ADJUSTMENT_OUT";
    TraceabilityMovementEventTypeEnum["CountVarianceOut"] = "COUNT_VARIANCE_OUT";
    TraceabilityMovementEventTypeEnum["AdjustCycleCount"] = "ADJUST_CYCLE_COUNT";
    TraceabilityMovementEventTypeEnum["ReservationCreated"] = "RESERVATION_CREATED";
    TraceabilityMovementEventTypeEnum["ReservationReleased"] = "RESERVATION_RELEASED";
    TraceabilityMovementEventTypeEnum["AllocationCreated"] = "ALLOCATION_CREATED";
    TraceabilityMovementEventTypeEnum["AllocationReleased"] = "ALLOCATION_RELEASED";
    TraceabilityMovementEventTypeEnum["BackorderCreated"] = "BACKORDER_CREATED";
    TraceabilityMovementEventTypeEnum["BackorderResolved"] = "BACKORDER_RESOLVED";
    TraceabilityMovementEventTypeEnum["PickTaskCreated"] = "PICK_TASK_CREATED";
    TraceabilityMovementEventTypeEnum["PickTaskCompleted"] = "PICK_TASK_COMPLETED";
})(TraceabilityMovementEventTypeEnum || (TraceabilityMovementEventTypeEnum = {}));
;
function isOptionalTraceabilityMovementPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTraceabilityMovementPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTraceabilityMovementOptionalProperties(...properties) {
    return properties;
}
function instanceOfTraceabilityMovement(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTraceabilityMovementPropertyNames('changeInQuantity', 'eventType', 'ledgerEntryId', 'timestamp');
    const optionalStringProperties = createTraceabilityMovementOptionalProperties({ name: 'eventType', nullable: false }, { name: 'fromLocationId', nullable: false }, { name: 'ledgerEntryId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'lotId', nullable: false }, { name: 'notes', nullable: false }, { name: 'sourceTransactionId', nullable: false }, { name: 'timestamp', nullable: false }, { name: 'toLocationId', nullable: false });
    const optionalNumberProperties = createTraceabilityMovementOptionalProperties({ name: 'changeInQuantity', nullable: false }, { name: 'quantityAfter', nullable: false });
    const optionalBooleanProperties = createTraceabilityMovementOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTraceabilityMovementPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTraceabilityMovementPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTraceabilityMovementPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalTraceabilityUpstreamPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTraceabilityUpstreamPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTraceabilityUpstreamOptionalProperties(...properties) {
    return properties;
}
function instanceOfTraceabilityUpstream(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTraceabilityUpstreamPropertyNames('documents');
    const optionalStringProperties = createTraceabilityUpstreamOptionalProperties({ name: 'receivedAt', nullable: false }, { name: 'vendorId', nullable: false });
    const optionalNumberProperties = createTraceabilityUpstreamOptionalProperties();
    const optionalBooleanProperties = createTraceabilityUpstreamOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTraceabilityUpstreamPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTraceabilityUpstreamPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTraceabilityUpstreamPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalTransferPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTransferPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTransferOptionalProperties(...properties) {
    return properties;
}
function instanceOfTransfer(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTransferPropertyNames();
    const optionalStringProperties = createTransferOptionalProperties({ name: 'movedAt', nullable: false });
    const optionalNumberProperties = createTransferOptionalProperties();
    const optionalBooleanProperties = createTransferOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTransferPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTransferPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTransferPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTransferOrderLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTransferOrderLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTransferOrderLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTransferOrderLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTransferOrderLineRequestPropertyNames('requestedQty', 'sku');
    const optionalStringProperties = createTransferOrderLineRequestOptionalProperties({ name: 'sku', nullable: false });
    const optionalNumberProperties = createTransferOrderLineRequestOptionalProperties({ name: 'requestedQty', nullable: false });
    const optionalBooleanProperties = createTransferOrderLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTransferOrderLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTransferOrderLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTransferOrderLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTransferOrderLineResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTransferOrderLineResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTransferOrderLineResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTransferOrderLineResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTransferOrderLineResponsePropertyNames();
    const optionalStringProperties = createTransferOrderLineResponseOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'lineId', nullable: false }, { name: 'lotId', nullable: false }, { name: 'lotNumber', nullable: false }, { name: 'sku', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createTransferOrderLineResponseOptionalProperties({ name: 'dispatchedQty', nullable: false }, { name: 'lineNumber', nullable: false }, { name: 'receivedQty', nullable: false }, { name: 'requestedQty', nullable: false });
    const optionalBooleanProperties = createTransferOrderLineResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTransferOrderLineResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTransferOrderLineResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTransferOrderLineResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var TransferOrderResponseShortCloseDispositionEnum;
(function (TransferOrderResponseShortCloseDispositionEnum) {
    TransferOrderResponseShortCloseDispositionEnum["LostInTransit"] = "LOST_IN_TRANSIT";
    TransferOrderResponseShortCloseDispositionEnum["ReturnedToSource"] = "RETURNED_TO_SOURCE";
})(TransferOrderResponseShortCloseDispositionEnum || (TransferOrderResponseShortCloseDispositionEnum = {}));
;
var TransferOrderResponseStatusEnum;
(function (TransferOrderResponseStatusEnum) {
    TransferOrderResponseStatusEnum["Draft"] = "DRAFT";
    TransferOrderResponseStatusEnum["Approved"] = "APPROVED";
    TransferOrderResponseStatusEnum["Dispatched"] = "DISPATCHED";
    TransferOrderResponseStatusEnum["PartiallyReceived"] = "PARTIALLY_RECEIVED";
    TransferOrderResponseStatusEnum["Received"] = "RECEIVED";
    TransferOrderResponseStatusEnum["ShortClosed"] = "SHORT_CLOSED";
    TransferOrderResponseStatusEnum["Cancelled"] = "CANCELLED";
})(TransferOrderResponseStatusEnum || (TransferOrderResponseStatusEnum = {}));
;
function isOptionalTransferOrderResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTransferOrderResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTransferOrderResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTransferOrderResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTransferOrderResponsePropertyNames();
    const optionalStringProperties = createTransferOrderResponseOptionalProperties({ name: 'approvedBy', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'destinationLocationId', nullable: false }, { name: 'destinationStorageLocationId', nullable: false }, { name: 'dispatchedBy', nullable: false }, { name: 'notes', nullable: false }, { name: 'shortCloseDisposition', nullable: false }, { name: 'shortCloseNotes', nullable: false }, { name: 'shortCloseReason', nullable: false }, { name: 'shortClosedAt', nullable: false }, { name: 'shortClosedBy', nullable: false }, { name: 'sourceLocationId', nullable: false }, { name: 'sourceStorageLocationId', nullable: false }, { name: 'status', nullable: false }, { name: 'transferOrderId', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createTransferOrderResponseOptionalProperties();
    const optionalBooleanProperties = createTransferOrderResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTransferOrderResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTransferOrderResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTransferOrderResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTransferQuantityLineRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTransferQuantityLineRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTransferQuantityLineRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTransferQuantityLineRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTransferQuantityLineRequestPropertyNames('lineId', 'quantity');
    const optionalStringProperties = createTransferQuantityLineRequestOptionalProperties({ name: 'lineId', nullable: false }, { name: 'lotNumber', nullable: false });
    const optionalNumberProperties = createTransferQuantityLineRequestOptionalProperties({ name: 'quantity', nullable: false });
    const optionalBooleanProperties = createTransferQuantityLineRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTransferQuantityLineRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTransferQuantityLineRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTransferQuantityLineRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var UpdateCycleCountPlanStatusRequestStatusEnum;
(function (UpdateCycleCountPlanStatusRequestStatusEnum) {
    UpdateCycleCountPlanStatusRequestStatusEnum["Planned"] = "PLANNED";
    UpdateCycleCountPlanStatusRequestStatusEnum["Started"] = "STARTED";
    UpdateCycleCountPlanStatusRequestStatusEnum["CompletedPendingApproval"] = "COMPLETED_PENDING_APPROVAL";
    UpdateCycleCountPlanStatusRequestStatusEnum["Approved"] = "APPROVED";
    UpdateCycleCountPlanStatusRequestStatusEnum["Rejected"] = "REJECTED";
    UpdateCycleCountPlanStatusRequestStatusEnum["Cancelled"] = "CANCELLED";
})(UpdateCycleCountPlanStatusRequestStatusEnum || (UpdateCycleCountPlanStatusRequestStatusEnum = {}));
;
function isOptionalUpdateCycleCountPlanStatusRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateCycleCountPlanStatusRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateCycleCountPlanStatusRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateCycleCountPlanStatusRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateCycleCountPlanStatusRequestPropertyNames('status');
    const optionalStringProperties = createUpdateCycleCountPlanStatusRequestOptionalProperties({ name: 'status', nullable: false });
    const optionalNumberProperties = createUpdateCycleCountPlanStatusRequestOptionalProperties();
    const optionalBooleanProperties = createUpdateCycleCountPlanStatusRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateCycleCountPlanStatusRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateCycleCountPlanStatusRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateCycleCountPlanStatusRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpdateCycleCountScheduleRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateCycleCountScheduleRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateCycleCountScheduleRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateCycleCountScheduleRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateCycleCountScheduleRequestPropertyNames();
    const optionalStringProperties = createUpdateCycleCountScheduleRequestOptionalProperties({ name: 'nextDueDate', nullable: false }, { name: 'skuCategory', nullable: false }, { name: 'zoneId', nullable: false });
    const optionalNumberProperties = createUpdateCycleCountScheduleRequestOptionalProperties({ name: 'frequencyDays', nullable: false });
    const optionalBooleanProperties = createUpdateCycleCountScheduleRequestOptionalProperties({ name: 'active', nullable: false }, { name: 'autoCreatePlan', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateCycleCountScheduleRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateCycleCountScheduleRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateCycleCountScheduleRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUpdateCycleCountToleranceRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateCycleCountToleranceRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateCycleCountToleranceRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateCycleCountToleranceRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateCycleCountToleranceRequestPropertyNames('active');
    const optionalStringProperties = createUpdateCycleCountToleranceRequestOptionalProperties();
    const optionalNumberProperties = createUpdateCycleCountToleranceRequestOptionalProperties({ name: 'absoluteTolerance', nullable: false }, { name: 'percentageTolerance', nullable: false });
    const optionalBooleanProperties = createUpdateCycleCountToleranceRequestOptionalProperties({ name: 'active', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateCycleCountToleranceRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateCycleCountToleranceRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateCycleCountToleranceRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var UpdatePickListStatusRequestStatusEnum;
(function (UpdatePickListStatusRequestStatusEnum) {
    UpdatePickListStatusRequestStatusEnum["Draft"] = "DRAFT";
    UpdatePickListStatusRequestStatusEnum["ReadyToPick"] = "READY_TO_PICK";
    UpdatePickListStatusRequestStatusEnum["InProgress"] = "IN_PROGRESS";
    UpdatePickListStatusRequestStatusEnum["Completed"] = "COMPLETED";
    UpdatePickListStatusRequestStatusEnum["Cancelled"] = "CANCELLED";
})(UpdatePickListStatusRequestStatusEnum || (UpdatePickListStatusRequestStatusEnum = {}));
;
function isOptionalUpdatePickListStatusRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdatePickListStatusRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdatePickListStatusRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdatePickListStatusRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdatePickListStatusRequestPropertyNames('status');
    const optionalStringProperties = createUpdatePickListStatusRequestOptionalProperties({ name: 'status', nullable: false });
    const optionalNumberProperties = createUpdatePickListStatusRequestOptionalProperties();
    const optionalBooleanProperties = createUpdatePickListStatusRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdatePickListStatusRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdatePickListStatusRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdatePickListStatusRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum;
(function (UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum) {
    UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum["InternalTransfer"] = "INTERNAL_TRANSFER";
    UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum["Purchase"] = "PURCHASE";
    UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum["Either"] = "EITHER";
})(UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum || (UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum = {}));
;
function isOptionalUpdateReplenishmentPolicyRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUpdateReplenishmentPolicyRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUpdateReplenishmentPolicyRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUpdateReplenishmentPolicyRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUpdateReplenishmentPolicyRequestPropertyNames('maximumQuantity', 'minimumQuantity');
    const optionalStringProperties = createUpdateReplenishmentPolicyRequestOptionalProperties({ name: 'preferredSourceType', nullable: false });
    const optionalNumberProperties = createUpdateReplenishmentPolicyRequestOptionalProperties({ name: 'leadTimeDaysOverride', nullable: false }, { name: 'maximumQuantity', nullable: false }, { name: 'minimumQuantity', nullable: false }, { name: 'orderMultiple', nullable: false });
    const optionalBooleanProperties = createUpdateReplenishmentPolicyRequestOptionalProperties({ name: 'active', nullable: false }, { name: 'minimumLessThanMaximum', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUpdateReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUpdateReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUpdateReplenishmentPolicyRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalValuationReportResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createValuationReportResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createValuationReportResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfValuationReportResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createValuationReportResponsePropertyNames('rows', 'totalOnHandValue');
    const optionalStringProperties = createValuationReportResponseOptionalProperties({ name: 'asOf', nullable: false }, { name: 'locationId', nullable: false });
    const optionalNumberProperties = createValuationReportResponseOptionalProperties({ name: 'totalOnHandValue', nullable: false });
    const optionalBooleanProperties = createValuationReportResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalValuationReportResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalValuationReportResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalValuationReportResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalValuationRowPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createValuationRowPropertyNames(...propertyNames) {
    return propertyNames;
}
function createValuationRowOptionalProperties(...properties) {
    return properties;
}
function instanceOfValuationRow(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createValuationRowPropertyNames('costingMethod', 'onHand', 'onHandValue', 'stockItemId', 'uncosted');
    const optionalStringProperties = createValuationRowOptionalProperties({ name: 'costingMethod', nullable: false }, { name: 'stockItemId', nullable: false });
    const optionalNumberProperties = createValuationRowOptionalProperties({ name: 'onHand', nullable: false }, { name: 'onHandValue', nullable: false }, { name: 'unitCostCurrent', nullable: false });
    const optionalBooleanProperties = createValuationRowOptionalProperties({ name: 'uncosted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalValuationRowPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalValuationRowPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalValuationRowPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalVarianceSummaryResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createVarianceSummaryResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createVarianceSummaryResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfVarianceSummaryResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createVarianceSummaryResponsePropertyNames('expectedQuantity', 'lineId', 'productId', 'receivedQuantity', 'varianceQuantity', 'varianceType');
    const optionalStringProperties = createVarianceSummaryResponseOptionalProperties({ name: 'lineId', nullable: false }, { name: 'productId', nullable: false }, { name: 'unitOfMeasure', nullable: false }, { name: 'varianceType', nullable: false });
    const optionalNumberProperties = createVarianceSummaryResponseOptionalProperties({ name: 'expectedQuantity', nullable: false }, { name: 'receivedQuantity', nullable: false }, { name: 'varianceQuantity', nullable: false });
    const optionalBooleanProperties = createVarianceSummaryResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalVarianceSummaryResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalVarianceSummaryResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalVarianceSummaryResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * Positivity Inventory API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalWarrantyHoldRefPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createWarrantyHoldRefPropertyNames(...propertyNames) {
    return propertyNames;
}
function createWarrantyHoldRefOptionalProperties(...properties) {
    return properties;
}
function instanceOfWarrantyHoldRef(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createWarrantyHoldRefPropertyNames('partReturnId', 'status');
    const optionalStringProperties = createWarrantyHoldRefOptionalProperties({ name: 'claimId', nullable: false }, { name: 'disposition', nullable: false }, { name: 'partReturnId', nullable: false }, { name: 'requestedAt', nullable: false }, { name: 'shippedAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createWarrantyHoldRefOptionalProperties();
    const optionalBooleanProperties = createWarrantyHoldRefOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalWarrantyHoldRefPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalWarrantyHoldRefPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalWarrantyHoldRefPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { ASNService, AdjustmentResponseRequiredApprovalTierEnum, AdjustmentResponseStatusEnum, ApiModule, AsnResponseStatusEnum, BASE_PATH, BackorderResponseResolutionSourceEnum, BackorderResponseStatusEnum, BackordersService, COLLECTION_FORMATS, Configuration, ConsumptionService, CostingMethodConfigRequestMethodEnum, CostingMethodConfigRequestScopeTypeEnum, CostingMethodConfigResponseMethodEnum, CostingMethodConfigResponseScopeTypeEnum, CountEntryResponseMeasurementMethodEnum, CountResponseTaskStatusEnum, CreateReplenishmentPolicyRequestPreferredSourceTypeEnum, CreateScrapRequestReasonCodeEnum, CycleCountAPIService, CycleCountAdjustmentsService, CycleCountOperationsService, CycleCountPlansService, CycleCountQueryService, CycleCountSchedulesService, CycleCountTaskResponseStatusEnum, CycleCountTolerancesService, InterferingMovementResponseEventTypeEnum, InventoryAvailabilityService, InventoryBulkIngestAPIService, InventoryLedgerEntryDtoEventTypeEnum, InventoryLedgerService, InventoryLocationsService, InventoryManagementService, InventoryReferenceDataService, InventoryReservationsService, InventoryRevaluationService, InventoryRollupService, InventorySitesService, InventoryValuationService, LocationSyncService, LotResponseStatusEnum, LotStatusUpdateRequestStatusEnum, LotTraceabilityResponseLotStatusEnum, LotsService, PickListResponseStatusEnum, PickListsService, PickTaskResponseStatusEnum, PickingListsService, PurchaseSuggestionResponseStatusEnum, PurchaseSuggestionResponseSuggestedVendorTypeEnum, PurchaseSuggestionsService, PutawayExecutionRequestOverrideReasonCodeEnum, PutawayExecutionService, PutawayService, ReallocationService, ReceivingService, RecordMovementRequestMovementTypeEnum, ReplenishmentNeedResponseLeadTimeSourceEnum, ReplenishmentService, ReturnsService, RevaluationResponseCostingMethodEnum, RevaluationResponseRequiredApprovalTierEnum, RevaluationResponseStatusEnum, ScrapResponseCostSourceEnum, ScrapResponseReasonCodeEnum, ScrapResponseRequiredApprovalTierEnum, ScrapResponseStatusEnum, ScrapsService, SerialTraceabilityResponseSerialStatusEnum, SerialUnitResponseStatusEnum, SerialUnitsService, ShortCloseTransferOrderRequestDispositionEnum, ShortageOptionDtoOptionTypeEnum, ShortageResolutionResultDtoOptionTypeEnum, ShortageResolutionService, ShortageResolveRequestOptionTypeEnum, SourcingStrategiesService, SourcingStrategyConfigRequestScopeTypeEnum, SourcingStrategyConfigRequestStrategyEnum, SourcingStrategyConfigResponseScopeTypeEnum, SourcingStrategyConfigResponseStrategyEnum, StockMovementsService, SubmitCountRequestMeasurementMethodEnum, SubmitRecountRequestMeasurementMethodEnum, SupplierStockHintViewAsOfSourceEnum, SupplierStockHintViewAvailabilityEnum, SupplierStockHintViewIdentityKindEnum, SupplierStockHintsService, TraceabilityDocumentRefDocumentTypeEnum, TraceabilityMovementEventTypeEnum, TraceabilityService, TransferOrderResponseShortCloseDispositionEnum, TransferOrderResponseStatusEnum, TransferOrdersService, UpdateCycleCountPlanStatusRequestStatusEnum, UpdatePickListStatusRequestStatusEnum, UpdateReplenishmentPolicyRequestPreferredSourceTypeEnum, ValuationMethodsService, instanceOfAdjustmentRequestResponse, instanceOfAdjustmentResponse, instanceOfApiError, instanceOfApproveAdjustmentRequest, instanceOfApproveScrapRequest, instanceOfAsnLineResponse, instanceOfAsnResponse, instanceOfAvailabilityView, instanceOfBackorderResponse, instanceOfBulkIngestRequestInventoryBulkIngestRecord, instanceOfBulkIngestResponse, instanceOfBulkIngestResult, instanceOfConfirmPickTaskRequest, instanceOfConsumeItemLine, instanceOfConsumeItemsRequest, instanceOfConsumptionResponse, instanceOfConvertPurchaseSuggestionsRequest, instanceOfConvertPurchaseSuggestionsResponse, instanceOfCostingMethodConfigRequest, instanceOfCostingMethodConfigResponse, instanceOfCountEntryResponse, instanceOfCountResponse, instanceOfCreateAdjustmentRequest, instanceOfCreateAdjustmentRequestDto, instanceOfCreateAsnLineRequest, instanceOfCreateAsnRequest, instanceOfCreateCycleCountPlanRequest, instanceOfCreateCycleCountScheduleRequest, instanceOfCreateCycleCountToleranceRequest, instanceOfCreateGoodsReceiptLineRequest, instanceOfCreateGoodsReceiptRequest, instanceOfCreatePickListRequest, instanceOfCreateReceivingSessionRequest, instanceOfCreateReplenishmentPolicyRequest, instanceOfCreateReservationRequest, instanceOfCreateRevaluationRequest, instanceOfCreateScrapRequest, instanceOfCreateTransferOrderRequest, instanceOfCrossDockRequest, instanceOfCrossDockResponse, instanceOfCycleCountPlanResponse, instanceOfCycleCountScheduleResponse, instanceOfCycleCountTaskResponse, instanceOfCycleCountToleranceResponse, instanceOfDeactivateLocationRequest, instanceOfDeactivateLocationResponse, instanceOfDismissPurchaseSuggestionRequest, instanceOfDispatchTransferOrderRequest, instanceOfFieldError, instanceOfGeneratePutawayTasksRequest, instanceOfGoodsReceiptLineResponse, instanceOfGoodsReceiptResponse, instanceOfInterferingMovementResponse, instanceOfInventoryAvailabilityResponse, instanceOfInventoryBulkIngestRecord, instanceOfInventoryLedgerEntryDto, instanceOfLeadTimeView, instanceOfLedgerPage, instanceOfLocationAvailabilityDto, instanceOfLocationInventoryInquiryResponse, instanceOfLocationInventoryItem, instanceOfLocationInventoryItemsResponse, instanceOfLocationInventoryRollupResponse, instanceOfLocationSyncRunResponse, instanceOfLotDetailResponse, instanceOfLotExpirationUpdateRequest, instanceOfLotLocationOnHand, instanceOfLotResponse, instanceOfLotStatusUpdateRequest, instanceOfLotTraceabilityResponse, instanceOfMovedItem, instanceOfPickListResponse, instanceOfPickTaskResponse, instanceOfPromoteAllocationRequest, instanceOfPurchaseSuggestionResponse, instanceOfPutawayExecutionRequest, instanceOfPutawayExecutionResponse, instanceOfPutawayLineItemRequest, instanceOfPutawayTaskResponse, instanceOfReallocateRequest, instanceOfReallocateResponse, instanceOfReasonCodeDto, instanceOfReceiveItemsRequest, instanceOfReceiveItemsResponse, instanceOfReceiveLineRequest, instanceOfReceiveTransferOrderRequest, instanceOfReceivingLineResponse, instanceOfReceivingSessionResponse, instanceOfRecordMovementRequest, instanceOfRejectAdjustmentRequest, instanceOfRejectRevaluationRequest, instanceOfRejectScrapRequest, instanceOfReplenishmentNeedResponse, instanceOfReplenishmentPolicyResponse, instanceOfReplenishmentScanResultResponse, instanceOfReplenishmentTaskResponse, instanceOfReservationResponse, instanceOfReturnLineDto, instanceOfReturnSubmissionResultDto, instanceOfReturnSubmitRequest, instanceOfReturnableItemDto, instanceOfRevaluationResponse, instanceOfRollupQuantities, instanceOfScrapResponse, instanceOfSerialTraceabilityResponse, instanceOfSerialUnitResponse, instanceOfShortCloseTransferOrderRequest, instanceOfShortageOptionDto, instanceOfShortageResolutionResultDto, instanceOfShortageResolveRequest, instanceOfSiteInventoryRollupResponse, instanceOfSiteRollupSummary, instanceOfSnoozeReplenishmentPolicyRequest, instanceOfSourcingStrategyConfigRequest, instanceOfSourcingStrategyConfigResponse, instanceOfStorageLocationRollupNode, instanceOfSubmitCountRequest, instanceOfSubmitRecountRequest, instanceOfSupplierStockHintView, instanceOfSyncLogResponse, instanceOfTraceabilityDocumentRef, instanceOfTraceabilityMovement, instanceOfTraceabilityUpstream, instanceOfTransfer, instanceOfTransferOrderLineRequest, instanceOfTransferOrderLineResponse, instanceOfTransferOrderResponse, instanceOfTransferQuantityLineRequest, instanceOfUpdateCycleCountPlanStatusRequest, instanceOfUpdateCycleCountScheduleRequest, instanceOfUpdateCycleCountToleranceRequest, instanceOfUpdatePickListStatusRequest, instanceOfUpdateReplenishmentPolicyRequest, instanceOfValuationReportResponse, instanceOfValuationRow, instanceOfVarianceSummaryResponse, instanceOfWarrantyHoldRef, provideApi };
//# sourceMappingURL=durion-sdk-inventory.mjs.map
