import * as i0 from '@angular/core';
import { InjectionToken, Optional, Inject, Injectable, SkipSelf, NgModule, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HttpContext } from '@angular/common/http';

const BASE_PATH = new InjectionToken('basePath');
const COLLECTION_FORMATS = {
    'csv': ',',
    'tsv': '   ',
    'ssv': ' ',
    'pipes': '|'
};

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
class CustomHttpParameterCodec {
    encodeKey(k) {
        return encodeURIComponent(k);
    }
    encodeValue(v) {
        return encodeURIComponent(v);
    }
    decodeKey(k) {
        return decodeURIComponent(k);
    }
    decodeValue(v) {
        return decodeURIComponent(v);
    }
}
class IdentityHttpParameterCodec {
    encodeKey(k) {
        return k;
    }
    encodeValue(v) {
        return v;
    }
    decodeKey(k) {
        return k;
    }
    decodeValue(v) {
        return v;
    }
}

class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys;
    username;
    password;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken;
    basePath;
    withCredentials;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials;
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials } = {}) {
        if (apiKeys) {
            this.apiKeys = apiKeys;
        }
        if (username !== undefined) {
            this.username = username;
        }
        if (password !== undefined) {
            this.password = password;
        }
        if (accessToken !== undefined) {
            this.accessToken = accessToken;
        }
        if (basePath !== undefined) {
            this.basePath = basePath;
        }
        if (withCredentials !== undefined) {
            this.withCredentials = withCredentials;
        }
        if (encoder) {
            this.encoder = encoder;
        }
        this.encodeParam = encodeParam ?? (param => this.defaultEncodeParam(param));
        this.credentials = credentials ?? {};
        // init default bearerAuth credential
        if (!this.credentials['bearerAuth']) {
            this.credentials['bearerAuth'] = () => {
                return typeof this.accessToken === 'function'
                    ? this.accessToken()
                    : this.accessToken;
            };
        }
    }
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes) {
        if (contentTypes.length === 0) {
            return undefined;
        }
        const type = contentTypes.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return contentTypes[0];
        }
        return type;
    }
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts) {
        if (accepts.length === 0) {
            return undefined;
        }
        const type = accepts.find((x) => this.isJsonMime(x));
        if (type === undefined) {
            return accepts[0];
        }
        return type;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
    lookupCredential(key) {
        const value = this.credentials[key];
        return typeof value === 'function'
            ? value()
            : value;
    }
    addCredentialToHeaders(credentialKey, headerName, headers, prefix) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? headers.set(headerName, (prefix ?? '') + value)
            : headers;
    }
    addCredentialToQuery(credentialKey, paramName, query) {
        const value = this.lookupCredential(credentialKey);
        return value
            ? query.set(paramName, value)
            : query;
    }
    defaultEncodeParam(param) {
        // This implementation exists as fallback for missing configuration
        // and for backwards compatibility to older typescript-angular generator versions.
        // It only works for the 'simple' parameter style.
        // Date-handling only works for the 'date-time' format.
        // All other styles and Date-formats are probably handled incorrectly.
        //
        // But: if that's all you need (i.e.: the most common use-case): no need for customization!
        const value = param.dataFormat === 'date-time' && param.value instanceof Date
            ? param.value.toISOString()
            : param.value;
        return encodeURIComponent(String(value));
    }
}

var QueryParamStyle;
(function (QueryParamStyle) {
    QueryParamStyle[QueryParamStyle["Json"] = 0] = "Json";
    QueryParamStyle[QueryParamStyle["Form"] = 1] = "Form";
    QueryParamStyle[QueryParamStyle["DeepObject"] = 2] = "DeepObject";
    QueryParamStyle[QueryParamStyle["SpaceDelimited"] = 3] = "SpaceDelimited";
    QueryParamStyle[QueryParamStyle["PipeDelimited"] = 4] = "PipeDelimited";
})(QueryParamStyle || (QueryParamStyle = {}));
class OpenApiHttpParams {
    params = new Map();
    defaults;
    encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder, defaults) {
        this.encoder = encoder || new CustomHttpParameterCodec();
        this.defaults = {
            explode: defaults?.explode ?? true,
            delimiter: defaults?.delimiter ?? ",",
        };
    }
    resolveOptions(local) {
        return {
            explode: local?.explode ?? this.defaults.explode,
            delimiter: local?.delimiter ?? this.defaults.delimiter,
        };
    }
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key, values, options) {
        const arr = Array.isArray(values) ? values.slice() : [values];
        const opts = this.resolveOptions(options);
        this.params.set(key, { values: arr, options: opts });
        return this;
    }
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key, value, options) {
        const entry = this.params.get(key);
        if (entry) {
            // If new options provided, override the stored options for subsequent serialization
            if (options) {
                entry.options = this.resolveOptions({ ...entry.options, ...options });
            }
            entry.values.push(value);
        }
        else {
            this.set(key, [value], options);
        }
        return this;
    }
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString() {
        const records = this.toRecord();
        const parts = [];
        for (const key in records) {
            parts.push(`${key}=${records[key]}`);
        }
        return parts.join("&");
    }
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord() {
        const parts = {};
        for (const [key, entry] of this.params.entries()) {
            const encodedKey = this.encoder.encodeKey(key);
            if (entry.options.explode) {
                parts[encodedKey] = entry.values.map((v) => this.encoder.encodeValue(v));
            }
            else {
                const encodedValues = entry.values.map((v) => this.encoder.encodeValue(v));
                // join with the delimiter *unencoded*
                parts[encodedKey] = encodedValues.join(entry.options.delimiter);
            }
        }
        return parts;
    }
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams() {
        const records = this.toRecord();
        let httpParams = new HttpParams({ encoder: new IdentityHttpParameterCodec() });
        return httpParams.appendAll(records);
    }
}
function concatHttpParamsObject(httpParams, key, item, delimiter) {
    let keyAndValues = [];
    for (const k in item) {
        keyAndValues.push(k);
        const value = item[k];
        if (Array.isArray(value)) {
            keyAndValues.push(...value.map(convertToString));
        }
        else {
            keyAndValues.push(convertToString(value));
        }
    }
    return httpParams.set(key, keyAndValues, { explode: false, delimiter: delimiter });
}
function convertToString(value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    else {
        return value.toString();
    }
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class BaseService {
    basePath = 'http://api-gateway.local/security-service';
    defaultHeaders = new HttpHeaders();
    configuration;
    encoder;
    constructor(basePath, configuration) {
        this.configuration = configuration || new Configuration();
        if (typeof this.configuration.basePath !== 'string') {
            const firstBasePath = Array.isArray(basePath) ? basePath[0] : undefined;
            if (firstBasePath != undefined) {
                basePath = firstBasePath;
            }
            if (typeof basePath !== 'string') {
                basePath = this.basePath;
            }
            this.configuration.basePath = basePath;
        }
        this.encoder = this.configuration.encoder || new CustomHttpParameterCodec();
    }
    canConsumeForm(consumes) {
        return consumes.indexOf('multipart/form-data') !== -1;
    }
    addToHttpParams(httpParams, key, value, paramStyle, explode) {
        if (value === null || value === undefined) {
            return httpParams;
        }
        if (paramStyle === QueryParamStyle.DeepObject) {
            if (typeof value !== 'object') {
                throw Error(`An object must be provided for key ${key} as it is a deep object`);
            }
            return Object.keys(value).reduce((hp, k) => hp.append(`${key}[${k}]`, value[k]), httpParams);
        }
        else if (paramStyle === QueryParamStyle.Json) {
            return httpParams.append(key, JSON.stringify(value));
        }
        else {
            // Form-style, SpaceDelimited or PipeDelimited
            if (Object(value) !== value) {
                // If it is a primitive type, add its string representation
                return httpParams.append(key, value.toString());
            }
            else if (value instanceof Date) {
                return httpParams.append(key, value.toISOString());
            }
            else if (Array.isArray(value)) {
                // Otherwise, if it's an array, add each element.
                if (paramStyle === QueryParamStyle.Form) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ',' });
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return httpParams.set(key, value, { explode: explode, delimiter: ' ' });
                }
                else {
                    // PipeDelimited
                    return httpParams.set(key, value, { explode: explode, delimiter: '|' });
                }
            }
            else {
                // Otherwise, if it's an object, add each field.
                if (paramStyle === QueryParamStyle.Form) {
                    if (explode) {
                        Object.keys(value).forEach(k => {
                            httpParams = this.addToHttpParams(httpParams, k, value[k], paramStyle, explode);
                        });
                        return httpParams;
                    }
                    else {
                        return concatHttpParamsObject(httpParams, key, value, ',');
                    }
                }
                else if (paramStyle === QueryParamStyle.SpaceDelimited) {
                    return concatHttpParamsObject(httpParams, key, value, ' ');
                }
                else {
                    // PipeDelimited
                    return concatHttpParamsObject(httpParams, key, value, '|');
                }
            }
        }
    }
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AdminAccountStateAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    disableUserAccount(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling disableUserAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/disable`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    enableUserAccount(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling enableUserAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/enable`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    expireUserAccount(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling expireUserAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/expire-account`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    expireUserCredentials(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling expireUserCredentials.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/expire-credentials`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUserAccountState(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getUserAccountState.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/account-state`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    unlockUserAccount(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling unlockUserAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/unlock`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AdminAccountStateAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AdminAccountStateAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AdminAccountStateAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AuditService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    createAuditEvent(auditLogEventRequest, observe = 'body', reportProgress = false, options) {
        if (auditLogEventRequest === null || auditLogEventRequest === undefined) {
            throw new Error('Required parameter auditLogEventRequest was null or undefined when calling createAuditEvent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/events`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: auditLogEventRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createPricingSnapshot(pricingSnapshotRequest, observe = 'body', reportProgress = false, options) {
        if (pricingSnapshotRequest === null || pricingSnapshotRequest === undefined) {
            throw new Error('Required parameter pricingSnapshotRequest was null or undefined when calling createPricingSnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/pricing-snapshots`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: pricingSnapshotRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getAuditEvent(eventId, observe = 'body', reportProgress = false, options) {
        if (eventId === null || eventId === undefined) {
            throw new Error('Required parameter eventId was null or undefined when calling getAuditEvent.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/events/${this.configuration.encodeParam({ name: "eventId", value: eventId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPricingSnapshot(snapshotId, observe = 'body', reportProgress = false, options) {
        if (snapshotId === null || snapshotId === undefined) {
            throw new Error('Required parameter snapshotId was null or undefined when calling getPricingSnapshot.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/pricing-snapshots/${this.configuration.encodeParam({ name: "snapshotId", value: snapshotId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectAuditEventDelete(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/events/**`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    rejectAuditEventUpdate(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/events/**`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    searchAuditEvents(fromDate, toDate, actorId, workorderId, movementId, productId, sku, eventType, aggregateId, correlationId, reasonCode, pageToken, locationIds, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'fromDate', fromDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'toDate', toDate, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'actorId', actorId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'workorderId', workorderId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'movementId', movementId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'productId', productId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sku', sku, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'eventType', eventType, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'aggregateId', aggregateId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'correlationId', correlationId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'reasonCode', reasonCode, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'pageToken', pageToken, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'locationIds', locationIds, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/events`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AuditExportsService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getAuditExportJob(jobId, observe = 'body', reportProgress = false, options) {
        if (jobId === null || jobId === undefined) {
            throw new Error('Required parameter jobId was null or undefined when calling getAuditExportJob.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/exports/${this.configuration.encodeParam({ name: "jobId", value: jobId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    requestAuditExport(auditExportRequest, observe = 'body', reportProgress = false, options) {
        if (auditExportRequest === null || auditExportRequest === undefined) {
            throw new Error('Required parameter auditExportRequest was null or undefined when calling requestAuditExport.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/audit/exports`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: auditExportRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditExportsService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditExportsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuditExportsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AuthAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    activateAccount(activateAccountRequest, observe = 'body', reportProgress = false, options) {
        if (activateAccountRequest === null || activateAccountRequest === undefined) {
            throw new Error('Required parameter activateAccountRequest was null or undefined when calling activateAccount.');
        }
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/activate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: activateAccountRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    loginUser(loginRequest, observe = 'body', reportProgress = false, options) {
        if (loginRequest === null || loginRequest === undefined) {
            throw new Error('Required parameter loginRequest was null or undefined when calling loginUser.');
        }
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/login`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: loginRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    selfRegisterUser(selfRegistrationRequest, observe = 'body', reportProgress = false, options) {
        if (selfRegistrationRequest === null || selfRegistrationRequest === undefined) {
            throw new Error('Required parameter selfRegistrationRequest was null or undefined when calling selfRegisterUser.');
        }
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/self-register`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: selfRegistrationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuthAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuthAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuthAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class AuthorizationService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getPersonAuthorizationDecision(personId, permission, observe = 'body', reportProgress = false, options) {
        if (personId === null || personId === undefined) {
            throw new Error('Required parameter personId was null or undefined when calling getPersonAuthorizationDecision.');
        }
        if (permission === null || permission === undefined) {
            throw new Error('Required parameter permission was null or undefined when calling getPersonAuthorizationDecision.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'personId', personId, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'permission', permission, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/authorization/person-decision`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuthorizationService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuthorizationService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AuthorizationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class JWTAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getTokenRoles(token, observe = 'body', reportProgress = false, options) {
        if (token === null || token === undefined) {
            throw new Error('Required parameter token was null or undefined when calling getTokenRoles.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'token', token, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTokenSubject(token, observe = 'body', reportProgress = false, options) {
        if (token === null || token === undefined) {
            throw new Error('Required parameter token was null or undefined when calling getTokenSubject.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'token', token, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/subject`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getTokenUserId(token, observe = 'body', reportProgress = false, options) {
        if (token === null || token === undefined) {
            throw new Error('Required parameter token was null or undefined when calling getTokenUserId.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'token', token, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/user-id`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    issueInternalToken(internalTokenRequest, observe = 'body', reportProgress = false, options) {
        if (internalTokenRequest === null || internalTokenRequest === undefined) {
            throw new Error('Required parameter internalTokenRequest was null or undefined when calling issueInternalToken.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/internal/token`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: internalTokenRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    issueTokenPair(tokenPairRequest, observe = 'body', reportProgress = false, options) {
        if (tokenPairRequest === null || tokenPairRequest === undefined) {
            throw new Error('Required parameter tokenPairRequest was null or undefined when calling issueTokenPair.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/token-pair`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: tokenPairRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    refreshTokenPair(refreshTokenRequest, observe = 'body', reportProgress = false, options) {
        if (refreshTokenRequest === null || refreshTokenRequest === undefined) {
            throw new Error('Required parameter refreshTokenRequest was null or undefined when calling refreshTokenPair.');
        }
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/refresh`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: refreshTokenRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revokeToken(token, observe = 'body', reportProgress = false, options) {
        if (token === null || token === undefined) {
            throw new Error('Required parameter token was null or undefined when calling revokeToken.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'token', token, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/revoke`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    validateToken(token, observe = 'body', reportProgress = false, options) {
        if (token === null || token === undefined) {
            throw new Error('Required parameter token was null or undefined when calling validateToken.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'token', token, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/auth/validate`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: JWTAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: JWTAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: JWTAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PermissionRegistryService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    checkPermissionExists(permissionName, observe = 'body', reportProgress = false, options) {
        if (permissionName === null || permissionName === undefined) {
            throw new Error('Required parameter permissionName was null or undefined when calling checkPermissionExists.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/exists/${this.configuration.encodeParam({ name: "permissionName", value: permissionName, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    decodePermissionBits(permissionDecodeRequest, observe = 'body', reportProgress = false, options) {
        if (permissionDecodeRequest === null || permissionDecodeRequest === undefined) {
            throw new Error('Required parameter permissionDecodeRequest was null or undefined when calling decodePermissionBits.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/decode`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: permissionDecodeRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPermissionById(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getPermissionById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getPermissionCatalogVersion(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/catalog-version`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPermissions(domain, page, size, sort, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'domain', domain, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'page', page, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'size', size, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'sort', sort, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listPermissionsByDomain(domain, observe = 'body', reportProgress = false, options) {
        if (domain === null || domain === undefined) {
            throw new Error('Required parameter domain was null or undefined when calling listPermissionsByDomain.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/domain/${this.configuration.encodeParam({ name: "domain", value: domain, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    registerModulePermissions(permissionRegistrationRequest, observe = 'body', reportProgress = false, options) {
        if (permissionRegistrationRequest === null || permissionRegistrationRequest === undefined) {
            throw new Error('Required parameter permissionRegistrationRequest was null or undefined when calling registerModulePermissions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/register`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: permissionRegistrationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    registerPermissionsContract(permissionRegistrationRequest, observe = 'body', reportProgress = false, options) {
        if (permissionRegistrationRequest === null || permissionRegistrationRequest === undefined) {
            throw new Error('Required parameter permissionRegistrationRequest was null or undefined when calling registerPermissionsContract.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/registerPermissions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: permissionRegistrationRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    validatePermissionName(permissionName, observe = 'body', reportProgress = false, options) {
        if (permissionName === null || permissionName === undefined) {
            throw new Error('Required parameter permissionName was null or undefined when calling validatePermissionName.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/permissions/validate/${this.configuration.encodeParam({ name: "permissionName", value: permissionName, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PermissionRegistryService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PermissionRegistryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PermissionRegistryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PlatformAdministratorAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    mintAdministratorActivationToken(tenantId, userId, observe = 'body', reportProgress = false, options) {
        if (tenantId === null || tenantId === undefined) {
            throw new Error('Required parameter tenantId was null or undefined when calling mintAdministratorActivationToken.');
        }
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling mintAdministratorActivationToken.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "tenantId", value: tenantId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/administrators/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/activation-token`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformAdministratorAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformAdministratorAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformAdministratorAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PlatformRoleTemplateAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    reconcileRoleTemplate(tenantId, observe = 'body', reportProgress = false, options) {
        if (tenantId === null || tenantId === undefined) {
            throw new Error('Required parameter tenantId was null or undefined when calling reconcileRoleTemplate.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "tenantId", value: tenantId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/roles/reconcile-template`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformRoleTemplateAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformRoleTemplateAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformRoleTemplateAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class PlatformSupportAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    mintImpersonationToken(tenantId, observe = 'body', reportProgress = false, options) {
        if (tenantId === null || tenantId === undefined) {
            throw new Error('Required parameter tenantId was null or undefined when calling mintImpersonationToken.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/platform/tenants/${this.configuration.encodeParam({ name: "tenantId", value: tenantId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/impersonation-token`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformSupportAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformSupportAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PlatformSupportAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class RoleBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestRoles(bulkIngestRequestRoleBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestRoleBulkIngestRecord === null || bulkIngestRequestRoleBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestRoleBulkIngestRecord was null or undefined when calling bulkIngestRoles.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestRoleBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RoleBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RoleBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RoleBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class RoleManagementService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignRolePermissionByKey(roleId, permissionKey, observe = 'body', reportProgress = false, options) {
        if (roleId === null || roleId === undefined) {
            throw new Error('Required parameter roleId was null or undefined when calling assignRolePermissionByKey.');
        }
        if (permissionKey === null || permissionKey === undefined) {
            throw new Error('Required parameter permissionKey was null or undefined when calling assignRolePermissionByKey.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "roleId", value: roleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/permissions/${this.configuration.encodeParam({ name: "permissionKey", value: permissionKey, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createRole(roleCreateRequest, observe = 'body', reportProgress = false, options) {
        if (roleCreateRequest === null || roleCreateRequest === undefined) {
            throw new Error('Required parameter roleCreateRequest was null or undefined when calling createRole.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: roleCreateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createRoleAssignment(roleAssignmentRequest, observe = 'body', reportProgress = false, options) {
        if (roleAssignmentRequest === null || roleAssignmentRequest === undefined) {
            throw new Error('Required parameter roleAssignmentRequest was null or undefined when calling createRoleAssignment.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/assignments`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: roleAssignmentRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteRole(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling deleteRole.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRoleById(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getRoleById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRoleByName(name, observe = 'body', reportProgress = false, options) {
        if (name === null || name === undefined) {
            throw new Error('Required parameter name was null or undefined when calling getRoleByName.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/by-name/${this.configuration.encodeParam({ name: "name", value: name, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRoleDefaultPermissions(role, observe = 'body', reportProgress = false, options) {
        if (role === null || role === undefined) {
            throw new Error('Required parameter role was null or undefined when calling getRoleDefaultPermissions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "role", value: role, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/default-permissions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getRolePersonas(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/personas`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUserPermissionsLegacy(userId, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling getUserPermissionsLegacy.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/permissions/user/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    grantRolePermission(roleId, rolePermissionGrantRequest, observe = 'body', reportProgress = false, options) {
        if (roleId === null || roleId === undefined) {
            throw new Error('Required parameter roleId was null or undefined when calling grantRolePermission.');
        }
        if (rolePermissionGrantRequest === null || rolePermissionGrantRequest === undefined) {
            throw new Error('Required parameter rolePermissionGrantRequest was null or undefined when calling grantRolePermission.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "roleId", value: roleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/permissions/grant`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rolePermissionGrantRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listRoles(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listUserRoleAssignments(userId, includeHistory, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling listUserRoleAssignments.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'includeHistory', includeHistory, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/assignments/user/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revokeRoleAssignment(assignmentId, endDate, observe = 'body', reportProgress = false, options) {
        if (assignmentId === null || assignmentId === undefined) {
            throw new Error('Required parameter assignmentId was null or undefined when calling revokeRoleAssignment.');
        }
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'endDate', endDate, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/assignments/${this.configuration.encodeParam({ name: "assignmentId", value: assignmentId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revokeRolePermission(roleId, permissionKey, observe = 'body', reportProgress = false, options) {
        if (roleId === null || roleId === undefined) {
            throw new Error('Required parameter roleId was null or undefined when calling revokeRolePermission.');
        }
        if (permissionKey === null || permissionKey === undefined) {
            throw new Error('Required parameter permissionKey was null or undefined when calling revokeRolePermission.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "roleId", value: roleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/permissions/${this.configuration.encodeParam({ name: "permissionKey", value: permissionKey, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateRole(id, roleUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateRole.');
        }
        if (roleUpdateRequest === null || roleUpdateRequest === undefined) {
            throw new Error('Required parameter roleUpdateRequest was null or undefined when calling updateRole.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: roleUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateRolePermissions(rolePermissionsRequest, observe = 'body', reportProgress = false, options) {
        if (rolePermissionsRequest === null || rolePermissionsRequest === undefined) {
            throw new Error('Required parameter rolePermissionsRequest was null or undefined when calling updateRolePermissions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/permissions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: rolePermissionsRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RoleManagementService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RoleManagementService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RoleManagementService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class RolePermissionBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestRolePermissions(bulkIngestRequestRolePermissionBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestRolePermissionBulkIngestRecord === null || bulkIngestRequestRolePermissionBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestRolePermissionBulkIngestRecord was null or undefined when calling bulkIngestRolePermissions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/roles/permissions/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestRolePermissionBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RolePermissionBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RolePermissionBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RolePermissionBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class SelfRegistrationReviewAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getSelfRegistrationReviewCase(caseId, observe = 'body', reportProgress = false, options) {
        if (caseId === null || caseId === undefined) {
            throw new Error('Required parameter caseId was null or undefined when calling getSelfRegistrationReviewCase.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/self-registration/review-cases/${this.configuration.encodeParam({ name: "caseId", value: caseId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listSelfRegistrationReviewCases(status, caseType, observe = 'body', reportProgress = false, options) {
        let localVarQueryParameters = new OpenApiHttpParams(this.encoder);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'status', status, QueryParamStyle.Form, true);
        localVarQueryParameters = this.addToHttpParams(localVarQueryParameters, 'caseType', caseType, QueryParamStyle.Form, true);
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/self-registration/review-cases`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            params: localVarQueryParameters.toHttpParams(),
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    resolveSelfRegistrationReviewCase(caseId, resolveSelfRegistrationReviewCaseRequest, observe = 'body', reportProgress = false, options) {
        if (caseId === null || caseId === undefined) {
            throw new Error('Required parameter caseId was null or undefined when calling resolveSelfRegistrationReviewCase.');
        }
        if (resolveSelfRegistrationReviewCaseRequest === null || resolveSelfRegistrationReviewCaseRequest === undefined) {
            throw new Error('Required parameter resolveSelfRegistrationReviewCaseRequest was null or undefined when calling resolveSelfRegistrationReviewCase.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/self-registration/review-cases/${this.configuration.encodeParam({ name: "caseId", value: caseId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/resolve`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: resolveSelfRegistrationReviewCaseRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelfRegistrationReviewAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelfRegistrationReviewAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelfRegistrationReviewAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class TenantAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    getMyTenant(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/tenants/me`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TenantAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TenantAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TenantAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class UserAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignUserRolesByUsername(username, body, observe = 'body', reportProgress = false, options) {
        if (username === null || username === undefined) {
            throw new Error('Required parameter username was null or undefined when calling assignUserRolesByUsername.');
        }
        if (body === null || body === undefined) {
            throw new Error('Required parameter body was null or undefined when calling assignUserRolesByUsername.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "username", value: username, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: undefined })}/roles`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: body,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    createUser(createUserRequest, observe = 'body', reportProgress = false, options) {
        if (createUserRequest === null || createUserRequest === undefined) {
            throw new Error('Required parameter createUserRequest was null or undefined when calling createUser.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: createUserRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    deleteUser(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling deleteUser.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUserById(id, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling getUserById.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    linkUserPerson(id, linkUserPersonRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling linkUserPerson.');
        }
        if (linkUserPersonRequest === null || linkUserPersonRequest === undefined) {
            throw new Error('Required parameter linkUserPersonRequest was null or undefined when calling linkUserPerson.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/person-link`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: linkUserPersonRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    listUsers(observe = 'body', reportProgress = false, options) {
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    updateUser(id, userUpdateRequest, observe = 'body', reportProgress = false, options) {
        if (id === null || id === undefined) {
            throw new Error('Required parameter id was null or undefined when calling updateUser.');
        }
        if (userUpdateRequest === null || userUpdateRequest === undefined) {
            throw new Error('Required parameter userUpdateRequest was null or undefined when calling updateUser.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "id", value: id, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: userUpdateRequest,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class UserBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestUsers(bulkIngestRequestUserBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestUserBulkIngestRecord === null || bulkIngestRequestUserBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestUserBulkIngestRecord was null or undefined when calling bulkIngestUsers.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestUserBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class UserPersonLinkBulkIngestAPIService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    bulkIngestUserPersonLinks(bulkIngestRequestUserPersonLinkBulkIngestRecord, observe = 'body', reportProgress = false, options) {
        if (bulkIngestRequestUserPersonLinkBulkIngestRecord === null || bulkIngestRequestUserPersonLinkBulkIngestRecord === undefined) {
            throw new Error('Required parameter bulkIngestRequestUserPersonLinkBulkIngestRecord was null or undefined when calling bulkIngestUserPersonLinks.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        // to determine the Content-Type header
        const consumes = [
            'application/json'
        ];
        const httpContentTypeSelected = this.configuration.selectHeaderContentType(consumes);
        if (httpContentTypeSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Content-Type', httpContentTypeSelected);
        }
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/person-link/bulk-ingest`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('post', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            body: bulkIngestRequestUserPersonLinkBulkIngestRecord,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserPersonLinkBulkIngestAPIService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserPersonLinkBulkIngestAPIService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserPersonLinkBulkIngestAPIService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
/* tslint:disable:no-unused-variable member-ordering */
class UserRoleManagementService extends BaseService {
    httpClient;
    constructor(httpClient, basePath, configuration) {
        super(basePath, configuration);
        this.httpClient = httpClient;
    }
    assignUserRole(userId, roleId, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling assignUserRole.');
        }
        if (roleId === null || roleId === undefined) {
            throw new Error('Required parameter roleId was null or undefined when calling assignUserRole.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/roles/${this.configuration.encodeParam({ name: "roleId", value: roleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('put', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    getUserPermissions(userId, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling getUserPermissions.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/permissions`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('get', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    revokeUserRole(userId, roleId, observe = 'body', reportProgress = false, options) {
        if (userId === null || userId === undefined) {
            throw new Error('Required parameter userId was null or undefined when calling revokeUserRole.');
        }
        if (roleId === null || roleId === undefined) {
            throw new Error('Required parameter roleId was null or undefined when calling revokeUserRole.');
        }
        let localVarHeaders = this.defaultHeaders;
        // authentication (bearerAuth) required
        localVarHeaders = this.configuration.addCredentialToHeaders('bearerAuth', 'Authorization', localVarHeaders, 'Bearer ');
        const localVarHttpHeaderAcceptSelected = options?.httpHeaderAccept ?? this.configuration.selectHeaderAccept([
            'application/json'
        ]);
        if (localVarHttpHeaderAcceptSelected !== undefined) {
            localVarHeaders = localVarHeaders.set('Accept', localVarHttpHeaderAcceptSelected);
        }
        const localVarHttpContext = options?.context ?? new HttpContext();
        const localVarTransferCache = options?.transferCache ?? true;
        let responseType_ = 'json';
        if (localVarHttpHeaderAcceptSelected) {
            if (localVarHttpHeaderAcceptSelected.startsWith('text')) {
                responseType_ = 'text';
            }
            else if (this.configuration.isJsonMime(localVarHttpHeaderAcceptSelected)) {
                responseType_ = 'json';
            }
            else {
                responseType_ = 'blob';
            }
        }
        let localVarPath = `/v1/users/${this.configuration.encodeParam({ name: "userId", value: userId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}/roles/${this.configuration.encodeParam({ name: "roleId", value: roleId, in: "path", style: "simple", explode: false, dataType: "string", dataFormat: "uuid" })}`;
        const { basePath, withCredentials } = this.configuration;
        return this.httpClient.request('delete', `${basePath}${localVarPath}`, {
            context: localVarHttpContext,
            responseType: responseType_,
            ...(withCredentials ? { withCredentials } : {}),
            headers: localVarHeaders,
            observe: observe,
            ...(localVarTransferCache !== undefined ? { transferCache: localVarTransferCache } : {}),
            reportProgress: reportProgress
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserRoleManagementService, deps: [{ token: i1.HttpClient }, { token: BASE_PATH, optional: true }, { token: Configuration, optional: true }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserRoleManagementService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UserRoleManagementService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [BASE_PATH]
                }] }, { type: Configuration, decorators: [{
                    type: Optional
                }] }] });

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAccountStateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAccountStateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAccountStateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAccountStateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAccountStateResponsePropertyNames('accountNonExpired', 'accountNonLocked', 'credentialsNonExpired', 'enabled', 'failedLoginAttempts', 'userId');
    const optionalStringProperties = createAccountStateResponseOptionalProperties({ name: 'accountExpiresAt', nullable: false }, { name: 'credentialsExpireAt', nullable: false }, { name: 'disabledAt', nullable: false }, { name: 'disabledBy', nullable: false }, { name: 'lockedAt', nullable: false }, { name: 'lockedUntil', nullable: false }, { name: 'userId', nullable: false });
    const optionalNumberProperties = createAccountStateResponseOptionalProperties({ name: 'failedLoginAttempts', nullable: false });
    const optionalBooleanProperties = createAccountStateResponseOptionalProperties({ name: 'accountNonExpired', nullable: false }, { name: 'accountNonLocked', nullable: false }, { name: 'credentialsNonExpired', nullable: false }, { name: 'enabled', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAccountStateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAccountStateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAccountStateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalActivateAccountRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createActivateAccountRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createActivateAccountRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfActivateAccountRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createActivateAccountRequestPropertyNames('newPassword', 'token');
    const optionalStringProperties = createActivateAccountRequestOptionalProperties({ name: 'newPassword', nullable: false }, { name: 'token', nullable: false });
    const optionalNumberProperties = createActivateAccountRequestOptionalProperties();
    const optionalBooleanProperties = createActivateAccountRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalActivateAccountRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalActivateAccountRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalActivateAccountRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalActivationTokenResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createActivationTokenResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createActivationTokenResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfActivationTokenResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createActivationTokenResponsePropertyNames('expiresAt', 'token');
    const optionalStringProperties = createActivationTokenResponseOptionalProperties({ name: 'expiresAt', nullable: false }, { name: 'token', nullable: false });
    const optionalNumberProperties = createActivationTokenResponseOptionalProperties();
    const optionalBooleanProperties = createActivationTokenResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalActivationTokenResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalActivationTokenResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalActivationTokenResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalApiErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createApiErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createApiErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfApiError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createApiErrorPropertyNames('code', 'correlationId', 'message', 'status', 'timestamp');
    const optionalStringProperties = createApiErrorOptionalProperties({ name: 'code', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'message', nullable: false }, { name: 'nextAction', nullable: false }, { name: 'referenceId', nullable: false }, { name: 'supportAction', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createApiErrorOptionalProperties({ name: 'status', nullable: false });
    const optionalBooleanProperties = createApiErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalApiErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAuditEventCreatedResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditEventCreatedResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditEventCreatedResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditEventCreatedResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditEventCreatedResponsePropertyNames('eventId', 'timestamp');
    const optionalStringProperties = createAuditEventCreatedResponseOptionalProperties({ name: 'eventId', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createAuditEventCreatedResponseOptionalProperties();
    const optionalBooleanProperties = createAuditEventCreatedResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditEventCreatedResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditEventCreatedResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditEventCreatedResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAuditEventSearchFilterPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditEventSearchFilterPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditEventSearchFilterOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditEventSearchFilter(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditEventSearchFilterPropertyNames();
    const optionalStringProperties = createAuditEventSearchFilterOptionalProperties({ name: 'actorId', nullable: false }, { name: 'aggregateId', nullable: false }, { name: 'correlationId', nullable: false }, { name: 'eventType', nullable: false }, { name: 'fromDate', nullable: false }, { name: 'movementId', nullable: false }, { name: 'pageToken', nullable: false }, { name: 'productId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'sku', nullable: false }, { name: 'toDate', nullable: false }, { name: 'workorderId', nullable: false });
    const optionalNumberProperties = createAuditEventSearchFilterOptionalProperties();
    const optionalBooleanProperties = createAuditEventSearchFilterOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditEventSearchFilterPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditEventSearchFilterPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditEventSearchFilterPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var AuditExportJobResponseStatusEnum;
(function (AuditExportJobResponseStatusEnum) {
    AuditExportJobResponseStatusEnum["Pending"] = "PENDING";
    AuditExportJobResponseStatusEnum["InProgress"] = "IN_PROGRESS";
    AuditExportJobResponseStatusEnum["Completed"] = "COMPLETED";
    AuditExportJobResponseStatusEnum["Failed"] = "FAILED";
})(AuditExportJobResponseStatusEnum || (AuditExportJobResponseStatusEnum = {}));
;
function isOptionalAuditExportJobResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditExportJobResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditExportJobResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditExportJobResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditExportJobResponsePropertyNames('jobId', 'requestedAt', 'status');
    const optionalStringProperties = createAuditExportJobResponseOptionalProperties({ name: 'completedAt', nullable: false }, { name: 'downloadUrl', nullable: false }, { name: 'errorMessage', nullable: false }, { name: 'jobId', nullable: false }, { name: 'requestedAt', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createAuditExportJobResponseOptionalProperties();
    const optionalBooleanProperties = createAuditExportJobResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditExportJobResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditExportJobResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditExportJobResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

var AuditExportRequestDeliveryModeEnum;
(function (AuditExportRequestDeliveryModeEnum) {
    AuditExportRequestDeliveryModeEnum["Download"] = "DOWNLOAD";
    AuditExportRequestDeliveryModeEnum["Webhook"] = "WEBHOOK";
})(AuditExportRequestDeliveryModeEnum || (AuditExportRequestDeliveryModeEnum = {}));
;
var AuditExportRequestFormatEnum;
(function (AuditExportRequestFormatEnum) {
    AuditExportRequestFormatEnum["Csv"] = "CSV";
    AuditExportRequestFormatEnum["Json"] = "JSON";
})(AuditExportRequestFormatEnum || (AuditExportRequestFormatEnum = {}));
;
function isOptionalAuditExportRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditExportRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditExportRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditExportRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditExportRequestPropertyNames('deliveryMode', 'format');
    const optionalStringProperties = createAuditExportRequestOptionalProperties({ name: 'deliveryMode', nullable: false }, { name: 'format', nullable: false });
    const optionalNumberProperties = createAuditExportRequestOptionalProperties();
    const optionalBooleanProperties = createAuditExportRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditExportRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditExportRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditExportRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAuditLogEventDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditLogEventDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditLogEventDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditLogEventDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditLogEventDtoPropertyNames('eventId', 'eventType', 'timestamp');
    const optionalStringProperties = createAuditLogEventDtoOptionalProperties({ name: 'actorId', nullable: false }, { name: 'context', nullable: false }, { name: 'entityId', nullable: false }, { name: 'entityType', nullable: false }, { name: 'eventId', nullable: false }, { name: 'eventType', nullable: false }, { name: 'newValue', nullable: false }, { name: 'oldValue', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createAuditLogEventDtoOptionalProperties();
    const optionalBooleanProperties = createAuditLogEventDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditLogEventDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditLogEventDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditLogEventDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAuditLogEventRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuditLogEventRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuditLogEventRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuditLogEventRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuditLogEventRequestPropertyNames('eventType');
    const optionalStringProperties = createAuditLogEventRequestOptionalProperties({ name: 'actorId', nullable: false }, { name: 'entityId', nullable: false }, { name: 'entityType', nullable: false }, { name: 'eventType', nullable: false });
    const optionalNumberProperties = createAuditLogEventRequestOptionalProperties();
    const optionalBooleanProperties = createAuditLogEventRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuditLogEventRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuditLogEventRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuditLogEventRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalAuthorizationDecisionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createAuthorizationDecisionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createAuthorizationDecisionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfAuthorizationDecisionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createAuthorizationDecisionResponsePropertyNames('decision');
    const optionalStringProperties = createAuthorizationDecisionResponseOptionalProperties({ name: 'decision', nullable: false });
    const optionalNumberProperties = createAuthorizationDecisionResponseOptionalProperties();
    const optionalBooleanProperties = createAuthorizationDecisionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalAuthorizationDecisionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalAuthorizationDecisionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalAuthorizationDecisionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestRoleBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestRoleBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestRoleBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestRoleBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestRoleBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestRoleBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestRoleBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestRoleBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestRoleBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestRoleBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestRoleBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestRolePermissionBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestRolePermissionBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestRolePermissionBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestRolePermissionBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestRolePermissionBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestRolePermissionBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestRolePermissionBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestRolePermissionBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestRolePermissionBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestRolePermissionBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestRolePermissionBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestUserBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestUserBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestUserBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestUserBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestUserBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestUserBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestUserBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestUserBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestUserBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestUserBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestUserBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestRequestUserPersonLinkBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestRequestUserPersonLinkBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestRequestUserPersonLinkBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestRequestUserPersonLinkBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestRequestUserPersonLinkBulkIngestRecordPropertyNames('jobId', 'locationId', 'records');
    const optionalStringProperties = createBulkIngestRequestUserPersonLinkBulkIngestRecordOptionalProperties({ name: 'jobId', nullable: false }, { name: 'locationId', nullable: false }, { name: 'operatorId', nullable: false });
    const optionalNumberProperties = createBulkIngestRequestUserPersonLinkBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createBulkIngestRequestUserPersonLinkBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestRequestUserPersonLinkBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestRequestUserPersonLinkBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestRequestUserPersonLinkBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalBulkIngestResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResponsePropertyNames('failureCount', 'results', 'successCount', 'totalSubmitted');
    const optionalStringProperties = createBulkIngestResponseOptionalProperties();
    const optionalNumberProperties = createBulkIngestResponseOptionalProperties({ name: 'failureCount', nullable: false }, { name: 'successCount', nullable: false }, { name: 'totalSubmitted', nullable: false });
    const optionalBooleanProperties = createBulkIngestResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalBulkIngestResultPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createBulkIngestResultPropertyNames(...propertyNames) {
    return propertyNames;
}
function createBulkIngestResultOptionalProperties(...properties) {
    return properties;
}
function instanceOfBulkIngestResult(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createBulkIngestResultPropertyNames('rowIndex', 'success');
    const optionalStringProperties = createBulkIngestResultOptionalProperties({ name: 'correlationId', nullable: false }, { name: 'entityId', nullable: false }, { name: 'errorCode', nullable: false }, { name: 'errorMessage', nullable: false });
    const optionalNumberProperties = createBulkIngestResultOptionalProperties({ name: 'rowIndex', nullable: false });
    const optionalBooleanProperties = createBulkIngestResultOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalBulkIngestResultPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCatalogVersionResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCatalogVersionResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createCatalogVersionResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfCatalogVersionResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCatalogVersionResponsePropertyNames('permissionCount', 'version');
    const optionalStringProperties = createCatalogVersionResponseOptionalProperties();
    const optionalNumberProperties = createCatalogVersionResponseOptionalProperties({ name: 'permissionCount', nullable: false }, { name: 'version', nullable: false });
    const optionalBooleanProperties = createCatalogVersionResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCatalogVersionResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCatalogVersionResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCatalogVersionResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCreateUserRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCreateUserRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCreateUserRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfCreateUserRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCreateUserRequestPropertyNames('password', 'roles', 'username');
    const optionalStringProperties = createCreateUserRequestOptionalProperties({ name: 'password', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createCreateUserRequestOptionalProperties();
    const optionalBooleanProperties = createCreateUserRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCreateUserRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCreateUserRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCreateUserRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalCrmMatchSummaryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createCrmMatchSummaryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createCrmMatchSummaryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfCrmMatchSummaryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createCrmMatchSummaryDtoPropertyNames('anyMatches', 'candidateCount', 'commercialContactCandidateCount', 'exactEmailMatch', 'exactNameMatch', 'exactPhoneMatch', 'individualCustomerCandidateCount', 'reviewRequired', 'sharedIdentityCandidateCount');
    const optionalStringProperties = createCrmMatchSummaryDtoOptionalProperties();
    const optionalNumberProperties = createCrmMatchSummaryDtoOptionalProperties({ name: 'candidateCount', nullable: false }, { name: 'commercialContactCandidateCount', nullable: false }, { name: 'individualCustomerCandidateCount', nullable: false }, { name: 'sharedIdentityCandidateCount', nullable: false });
    const optionalBooleanProperties = createCrmMatchSummaryDtoOptionalProperties({ name: 'anyMatches', nullable: false }, { name: 'exactEmailMatch', nullable: false }, { name: 'exactNameMatch', nullable: false }, { name: 'exactPhoneMatch', nullable: false }, { name: 'reviewRequired', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalCrmMatchSummaryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalCrmMatchSummaryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalCrmMatchSummaryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalFieldErrorPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createFieldErrorPropertyNames(...propertyNames) {
    return propertyNames;
}
function createFieldErrorOptionalProperties(...properties) {
    return properties;
}
function instanceOfFieldError(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createFieldErrorPropertyNames('field', 'message');
    const optionalStringProperties = createFieldErrorOptionalProperties({ name: 'field', nullable: false }, { name: 'message', nullable: false });
    const optionalNumberProperties = createFieldErrorOptionalProperties();
    const optionalBooleanProperties = createFieldErrorOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalFieldErrorPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalGrantAddedPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createGrantAddedPropertyNames(...propertyNames) {
    return propertyNames;
}
function createGrantAddedOptionalProperties(...properties) {
    return properties;
}
function instanceOfGrantAdded(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createGrantAddedPropertyNames();
    const optionalStringProperties = createGrantAddedOptionalProperties({ name: 'permission', nullable: false }, { name: 'role', nullable: false });
    const optionalNumberProperties = createGrantAddedOptionalProperties();
    const optionalBooleanProperties = createGrantAddedOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalGrantAddedPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalGrantAddedPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalGrantAddedPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalImpersonationTokenResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createImpersonationTokenResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createImpersonationTokenResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfImpersonationTokenResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createImpersonationTokenResponsePropertyNames('expiresAt', 'tenantId', 'tenantSlug', 'token');
    const optionalStringProperties = createImpersonationTokenResponseOptionalProperties({ name: 'expiresAt', nullable: false }, { name: 'tenantId', nullable: false }, { name: 'tenantSlug', nullable: false }, { name: 'token', nullable: false });
    const optionalNumberProperties = createImpersonationTokenResponseOptionalProperties();
    const optionalBooleanProperties = createImpersonationTokenResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalImpersonationTokenResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalImpersonationTokenResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalImpersonationTokenResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalInternalTokenRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createInternalTokenRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createInternalTokenRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfInternalTokenRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createInternalTokenRequestPropertyNames('subject');
    const optionalStringProperties = createInternalTokenRequestOptionalProperties({ name: 'subject', nullable: false });
    const optionalNumberProperties = createInternalTokenRequestOptionalProperties();
    const optionalBooleanProperties = createInternalTokenRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalInternalTokenRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalInternalTokenRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalInternalTokenRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLinkUserPersonRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLinkUserPersonRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLinkUserPersonRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfLinkUserPersonRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLinkUserPersonRequestPropertyNames('personId');
    const optionalStringProperties = createLinkUserPersonRequestOptionalProperties({ name: 'personId', nullable: false });
    const optionalNumberProperties = createLinkUserPersonRequestOptionalProperties();
    const optionalBooleanProperties = createLinkUserPersonRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLinkUserPersonRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLinkUserPersonRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLinkUserPersonRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalLoginRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createLoginRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createLoginRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfLoginRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createLoginRequestPropertyNames('password', 'username');
    const optionalStringProperties = createLoginRequestOptionalProperties({ name: 'password', nullable: false }, { name: 'tenantSlug', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createLoginRequestOptionalProperties();
    const optionalBooleanProperties = createLoginRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalLoginRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalLoginRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalLoginRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPagePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPagePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageOptionalProperties(...properties) {
    return properties;
}
function instanceOfPage(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPagePropertyNames();
    const optionalStringProperties = createPageOptionalProperties();
    const optionalNumberProperties = createPageOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPagePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPagePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPagePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageAuditLogEventDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageAuditLogEventDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageAuditLogEventDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageAuditLogEventDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageAuditLogEventDtoPropertyNames();
    const optionalStringProperties = createPageAuditLogEventDtoOptionalProperties();
    const optionalNumberProperties = createPageAuditLogEventDtoOptionalProperties({ name: 'number', nullable: false }, { name: 'numberOfElements', nullable: false }, { name: 'size', nullable: false }, { name: 'totalElements', nullable: false }, { name: 'totalPages', nullable: false });
    const optionalBooleanProperties = createPageAuditLogEventDtoOptionalProperties({ name: 'empty', nullable: false }, { name: 'first', nullable: false }, { name: 'last', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageAuditLogEventDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageAuditLogEventDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageAuditLogEventDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPageableObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPageableObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPageableObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfPageableObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPageableObjectPropertyNames();
    const optionalStringProperties = createPageableObjectOptionalProperties();
    const optionalNumberProperties = createPageableObjectOptionalProperties({ name: 'offset', nullable: false }, { name: 'pageNumber', nullable: false }, { name: 'pageSize', nullable: false });
    const optionalBooleanProperties = createPageableObjectOptionalProperties({ name: 'paged', nullable: false }, { name: 'unpaged', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPageableObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPermissionDecodeRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPermissionDecodeRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPermissionDecodeRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPermissionDecodeRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPermissionDecodeRequestPropertyNames('perm_bits', 'perm_ver');
    const optionalStringProperties = createPermissionDecodeRequestOptionalProperties({ name: 'perm_bits', nullable: false });
    const optionalNumberProperties = createPermissionDecodeRequestOptionalProperties({ name: 'perm_ver', nullable: false });
    const optionalBooleanProperties = createPermissionDecodeRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPermissionDecodeRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPermissionDecodeRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPermissionDecodeRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPermissionDecodeResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPermissionDecodeResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPermissionDecodeResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPermissionDecodeResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPermissionDecodeResponsePropertyNames('permissions');
    const optionalStringProperties = createPermissionDecodeResponseOptionalProperties();
    const optionalNumberProperties = createPermissionDecodeResponseOptionalProperties();
    const optionalBooleanProperties = createPermissionDecodeResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPermissionDecodeResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPermissionDecodeResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPermissionDecodeResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPermissionDefinitionPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPermissionDefinitionPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPermissionDefinitionOptionalProperties(...properties) {
    return properties;
}
function instanceOfPermissionDefinition(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPermissionDefinitionPropertyNames('name');
    const optionalStringProperties = createPermissionDefinitionOptionalProperties({ name: 'description', nullable: false }, { name: 'name', nullable: false }, { name: 'supersededBy', nullable: false });
    const optionalNumberProperties = createPermissionDefinitionOptionalProperties();
    const optionalBooleanProperties = createPermissionDefinitionOptionalProperties({ name: 'deprecated', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPermissionDefinitionPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPermissionDefinitionPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPermissionDefinitionPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPermissionDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPermissionDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPermissionDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPermissionDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPermissionDtoPropertyNames('deprecated', 'domain', 'id', 'name');
    const optionalStringProperties = createPermissionDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'domain', nullable: false }, { name: 'id', nullable: false }, { name: 'name', nullable: false }, { name: 'supersededBy', nullable: false });
    const optionalNumberProperties = createPermissionDtoOptionalProperties();
    const optionalBooleanProperties = createPermissionDtoOptionalProperties({ name: 'deprecated', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPermissionDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPermissionDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPermissionDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPermissionRegistrationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPermissionRegistrationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPermissionRegistrationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPermissionRegistrationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPermissionRegistrationRequestPropertyNames('domain', 'permissions', 'serviceName');
    const optionalStringProperties = createPermissionRegistrationRequestOptionalProperties({ name: 'domain', nullable: false }, { name: 'serviceName', nullable: false }, { name: 'version', nullable: false });
    const optionalNumberProperties = createPermissionRegistrationRequestOptionalProperties();
    const optionalBooleanProperties = createPermissionRegistrationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPermissionRegistrationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPermissionRegistrationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPermissionRegistrationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPermissionRegistrationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPermissionRegistrationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPermissionRegistrationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPermissionRegistrationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPermissionRegistrationResponsePropertyNames('registeredPermissions', 'skippedPermissions', 'success', 'totalPermissions', 'updatedPermissions');
    const optionalStringProperties = createPermissionRegistrationResponseOptionalProperties({ name: 'message', nullable: false });
    const optionalNumberProperties = createPermissionRegistrationResponseOptionalProperties({ name: 'registeredPermissions', nullable: false }, { name: 'skippedPermissions', nullable: false }, { name: 'totalPermissions', nullable: false }, { name: 'updatedPermissions', nullable: false });
    const optionalBooleanProperties = createPermissionRegistrationResponseOptionalProperties({ name: 'success', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPermissionRegistrationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPermissionRegistrationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPermissionRegistrationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPricingRuleTraceEntryDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPricingRuleTraceEntryDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPricingRuleTraceEntryDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPricingRuleTraceEntryDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPricingRuleTraceEntryDtoPropertyNames('id', 'ruleId', 'status');
    const optionalStringProperties = createPricingRuleTraceEntryDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'inputs', nullable: false }, { name: 'outputs', nullable: false }, { name: 'ruleId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createPricingRuleTraceEntryDtoOptionalProperties();
    const optionalBooleanProperties = createPricingRuleTraceEntryDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPricingRuleTraceEntryDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPricingRuleTraceEntryDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPricingRuleTraceEntryDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPricingRuleTraceEntryRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPricingRuleTraceEntryRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPricingRuleTraceEntryRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPricingRuleTraceEntryRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPricingRuleTraceEntryRequestPropertyNames('ruleId', 'status');
    const optionalStringProperties = createPricingRuleTraceEntryRequestOptionalProperties({ name: 'ruleId', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createPricingRuleTraceEntryRequestOptionalProperties();
    const optionalBooleanProperties = createPricingRuleTraceEntryRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPricingRuleTraceEntryRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPricingRuleTraceEntryRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPricingRuleTraceEntryRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalPricingSnapshotCreatedResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPricingSnapshotCreatedResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createPricingSnapshotCreatedResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfPricingSnapshotCreatedResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPricingSnapshotCreatedResponsePropertyNames('snapshotId');
    const optionalStringProperties = createPricingSnapshotCreatedResponseOptionalProperties({ name: 'snapshotId', nullable: false });
    const optionalNumberProperties = createPricingSnapshotCreatedResponseOptionalProperties();
    const optionalBooleanProperties = createPricingSnapshotCreatedResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPricingSnapshotCreatedResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPricingSnapshotCreatedResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPricingSnapshotCreatedResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPricingSnapshotDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPricingSnapshotDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPricingSnapshotDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfPricingSnapshotDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPricingSnapshotDtoPropertyNames('finalPrice', 'snapshotId', 'timestamp');
    const optionalStringProperties = createPricingSnapshotDtoOptionalProperties({ name: 'quoteContext', nullable: false }, { name: 'snapshotId', nullable: false }, { name: 'timestamp', nullable: false });
    const optionalNumberProperties = createPricingSnapshotDtoOptionalProperties({ name: 'finalPrice', nullable: false });
    const optionalBooleanProperties = createPricingSnapshotDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPricingSnapshotDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPricingSnapshotDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPricingSnapshotDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalPricingSnapshotRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createPricingSnapshotRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createPricingSnapshotRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfPricingSnapshotRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createPricingSnapshotRequestPropertyNames('finalPrice');
    const optionalStringProperties = createPricingSnapshotRequestOptionalProperties();
    const optionalNumberProperties = createPricingSnapshotRequestOptionalProperties({ name: 'finalPrice', nullable: false });
    const optionalBooleanProperties = createPricingSnapshotRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalPricingSnapshotRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalPricingSnapshotRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalPricingSnapshotRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRefreshTokenRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRefreshTokenRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRefreshTokenRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRefreshTokenRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRefreshTokenRequestPropertyNames('refreshToken');
    const optionalStringProperties = createRefreshTokenRequestOptionalProperties({ name: 'refreshToken', nullable: false });
    const optionalNumberProperties = createRefreshTokenRequestOptionalProperties();
    const optionalBooleanProperties = createRefreshTokenRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRefreshTokenRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRefreshTokenRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRefreshTokenRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalResolveSelfRegistrationReviewCaseRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createResolveSelfRegistrationReviewCaseRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createResolveSelfRegistrationReviewCaseRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfResolveSelfRegistrationReviewCaseRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createResolveSelfRegistrationReviewCaseRequestPropertyNames('resolutionNotes');
    const optionalStringProperties = createResolveSelfRegistrationReviewCaseRequestOptionalProperties({ name: 'resolutionNotes', nullable: false });
    const optionalNumberProperties = createResolveSelfRegistrationReviewCaseRequestOptionalProperties();
    const optionalBooleanProperties = createResolveSelfRegistrationReviewCaseRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalResolveSelfRegistrationReviewCaseRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalResolveSelfRegistrationReviewCaseRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalResolveSelfRegistrationReviewCaseRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleAssignmentDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleAssignmentDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleAssignmentDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleAssignmentDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleAssignmentDtoPropertyNames('id', 'roleCode', 'roleId', 'userId');
    const optionalStringProperties = createRoleAssignmentDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'id', nullable: false }, { name: 'lastModifiedAt', nullable: false }, { name: 'lastModifiedBy', nullable: false }, { name: 'revokedAt', nullable: false }, { name: 'roleCode', nullable: false }, { name: 'roleId', nullable: false }, { name: 'userId', nullable: false });
    const optionalNumberProperties = createRoleAssignmentDtoOptionalProperties();
    const optionalBooleanProperties = createRoleAssignmentDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleAssignmentDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleAssignmentDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleAssignmentDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleAssignmentRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleAssignmentRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleAssignmentRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleAssignmentRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleAssignmentRequestPropertyNames('roleId', 'userId');
    const optionalStringProperties = createRoleAssignmentRequestOptionalProperties({ name: 'effectiveEndDate', nullable: false }, { name: 'effectiveStartDate', nullable: false }, { name: 'roleId', nullable: false }, { name: 'userId', nullable: false });
    const optionalNumberProperties = createRoleAssignmentRequestOptionalProperties();
    const optionalBooleanProperties = createRoleAssignmentRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleAssignmentRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleAssignmentRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleAssignmentRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleBulkIngestRecordPropertyNames('name');
    const optionalStringProperties = createRoleBulkIngestRecordOptionalProperties({ name: 'description', nullable: false }, { name: 'name', nullable: false }, { name: 'personaFocus', nullable: false }, { name: 'personaTitle', nullable: false }, { name: 'personaTone', nullable: false });
    const optionalNumberProperties = createRoleBulkIngestRecordOptionalProperties({ name: 'mcpPersonaRank', nullable: false });
    const optionalBooleanProperties = createRoleBulkIngestRecordOptionalProperties({ name: 'mcpPersonaEligible', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleCreateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleCreateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleCreateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleCreateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleCreateRequestPropertyNames('name');
    const optionalStringProperties = createRoleCreateRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'name', nullable: false }, { name: 'personaFocus', nullable: false }, { name: 'personaTitle', nullable: false }, { name: 'personaTone', nullable: false });
    const optionalNumberProperties = createRoleCreateRequestOptionalProperties({ name: 'mcpPersonaRank', nullable: false });
    const optionalBooleanProperties = createRoleCreateRequestOptionalProperties({ name: 'mcpPersonaEligible', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleCreateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleCreateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleCreateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleDefaultPermissionsResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleDefaultPermissionsResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleDefaultPermissionsResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleDefaultPermissionsResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleDefaultPermissionsResponsePropertyNames('permissions', 'role');
    const optionalStringProperties = createRoleDefaultPermissionsResponseOptionalProperties({ name: 'role', nullable: false });
    const optionalNumberProperties = createRoleDefaultPermissionsResponseOptionalProperties();
    const optionalBooleanProperties = createRoleDefaultPermissionsResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleDefaultPermissionsResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleDefaultPermissionsResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleDefaultPermissionsResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalRoleDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleDtoPropertyNames('id', 'name');
    const optionalStringProperties = createRoleDtoOptionalProperties({ name: 'createdAt', nullable: false }, { name: 'createdBy', nullable: false }, { name: 'description', nullable: false }, { name: 'id', nullable: false }, { name: 'lastModifiedAt', nullable: false }, { name: 'lastModifiedBy', nullable: false }, { name: 'name', nullable: false }, { name: 'personaFocus', nullable: false }, { name: 'personaTitle', nullable: false }, { name: 'personaTone', nullable: false }, { name: 'templateKey', nullable: true });
    const optionalNumberProperties = createRoleDtoOptionalProperties({ name: 'mcpPersonaRank', nullable: false });
    const optionalBooleanProperties = createRoleDtoOptionalProperties({ name: 'mcpPersonaEligible', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRolePermissionBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRolePermissionBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRolePermissionBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfRolePermissionBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRolePermissionBulkIngestRecordPropertyNames('permissions', 'roleName');
    const optionalStringProperties = createRolePermissionBulkIngestRecordOptionalProperties({ name: 'roleName', nullable: false });
    const optionalNumberProperties = createRolePermissionBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createRolePermissionBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRolePermissionBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRolePermissionBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRolePermissionBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRolePermissionGrantRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRolePermissionGrantRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRolePermissionGrantRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRolePermissionGrantRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRolePermissionGrantRequestPropertyNames('permission');
    const optionalStringProperties = createRolePermissionGrantRequestOptionalProperties({ name: 'permission', nullable: false });
    const optionalNumberProperties = createRolePermissionGrantRequestOptionalProperties();
    const optionalBooleanProperties = createRolePermissionGrantRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRolePermissionGrantRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRolePermissionGrantRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRolePermissionGrantRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRolePermissionsRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRolePermissionsRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRolePermissionsRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRolePermissionsRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRolePermissionsRequestPropertyNames('permissionNames', 'roleId');
    const optionalStringProperties = createRolePermissionsRequestOptionalProperties({ name: 'roleId', nullable: false });
    const optionalNumberProperties = createRolePermissionsRequestOptionalProperties();
    const optionalBooleanProperties = createRolePermissionsRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRolePermissionsRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRolePermissionsRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRolePermissionsRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRolePersonaDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRolePersonaDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRolePersonaDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfRolePersonaDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRolePersonaDtoPropertyNames('mcpPersonaEligible', 'name');
    const optionalStringProperties = createRolePersonaDtoOptionalProperties({ name: 'description', nullable: false }, { name: 'name', nullable: false }, { name: 'personaFocus', nullable: false }, { name: 'personaTitle', nullable: false }, { name: 'personaTone', nullable: false });
    const optionalNumberProperties = createRolePersonaDtoOptionalProperties({ name: 'mcpPersonaRank', nullable: false });
    const optionalBooleanProperties = createRolePersonaDtoOptionalProperties({ name: 'mcpPersonaEligible', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRolePersonaDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRolePersonaDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRolePersonaDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalRolePersonasResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRolePersonasResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createRolePersonasResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfRolePersonasResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRolePersonasResponsePropertyNames('generatedAt', 'roles');
    const optionalStringProperties = createRolePersonasResponseOptionalProperties({ name: 'generatedAt', nullable: false });
    const optionalNumberProperties = createRolePersonasResponseOptionalProperties();
    const optionalBooleanProperties = createRolePersonasResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRolePersonasResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRolePersonasResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRolePersonasResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalRoleTemplateReconcileResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleTemplateReconcileResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleTemplateReconcileResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleTemplateReconcileResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleTemplateReconcileResponsePropertyNames();
    const optionalStringProperties = createRoleTemplateReconcileResponseOptionalProperties({ name: 'tenantId', nullable: false });
    const optionalNumberProperties = createRoleTemplateReconcileResponseOptionalProperties();
    const optionalBooleanProperties = createRoleTemplateReconcileResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleTemplateReconcileResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleTemplateReconcileResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleTemplateReconcileResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalRoleUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createRoleUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createRoleUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfRoleUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createRoleUpdateRequestPropertyNames();
    const optionalStringProperties = createRoleUpdateRequestOptionalProperties({ name: 'description', nullable: false }, { name: 'personaFocus', nullable: false }, { name: 'personaTitle', nullable: false }, { name: 'personaTone', nullable: false });
    const optionalNumberProperties = createRoleUpdateRequestOptionalProperties({ name: 'mcpPersonaRank', nullable: false });
    const optionalBooleanProperties = createRoleUpdateRequestOptionalProperties({ name: 'mcpPersonaEligible', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalRoleUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalRoleUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalRoleUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSelfRegistrationRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSelfRegistrationRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSelfRegistrationRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfSelfRegistrationRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSelfRegistrationRequestPropertyNames('email', 'firstName', 'lastName', 'password');
    const optionalStringProperties = createSelfRegistrationRequestOptionalProperties({ name: 'email', nullable: false }, { name: 'firstName', nullable: false }, { name: 'idempotencyKey', nullable: false }, { name: 'idpSubject', nullable: false }, { name: 'lastName', nullable: false }, { name: 'password', nullable: false }, { name: 'phone', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createSelfRegistrationRequestOptionalProperties();
    const optionalBooleanProperties = createSelfRegistrationRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSelfRegistrationRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSelfRegistrationRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSelfRegistrationRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

function isOptionalSelfRegistrationResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSelfRegistrationResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSelfRegistrationResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSelfRegistrationResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSelfRegistrationResponsePropertyNames('issuedTokens', 'linkStatus', 'matchedExistingPerson', 'personId', 'userId', 'username');
    const optionalStringProperties = createSelfRegistrationResponseOptionalProperties({ name: 'idempotencyKey', nullable: false }, { name: 'linkStatus', nullable: false }, { name: 'personId', nullable: false }, { name: 'userId', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createSelfRegistrationResponseOptionalProperties();
    const optionalBooleanProperties = createSelfRegistrationResponseOptionalProperties({ name: 'issuedTokens', nullable: false }, { name: 'matchedExistingPerson', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSelfRegistrationResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSelfRegistrationResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSelfRegistrationResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
var SelfRegistrationReviewCaseResponseCaseTypeEnum;
(function (SelfRegistrationReviewCaseResponseCaseTypeEnum) {
    SelfRegistrationReviewCaseResponseCaseTypeEnum["AccountRecovery"] = "ACCOUNT_RECOVERY";
    SelfRegistrationReviewCaseResponseCaseTypeEnum["IdentityReview"] = "IDENTITY_REVIEW";
})(SelfRegistrationReviewCaseResponseCaseTypeEnum || (SelfRegistrationReviewCaseResponseCaseTypeEnum = {}));
;
var SelfRegistrationReviewCaseResponseStatusEnum;
(function (SelfRegistrationReviewCaseResponseStatusEnum) {
    SelfRegistrationReviewCaseResponseStatusEnum["Open"] = "OPEN";
    SelfRegistrationReviewCaseResponseStatusEnum["Resolved"] = "RESOLVED";
})(SelfRegistrationReviewCaseResponseStatusEnum || (SelfRegistrationReviewCaseResponseStatusEnum = {}));
;
function isOptionalSelfRegistrationReviewCaseResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSelfRegistrationReviewCaseResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createSelfRegistrationReviewCaseResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfSelfRegistrationReviewCaseResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSelfRegistrationReviewCaseResponsePropertyNames('caseId', 'caseType', 'createdAt', 'email', 'reasonCode', 'reasonMessage', 'status', 'updatedAt');
    const optionalStringProperties = createSelfRegistrationReviewCaseResponseOptionalProperties({ name: 'caseId', nullable: false }, { name: 'caseType', nullable: false }, { name: 'createdAt', nullable: false }, { name: 'email', nullable: false }, { name: 'linkedUserId', nullable: false }, { name: 'notes', nullable: false }, { name: 'personId', nullable: false }, { name: 'reasonCode', nullable: false }, { name: 'reasonMessage', nullable: false }, { name: 'requestedUsername', nullable: false }, { name: 'resolutionNotes', nullable: false }, { name: 'resolvedAt', nullable: false }, { name: 'resolvedBy', nullable: false }, { name: 'status', nullable: false }, { name: 'updatedAt', nullable: false });
    const optionalNumberProperties = createSelfRegistrationReviewCaseResponseOptionalProperties({ name: 'crmCandidateCount', nullable: false }, { name: 'crmSharedIdentityCandidateCount', nullable: false });
    const optionalBooleanProperties = createSelfRegistrationReviewCaseResponseOptionalProperties({ name: 'crmExactEmailMatch', nullable: false }, { name: 'crmExactNameMatch', nullable: false }, { name: 'crmExactPhoneMatch', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSelfRegistrationReviewCaseResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSelfRegistrationReviewCaseResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSelfRegistrationReviewCaseResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalSortObjectPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createSortObjectPropertyNames(...propertyNames) {
    return propertyNames;
}
function createSortObjectOptionalProperties(...properties) {
    return properties;
}
function instanceOfSortObject(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createSortObjectPropertyNames();
    const optionalStringProperties = createSortObjectOptionalProperties();
    const optionalNumberProperties = createSortObjectOptionalProperties();
    const optionalBooleanProperties = createSortObjectOptionalProperties({ name: 'empty', nullable: false }, { name: 'sorted', nullable: false }, { name: 'unsorted', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalSortObjectPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTenantMeResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTenantMeResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTenantMeResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTenantMeResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTenantMeResponsePropertyNames('id', 'slug', 'status');
    const optionalStringProperties = createTenantMeResponseOptionalProperties({ name: 'displayName', nullable: false }, { name: 'id', nullable: false }, { name: 'slug', nullable: false }, { name: 'status', nullable: false });
    const optionalNumberProperties = createTenantMeResponseOptionalProperties();
    const optionalBooleanProperties = createTenantMeResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTenantMeResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTenantMeResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTenantMeResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTokenPairRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTokenPairRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createTokenPairRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfTokenPairRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTokenPairRequestPropertyNames('subject');
    const optionalStringProperties = createTokenPairRequestOptionalProperties({ name: 'subject', nullable: false });
    const optionalNumberProperties = createTokenPairRequestOptionalProperties();
    const optionalBooleanProperties = createTokenPairRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTokenPairRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTokenPairRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTokenPairRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTokenPairResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTokenPairResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTokenPairResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTokenPairResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTokenPairResponsePropertyNames('accessToken', 'refreshToken');
    const optionalStringProperties = createTokenPairResponseOptionalProperties({ name: 'accessToken', nullable: false }, { name: 'refreshToken', nullable: false });
    const optionalNumberProperties = createTokenPairResponseOptionalProperties();
    const optionalBooleanProperties = createTokenPairResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTokenPairResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTokenPairResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTokenPairResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalTokenResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createTokenResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createTokenResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfTokenResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createTokenResponsePropertyNames('token');
    const optionalStringProperties = createTokenResponseOptionalProperties({ name: 'token', nullable: false });
    const optionalNumberProperties = createTokenResponseOptionalProperties();
    const optionalBooleanProperties = createTokenResponseOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalTokenResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalTokenResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalTokenResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUserBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUserBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUserBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfUserBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUserBulkIngestRecordPropertyNames('roles', 'username');
    const optionalStringProperties = createUserBulkIngestRecordOptionalProperties({ name: 'username', nullable: false });
    const optionalNumberProperties = createUserBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createUserBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUserBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUserBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUserBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUserDtoPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUserDtoPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUserDtoOptionalProperties(...properties) {
    return properties;
}
function instanceOfUserDto(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUserDtoPropertyNames('id', 'roles', 'username');
    const optionalStringProperties = createUserDtoOptionalProperties({ name: 'id', nullable: false }, { name: 'personId', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createUserDtoOptionalProperties();
    const optionalBooleanProperties = createUserDtoOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUserDtoPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUserDtoPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUserDtoPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUserPersonLinkBulkIngestRecordPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUserPersonLinkBulkIngestRecordPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUserPersonLinkBulkIngestRecordOptionalProperties(...properties) {
    return properties;
}
function instanceOfUserPersonLinkBulkIngestRecord(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUserPersonLinkBulkIngestRecordPropertyNames('personId', 'username');
    const optionalStringProperties = createUserPersonLinkBulkIngestRecordOptionalProperties({ name: 'personId', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createUserPersonLinkBulkIngestRecordOptionalProperties();
    const optionalBooleanProperties = createUserPersonLinkBulkIngestRecordOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUserPersonLinkBulkIngestRecordPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUserPersonLinkBulkIngestRecordPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUserPersonLinkBulkIngestRecordPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalUserUpdateRequestPropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createUserUpdateRequestPropertyNames(...propertyNames) {
    return propertyNames;
}
function createUserUpdateRequestOptionalProperties(...properties) {
    return properties;
}
function instanceOfUserUpdateRequest(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createUserUpdateRequestPropertyNames();
    const optionalStringProperties = createUserUpdateRequestOptionalProperties({ name: 'password', nullable: false }, { name: 'username', nullable: false });
    const optionalNumberProperties = createUserUpdateRequestOptionalProperties();
    const optionalBooleanProperties = createUserUpdateRequestOptionalProperties();
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalUserUpdateRequestPropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalUserUpdateRequestPropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalUserUpdateRequestPropertyOfType(_v, property.name, 'boolean', property.nullable));
}

/**
 * POS Security Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
function isOptionalValidateResponsePropertyOfType(value, propertyName, propertyType, isNullable = false) {
    if (!(propertyName in value)) {
        return true;
    }
    const propertyValue = value[propertyName];
    if (isNullable && propertyValue === null) {
        return true;
    }
    return typeof propertyValue === propertyType;
}
function createValidateResponsePropertyNames(...propertyNames) {
    return propertyNames;
}
function createValidateResponseOptionalProperties(...properties) {
    return properties;
}
function instanceOfValidateResponse(value) {
    if (value === null || typeof value !== 'object' || Array.isArray(value))
        return false;
    const _v = value;
    const requiredProperties = createValidateResponsePropertyNames();
    const optionalStringProperties = createValidateResponseOptionalProperties();
    const optionalNumberProperties = createValidateResponseOptionalProperties();
    const optionalBooleanProperties = createValidateResponseOptionalProperties({ name: 'valid', nullable: false });
    return requiredProperties.every((propertyName) => propertyName in _v && _v[propertyName] !== undefined)
        && optionalStringProperties.every((property) => isOptionalValidateResponsePropertyOfType(_v, property.name, 'string', property.nullable))
        && optionalNumberProperties.every((property) => isOptionalValidateResponsePropertyOfType(_v, property.name, 'number', property.nullable))
        && optionalBooleanProperties.every((property) => isOptionalValidateResponsePropertyOfType(_v, property.name, 'boolean', property.nullable));
}

class ApiModule {
    static forRoot(configurationFactory) {
        return {
            ngModule: ApiModule,
            providers: [{ provide: Configuration, useFactory: configurationFactory }]
        };
    }
    constructor(parentModule, http) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
                'See also https://github.com/angular/angular/issues/20575');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, deps: [{ token: ApiModule, optional: true, skipSelf: true }, { token: i1.HttpClient, optional: true }], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    declarations: [],
                    exports: [],
                    providers: []
                }]
        }], ctorParameters: () => [{ type: ApiModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }, { type: i1.HttpClient, decorators: [{
                    type: Optional
                }] }] });

// Returns the service class providers, to be used in the [ApplicationConfig](https://angular.dev/api/core/ApplicationConfig).
function provideApi(configOrBasePath) {
    return makeEnvironmentProviders([
        typeof configOrBasePath === "string"
            ? { provide: BASE_PATH, useValue: configOrBasePath }
            : {
                provide: Configuration,
                useValue: new Configuration({ ...configOrBasePath }),
            },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AdminAccountStateAPIService, ApiModule, AuditExportJobResponseStatusEnum, AuditExportRequestDeliveryModeEnum, AuditExportRequestFormatEnum, AuditExportsService, AuditService, AuthAPIService, AuthorizationService, BASE_PATH, COLLECTION_FORMATS, Configuration, JWTAPIService, PermissionRegistryService, PlatformAdministratorAPIService, PlatformRoleTemplateAPIService, PlatformSupportAPIService, RoleBulkIngestAPIService, RoleManagementService, RolePermissionBulkIngestAPIService, SelfRegistrationReviewAPIService, SelfRegistrationReviewCaseResponseCaseTypeEnum, SelfRegistrationReviewCaseResponseStatusEnum, TenantAPIService, UserAPIService, UserBulkIngestAPIService, UserPersonLinkBulkIngestAPIService, UserRoleManagementService, instanceOfAccountStateResponse, instanceOfActivateAccountRequest, instanceOfActivationTokenResponse, instanceOfApiError, instanceOfAuditEventCreatedResponse, instanceOfAuditEventSearchFilter, instanceOfAuditExportJobResponse, instanceOfAuditExportRequest, instanceOfAuditLogEventDto, instanceOfAuditLogEventRequest, instanceOfAuthorizationDecisionResponse, instanceOfBulkIngestRequestRoleBulkIngestRecord, instanceOfBulkIngestRequestRolePermissionBulkIngestRecord, instanceOfBulkIngestRequestUserBulkIngestRecord, instanceOfBulkIngestRequestUserPersonLinkBulkIngestRecord, instanceOfBulkIngestResponse, instanceOfBulkIngestResult, instanceOfCatalogVersionResponse, instanceOfCreateUserRequest, instanceOfCrmMatchSummaryDto, instanceOfFieldError, instanceOfGrantAdded, instanceOfImpersonationTokenResponse, instanceOfInternalTokenRequest, instanceOfLinkUserPersonRequest, instanceOfLoginRequest, instanceOfPage, instanceOfPageAuditLogEventDto, instanceOfPageableObject, instanceOfPermissionDecodeRequest, instanceOfPermissionDecodeResponse, instanceOfPermissionDefinition, instanceOfPermissionDto, instanceOfPermissionRegistrationRequest, instanceOfPermissionRegistrationResponse, instanceOfPricingRuleTraceEntryDto, instanceOfPricingRuleTraceEntryRequest, instanceOfPricingSnapshotCreatedResponse, instanceOfPricingSnapshotDto, instanceOfPricingSnapshotRequest, instanceOfRefreshTokenRequest, instanceOfResolveSelfRegistrationReviewCaseRequest, instanceOfRoleAssignmentDto, instanceOfRoleAssignmentRequest, instanceOfRoleBulkIngestRecord, instanceOfRoleCreateRequest, instanceOfRoleDefaultPermissionsResponse, instanceOfRoleDto, instanceOfRolePermissionBulkIngestRecord, instanceOfRolePermissionGrantRequest, instanceOfRolePermissionsRequest, instanceOfRolePersonaDto, instanceOfRolePersonasResponse, instanceOfRoleTemplateReconcileResponse, instanceOfRoleUpdateRequest, instanceOfSelfRegistrationRequest, instanceOfSelfRegistrationResponse, instanceOfSelfRegistrationReviewCaseResponse, instanceOfSortObject, instanceOfTenantMeResponse, instanceOfTokenPairRequest, instanceOfTokenPairResponse, instanceOfTokenResponse, instanceOfUserBulkIngestRecord, instanceOfUserDto, instanceOfUserPersonLinkBulkIngestRecord, instanceOfUserUpdateRequest, instanceOfValidateResponse, provideApi };
//# sourceMappingURL=durion-sdk-security.mjs.map
