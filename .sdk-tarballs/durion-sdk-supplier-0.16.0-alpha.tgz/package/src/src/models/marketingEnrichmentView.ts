export * from '../../models/marketingEnrichmentView';
