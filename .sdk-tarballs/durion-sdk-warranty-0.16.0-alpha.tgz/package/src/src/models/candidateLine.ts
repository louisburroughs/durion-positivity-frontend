export * from '../../models/candidateLine';
