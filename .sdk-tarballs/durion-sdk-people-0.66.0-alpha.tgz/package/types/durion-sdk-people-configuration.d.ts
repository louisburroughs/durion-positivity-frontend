import { HttpParameterCodec, HttpParams, HttpHeaders } from '@angular/common/http';
import { InjectionToken, EnvironmentProviders } from '@angular/core';

/**
 * Standard parameter styles defined by OpenAPI spec
 */
type StandardParamStyle = 'matrix' | 'label' | 'form' | 'simple' | 'spaceDelimited' | 'pipeDelimited' | 'deepObject';
/**
 * The OpenAPI standard {@link StandardParamStyle}s may be extended by custom styles by the user.
 */
type ParamStyle = StandardParamStyle | string;
/**
 * Standard parameter locations defined by OpenAPI spec
 */
type ParamLocation = 'query' | 'header' | 'path' | 'cookie';
/**
 * Standard types as defined in <a href="https://swagger.io/specification/#data-types">OpenAPI Specification: Data Types</a>
 */
type StandardDataType = "integer" | "number" | "boolean" | "string" | "object" | "array";
/**
 * Standard {@link DataType}s plus your own types/classes.
 */
type DataType = StandardDataType | string;
/**
 * Standard formats as defined in <a href="https://swagger.io/specification/#data-types">OpenAPI Specification: Data Types</a>
 */
type StandardDataFormat = "int32" | "int64" | "float" | "double" | "byte" | "binary" | "date" | "date-time" | "password";
type DataFormat = StandardDataFormat | string;
/**
 * The parameter to encode.
 */
interface Param {
    name: string;
    value: unknown;
    in: ParamLocation;
    style: ParamStyle;
    explode: boolean;
    dataType: DataType;
    dataFormat: DataFormat | undefined;
}

declare enum QueryParamStyle {
    Json = 0,
    Form = 1,
    DeepObject = 2,
    SpaceDelimited = 3,
    PipeDelimited = 4
}
type Delimiter = "," | " " | "|" | "\t";
interface ParamOptions {
    /** When true, serialized as multiple repeated key=value pairs. When false, serialized as a single key with joined values using `delimiter`. */
    explode?: boolean;
    /** Delimiter used when explode=false. The delimiter itself is inserted unencoded between encoded values. */
    delimiter?: Delimiter;
}
declare class OpenApiHttpParams {
    private params;
    private defaults;
    private encoder;
    /**
     * @param encoder  Parameter serializer
     * @param defaults Global defaults used when a specific parameter has no explicit options.
     *                 By OpenAPI default, explode is true for query params with style=form.
     */
    constructor(encoder?: HttpParameterCodec, defaults?: {
        explode?: boolean;
        delimiter?: Delimiter;
    });
    private resolveOptions;
    /**
     * Replace the parameter's values and (optionally) its options.
     * Options are stored per-parameter (not global).
     */
    set(key: string, values: string[] | string, options?: ParamOptions): this;
    /**
     * Append a single value to the parameter. If the parameter didn't exist it will be created
     * and use resolved options (global defaults merged with any provided options).
     */
    append(key: string, value: string, options?: ParamOptions): this;
    /**
     * Serialize to a query string according to per-parameter OpenAPI options.
     * - If explode=true for that parameter → repeated key=value pairs (each value encoded).
     * - If explode=false for that parameter → single key=value where values are individually encoded
     *   and joined using the configured delimiter. The delimiter character is inserted AS-IS
     *   (not percent-encoded).
     */
    toString(): string;
    /**
     * Return parameters as a plain record.
     * - If a parameter has exactly one value, returns that value directly.
     * - If a parameter has multiple values, returns a readonly array of values.
     */
    toRecord(): Record<string, string | number | boolean | ReadonlyArray<string | number | boolean>>;
    /**
     * Return an Angular's HttpParams with an identity parameter codec as the parameters are already encoded.
     */
    toHttpParams(): HttpParams;
}
declare function concatHttpParamsObject(httpParams: OpenApiHttpParams, key: string, item: {
    [index: string]: any;
}, delimiter: Delimiter): OpenApiHttpParams;

interface ConfigurationParameters {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys?: {
        [key: string]: string;
    };
    username?: string;
    password?: string;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken?: string | (() => string);
    basePath?: string;
    withCredentials?: boolean;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder?: HttpParameterCodec;
    /**
     * Override the default method for encoding path parameters in various
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam?: (param: Param) => string;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials?: {
        [key: string]: string | (() => string | undefined);
    };
}
declare class Configuration {
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    apiKeys?: {
        [key: string]: string;
    };
    username?: string;
    password?: string;
    /**
     *  @deprecated Since 5.0. Use credentials instead
     */
    accessToken?: string | (() => string);
    basePath?: string;
    withCredentials?: boolean;
    /**
     * Takes care of encoding query- and form-parameters.
     */
    encoder?: HttpParameterCodec;
    /**
     * Encoding of various path parameter
     * <a href="https://github.com/OAI/OpenAPI-Specification/blob/main/versions/3.1.0.md#style-values">styles</a>.
     * <p>
     * See {@link README.md} for more details
     * </p>
     */
    encodeParam: (param: Param) => string;
    /**
     * The keys are the names in the securitySchemes section of the OpenAPI
     * document. They should map to the value used for authentication
     * minus any standard prefixes such as 'Basic' or 'Bearer'.
     */
    credentials: {
        [key: string]: string | (() => string | undefined);
    };
    constructor({ accessToken, apiKeys, basePath, credentials, encodeParam, encoder, password, username, withCredentials }?: ConfigurationParameters);
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes: string[]): string | undefined;
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts: string[]): string | undefined;
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime: string): boolean;
    lookupCredential(key: string): string | undefined;
    addCredentialToHeaders(credentialKey: string, headerName: string, headers: HttpHeaders, prefix?: string): HttpHeaders;
    addCredentialToQuery(credentialKey: string, paramName: string, query: OpenApiHttpParams): OpenApiHttpParams;
    private defaultEncodeParam;
}

/**
 * POS Human Resources Service API
 *
 * Contact: louis.burroughs@gmail.com
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */

declare class BaseService {
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    encoder: HttpParameterCodec;
    constructor(basePath?: string | string[], configuration?: Configuration);
    protected canConsumeForm(consumes: string[]): boolean;
    protected addToHttpParams(httpParams: OpenApiHttpParams, key: string, value: any | null | undefined, paramStyle: QueryParamStyle, explode: boolean): OpenApiHttpParams;
}

/**
 * Custom HttpParameterCodec
 * Workaround for https://github.com/angular/angular/issues/18261
 */
declare class CustomHttpParameterCodec implements HttpParameterCodec {
    encodeKey(k: string): string;
    encodeValue(v: string): string;
    decodeKey(k: string): string;
    decodeValue(v: string): string;
}
declare class IdentityHttpParameterCodec implements HttpParameterCodec {
    encodeKey(k: string): string;
    encodeValue(v: string): string;
    decodeKey(k: string): string;
    decodeValue(v: string): string;
}

declare const BASE_PATH: InjectionToken<string>;
declare const COLLECTION_FORMATS: {
    csv: string;
    tsv: string;
    ssv: string;
    pipes: string;
};

declare function provideApi(configOrBasePath: string | ConfigurationParameters): EnvironmentProviders;

export { BASE_PATH, BaseService, COLLECTION_FORMATS, Configuration, CustomHttpParameterCodec, IdentityHttpParameterCodec, OpenApiHttpParams, QueryParamStyle, concatHttpParamsObject, provideApi };
export type { ConfigurationParameters, DataFormat, DataType, Delimiter, Param, ParamLocation, ParamOptions, ParamStyle, StandardDataFormat, StandardDataType, StandardParamStyle };
