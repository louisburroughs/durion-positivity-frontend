export * from '../../models/postingCategoryResponse';
