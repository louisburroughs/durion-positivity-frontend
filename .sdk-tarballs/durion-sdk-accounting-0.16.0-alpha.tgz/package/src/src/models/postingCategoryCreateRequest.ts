export * from '../../models/postingCategoryCreateRequest';
