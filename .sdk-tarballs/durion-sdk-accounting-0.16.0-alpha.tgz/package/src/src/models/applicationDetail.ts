export * from '../../models/applicationDetail';
