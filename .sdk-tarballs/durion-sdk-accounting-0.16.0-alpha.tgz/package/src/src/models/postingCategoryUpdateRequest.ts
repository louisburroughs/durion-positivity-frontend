export * from '../../models/postingCategoryUpdateRequest';
