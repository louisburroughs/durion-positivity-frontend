export * from '../../models/matchedRule';
