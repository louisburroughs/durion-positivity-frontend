export * from '../../models/postingCategoryListResponse';
