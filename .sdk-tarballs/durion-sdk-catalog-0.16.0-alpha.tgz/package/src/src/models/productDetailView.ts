export * from '../../models/productDetailView';
