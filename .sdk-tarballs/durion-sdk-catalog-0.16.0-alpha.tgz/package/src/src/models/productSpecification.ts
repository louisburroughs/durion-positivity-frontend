export * from '../../models/productSpecification';
