export * from '../../models/vehicleBulkIngestRecord';
