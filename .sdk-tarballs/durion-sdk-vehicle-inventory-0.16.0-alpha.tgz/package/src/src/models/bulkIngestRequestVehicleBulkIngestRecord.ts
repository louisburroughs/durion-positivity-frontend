export * from '../../models/bulkIngestRequestVehicleBulkIngestRecord';
