export * from '../../models/vehicleSummary';
