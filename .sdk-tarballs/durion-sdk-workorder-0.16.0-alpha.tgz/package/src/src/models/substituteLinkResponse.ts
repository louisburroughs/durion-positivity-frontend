export * from '../../models/substituteLinkResponse';
